"""
Piezo_properity.png (.pdf):
Comparison of Classic PZT Grades (PZT-5H, PZT-5A, PZT-4, PZT-8)
and Eco-Friendly Lead-Free Piezoelectric Families (KNN, BT/BCZT, BNT-BT, AlN/ScAlN).

Includes: d33/d31, Strain (變形量), Qm, Low Loss (抗發熱), Temp Stability (Tc),
High-Field Resistance, and PZT Similarity Mapping.
Clean executive/client-facing language with zero meta-commentary.
"""

from pathlib import Path
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import matplotlib.patches as patches


plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Microsoft JhengHei", "Noto Sans HK", "Microsoft YaHei", "DejaVu Sans"],
    "axes.unicode_minus": False,
    "figure.facecolor": "#FFFFFF",
    "axes.facecolor": "#FFFFFF",
    "savefig.facecolor": "#FFFFFF",
    "text.color": "#1A1F2C",
})

C_INK = "#1A1F2C"
C_MUTED = "#4A5568"
C_GRID = "#CBD5E0"
C_ZEBRA = "#F7F9FB"
C_HEADER = "#EDF2F7"
C_SUBHDR = "#EBF3F9"
C_ECO_HDR = "#EDF7F2"

C_SOFT = "#1B4F72"
C_HARD = "#B0413E"
C_ECO = "#1E6B52"


def draw_dots(ax, xc, yc, level, color):
    spacing = 0.0135
    rx = 0.0049
    ry = 0.0090
    for k in range(3):
        cx = xc + (k - 1) * spacing
        filled = k < level
        ax.add_patch(patches.Ellipse(
            (cx, yc), width=2 * rx, height=2 * ry,
            facecolor=color if filled else "#FFFFFF",
            edgecolor=color if filled else "#A0AEC0",
            linewidth=1.1, zorder=4
        ))


def draw_panel_a_material_matrix(ax):
    ax.axis("off")
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)

    ax.text(0.0, 0.992, "(a) 常見 PZT 與環保無鉛壓電材料特性對照",
            fontsize=14.2, fontweight="bold", color=C_INK, va="top", ha="left")

    ly = 0.974
    ax.text(0.555, ly, "相對表現：", fontsize=10.5, fontweight="bold", color=C_MUTED, va="center", ha="left")
    for lx, lvl, txt in [(0.655, 3, "強/優"), (0.768, 2, "中/均"), (0.880, 1, "弱/限")]:
        draw_dots(ax, lx, ly, lvl, C_INK)
        ax.text(lx + 0.025, ly, txt, fontsize=10.5, color=C_MUTED, va="center", ha="left")

    # 8 columns: Material | d33/d31 | 變形量 | Qm | 低tanδ | 高Tc | 耐高場 | PZT相近性與適用方向
    col_x = [0.00, 0.195, 0.273, 0.351, 0.429, 0.507, 0.585, 0.665]
    headers = [
        ("壓電材料系列 / 等級", C_INK, "left"),
        ("壓電係數\n(d33/d31)", C_INK, "center"),
        ("變形量\n(應變)", C_INK, "center"),
        ("機械品質\n(Qm)", C_INK, "center"),
        ("抗發熱性\n(低tanδ)", C_INK, "center"),
        ("溫度穩定\n(高Tc)", C_INK, "center"),
        ("抗高場/\n去極化", C_INK, "center"),
        ("PZT 相近性對照 ＆ 適用致動方向", C_INK, "left"),
    ]

    # (kind, name, d33, strain, Qm, loss, Tc, field, note, color)
    items = [
        ("banner", "【傳統含鉛 PZT 系列】", None, None, None, None, None, None, None, C_SUBHDR),
        ("row", "PZT-5H（極軟 Soft）\n高靈敏大位移代表", 3, 3, 1, 1, 1, 1,
         "d33 與靜態變形量最大，但發熱高、Tc 偏低。\n→ 直接增益、低頻黏滑、尺蠖式。", C_SOFT),
        ("row", "PZT-5A（標準 Soft）\n溫穩均衡軟壓電", 3, 3, 1, 2, 2, 2,
         "變形量略低於 5H，但溫穩與抗漂移明顯更佳。\n→ 需溫穩之直接增益、低頻 SIDM。", C_SOFT),
        ("row", "PZT-4（標準 Hard）\n高頻共振主力", 2, 2, 3, 3, 3, 3,
         "高 Qm、低發熱、耐應力，共振下位移放大佳。\n→ 超聲波馬達 (USM)、超聲頻 SIDM。", C_HARD),
        ("row", "PZT-8（極硬 Hard）\n極致低損高功率", 1, 1, 3, 3, 3, 3,
         "Qm 最高、發熱最低，靜態變形小但極耐預緊。\n→ 高負載超聲波馬達防溫漂首選。", C_HARD),

        ("banner", "【環保無鉛替代系列】", None, None, None, None, None, None, None, C_ECO_HDR),
        ("row", "KNN 系（鈮酸鉀鈉）\n通用無鉛替代主力", 2, 2, 2, 2, 3, 2,
         "【近 PZT-5A ~ PZT-4】綜合與溫穩最均衡；\n全面替代潛力高，燒結與防潮要求較高。", C_ECO),
        ("row", "BT / BCZT（鈦酸鋇）\n室溫高靈敏無鉛", 3, 3, 1, 2, 1, 1,
         "【室溫近 PZT-5H】室溫 d33 與變形量亮眼；\n但居禮溫度低、溫域窄，高溫易去極化。", C_ECO),
        ("row", "BNT-BT（鈦酸鉍鈉）\n硬特性／大應變", 2, 3, 3, 2, 2, 3,
         "【共振近 PZT-4 / 8】Qm 佳且高場變形量大，\n具潛力用於 USM，但須控管遲滯現象。", C_ECO),
        ("row", "AlN / ScAlN 薄膜\nMEMS 半導體無鉛", 1, 1, 3, 3, 3, 3,
         "【MEMS 專用】無遲滯、低損、相容 CMOS；\n但原生變形量遠小於塊材壓電陶瓷。", C_ECO),
    ]

    y_top = 0.925
    hdr_h = 0.105
    banner_h = 0.054
    n_data = sum(1 for it in items if it[0] == "row")
    n_ban = sum(1 for it in items if it[0] == "banner")
    row_h = (y_top - hdr_h - n_ban * banner_h - 0.010) / n_data

    ax.add_patch(patches.Rectangle((0.0, y_top - hdr_h), 1.0, hdr_h, facecolor=C_HEADER, edgecolor="none", zorder=0))
    ax.plot([0.0, 1.0], [y_top, y_top], color=C_INK, linewidth=2.0, zorder=3)
    ax.plot([0.0, 1.0], [y_top - hdr_h, y_top - hdr_h], color=C_INK, linewidth=1.1, zorder=3)

    for (title, col, align), x0 in zip(headers, col_x):
        tx = x0 + 0.008 if align == "left" else x0 + 0.037
        ax.text(tx, y_top - hdr_h / 2, title, fontsize=10.3, fontweight="bold",
                color=col, va="center", ha=align, linespacing=1.20)

    cur_y = y_top - hdr_h
    row_idx = 0
    for it in items:
        if it[0] == "banner":
            yb = cur_y - banner_h
            ax.add_patch(patches.Rectangle((0.0, yb), 1.0, banner_h, facecolor=it[9], edgecolor="none", zorder=1))
            ax.plot([0.0, 1.0], [cur_y, cur_y], color=C_GRID, linewidth=0.75, zorder=2)
            ax.plot([0.0, 1.0], [yb, yb], color=C_GRID, linewidth=0.75, zorder=2)
            ax.text(0.010, (cur_y + yb) / 2, it[1], fontsize=10.8, fontweight="bold",
                    color=C_INK, va="center", ha="left", zorder=3)
            cur_y = yb
        else:
            _, name, v1, v2, v3, v4, v5, v6, note, col = it
            yb = cur_y - row_h
            ym = (cur_y + yb) / 2
            if row_idx % 2 == 1:
                ax.add_patch(patches.Rectangle((0.0, yb), 1.0, row_h, facecolor=C_ZEBRA, edgecolor="none", zorder=0))
            ax.plot([0.0, 1.0], [yb, yb], color=C_GRID, linewidth=0.55, zorder=2)

            ax.text(col_x[0] + 0.008, ym, name, fontsize=10.1, fontweight="bold",
                    color=col, va="center", ha="left", linespacing=1.24)

            for k, val in enumerate([v1, v2, v3, v4, v5, v6], start=1):
                draw_dots(ax, col_x[k] + 0.037, ym, val, col)

            ax.text(col_x[7] + 0.008, ym, note, fontsize=9.9, color="#1F2937",
                    va="center", ha="left", linespacing=1.26)

            cur_y = yb
            row_idx += 1

    ax.plot([0.0, 1.0], [cur_y, cur_y], color=C_INK, linewidth=2.0, zorder=3)


def draw_panel_b_selection_guide(ax_left, ax_right):
    ax_left.axis("off")
    ax_left.set_xlim(0, 1)
    ax_left.set_ylim(0, 1)
    ax_left.text(0.0, 0.98, "(b) 選型原則：軟性 (Soft) vs. 硬性 (Hard)",
                 fontsize=13.5, fontweight="bold", color=C_INK, va="top", ha="left")

    box1 = patches.FancyBboxPatch((0.0, 0.01), 0.985, 0.85, boxstyle="round,pad=0.015,rounding_size=0.02",
                                  facecolor="#F8FAFC", edgecolor=C_GRID, linewidth=1.0)
    ax_left.add_patch(box1)

    rules = [
        ("• 軟性（PZT-5H / 5A ｜ 無鉛：BT / BCZT）",
         "強項：高 d33/d31 與大靜態變形量，低壓大位移。\n限制：Qm 低、tanδ 高，高頻共振易發熱。\n→ 適用非共振：直接增益、低頻黏滑、尺蠖。", C_SOFT),
        ("• 硬性（PZT-4 / 8 ｜ 無鉛：BNT-BT / 硬KNN）",
         "強項：高 Qm、低發熱、耐高壓與高預緊應力。\n限制：原生靜態變形量較低，仰賴共振放大。\n→ 適用共振：超聲波馬達、超聲頻 SIDM。", C_HARD),
    ]
    for i, (h, b, col) in enumerate(rules):
        y = 0.80 - i * 0.41
        ax_left.text(0.03, y, h, fontsize=11.0, fontweight="bold", color=col, va="top", ha="left")
        ax_left.text(0.05, y - 0.095, b, fontsize=10.3, color="#2D3748", va="top", ha="left", linespacing=1.32)

    ax_right.axis("off")
    ax_right.set_xlim(0, 1)
    ax_right.set_ylim(0, 1)
    ax_right.text(0.0, 0.98, "(c) 導入環保無鉛壓電之評估重點",
                  fontsize=13.5, fontweight="bold", color=C_INK, va="top", ha="left")

    box2 = patches.FancyBboxPatch((0.0, 0.01), 0.99, 0.85, boxstyle="round,pad=0.015,rounding_size=0.02",
                                  facecolor="#F8FAFC", edgecolor=C_GRID, linewidth=1.0)
    ax_right.add_patch(box2)

    eco_notes = [
        ("1. 法規與供應鏈現況",
         "RoHS 對壓電含鉛仍有豁免，PZT 成熟度最高；\n但穿戴貼近臉部，長期具備無鉛環保趨勢。"),
        ("2. PZT 與無鉛系列快速對照",
         "• 大變形量 (近 5H)：BT / BCZT (防高溫去極化)\n• 均衡萬用 (近 5A/4)：改質 KNN (替代主力)\n• 低熱共振 (近 4/8)：BNT-BT 或硬改質 KNN"),
        ("3. 開發導入策略",
         "POC 先用成熟 PZT 驗證，量產規劃再評估無鉛。"),
    ]
    ys = [0.80, 0.52, 0.17]
    for (h, b), y in zip(eco_notes, ys):
        ax_right.text(0.03, y, h, fontsize=10.8, fontweight="bold", color=C_ECO, va="top", ha="left")
        ax_right.text(0.05, y - 0.082, b, fontsize=10.1, color="#2D3748", va="top", ha="left", linespacing=1.30)


def main():
    fig = plt.figure(figsize=(13.6, 12.2), dpi=300)

    fig.suptitle(
        "壓電材料選型指南：常見 PZT 與環保無鉛系列特性對照",
        fontsize=19.2, fontweight="bold", color=C_INK, y=0.974
    )
    fig.text(
        0.5, 0.942,
        "Soft/Hard PZT (PZT-5H/5A/4/8) vs. Eco-Friendly Lead-Free Counterparts",
        fontsize=11.5, color=C_MUTED, ha="center"
    )

    outer = gridspec.GridSpec(
        2, 1, figure=fig,
        height_ratios=[1.88, 0.92],
        hspace=0.11,
        left=0.028, right=0.972, top=0.908, bottom=0.018
    )

    draw_panel_a_material_matrix(fig.add_subplot(outer[0]))

    bot_row = gridspec.GridSpecFromSubplotSpec(1, 2, subplot_spec=outer[1], width_ratios=[1.0, 1.0], wspace=0.05)
    draw_panel_b_selection_guide(fig.add_subplot(bot_row[0]), fig.add_subplot(bot_row[1]))

    out_dir = Path(__file__).resolve().parent
    png_path = out_dir / "Piezo_properity.png"
    pdf_path = out_dir / "Piezo_properity.pdf"

    fig.savefig(png_path, dpi=300, facecolor="#FFFFFF")
    try:
        fig.savefig(pdf_path, facecolor="#FFFFFF")
        pdf_out = pdf_path
    except PermissionError:
        alt_pdf = out_dir / "Piezo_properity_updated.pdf"
        fig.savefig(alt_pdf, facecolor="#FFFFFF")
        pdf_out = alt_pdf
    plt.close(fig)
    print(f"Saved:\n  PNG: {png_path}\n  PDF: {pdf_out}")


if __name__ == "__main__":
    main()
