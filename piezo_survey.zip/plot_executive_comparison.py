"""
Figure 1 (True Large-Font Executive Edition, No Bottom Footnote):
  - Visual font size increased ~50% (compact 13.4-inch width + 10.2–11.5 pt body fonts).
  - Bottom footnote completely removed.
  - Pure white academic Booktabs palette.
"""

from pathlib import Path
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import matplotlib.patches as patches


plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Microsoft JhengHei", "Noto Sans HK", "Microsoft YaHei", "DejaVu Sans"],
    "axes.unicode_minus": False,
    "figure.facecolor": "#FFFFFF",
    "axes.facecolor": "#FFFFFF",
    "savefig.facecolor": "#FFFFFF",
    "text.color": "#1A1F2C",
})

C_INK = "#1A1F2C"
C_MUTED = "#4A5568"
C_GRID = "#CBD5E0"
C_ZEBRA = "#F7F9FB"
C_HEADER = "#EDF2F7"
C_BOX_BG = "#F8FAFC"

C_DIRECT = "#1B4F72"
C_SIDM = "#B0413E"
C_USM = "#1E6B52"
C_INCH = "#6B4E71"


def draw_rating_dots(ax, x_center, y_center, level, color):
    spacing = 0.0150
    rx = 0.0054
    ry = 0.0138
    for k in range(3):
        cx = x_center + (k - 1) * spacing
        filled = k < level
        ax.add_patch(patches.Ellipse(
            (cx, y_center), width=2 * rx, height=2 * ry,
            facecolor=color if filled else "#FFFFFF",
            edgecolor=color if filled else "#A0AEC0",
            linewidth=1.2, zorder=4
        ))


def draw_panel_a_qualitative_matrix(ax):
    ax.axis("off")
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)

    ax.text(0.0, 0.992, "(a) 四大壓電致動路線定性評比（含 PZT 等級）",
            fontsize=14.2, fontweight="bold", color=C_INK, va="top", ha="left")

    leg_y = 0.972
    ax.text(0.555, leg_y, "圖例：", fontsize=10.5, fontweight="bold", color=C_MUTED, va="center", ha="left")
    for lx, lvl, txt in [(0.625, 3, "優勢"), (0.745, 2, "條件滿足"), (0.885, 1, "受限")]:
        draw_rating_dots(ax, lx, leg_y, lvl, C_INK)
        ax.text(lx + 0.028, leg_y, txt, fontsize=10.5, color=C_MUTED, va="center", ha="left")

    col_x = [0.00, 0.132, 0.349, 0.566, 0.783]
    headers = [
        ("評估維度", C_INK),
        ("直接增益\n雙晶片/柔性放大\n[PZT-5H / 5A]", C_DIRECT),
        ("TULA / SIDM\n慣性黏滑驅動\n[PZT-5 / 超聲PZT-4]", C_SIDM),
        ("超聲波馬達 USM\n微型直線/複合\n[PZT-4 / PZT-8]", C_USM),
        ("尺蠖式 Inchworm\n夾持＋伸縮步進\n[PZT-5H / 5A]", C_INCH),
    ]

    rows = [
        ("行程延展性",
         (1, "短行程受限"), (3, "長行程不限"), (3, "無限長行程"), (3, "步進長行程")),
        ("動態響應力",
         (3, "極快可消振"), (2, "步進速度中"), (3, "啟停快線速高"), (1, "多步協同慢")),
        ("定位穩定性",
         (2, "遲滯需閉環"), (2, "回退需閉環"), (3, "無背隙穩定"), (3, "高精度解析")),
        ("貼耳靜音性",
         (3, "無摩擦極靜"), (1, "須推超聲頻"), (3, "天生超聲靜音"), (2, "切換易有聲")),
        ("斷電自鎖性",
         (1, "無自鎖須保壓"), (3, "自鎖零功耗"), (3, "自鎖零功耗"), (3, "常閉可自鎖")),
        ("微型化整合",
         (1, "佔側向空間"), (3, "細長易藏框"), (3, "超薄高密度"), (1, "堆疊體積大")),
        ("推力與剛性",
         (2, "放大損剛性"), (2, "受限靜摩擦"), (3, "高推力剛性"), (3, "推力極大")),
        ("耐磨與壽命",
         (3, "無磨損長壽"), (2, "需控磨耗"), (2, "間歇可控"), (2, "夾持易疲勞")),
        ("電路與成本",
         (2, "升壓＋補償"), (3, "單訊號最簡"), (1, "需追頻預緊"), (1, "多路極複雜")),
    ]

    y_top = 0.912
    header_h = 0.160
    n_rows = len(rows)
    row_h = (y_top - header_h - 0.010) / n_rows

    ax.add_patch(patches.Rectangle((0.0, y_top - header_h), 1.0, header_h, facecolor=C_HEADER, edgecolor="none", zorder=0))
    ax.plot([0.0, 1.0], [y_top, y_top], color=C_INK, linewidth=2.0, zorder=3)
    ax.plot([0.0, 1.0], [y_top - header_h, y_top - header_h], color=C_INK, linewidth=1.1, zorder=3)

    for (title, col), x0 in zip(headers, col_x):
        ax.text(x0 + 0.008, y_top - header_h / 2, title,
                fontsize=11.0, fontweight="bold", color=col, va="center", ha="left", linespacing=1.22)

    colors = [C_DIRECT, C_SIDM, C_USM, C_INCH]
    for i, (dim, r0, r1, r2, r3) in enumerate(rows):
        y_rt = y_top - header_h - i * row_h
        y_rb = y_rt - row_h
        y_m = (y_rt + y_rb) / 2

        if i % 2 == 1:
            ax.add_patch(patches.Rectangle((0.0, y_rb), 1.0, row_h, facecolor=C_ZEBRA, edgecolor="none", zorder=0))
        if i < n_rows - 1:
            ax.plot([0.0, 1.0], [y_rb, y_rb], color=C_GRID, linewidth=0.6, zorder=2)

        ax.text(col_x[0] + 0.008, y_m, dim, fontsize=11.0, fontweight="bold", color=C_INK, va="center", ha="left")

        for j, (lvl, tag) in enumerate([r0, r1, r2, r3]):
            x0 = col_x[j + 1]
            draw_rating_dots(ax, x0 + 0.028, y_m, lvl, colors[j])
            ax.text(x0 + 0.058, y_m, tag, fontsize=10.6, color="#1F2937", va="center", ha="left")

    y_bot = y_top - header_h - n_rows * row_h
    ax.plot([0.0, 1.0], [y_bot, y_bot], color=C_INK, linewidth=2.0, zorder=3)


def draw_panel_b_needs_and_fit(ax_left, ax_right):
    ax_left.axis("off")
    ax_left.set_xlim(0, 1)
    ax_left.set_ylim(0, 1)

    ax_left.text(0.0, 0.985, "(b) 自動對焦眼鏡五大核心訴求",
                 fontsize=13.5, fontweight="bold", color=C_INK, va="top", ha="left")

    box = patches.FancyBboxPatch(
        (0.0, 0.01), 0.99, 0.85, boxstyle="round,pad=0.015,rounding_size=0.02",
        facecolor=C_BOX_BG, edgecolor=C_GRID, linewidth=1.0, zorder=0
    )
    ax_left.add_patch(box)

    needs = [
        ("1. 配戴舒適與外觀", "輕量化與纖薄鏡框是商業化最大門檻。"),
        ("2. 自然無感畫質", "全口徑高透光、無偏振損耗、無抖動。"),
        ("3. 僅變焦時耗電", "斷電自鎖把電力留給眼動感測與續航。"),
        ("4. 貼耳靜音低溫", "避開可聽頻段並控管鏡腳表面溫升。"),
        ("5. 長期可靠抗摔", "耐頻繁切換、行走震動與意外跌落。"),
    ]
    for i, (head, desc) in enumerate(needs):
        y = 0.80 - i * 0.168
        ax_left.text(0.03, y, head, fontsize=11.0, fontweight="bold", color=C_INK, va="top", ha="left")
        ax_left.text(0.05, y - 0.072, desc, fontsize=10.2, color=C_MUTED, va="top", ha="left")

    ax_right.axis("off")
    ax_right.set_xlim(0, 1)
    ax_right.set_ylim(0, 1)

    ax_right.text(0.0, 0.985, "(c) 變焦鏡片 × 四大壓電路線適配",
                  fontsize=13.5, fontweight="bold", color=C_INK, va="top", ha="left")

    cols = [
        ("鏡片變焦方式", 0.00, C_INK),
        ("直接增益", 0.34, C_DIRECT),
        ("TULA", 0.51, C_SIDM),
        ("超聲波USM", 0.67, C_USM),
        ("尺蠖式", 0.85, C_INCH),
    ]
    fit_rows = [
        ("左右錯動雙片\n(Alvarez)", "物理受限\n(行程短)", "高度適配\n(超聲頻)", "首選推薦\n(靜音自鎖)", "不適用\n(體積大)"),
        ("擠壓液體變弧\n(液態膜片)", "高度適配\n(無磨損)", "條件可行\n(空間限)", "進階優選\n(高推力)", "不適用\n(過複雜)"),
        ("前後拉開距離\n(軸向雙鏡)", "物理受限\n(行程短)", "條件可行\n(鏡框厚)", "條件可行\n(鏡框厚)", "不適用\n(過厚重)"),
    ]

    y_top = 0.86
    hdr_h = 0.16
    rh = (y_top - hdr_h - 0.01) / len(fit_rows)

    ax_right.add_patch(patches.Rectangle((0.0, y_top - hdr_h), 1.0, hdr_h, facecolor=C_HEADER, edgecolor="none", zorder=0))
    ax_right.plot([0.0, 1.0], [y_top, y_top], color=C_INK, linewidth=1.9, zorder=3)
    ax_right.plot([0.0, 1.0], [y_top - hdr_h, y_top - hdr_h], color=C_INK, linewidth=1.0, zorder=3)

    for title, x0, col in cols:
        ax_right.text(x0 + 0.008, y_top - hdr_h / 2, title,
                      fontsize=10.6, fontweight="bold", color=col, va="center", ha="left")

    def tag_color(txt):
        if any(k in txt for k in ["首選", "高度適配", "進階優選"]):
            return C_USM
        if any(k in txt for k in ["受限", "不適用"]):
            return C_SIDM
        return C_MUTED

    for i, r in enumerate(fit_rows):
        yt = y_top - hdr_h - i * rh
        yb = yt - rh
        ym = (yt + yb) / 2
        if i % 2 == 1:
            ax_right.add_patch(patches.Rectangle((0.0, yb), 1.0, rh, facecolor=C_ZEBRA, edgecolor="none", zorder=0))
        if i < len(fit_rows) - 1:
            ax_right.plot([0.0, 1.0], [yb, yb], color=C_GRID, linewidth=0.55, zorder=2)

        ax_right.text(cols[0][1] + 0.008, ym, r[0], fontsize=10.5, fontweight="bold",
                      color=C_INK, va="center", ha="left", linespacing=1.22)
        for j in range(1, 5):
            tc = tag_color(r[j])
            fw = "bold" if tc == C_USM else "normal"
            ax_right.text(cols[j][1] + 0.008, ym, r[j], fontsize=10.0, fontweight=fw,
                          color=tc, va="center", ha="left", linespacing=1.20)

    yb_end = y_top - hdr_h - len(fit_rows) * rh
    ax_right.plot([0.0, 1.0], [yb_end, yb_end], color=C_INK, linewidth=1.9, zorder=3)


def draw_panel_d_executive_summary(ax):
    ax.axis("off")
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)

    ax.text(0.0, 0.992, "(d) 技術路線決策總表：PZT 選型、典型驅動電壓／頻率、風險與對策",
            fontsize=14.2, fontweight="bold", color=C_INK, va="top", ha="left")

    columns = [
        ("決策面向", 0.00, C_INK),
        ("直接增益\n雙晶片 / 柔性放大", 0.130, C_DIRECT),
        ("TULA / SIDM\n慣性黏滑驅動", 0.348, C_SIDM),
        ("超聲波馬達 (USM)\n微型直線 / 複合", 0.565, C_USM),
        ("尺蠖式 (Inchworm)\n夾持＋伸縮步進", 0.783, C_INCH),
    ]

    rows = [
        (
            "建議 PZT\n材料等級",
            "軟性 PZT-5H / 5A\n非共振大位移優先，\n首重高 d33 / d31。",
            "低頻：PZT-5H / 5A\n超聲頻：硬性 PZT-4\n(兼顧位移與低發熱)",
            "硬性 PZT-4 / PZT-8\n首重高 Qm 與低損耗\n以抑制共振發熱。",
            "軟性 PZT-5H / 5A\n非共振步進推頂，\n首重位移與夾持力。",
        ),
        (
            "典型驅動\n電壓 / 頻率",
            "約 60–250 V\n(多層低、雙晶片高)\nDC ～ 數十 Hz",
            "約 20–100 Vpp\n(多層堆疊可降壓)\n數百 Hz / >20 kHz",
            "塊材 80–400 Vpp；\n多層降至 5–30 Vpp\n20–200+ kHz (靜音)",
            "約 60–200 V\n(多路獨立時序供電)\n數 Hz ～ 數百 Hz",
        ),
        (
            "核心優勢",
            "• 無摩擦磨損壽命長\n• 準靜態本質極靜音\n• 響應快、無背隙",
            "• 結構最簡成本低\n• 長行程細長易藏框\n• 斷電自鎖零功耗",
            "• 天生超聲頻無聲\n• 長行程高推力自鎖\n• 具相機對焦實績",
            "• 長行程＋極高推力\n• 次微米～奈米精度\n• 常閉夾持可自鎖",
        ),
        (
            "物理瓶頸\n與風險",
            "• 微應變限制行程短\n• 放大機構佔空間\n• 無自鎖、具遲滯",
            "• 低頻具可聽噪音\n• 回退與累積誤差\n• 磨耗與防摔保持",
            "• 溫升致共振飄移\n• 追頻電路較複雜\n• 微型預緊與防摔",
            "• 多組堆疊體積大\n• 多路時序極複雜\n• 慢、眼鏡塞不下",
        ),
        (
            "工程對策",
            "• 前饋整形消振鈴\n• 自感測去編碼器\n• 電荷回收降溫",
            "• 推超聲頻消音\n• 複合波＋閉環\n• 耐磨塗層延壽",
            "• 間歇使用緩發熱\n• 多層陶瓷降電壓\n• 追頻IC＋緩衝",
            "• 屬工業精密平台\n  架構，不適用穿\n  戴式眼鏡開發",
        ),
        (
            "選型結論",
            "【適用】搭液態膜片\n透鏡具無磨損優勢。",
            "【適用】精簡推錯動\n鏡片，須驗超聲靜音。",
            "【首選】搭左右錯動\n鏡片最均衡可控。",
            "【排除】體積與複雜\n度不符眼鏡需求。",
        ),
    ]

    y_top = 0.932
    header_h = 0.105
    n_rows = len(rows)
    row_h = (y_top - header_h - 0.012) / n_rows

    ax.add_patch(patches.Rectangle((0.0, y_top - header_h), 1.0, header_h, facecolor=C_HEADER, edgecolor="none", zorder=0))
    ax.plot([0.0, 1.0], [y_top, y_top], color=C_INK, linewidth=2.0, zorder=3)
    ax.plot([0.0, 1.0], [y_top - header_h, y_top - header_h], color=C_INK, linewidth=1.1, zorder=3)

    for title, x0, col in columns:
        ax.text(x0 + 0.008, y_top - header_h / 2, title,
                fontsize=11.0, fontweight="bold", color=col, va="center", ha="left", linespacing=1.20)

    for i, rvals in enumerate(rows):
        yt = y_top - header_h - i * row_h
        yb = yt - row_h
        ym = (yt + yb) / 2
        if i % 2 == 1:
            ax.add_patch(patches.Rectangle((0.0, yb), 1.0, row_h, facecolor=C_ZEBRA, edgecolor="none", zorder=0))
        if i < n_rows - 1:
            ax.plot([0.0, 1.0], [yb, yb], color=C_GRID, linewidth=0.6, zorder=2)

        for j, ((_, x0, _), txt) in enumerate(zip(columns, rvals)):
            fw = "bold" if (j == 0 or i in (0, 1)) else "normal"
            col = C_INK if j == 0 else (columns[j][2] if i == 0 else "#1F2937")
            ax.text(x0 + 0.008, ym, txt, fontsize=10.3, fontweight=fw, color=col,
                    va="center", ha="left", linespacing=1.26, zorder=3)

    y_bot = y_top - header_h - n_rows * row_h
    ax.plot([0.0, 1.0], [y_bot, y_bot], color=C_INK, linewidth=2.0, zorder=3)


def main():
    # Compact 13.4-inch width makes 10.5-11pt fonts appear ~50% larger visually!
    fig = plt.figure(figsize=(13.4, 17.6), dpi=300)

    fig.suptitle(
        "機械式對焦眼鏡：四大壓電致動技術路線定性評估",
        fontsize=19.5, fontweight="bold", color=C_INK, y=0.980
    )
    fig.text(
        0.5, 0.955,
        "Direct Amplification vs. TULA (SIDM) vs. Ultrasonic Motor vs. Inchworm",
        fontsize=11.5, color=C_MUTED, ha="center"
    )

    outer = gridspec.GridSpec(
        3, 1, figure=fig,
        height_ratios=[1.18, 0.62, 1.48],
        hspace=0.11,
        left=0.030, right=0.970, top=0.930, bottom=0.015
    )

    draw_panel_a_qualitative_matrix(fig.add_subplot(outer[0]))

    mid_row = gridspec.GridSpecFromSubplotSpec(1, 2, subplot_spec=outer[1], width_ratios=[0.84, 1.16], wspace=0.05)
    draw_panel_b_needs_and_fit(fig.add_subplot(mid_row[0]), fig.add_subplot(mid_row[1]))

    draw_panel_d_executive_summary(fig.add_subplot(outer[2]))

    out_dir = Path(__file__).resolve().parent
    png_path = out_dir / "autofocal_actuator_executive.png"
    pdf_path = out_dir / "autofocal_actuator_executive.pdf"

    fig.savefig(png_path, dpi=300, facecolor="#FFFFFF")
    try:
        fig.savefig(pdf_path, facecolor="#FFFFFF")
        pdf_out = pdf_path
    except PermissionError:
        alt_pdf = out_dir / "autofocal_actuator_executive_updated.pdf"
        fig.savefig(alt_pdf, facecolor="#FFFFFF")
        pdf_out = alt_pdf
    plt.close(fig)
    print(f"Saved:\n  PNG: {png_path}\n  PDF: {pdf_out}")


if __name__ == "__main__":
    main()
