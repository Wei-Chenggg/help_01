"""
Publication-grade academic summary figure & booktabs comparison table
for Mechanical Focusing Eyeglasses: Direct Amplification vs. TULA(SIDM) vs. Ultrasonic Motor (USM).

Classic academic style: pure white background (#FFFFFF) + dark ink (#1A1F2C) + colorblind-safe muted palette.
Outputs:
  - autofocal_actuator_survey.png (300 DPI)
  - autofocal_actuator_survey.pdf (vector)
"""

from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import matplotlib.patches as patches
from matplotlib.lines import Line2D


# =============================================================================
# 1. Global Classic Academic Typography & Palette
# =============================================================================
plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Microsoft JhengHei", "Noto Sans HK", "Microsoft YaHei", "DejaVu Sans"],
    "axes.unicode_minus": False,
    "figure.facecolor": "#FFFFFF",
    "axes.facecolor": "#FFFFFF",
    "savefig.facecolor": "#FFFFFF",
    "text.color": "#1A1F2C",
    "axes.labelcolor": "#1A1F2C",
    "xtick.color": "#2D3748",
    "ytick.color": "#2D3748",
    "axes.edgecolor": "#2D3748",
    "axes.linewidth": 0.9,
})

# Classic Academic Muted Palette (High-contrast on white, print-friendly)
C_INK = "#1A1F2C"        # Deep charcoal ink
C_MUTED = "#4A5568"      # Secondary slate gray
C_GRID = "#CBD5E0"       # Subtle gridlines
C_ZEBRA = "#F7F9FB"      # Very light academic table row tint
C_HEADER = "#EDF2F7"     # Subtle header shading

C_DIRECT = "#1B4F72"     # Academic Navy — Direct Drive / Amplification
C_SIDM = "#B0413E"       # Muted Terracotta — TULA / SIDM (Stick-Slip)
C_USM = "#1E6B52"        # Deep Forest Teal — Ultrasonic Motor (USM)

C_WARN_BG = "#FDF2F2"    # Faint red tint for audible noise zone
C_WARN_FG = "#9B2C2C"
C_OK_BG = "#EDF7F2"      # Faint teal tint for eyewear target / silent zone
C_OK_FG = "#1E6B52"


def draw_panel_a_radar(ax):
    """Panel (a): 8-Axis Engineering Capability Radar Chart."""
    labels = [
        "行程能力\n(Stroke)",
        "對焦速度\n(Speed)",
        "定位精度\n(Precision)",
        "靜音表現\n(>20 kHz)",
        "斷電自鎖\n(0 W Hold)",
        "微型化/輕量\n(Compact)",
        "推力/剛性\n(Force)",
        "無磨損/壽命\n(Durability)",
    ]
    n = len(labels)
    angles = np.linspace(0, 2 * np.pi, n, endpoint=False)
    angles_closed = np.concatenate([angles, [angles[0]]])

    # Scores (1-10) synthesized from the 18 papers
    scores_direct = [3.5, 9.5, 8.5, 9.5, 4.5, 5.5, 5.5, 9.5]
    scores_sidm   = [9.0, 6.5, 8.0, 5.5, 9.5, 8.5, 6.5, 5.5]
    scores_usm    = [9.5, 9.0, 8.5, 9.5, 9.5, 9.0, 9.5, 6.5]

    ax.set_theta_offset(np.pi / 2)
    ax.set_theta_direction(-1)
    ax.set_ylim(0, 10.5)
    ax.set_yticks([2, 4, 6, 8, 10])
    ax.set_yticklabels(["2", "4", "6", "8", "10"], fontsize=8, color=C_MUTED)
    ax.set_rlabel_position(22.5)

    ax.set_xticks(angles)
    ax.set_xticklabels(labels, fontsize=9.2, fontweight="bold", color=C_INK)
    ax.tick_params(axis="x", pad=12)

    ax.xaxis.grid(True, color=C_GRID, linestyle="-", linewidth=0.7)
    ax.yaxis.grid(True, color=C_GRID, linestyle="--", linewidth=0.7)
    ax.spines["polar"].set_color("#A0AEC0")
    ax.spines["polar"].set_linewidth(0.9)

    series = [
        ("直接增益 (Direct / Amp.)", scores_direct, C_DIRECT, "-", "o"),
        ("TULA / SIDM (黏滑慣性)", scores_sidm, C_SIDM, "--", "s"),
        ("超聲波馬達 (USM)", scores_usm, C_USM, "-.", "^"),
    ]
    for name, vals, color, ls, mk in series:
        v_closed = np.concatenate([vals, [vals[0]]])
        ax.plot(angles_closed, v_closed, color=color, linestyle=ls, linewidth=2.0,
                marker=mk, markersize=5.2, label=name, zorder=4)
        ax.fill(angles_closed, v_closed, color=color, alpha=0.09, zorder=3)

    # Title for polar panel (a) is placed at figure-level to align cleanly with panel (b)


def draw_panel_b_scatter(ax):
    """Panel (b): Log-Log Empirical Performance Map (Stroke vs. Speed)."""
    # Eyewear target zone: Stroke 0.5 - 16 mm, Speed >= 10 mm/s
    target_rect = patches.Rectangle(
        (0.5, 10), 15.5, 590,
        facecolor=C_OK_BG, edgecolor=C_OK_FG, linestyle="--", linewidth=1.2, zorder=1
    )
    ax.add_patch(target_rect)
    ax.text(0.56, 540, "機械對焦眼鏡黃金區間\n(行程 0.5–10+ mm，速度 $\\geq$10 mm/s)",
            fontsize=8.3, fontweight="bold", color=C_OK_FG, va="top", ha="left", zorder=2)

    # Empirical benchmarks from the 18 papers:
    # (label, stroke_mm, speed_mm_s, color, marker, dx, dy, ha)
    points = [
        ("Tokin PSA 堆疊\n(Minase 2010, 17μm)", 0.017, 50, C_DIRECT, "o", 8, 8, "left"),
        ("Scott-Russell 放大\n(Zhou 2024, 134μm)", 0.134, 15, C_DIRECT, "o", -6, -24, "center"),
        ("固態 Alvarez 彎曲片\n(Zou 2015, ±225μm)", 0.45, 4.1, C_DIRECT, "o", -10, -2, "right"),
        ("液態眼鏡弧形雙晶片\n(Hasan 2017, 0.51mm)", 0.511, 34, C_DIRECT, "o", -10, 12, "right"),

        ("不對稱黏滑 SIDM\n(Gao 2019, 15mm/s)", 10.0, 15.04, C_SIDM, "s", -12, 8, "right"),
        ("對焦用 Stick-Slip\n(Naz 2024, 5mm)", 5.0, 10.0, C_SIDM, "s", -10, -20, "right"),

        ("微型相機 LUSM\n(X. Li 2015, 0.2g)", 10.0, 230, C_USM, "^", -12, 16, "right"),
        ("微型盤狀 HUSM\n(Naz 2024, 7.5N)", 7.5, 169.4, C_USM, "^", -14, -4, "right"),
        ("小型 LUSM\n(Tanoue 2020, 5g)", 12.0, 148, C_USM, "^", -14, -22, "right"),
        ("微環形 E01 USM\n(Naz 2024, 0.1μm)", 8.5, 56, C_USM, "^", -12, -2, "right"),
    ]

    for lbl, x, y, col, mk, dx, dy, ha in points:
        ax.scatter(x, y, s=62, color=col, marker=mk, edgecolors="#FFFFFF", linewidth=0.9, zorder=5)
        ax.annotate(
            lbl, xy=(x, y), xytext=(dx, dy), textcoords="offset points",
            fontsize=7.7, color=C_INK, ha=ha, va="center",
            arrowprops=dict(arrowstyle="-", color="#A0AEC0", lw=0.7, shrinkA=0, shrinkB=4),
            zorder=6
        )

    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlim(0.01, 22)
    ax.set_ylim(2, 650)
    ax.set_xticks([0.01, 0.1, 0.5, 1, 5, 10])
    ax.set_xticklabels(["0.01", "0.1", "0.5", "1", "5", "10+ (無限)"], fontsize=8.8)
    ax.set_yticks([2, 5, 10, 50, 100, 300, 600])
    ax.set_yticklabels(["2", "5", "10", "50", "100", "300", "600"], fontsize=8.8)

    ax.grid(True, which="major", color=C_GRID, linestyle="--", linewidth=0.6, alpha=0.8)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    ax.set_xlabel("有效線性行程 Stroke (mm，對數刻度)", fontsize=9.5, fontweight="bold")
    ax.set_ylabel("移動速度 Speed (mm/s，對數刻度)", fontsize=9.5, fontweight="bold")
    ax.set_title("(b) 論文實測性能分佈：行程 vs. 速度（雙對數座標）", fontsize=11.2,
                 fontweight="bold", pad=12, loc="left", color=C_INK)


def draw_panel_c_noise(ax):
    """Panel (c): Operating Frequency & Acoustic Noise Risk Spectrum."""
    ax.set_xscale("log")
    ax.set_xlim(10, 600_000)
    ax.set_ylim(-0.6, 4.9)

    # Shaded zones
    ax.axvspan(20, 20_000, color=C_WARN_BG, zorder=0)
    ax.axvspan(20_000, 600_000, color=C_OK_BG, zorder=0)
    ax.axvline(20_000, color=C_OK_FG, linestyle="--", linewidth=1.3, zorder=2)

    ax.text(650, 4.55, "人耳可聽噪音區 (20 Hz – 20 kHz) — 貼耳鏡腳高風險",
            fontsize=8.8, fontweight="bold", color=C_WARN_FG, ha="center", va="center")
    ax.text(110_000, 4.55, "超聲波靜音區 (> 20 kHz) — 穿戴完全無聲",
            fontsize=8.8, fontweight="bold", color=C_OK_FG, ha="center", va="center")

    bands = [
        ("微型相機 LUSM / 球面 USM (X. Li / Yan)", 85_000, 447_000, C_USM, "174–447 kHz 絕對靜音"),
        ("典型行波/駐波/複合 USM (Naz 2024)", 20_000, 96_000, C_USM, "20–96 kHz 天生靜音"),
        ("超聲頻共振型 TULA / SIDM", 22_000, 75_000, C_SIDM, "須推至 >20 kHz 避噪音"),
        ("低頻黏滑原型 (Gao 2019 @ 490 Hz)", 200, 1_200, C_SIDM, "490 Hz 明顯蜂鳴 (不可接受)"),
        ("直接增益壓電 (Hasan 70 Hz / 準靜態)", 12, 100, C_DIRECT, "無摩擦介面，極靜音"),
    ]

    for idx, (label, f1, f2, col, note) in enumerate(bands):
        ax.barh(idx, f2 - f1, left=f1, height=0.46, color=col, alpha=0.88,
                edgecolor=C_INK, linewidth=0.6, zorder=3)
        if f2 < 200_000:
            ax.text(f2 * 1.18, idx, note, fontsize=8.3, color=C_INK, va="center", ha="left", zorder=4)
        else:
            # Place cleanly inside the wide top bar in crisp white text
            ax.text(np.sqrt(f1 * f2), idx, note, fontsize=8.2, fontweight="bold",
                    color="#FFFFFF", va="center", ha="center", zorder=4)

    ax.set_yticks(range(len(bands)))
    ax.set_yticklabels([b[0] for b in bands], fontsize=8.8, fontweight="bold", color=C_INK)
    ax.set_xticks([10, 100, 1_000, 20_000, 100_000, 500_000])
    ax.set_xticklabels(["10 Hz", "100 Hz", "1 kHz", "20 kHz\n(人耳上限)", "100 kHz", "500 kHz"], fontsize=8.8)

    ax.grid(True, axis="x", color=C_GRID, linestyle=":", linewidth=0.7, zorder=1)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.set_title("(c) 工作頻率與貼耳噪音風險光譜（10 Hz – 500 kHz，對數刻度）", fontsize=11.2,
                 fontweight="bold", pad=10, loc="left", color=C_INK)


def draw_panel_d_booktabs_table(ax):
    """Panel (d): Publication-grade Booktabs Comparison Table."""
    ax.axis("off")
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)

    ax.text(0.0, 0.985, "(d) 自動對焦眼鏡硬規格門檻與三大壓電致動方向完整對照表（Booktabs 學術表格）",
            fontsize=11.5, fontweight="bold", color=C_INK, va="top", ha="left")

    columns = [
        ("評估指標", 0.00, 0.135, C_INK),
        ("眼鏡臨床 / 光學硬規格\n(Padmanaban / Charman / BCLA)", 0.135, 0.215, C_INK),
        ("直接增益 (Direct / Amp.)\nPZT 雙晶片 / 柔性鉸鏈放大", 0.350, 0.215, C_DIRECT),
        ("TULA / SIDM\n慣性黏滑驅動 (Stick-Slip)", 0.565, 0.215, C_SIDM),
        ("超聲波馬達 (USM)\n微型 LUSM / HUSM / 環形", 0.780, 0.220, C_USM),
    ]

    rows = [
        (
            "有效行程\n(Stroke)",
            "需支撐 3–4 D (理想 ±4 D)\nAlvarez: 1–5 mm 橫向\n液態膜片: 0.5–1.0 mm 軸向",
            "短行程 (0.2–0.51 mm)\n原生應變 0.1%，放大 9–15.5×\n【瓶頸】推不動大口徑 Alvarez",
            "理論無限制（受導軌長度限）\n輕鬆達 1–10+ mm 長行程\n適合大口徑滑動/軸向移位",
            "理論無限制（直線或 360° 旋轉）\n直線推 Alvarez、環形轉 Moiré\n【最佳】空間利用率最高",
        ),
        (
            "對焦速度\n(Speed)",
            "基本門檻 $\\leq$ 500 ms\n臨床實證 $\\leq$ 100 ms 已非瓶頸\n(總系統延遲 $\\leq$ 150 ms)",
            "極快：1–15 ms (Hasan 15 ms)\n搭雙步階 ZV 整形 (Imboden)\n可在 $T_0/2$ (~10 ms) 零振鈴",
            "中速：10–15 mm/s (Gao 15.04)\n3 mm 行程約需 ~200 ms\n符合 $\\leq$500 ms，略慢於 100 ms",
            "極快：148–230 mm/s (X. Li)\n啟動 4.6 ms / 停止 5.5 ms\n3 mm 行程僅需 15–30 ms",
        ),
        (
            "精度與誤差\n(Precision)",
            "步階 ±0.25 D (人眼焦深 0.5–0.75D)\n雙眼稜鏡容差 $\\leq$ 1–2 Δ\n【痛點】不可有焦距抖動 jitter",
            "次奈米解析；但開環遲滯 10–15%\n+ 靜態潛變 (Minase 2010)\n解方：HPO 自感測去編碼器",
            "解析度 65–86 nm (Gao / Naz)\n【痛點】具回退誤差 S_b 與累積誤\n解方：複合波抑回退 83–85% + 閉環",
            "開環精度可達 0.1 μm (E01)\n閉環可達奈米級、無背隙\n定位穩定、不易產生 jitter",
        ),
        (
            "推力與剛性\n(Force)",
            "液態活塞 ~0.75 N (高張力膜更大)\nAlvarez 需高 Y 軸剛性防 45° 散光\n需耐日常配戴震動與跌落",
            "中低：放大倍率折損剛性與推力\nHasan 雙晶片 k_b $\\approx$ 390 N/m (0.75N)\n柔性鉸鏈有應力集中脆斷風險",
            "中：Gao 原型載重 440 g (~4.3 N)\n保持力受限於靜摩擦力\n強撞擊/跌落有滑移失步風險",
            "高推力密度：0.2 g 達 0.3 N；\n0.6 mm 超薄雙晶片達 3.08 N\n可拉高膜張力抑制重力彗差",
        ),
        (
            "貼耳噪音\n(Noise)",
            "致動器緊貼太陽穴與雙耳\n必須避開 20 Hz–20 kHz 人耳敏感區\n(臨床論文缺 dB 規範，須自訂)",
            "極靜音\n準靜態操作、無摩擦接觸介面",
            "【高風險】低頻 490 Hz 噪音大\n務必改採 >20 kHz 超聲頻共振\nSIDM 才能達成靜音配戴",
            "天生 >20 kHz (20–447 kHz)\n人耳完全靜音、無齒輪噪音\n且完全無磁場與 EMI 干擾",
        ),
        (
            "自鎖與功耗\n(Power)",
            "零靜態維持功耗 (僅變焦耗電)\n優於持續供電 VCM (100–2000 mW)\n需留電力給眼動追蹤與 MCU",
            "無機械自鎖（須持續維持高壓）\n靜態漏電小；Hasan 總耗 10–20 mW\nKarpelson 電荷回收可省電 >50%",
            "天生摩擦自鎖（斷電 0 W 保持）\n運動時效率偏低 (1–3.7%, 0.78W)\n但間歇調焦平均功耗極低",
            "天生摩擦自鎖（斷電 0 W 保持）\n效率 ~15.9% (高於黏滑)\n間歇脈衝使用極利全天續航",
        ),
        (
            "電壓與電路\n(Driver)",
            "3.7 V 鋰電池供電、輕量化驅動板\n避免高壓安全疑慮與 EMI 干擾\n鄰近眼動追蹤攝影機",
            "高壓 90–250 V (Hasan ±250 V)\nKarpelson 證實 5→200 V 驅動板\n可微縮至 20–90 mg + 50 μW ASIC",
            "驅動最簡（單路鋸齒波即可）\n低成本；單層需 ~100 Vpp\n多層堆疊可降至數十伏特",
            "塊材需 80–500 Vpp；【突破】\n多層陶瓷/薄膜可壓至 5–30 Vpp\n需高頻諧振自動追頻電路",
        ),
        (
            "微型化實績\n(Size/Weight)",
            "商業化頭號障礙！目標 < 20–30 g\n有效口徑 $\\geq$30 mm (30–45 mm)\n日常眼鏡級纖薄外觀",
            "放大機構佔鏡框側向空間\nHasan 32 mm 口徑 → 52 mm 外徑\n單眼厚 8.4 mm、重 14.4 g",
            "結構極簡、細長條狀易藏鏡腳\n已應用於緊湊型變焦鏡頭\nBOM 成本最低",
            "極致微型化實績：5×2×2 mm / 0.2 g\n(X. Li)；0.6 mm 超薄雙晶片；\n中空環形定子可環繞鏡片周邊",
        ),
        (
            "發熱與壽命\n(Thermal/Wear)",
            "鏡腳接觸皮膚須控溫升 (IEC 標準)\n需數年日常循環耐用度\n避免溫漂導致焦距偏移",
            "完全無摩擦磨損、壽命最長\n高電場 tanδ 增 10× 須注意\n按需切換關斷可消除待機發熱",
            "有摩擦磨耗與粉塵風險\n須靠耐磨塗層與預緊控管壽命\n間歇使用發熱可控",
            "連續運轉易發熱致共振飄移\n但眼鏡屬間歇短脈衝大幅緩解\n須自動追頻 + 橡膠防摔緩衝",
        ),
        (
            "最適配透鏡\n(Best Pairing)",
            "全口徑偏振無關折射鏡片\n(60 歲視網膜照度已降 >60%，\n不可再有偏振或繞射損耗)",
            "★★ 大口徑液態膜片活塞透鏡\n(0.5 mm 行程，搭 ZV + HPO 自感測)\n× 不適大口徑 Alvarez / Moiré",
            "★ Alvarez / Lohmann 固態滑動\n(前提：>20 kHz 超聲頻 + 閉環)\n△ 液態膜片次選",
            "★★ Alvarez 固態滑動 (LUSM)\n★★ Moiré 旋轉鏡片 (中空環 USM)\n★ 高張力液態活塞 (抑重力彗差)",
        ),
    ]

    # Layout vertical coordinates
    y_top = 0.945
    header_h = 0.088
    n_rows = len(rows)
    row_h = (y_top - header_h - 0.04) / n_rows

    # Header background & booktabs top/mid rules
    ax.add_patch(patches.Rectangle((0.0, y_top - header_h), 1.0, header_h,
                                   facecolor=C_HEADER, edgecolor="none", zorder=0))
    ax.plot([0.0, 1.0], [y_top, y_top], color=C_INK, linewidth=1.8, zorder=3)
    ax.plot([0.0, 1.0], [y_top - header_h, y_top - header_h], color=C_INK, linewidth=1.1, zorder=3)

    for title, x0, w, col in columns:
        ax.text(x0 + 0.008, y_top - header_h / 2, title,
                fontsize=8.6, fontweight="bold", color=col, va="center", ha="left", linespacing=1.25)

    # Data rows
    for i, row_vals in enumerate(rows):
        y_row_top = y_top - header_h - i * row_h
        y_row_bot = y_row_top - row_h
        y_mid = (y_row_top + y_row_bot) / 2

        if i % 2 == 1:
            ax.add_patch(patches.Rectangle((0.0, y_row_bot), 1.0, row_h,
                                           facecolor=C_ZEBRA, edgecolor="none", zorder=0))
        if i < n_rows - 1:
            ax.plot([0.0, 1.0], [y_row_bot, y_row_bot], color=C_GRID, linewidth=0.5, zorder=2)

        for j, ((_, x0, w, col), val) in enumerate(zip(columns, row_vals)):
            fw = "bold" if j == 0 else "normal"
            txt_col = C_INK if j <= 1 else "#1F2937"
            if j == 0:
                txt_col = C_INK
            ax.text(x0 + 0.008, y_mid, val,
                    fontsize=7.65, fontweight=fw, color=txt_col,
                    va="center", ha="left", linespacing=1.28, zorder=3)

    # Booktabs bottom rule
    y_bot = y_top - header_h - n_rows * row_h
    ax.plot([0.0, 1.0], [y_bot, y_bot], color=C_INK, linewidth=1.8, zorder=3)

    # Academic footnote
    footnote = (
        "註：彙整自 ./translate 全部 18 篇文獻，核心引用含 Padmanaban et al. (Sci. Adv. 2019)、Hasan et al. (Opt. Express 2017)、"
        "Charman (OPO 2014)、Morgan et al. (BCLA CLEAR 2024)、Davies (OPO 2026)、Wang & Lin (LC Rev. 2021)、\n"
        "Zhou et al. (Front. Mech. Eng. 2024)、Ryndzionek & Sienkiewicz (Ultrasonics 2021)、Naz & Xu (Micromachines 2024)、"
        "Gao et al. (JIMSS 2019)、Karpelson et al. (Sens. Actuators A 2012)、Minase (2010)、Bafumba (2019)、Imboden (2016)。"
    )
    ax.text(0.0, y_bot - 0.012, footnote, fontsize=7.2, color=C_MUTED, va="top", ha="left", linespacing=1.35)


def main():
    fig = plt.figure(figsize=(14.5, 17.8), dpi=300)

    # Top Academic Title Block
    fig.suptitle(
        "機械式對焦眼鏡之壓電致動器選型綜述：直接增益 vs. TULA(SIDM) vs. 超聲波馬達",
        fontsize=15.0, fontweight="bold", color=C_INK, y=0.980
    )
    fig.text(
        0.5, 0.958,
        "Quantitative Synthesis of 18 Literature Papers: Clinical Eyewear Specifications, Empirical Actuator Performance, Acoustic Spectrum & Design Trade-offs",
        fontsize=9.3, color=C_MUTED, ha="center"
    )

    # Shared figure-level legend (clean IEEE / Nature style, zero collision with panels)
    legend_handles = [
        Line2D([0], [0], color=C_DIRECT, lw=2.2, ls="-", marker="o", ms=6, label="直接增益 (Direct / Flexure Amplification)"),
        Line2D([0], [0], color=C_SIDM, lw=2.2, ls="--", marker="s", ms=6, label="TULA / SIDM (慣性黏滑 Stick-Slip)"),
        Line2D([0], [0], color=C_USM, lw=2.2, ls="-.", marker="^", ms=6.5, label="超聲波馬達 (Ultrasonic Motor, USM)"),
    ]
    fig.legend(
        handles=legend_handles, loc="upper center", bbox_to_anchor=(0.5, 0.942),
        ncol=3, frameon=True, facecolor="#F7F9FB", edgecolor=C_GRID, fontsize=9.2,
        handlelength=2.8, columnspacing=2.2
    )

    outer = gridspec.GridSpec(
        3, 1, figure=fig,
        height_ratios=[1.10, 0.62, 1.80],
        hspace=0.25,
        left=0.055, right=0.965, top=0.888, bottom=0.025
    )

    # Row 0: Panel (a) Radar + Panel (b) Scatter
    top_row = gridspec.GridSpecFromSubplotSpec(1, 2, subplot_spec=outer[0], width_ratios=[0.95, 1.15], wspace=0.22)
    ax_a = fig.add_subplot(top_row[0], polar=True)
    ax_b = fig.add_subplot(top_row[1])

    # Slightly lower & compact polar plot so top axis label never crowds title (a)
    pos_a = ax_a.get_position()
    ax_a.set_position([pos_a.x0, pos_a.y0 - 0.006, pos_a.width, pos_a.height * 0.91])
    fig.text(0.055, 0.900, "(a) 眼鏡八大工程指標綜合雷達評估（1–10 分）",
             fontsize=11.2, fontweight="bold", color=C_INK, va="bottom", ha="left")

    # Row 1: Panel (c) Noise Spectrum (shifted right slightly for long y-labels)
    mid_row = gridspec.GridSpecFromSubplotSpec(1, 1, subplot_spec=outer[1])
    ax_c = fig.add_subplot(mid_row[0])
    pos_c = ax_c.get_position()
    ax_c.set_position([pos_c.x0 + 0.165, pos_c.y0, pos_c.width - 0.165, pos_c.height])

    # Row 2: Panel (d) Booktabs Table
    ax_d = fig.add_subplot(outer[2])

    draw_panel_a_radar(ax_a)
    draw_panel_b_scatter(ax_b)
    draw_panel_c_noise(ax_c)
    draw_panel_d_booktabs_table(ax_d)

    out_dir = Path(__file__).resolve().parent
    png_path = out_dir / "autofocal_actuator_survey.png"
    pdf_path = out_dir / "autofocal_actuator_survey.pdf"

    fig.savefig(png_path, dpi=300, facecolor="#FFFFFF")
    fig.savefig(pdf_path, facecolor="#FFFFFF")
    plt.close(fig)
    print(f"Saved:\n  PNG: {png_path}\n  PDF: {pdf_path}")


if __name__ == "__main__":
    main()
