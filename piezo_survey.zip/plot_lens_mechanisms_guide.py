"""
Figure 2 (True Large-Font Executive Edition, No Bottom Footnote):
  - Compact 13.4-inch width + 10.4–11.5 pt body fonts (+50% visual readability).
  - Bottom footnote completely removed.
  - Moiré completely removed.
  - Pure white academic Booktabs palette.
"""

from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import matplotlib.patches as patches


plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Microsoft JhengHei", "Noto Sans HK", "Microsoft YaHei", "DejaVu Sans"],
    "axes.unicode_minus": False,
    "figure.facecolor": "#FFFFFF",
    "axes.facecolor": "#FFFFFF",
    "savefig.facecolor": "#FFFFFF",
    "text.color": "#1A1F2C",
})

C_INK = "#1A1F2C"
C_MUTED = "#4A5568"
C_BORDER = "#CBD5E0"
C_ZEBRA = "#F7F9FB"
C_HEADER = "#EDF2F7"

C_GLASS_FILL = "#DCEAF7"
C_GLASS_EDGE = "#2B6CB0"
C_LIQ_FILL = "#E0F2FE"
C_LIQ_EDGE = "#0284C7"
C_RAY = "#C05621"
C_ARROW = "#B0413E"

C_ALV = "#1E6B52"
C_LIQ = "#1B4F72"
C_AXL = "#6B4E71"


def setup_compact_card(ax, title, metaphor, accent_col):
    ax.axis("off")
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 6.4)

    frame = patches.FancyBboxPatch(
        (0.08, 0.08), 9.84, 6.24,
        boxstyle="round,pad=0.04,rounding_size=0.16",
        facecolor="#FFFFFF", edgecolor=C_BORDER, linewidth=1.1, zorder=0
    )
    ax.add_patch(frame)

    hdr = patches.Rectangle((0.12, 5.12), 9.76, 1.16, facecolor="#F1F5F9", edgecolor="none", zorder=1)
    ax.add_patch(hdr)
    ax.plot([0.12, 9.88], [5.12, 5.12], color=C_BORDER, linewidth=0.9, zorder=2)

    ax.text(0.26, 5.90, title, fontsize=11.6, fontweight="bold", color=accent_col, va="center", ha="left", zorder=3)
    ax.text(0.26, 5.40, metaphor, fontsize=9.2, color=C_MUTED, va="center", ha="left", zorder=3)

    ax.plot([5.0, 5.0], [0.30, 4.92], color=C_BORDER, linestyle="--", linewidth=0.85, zorder=1)


def draw_ray(ax, pts, arrow_end=True):
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    ax.plot(xs, ys, color=C_RAY, linewidth=1.4, zorder=4)
    if arrow_end and len(pts) >= 2:
        ax.annotate(
            "", xy=pts[-1], xytext=pts[-2],
            arrowprops=dict(arrowstyle="-|>", color=C_RAY, lw=1.25, mutation_scale=10),
            zorder=5
        )


def draw_compact_alvarez(ax):
    setup_compact_card(
        ax,
        "(a) 左右錯動（Alvarez/Lohmann）",
        "比喻：互補波浪玻璃左右微移變焦",
        C_ALV
    )

    def draw_state(xc, shift, label, converged):
        ax.text(xc, 4.74, label, fontsize=10.0, fontweight="bold", color=C_INK, ha="center", va="center")
        xs = np.linspace(-1.40, 1.40, 100)
        wave = lambda u: 0.22 * (u / 1.35) ** 3 - 0.08 * (u / 1.35)

        x1 = xc + xs - shift
        poly1 = np.vstack([
            np.column_stack([x1, np.full_like(xs, 3.76)]),
            np.column_stack([x1[::-1], (3.26 + wave(xs))[::-1]])
        ])
        ax.add_patch(patches.Polygon(poly1, closed=True, facecolor=C_GLASS_FILL,
                                     edgecolor=C_GLASS_EDGE, linewidth=1.2, zorder=3))

        x2 = xc + xs + shift
        poly2 = np.vstack([
            np.column_stack([x2, 3.02 + wave(xs)]),
            np.column_stack([x2[::-1], np.full_like(xs, 2.52)])
        ])
        ax.add_patch(patches.Polygon(poly2, closed=True, facecolor="#C7DFF5",
                                     edgecolor=C_GLASS_EDGE, linewidth=1.2, zorder=3))

        if shift > 0:
            ax.annotate("", xy=(xc - 2.02, 3.50), xytext=(xc - 1.36, 3.50),
                        arrowprops=dict(arrowstyle="-|>", color=C_ARROW, lw=2.2, mutation_scale=12), zorder=6)
            ax.annotate("", xy=(xc + 2.02, 2.76), xytext=(xc + 1.36, 2.76),
                        arrowprops=dict(arrowstyle="-|>", color=C_ARROW, lw=2.2, mutation_scale=12), zorder=6)

        for dx in [-0.70, 0.0, 0.70]:
            x0 = xc + dx
            if not converged:
                draw_ray(ax, [(x0, 4.35), (x0, 3.76), (x0, 2.52), (x0, 1.15)])
            else:
                draw_ray(ax, [(x0, 4.35), (x0, 3.76), (x0, 2.52), (xc, 1.15)])

        if converged:
            ax.scatter([xc], [1.12], s=32, color=C_ARROW, zorder=6)
            ax.text(xc, 0.48, "錯動 → 聚焦看近", fontsize=9.4, fontweight="bold", color=C_ARROW, ha="center")
        else:
            ax.text(xc, 0.48, "對齊 → 平行看遠", fontsize=9.4, color=C_MUTED, ha="center")

    draw_state(2.50, 0.0, "【看遠】對齊", False)
    draw_state(7.50, 0.36, "【看近】左右錯動", True)


def draw_compact_liquid(ax):
    setup_compact_card(
        ax,
        "(b) 擠壓液體（液態膜片式）",
        "比喻：輕捏透明水氣球讓表面鼓起",
        C_LIQ
    )

    def draw_state(xc, bulged, label, cap):
        ax.text(xc, 4.74, label, fontsize=10.0, fontweight="bold", color=C_INK, ha="center", va="center")
        y_mid = 2.96
        h_half = 1.00
        x_piston = xc - 0.58 + (0.28 if bulged else 0.0)
        x_rim_l = xc - 0.68
        x_rim_r = xc + 0.42

        ax.add_patch(patches.Rectangle((x_rim_l, y_mid + h_half), x_rim_r - x_rim_l, 0.20,
                                       facecolor="#64748B", edgecolor=C_INK, linewidth=0.9, zorder=4))
        ax.add_patch(patches.Rectangle((x_rim_l, y_mid - h_half - 0.20), x_rim_r - x_rim_l, 0.20,
                                       facecolor="#64748B", edgecolor=C_INK, linewidth=0.9, zorder=4))

        ys = np.linspace(y_mid - h_half, y_mid + h_half, 80)
        bulge_amp = 0.56 if bulged else 0.0
        xs_front = x_rim_r + bulge_amp * (1 - ((ys - y_mid) / h_half) ** 2)

        poly = np.vstack([
            [[x_piston, y_mid - h_half]],
            np.column_stack([xs_front, ys]),
            [[x_piston, y_mid + h_half]],
        ])
        ax.add_patch(patches.Polygon(poly, closed=True, facecolor=C_LIQ_FILL, edgecolor="none", zorder=2))
        ax.plot(xs_front, ys, color=C_LIQ_EDGE, linewidth=2.3, zorder=4)
        ax.add_patch(patches.Rectangle((x_piston - 0.16, y_mid - h_half + 0.04), 0.16, 2 * h_half - 0.08,
                                       facecolor="#CBD5E1", edgecolor=C_INK, linewidth=1.0, zorder=4))

        if bulged:
            for dy in [-0.60, 0.60]:
                ax.annotate("", xy=(x_piston - 0.18, y_mid + dy), xytext=(x_piston - 0.82, y_mid + dy),
                            arrowprops=dict(arrowstyle="-|>", color=C_ARROW, lw=2.2, mutation_scale=11), zorder=6)
        else:
            ax.text((x_piston + x_rim_r) / 2, y_mid, "液體", fontsize=9.2, fontweight="bold",
                    color=C_LIQ_EDGE, ha="center", va="center")

        for dy in [-0.60, 0.0, 0.60]:
            y0 = y_mid + dy
            x_hit = x_rim_r + bulge_amp * (1 - (dy / h_half) ** 2)
            if not bulged:
                draw_ray(ax, [(xc - 1.95, y0), (x_hit, y0), (xc + 1.95, y0)])
            else:
                draw_ray(ax, [(xc - 1.95, y0), (x_hit, y0), (xc + 2.00, y_mid)])

        if bulged:
            ax.scatter([xc + 2.03], [y_mid], s=32, color=C_ARROW, zorder=6)

        ax.text(xc, 0.48, cap, fontsize=9.4, fontweight="bold" if bulged else "normal",
                color=C_ARROW if bulged else C_MUTED, ha="center")

    draw_state(2.50, False, "【看遠】薄膜平坦", "未擠壓 → 平行光")
    draw_state(7.45, True, "【看近】活塞前推", "鼓起 → 凸鏡聚焦")


def draw_compact_axial(ax):
    setup_compact_card(
        ax,
        "(c) 前後拉開（軸向雙鏡組）",
        "比喻：像伸縮相機鏡頭拉開間距",
        C_AXL
    )

    def draw_biconvex(xc, yc, h, w):
        ys = np.linspace(yc - h, yc + h, 60)
        dx = w * (1 - ((ys - yc) / h) ** 2)
        poly = np.vstack([np.column_stack([xc - dx, ys]), np.column_stack([xc + dx[::-1], ys[::-1]])])
        ax.add_patch(patches.Polygon(poly, closed=True, facecolor=C_GLASS_FILL,
                                     edgecolor=C_GLASS_EDGE, linewidth=1.2, zorder=3))

    def draw_biconcave(xc, yc, h, we, wm):
        ys = np.linspace(yc - h, yc + h, 60)
        dx = wm + (we - wm) * ((ys - yc) / h) ** 2
        poly = np.vstack([np.column_stack([xc - dx, ys]), np.column_stack([xc + dx[::-1], ys[::-1]])])
        ax.add_patch(patches.Polygon(poly, closed=True, facecolor="#C7DFF5",
                                     edgecolor=C_GLASS_EDGE, linewidth=1.2, zorder=3))

    def draw_state(xc, gap, label, cap, converged):
        ax.text(xc, 4.74, label, fontsize=10.0, fontweight="bold", color=C_INK, ha="center", va="center")
        y_mid = 2.96
        h = 1.00
        x1 = xc - gap / 2 - 0.18
        x2 = xc + gap / 2 + 0.18
        draw_biconvex(x1, y_mid, h, 0.20)
        draw_biconcave(x2, y_mid, h, 0.20, 0.07)

        if converged:
            ax.annotate("", xy=(x2 - 0.14, y_mid - h - 0.34), xytext=(x1 + 0.14, y_mid - h - 0.34),
                        arrowprops=dict(arrowstyle="<->", color=C_ARROW, lw=2.1, mutation_scale=11), zorder=6)

        for dy in [-0.60, 0.0, 0.60]:
            y0 = y_mid + dy
            if not converged:
                draw_ray(ax, [(xc - 1.95, y0), (x1, y0), (x2, y0), (xc + 1.95, y0)])
            else:
                draw_ray(ax, [(xc - 1.95, y0), (x1, y0), (x2, y_mid + dy * 0.62), (xc + 2.05, y_mid)])

        if converged:
            ax.scatter([xc + 2.08], [y_mid], s=32, color=C_ARROW, zorder=6)

        ax.text(xc, 0.48, cap, fontsize=9.4, fontweight="bold" if converged else "normal",
                color=C_ARROW if converged else C_MUTED, ha="center")

    draw_state(2.50, 0.14, "【看遠】兩片貼合", "互消 → 平光", False)
    draw_state(7.40, 1.25, "【看近】大幅拉開", "拉開 → 前框厚", True)


def draw_dots(ax, xc, yc, level, color):
    spacing = 0.0155
    rx = 0.0054
    ry = 0.0072
    for k in range(3):
        cx = xc + (k - 1) * spacing
        filled = k < level
        ax.add_patch(patches.Ellipse(
            (cx, yc), width=2 * rx, height=2 * ry,
            facecolor=color if filled else "#FFFFFF",
            edgecolor=color if filled else "#A0AEC0",
            linewidth=1.15, zorder=4
        ))


def draw_panel_d_lens_criteria_table(ax):
    ax.axis("off")
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)

    ax.text(0.0, 0.992, "(d) 三大機械變焦透鏡之核心關注指標與工程考量",
            fontsize=14.2, fontweight="bold", color=C_INK, va="top", ha="left")

    ly = 0.978
    ax.text(0.555, ly, "相對表現：", fontsize=10.5, fontweight="bold", color=C_MUTED, va="center", ha="left")
    for lx, lvl, txt in [(0.655, 3, "優勢"), (0.768, 2, "條件滿足"), (0.900, 1, "瓶頸")]:
        draw_dots(ax, lx, ly, lvl, C_INK)
        ax.text(lx + 0.026, ly, txt, fontsize=10.5, color=C_MUTED, va="center", ha="left")

    col_x = [0.00, 0.145, 0.430, 0.715]
    headers = [
        ("透鏡考量指標", C_INK),
        ("左右錯動雙片變焦\n(Alvarez / Lohmann)", C_ALV),
        ("擠壓液體改變弧度\n(液態膜片式透鏡)", C_LIQ),
        ("前後拉開鏡片距離\n(軸向雙鏡組變焦)", C_AXL),
    ]

    rows = [
        ("光學畫質像差",
         (2, "中央穩定無色差；邊緣易散光，\n4 光學面略增反光 (須鍍 AR)。"),
         (2, "大口徑連續變焦；直立液體重\n力易生彗差、多點易生三葉差。"),
         (3, "傳統折射鏡組原理成熟，軸上\n與周邊像質最易精確控制。")),
        ("視野與鏡框\n造型彈性",
         (2, "可做非圓形日常鏡框；但左右\n錯動使清晰區略小於外框。"),
         (1, "受限均勻受壓幾乎強制圓形，\n需額外框寬容納腔體與致動。"),
         (2, "可做標準圓形或裁切鏡片，拉\n開後周邊較易受框緣遮擋。")),
        ("環境穩定與\n長期可靠度",
         (3, "全固態結構，無滲漏、蒸發或\n重力變形，長期耐用度最高。"),
         (1, "存密封、氣泡、蒸發滲漏風險，\n對環境溫度與震動較敏感。"),
         (3, "全固態玻璃或光學塑膠，無液\n體老化、滲漏或下垂顧慮。")),
        ("對準精度與\n加工公差",
         (1, "【痛點】須極小空氣間隙；軌道\n歪斜會誘發斜軸散光致頭暈。"),
         (2, "左右對準較寬容，但薄膜預張\n力與壓力平衡決定初始像差。"),
         (2, "須維持嚴格同軸與平行，移動\n過程不可晃動偏心。")),
        ("外觀厚度與\n輕量化潛力",
         (3, "整體輕薄，市售手動版已證實\n可輕量化；高階曲面更薄。"),
         (2, "薄膜不厚，但加上活塞、外框\n與周邊致動器後整體偏大。"),
         (1, "【痛點】須大幅拉開前後間距，\n前框凸出厚重，不符眼鏡外觀。")),
        ("所需致動行程",
         (2, "需左右直線長行程 (多片堆疊\n可縮減)；需防末端卡滯。"),
         (3, "僅需短行程軸向推動即可變弧，\n對致動位移量要求最低。"),
         (1, "需長行程前後軸向平移，縱深\n吃重，鏡框空間極難隱藏。")),
        ("遠用散光與\n雙眼同步",
         (2, "僅調球面，高散光須加補償片；\n須雙眼同步並留意鏡框傾角。"),
         (2, "主調球面，常採前片磁吸固定\n遠用球柱面＋後片液態變焦。"),
         (2, "可於固定片整合處方，但看近\n輻輳時光軸對準較複雜。")),
        ("綜合定位與\n推薦致動",
         (3, "【眼鏡主流】固態輕薄無滲漏，\n首推 USM 或超聲頻 SIDM。"),
         (2, "【短行程替代】適配直接增益\n(無磨損) 或高推力 USM。"),
         (1, "【不建議日常眼鏡】外觀過厚\n重，較適合望遠鏡或 HMD。")),
    ]

    y_top = 0.935
    hdr_h = 0.100
    n_rows = len(rows)
    row_h = (y_top - hdr_h - 0.012) / n_rows

    ax.add_patch(patches.Rectangle((0.0, y_top - hdr_h), 1.0, hdr_h, facecolor=C_HEADER, edgecolor="none", zorder=0))
    ax.plot([0.0, 1.0], [y_top, y_top], color=C_INK, linewidth=2.0, zorder=3)
    ax.plot([0.0, 1.0], [y_top - hdr_h, y_top - hdr_h], color=C_INK, linewidth=1.1, zorder=3)

    for (title, col), x0 in zip(headers, col_x):
        ax.text(x0 + 0.008, y_top - hdr_h / 2, title,
                fontsize=11.0, fontweight="bold", color=col, va="center", ha="left", linespacing=1.20)

    cols_accent = [C_ALV, C_LIQ, C_AXL]
    for i, (metric, c0, c1, c2) in enumerate(rows):
        yt = y_top - hdr_h - i * row_h
        yb = yt - row_h
        ym = (yt + yb) / 2
        if i % 2 == 1:
            ax.add_patch(patches.Rectangle((0.0, yb), 1.0, row_h, facecolor=C_ZEBRA, edgecolor="none", zorder=0))
        if i < n_rows - 1:
            ax.plot([0.0, 1.0], [yb, yb], color=C_BORDER, linewidth=0.6, zorder=2)

        ax.text(col_x[0] + 0.008, ym, metric, fontsize=10.8, fontweight="bold",
                color=C_INK, va="center", ha="left", linespacing=1.22)

        for j, (lvl, desc) in enumerate([c0, c1, c2]):
            x0 = col_x[j + 1]
            draw_dots(ax, x0 + 0.028, ym + row_h * 0.20, lvl, cols_accent[j])
            ax.text(x0 + 0.062, ym, desc, fontsize=10.2, color="#1F2937",
                    va="center", ha="left", linespacing=1.26)

    y_bot = y_top - hdr_h - n_rows * row_h
    ax.plot([0.0, 1.0], [y_bot, y_bot], color=C_INK, linewidth=2.0, zorder=3)


def main():
    fig = plt.figure(figsize=(13.4, 16.5), dpi=300)

    fig.suptitle(
        "機械式對焦眼鏡：三大變焦透鏡運作原理與工程考量",
        fontsize=19.5, fontweight="bold", color=C_INK, y=0.980
    )
    fig.text(
        0.5, 0.955,
        "Visual Guide & Qualitative Engineering Trade-offs of Mechanical Tunable Lenses",
        fontsize=11.5, color=C_MUTED, ha="center"
    )

    outer = gridspec.GridSpec(
        2, 1, figure=fig,
        height_ratios=[0.54, 1.56],
        hspace=0.075,
        left=0.028, right=0.972, top=0.930, bottom=0.015
    )

    top_row = gridspec.GridSpecFromSubplotSpec(1, 3, subplot_spec=outer[0], wspace=0.035)
    draw_compact_alvarez(fig.add_subplot(top_row[0]))
    draw_compact_liquid(fig.add_subplot(top_row[1]))
    draw_compact_axial(fig.add_subplot(top_row[2]))

    draw_panel_d_lens_criteria_table(fig.add_subplot(outer[1]))

    out_dir = Path(__file__).resolve().parent
    png_path = out_dir / "autofocal_lens_mechanisms.png"
    pdf_path = out_dir / "autofocal_lens_mechanisms.pdf"

    fig.savefig(png_path, dpi=300, facecolor="#FFFFFF")
    try:
        fig.savefig(pdf_path, facecolor="#FFFFFF")
        pdf_out = pdf_path
    except PermissionError:
        alt_pdf = out_dir / "autofocal_lens_mechanisms_updated.pdf"
        fig.savefig(alt_pdf, facecolor="#FFFFFF")
        pdf_out = alt_pdf
    plt.close(fig)
    print(f"Saved:\n  PNG: {png_path}\n  PDF: {pdf_out}")


if __name__ == "__main__":
    main()
