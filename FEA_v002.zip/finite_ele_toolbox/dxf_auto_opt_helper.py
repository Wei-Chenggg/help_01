import math
import os
import time
from dataclasses import dataclass, field
import numpy as np
import ezdxf
import matplotlib
from matplotlib.collections import LineCollection, PolyCollection
from matplotlib.path import Path
from matplotlib.patches import Arc as MplArc
from scipy.linalg import cho_factor, cho_solve
from scipy.optimize import minimize
from scipy.ndimage import binary_erosion, label as nd_label
from scipy.spatial import cKDTree
from scipy.stats import norm

try:
    from .dxf_editting_helper import DXFEditingHelper
    from .dxf_contour_helper import DXFContourHelper
    from .finite_ele_mesh_helper import FiniteEleMeshHelper, MeshHyperParams
    from .finite_ele_solver_helper import FiniteEleSolverHelper, SolverHyperParams
except ImportError:
    from dxf_editting_helper import DXFEditingHelper
    from dxf_contour_helper import DXFContourHelper
    from finite_ele_mesh_helper import FiniteEleMeshHelper, MeshHyperParams
    from finite_ele_solver_helper import FiniteEleSolverHelper, SolverHyperParams

AUTO_LAYER = "AUTO"
SOLID_LAYER = "0"
AUTO_LAYER_ALIASES = ("AUTO", "SEARCH_ZONE")


@dataclass
class AutoContourRepairConfig:
    num_contours: int = 3
    num_pts: int = 5
    allow_outer_boundary_cut: bool = False
    min_angle_deg: float = 90.0
    fillet_ratio: float = 0.28
    min_fillet_radius: float = 0.30
    min_wall_thickness: float = 1.5
    min_hole_radius: float = 2.0
    shrink_gamma: float = 0.86
    max_shrink_iters: int = 50
    arc_discretize_steps: int = 8
    void_layer_name: str = SOLID_LAYER
    random_seed: int = None
    raster_pitch: float = 0.5

    def sub(self, **kw):
        data = dict(self.__dict__)
        data.update(kw)
        return AutoContourRepairConfig(**data)


@dataclass
class FilletCornerPrimitive:
    corner_index: int
    center: tuple
    radius: float
    start_deg: float
    end_deg: float
    t1: tuple
    t2: tuple


@dataclass
class SingleContourRepairResult:
    index: int
    raw_pts: list
    repaired_pts: list
    fillets: list = field(default_factory=list)
    shrunk_iters: int = 0
    pushed: bool = False
    valid: bool = False
    reason: str = ""


@dataclass
class AutoContourPipelineResult:
    output_doc: object = None
    raw_contours: list = field(default_factory=list)
    repaired_contours: list = field(default_factory=list)
    contour_results: list = field(default_factory=list)
    bo_vector_raw: list = field(default_factory=list)
    bo_vector_repaired: list = field(default_factory=list)
    final_outer: list = field(default_factory=list)
    final_holes: list = field(default_factory=list)
    final_outer_fillets: list = field(default_factory=list)
    final_hole_fillets: list = field(default_factory=list)
    severed: bool = False
    blank_area_mm2: float = 0.0
    cut_area_mm2: float = 0.0
    min_gap_mm: float = 0.0
    elapsed_ms: float = 0.0
    warnings: list = field(default_factory=list)


@dataclass
class BOIterationRecord:
    iter_idx: int
    is_warmup: bool
    x_raw: np.ndarray
    x_repaired: np.ndarray
    obj_score: float
    dxy_mm: float
    max_vm_mpa: float
    cut_area_mm2: float
    feasible: bool
    elapsed_ms: float
    note: str = ""


class DXFAutoContourRepairHelper:
    @staticmethod
    def _as_path(pts) -> Path:
        arr = np.asarray(pts, dtype=float)
        if len(arr) < 3:
            return Path(np.zeros((0, 2)), closed=True)
        closed = np.vstack([arr, arr[0]])
        return Path(closed, closed=True)

    @staticmethod
    def _interior_point(pts):
        """取多邊形內部一點（多邊形近似質心；若落在外部則退回頂點平均）。"""
        arr = np.asarray(pts, dtype=float)
        if len(arr) < 3:
            return (float(arr[:, 0].mean()) if len(arr) else 0.0,
                    float(arr[:, 1].mean()) if len(arr) else 0.0)
        cx, cy = DXFAutoContourRepairHelper.polygon_centroid(arr)
        if DXFAutoContourRepairHelper._as_path(arr).contains_point((cx, cy)):
            return (cx, cy)
        for k in range(len(arr)):
            a = arr[k]
            b = arr[(k + 1) % len(arr)]
            mid = 0.5 * (a + b)
            cen = np.array([(arr[:, 0].max() + arr[:, 0].min()) / 2.0,
                            (arr[:, 1].max() + arr[:, 1].min()) / 2.0])
            cand = mid + (cen - mid) * 1e-3
            if DXFAutoContourRepairHelper._as_path(arr).contains_point(tuple(cand)):
                return (float(cand[0]), float(cand[1]))
        return (float(arr[:, 0].mean()), float(arr[:, 1].mean()))

    @staticmethod
    def polygon_area(pts) -> float:
        arr = np.asarray(pts, dtype=float)
        if len(arr) < 3:
            return 0.0
        x, y = arr[:, 0], arr[:, 1]
        return 0.5 * abs(float(np.dot(x, np.roll(y, -1)) - np.dot(y, np.roll(x, -1))))

    @staticmethod
    def polygon_centroid(pts) -> tuple:
        arr = np.asarray(pts, dtype=float)
        if len(arr) < 3:
            return (0.0, 0.0)
        x, y = arr[:, 0], arr[:, 1]
        cross = x * np.roll(y, -1) - np.roll(x, -1) * y
        a = float(np.sum(cross))
        if abs(a) < 1e-12:
            return (float(arr[:, 0].mean()), float(arr[:, 1].mean()))
        cx = float(np.sum((x + np.roll(x, -1)) * cross) / (3.0 * a))
        cy = float(np.sum((y + np.roll(y, -1)) * cross) / (3.0 * a))
        return (cx, cy)

    @staticmethod
    def sort_points_ccw(pts) -> np.ndarray:
        arr = np.asarray(pts, dtype=float)
        if len(arr) < 3:
            return arr
        cx, cy = arr[:, 0].mean(), arr[:, 1].mean()
        ang = np.arctan2(arr[:, 1] - cy, arr[:, 0] - cx)
        order = np.argsort(ang)
        return arr[order]

    @staticmethod
    def shrink_points_around_centroid(pts, gamma: float) -> np.ndarray:
        arr = np.asarray(pts, dtype=float)
        cen = np.array(DXFAutoContourRepairHelper.polygon_centroid(arr), dtype=float)
        return cen + (arr - cen) * float(np.clip(gamma, 0.2, 0.999))

    @staticmethod
    def _point_seg_dist(pts, a, b) -> np.ndarray:
        p = np.asarray(pts, dtype=float)
        a = np.asarray(a, dtype=float)
        b = np.asarray(b, dtype=float)
        v = b - a
        c2 = float(v @ v)
        if c2 < 1e-12:
            return np.hypot(p[:, 0] - a[0], p[:, 1] - a[1])
        t = np.clip(((p - a) @ v) / c2, 0.0, 1.0)
        proj = a + t[:, None] * v
        return np.hypot(proj[:, 0] - p[:, 0], proj[:, 1] - p[:, 1])

    @classmethod
    def min_distance_to_loops(cls, pts, loops) -> float:
        best = float("inf")
        for loop in loops or []:
            arr = np.asarray(loop, dtype=float)
            if len(arr) < 2:
                continue
            nxt = np.roll(arr, -1, axis=0)
            for a, b in zip(arr, nxt):
                d = cls._point_seg_dist(pts, a, b)
                if len(d):
                    best = min(best, float(d.min()))
        return best

    @staticmethod
    def self_intersects(pts) -> bool:
        arr = np.asarray(pts, dtype=float)
        n = len(arr)
        if n < 4:
            return False
        p1 = arr
        p2 = np.roll(arr, -1, axis=0)

        def cross(o, a, b):
            return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])

        for i in range(n):
            for j in range(i + 2, n):
                if i == 0 and j == n - 1:
                    continue
                a, b = p1[i], p2[i]
                c, d = p1[j], p2[j]
                d1 = cross(a, b, c)
                d2 = cross(a, b, d)
                d3 = cross(c, d, a)
                d4 = cross(c, d, b)
                if ((d1 > 0) != (d2 > 0)) and ((d3 > 0) != (d4 > 0)):
                    return True
        return False

    # ------------------------------------------------------------ 幾何引擎（零 shapely）
    @staticmethod
    def _split_params(a, b, c, d):
        r = b - a
        s_ = d - c
        denom = r[0] * s_[1] - r[1] * s_[0]
        if abs(denom) < 1e-12:
            return None
        qp = c - a
        t = (qp[0] * s_[1] - qp[1] * s_[0]) / denom
        u = (qp[0] * r[1] - qp[1] * r[0]) / denom
        return float(t), float(u)

    @classmethod
    def intersect_and_split_segments(cls, segments, snap_tol: float = 1e-7) -> list:
        n = len(segments)
        if n == 0:
            return []
        params = [[0.0, 1.0] for _ in range(n)]
        for i in range(n):
            a, b = segments[i]
            for j in range(i + 1, n):
                c, d = segments[j]
                res = cls._split_params(a, b, c, d)
                if res is None:
                    continue
                t, u = res
                if -1e-9 <= t <= 1.0 + 1e-9 and -1e-9 <= u <= 1.0 + 1e-9:
                    params[i].append(min(max(t, 0.0), 1.0))
                    params[j].append(min(max(u, 0.0), 1.0))
        subs = []
        for i in range(n):
            a, b = segments[i]
            vals = sorted(params[i])
            for m in range(len(vals) - 1):
                t0, t1 = vals[m], vals[m + 1]
                if t1 - t0 < 1e-9:
                    continue
                p0 = a + t0 * (b - a)
                p1 = a + t1 * (b - a)
                if float(np.linalg.norm(p1 - p0)) > snap_tol:
                    subs.append((p0, p1))
        return subs

    @classmethod
    def boolean_loops(cls, solid_loops, cut_loops=None, eps: float = 1e-3, solid_holes=None) -> tuple:
        """以「中點 + 法線微偏 + contains_points」實作 union(0∪AUTO) 與 difference(母體−挖空)。"""
        solid_loops = [np.asarray(lp, dtype=float) for lp in (solid_loops or []) if len(lp) >= 3]
        cut_loops = [np.asarray(lp, dtype=float) for lp in (cut_loops or []) if len(lp) >= 3]
        if not solid_loops:
            return [], []
        solid_paths = [cls._as_path(lp) for lp in solid_loops]
        hole_paths = [cls._as_path(lp) for lp in (solid_holes or []) if len(lp) >= 3]
        cut_paths = [cls._as_path(lp) for lp in cut_loops]

        def inside_solid(pts):
            pts = np.atleast_2d(np.asarray(pts, dtype=float))
            mask = np.zeros(len(pts), dtype=bool)
            for sp in solid_paths:
                mask |= sp.contains_points(pts)
            for hp in hole_paths:
                mask &= ~hp.contains_points(pts)
            if cut_paths:
                cutmask = np.zeros(len(pts), dtype=bool)
                for cp in cut_paths:
                    cutmask |= cp.contains_points(pts)
                mask &= ~cutmask
            return mask

        segments = []
        for lp in solid_loops + list(solid_holes or []) + cut_loops:
            closed = np.vstack([lp, lp[0]])
            for a, b in zip(closed[:-1], closed[1:]):
                if float(np.linalg.norm(b - a)) > 1e-9:
                    segments.append((a, b))
        subs = cls.intersect_and_split_segments(segments)
        directed = []
        for a, b in subs:
            tangent = b - a
            length = float(np.linalg.norm(tangent))
            if length < 1e-12:
                continue
            tangent = tangent / length
            normal = np.array([-tangent[1], tangent[0]])
            mid = 0.5 * (a + b)
            left = bool(inside_solid(mid + eps * normal)[0])
            right = bool(inside_solid(mid - eps * normal)[0])
            if left and not right:
                directed.append((a, b))
            elif right and not left:
                directed.append((b, a))
        rings = cls._chain_rings(directed)
        outer, holes = [], []
        for ring in rings:
            if len(ring) < 3:
                continue
            area = cls._signed_area(ring)
            if area > 0:
                outer.append(ring)
            elif area < 0:
                holes.append(ring)
        outer.sort(key=lambda r: abs(cls._signed_area(r)), reverse=True)
        holes.sort(key=lambda r: abs(cls._signed_area(r)), reverse=True)
        return outer, holes

    @staticmethod
    def _signed_area(pts) -> float:
        arr = np.asarray(pts, dtype=float)
        x, y = arr[:, 0], arr[:, 1]
        return 0.5 * float(np.dot(x, np.roll(y, -1)) - np.dot(y, np.roll(x, -1)))

    @classmethod
    def _chain_rings(cls, edges, snap_tol: float = 1e-5) -> list:
        if not edges:
            return []
        scale = 1.0 / max(snap_tol, 1e-12)

        def key(p):
            return (int(round(float(p[0]) * scale)), int(round(float(p[1]) * scale)))

        buckets = {}
        for idx, (a, b) in enumerate(edges):
            buckets.setdefault(key(a), []).append(idx)
        used = [False] * len(edges)
        rings = []
        for start_idx in range(len(edges)):
            if used[start_idx]:
                continue
            used[start_idx] = True
            ring = [edges[start_idx][0]]
            cur = edges[start_idx][1]
            guard = 0
            while guard < len(edges) + 4:
                guard += 1
                if key(cur) == key(ring[0]):
                    break
                cand = [i for i in buckets.get(key(cur), []) if not used[i]]
                if not cand:
                    break
                nxt = cand[0]
                used[nxt] = True
                ring.append(edges[nxt][0])
                cur = edges[nxt][1]
            if len(ring) >= 3 and key(cur) == key(ring[0]):
                rings.append(np.array(ring, dtype=float))
        return rings

    @staticmethod
    def build_boundary_tree(loops, step: float = 0.25):
        pts = []
        for lp in loops or []:
            arr = np.asarray(lp, dtype=float)
            if len(arr) < 2:
                continue
            closed = np.vstack([arr, arr[0]])
            for a, b in zip(closed[:-1], closed[1:]):
                seg = float(np.linalg.norm(b - a))
                n = max(1, int(np.ceil(seg / max(step, 1e-6))))
                t = np.linspace(0.0, 1.0, n + 1)[:-1]
                pts.append(a + t[:, None] * (b - a))
        if not pts:
            return np.zeros((0, 2)), None
        stacked = np.vstack(pts)
        return stacked, cKDTree(stacked)

    # ------------------------------------------------------------ 圖層幾何
    @classmethod
    def extract_layer_loops(cls, doc) -> dict:
        if doc is None:
            return {}
        msp = doc.modelspace()
        segs_by_layer = {}
        for ent in msp:
            lay = ent.dxf.layer if ent.dxf.hasattr("layer") else "0"
            for a, b in DXFEditingHelper.entity_to_segments(ent):
                segs_by_layer.setdefault(lay, []).append((np.array([a, b], dtype=float), lay))
        loops_by_layer = {}
        for lay, segs in segs_by_layer.items():
            chains = FiniteEleMeshHelper._chain_segments_with_layers(segs, snap_tol=1e-2)
            loops = []
            for pts, _lays in chains:
                arr = np.asarray(pts, dtype=float)
                if len(arr) >= 3:
                    loops.append(arr)
            if loops:
                loops.sort(key=cls.polygon_area, reverse=True)
                loops_by_layer[lay] = loops
        return loops_by_layer

    @staticmethod
    def create_demo_0_and_auto_dxf(filepath: str = None):
        """產生一張標準夾爪測試毛坯：0 外框 + AUTO 下刀區 + FIXED / FORCE / PROBE。"""
        doc = ezdxf.new(dxfversion="R2010")
        doc.units = ezdxf.units.MM
        msp = doc.modelspace()
        left_block = [(0.0, 0.0), (12.0, 0.0), (12.0, 30.0), (0.0, 30.0)]
        right_block = [(48.0, 0.0), (60.0, 0.0), (60.0, 30.0), (48.0, 30.0)]
        for block in (left_block, right_block):
            for i in range(4):
                msp.add_line(block[i], block[(i + 1) % 4], dxfattribs={"layer": "0"})
        doc.layers.add(name=AUTO_LAYER, color=4)
        zone = [(12.0, 0.0), (48.0, 0.0), (48.0, 30.0), (12.0, 30.0)]
        for i in range(4):
            msp.add_line(zone[i], zone[(i + 1) % 4], dxfattribs={"layer": AUTO_LAYER})
        doc.layers.add(name="FIXED", color=5)
        msp.add_line((0.0, 0.0), (0.0, 30.0), dxfattribs={"layer": "FIXED"})
        doc.layers.add(name="FORCE_X1529.574Y0", color=1)
        msp.add_line((60.0, 0.0), (60.0, 30.0), dxfattribs={"layer": "FORCE_X1529.574Y0"})
        doc.layers.add(name="PROBE#001", color=3)
        msp.add_circle((30.0, 15.0), 1.2, dxfattribs={"layer": "PROBE#001"})
        if filepath:
            doc.saveas(filepath)
        return doc

    @classmethod
    def collect_entities(cls, doc) -> dict:
        loops = cls.extract_layer_loops(doc)
        solid_all = loops.get(SOLID_LAYER, [])
        solid, solid_holes = [], []
        candidates = [(cls.polygon_area(lp), lp) for lp in solid_all]
        for i, (area_i, loop_i) in enumerate(candidates):
            pt_in = cls._interior_point(loop_i)
            depth = 0
            for j, (area_j, loop_j) in enumerate(candidates):
                if i == j or area_j <= area_i:
                    continue
                if cls._as_path(loop_j).contains_point(pt_in):
                    depth += 1
            (solid_holes if depth % 2 == 1 else solid).append(loop_i)
        auto = []
        for alias in AUTO_LAYER_ALIASES:
            auto.extend(loops.get(alias, []))
        auto.sort(key=cls.polygon_area, reverse=True)
        bc_layers = {}
        probe_circles = []
        if doc is not None:
            for ent in doc.modelspace():
                info = DXFEditingHelper.parse_bc_layer_name(ent.dxf.layer)
                btype = info.get("type")
                if btype == "PROBE" and ent.dxftype() == "CIRCLE":
                    probe_circles.append({
                        "layer": ent.dxf.layer,
                        "center": (float(ent.dxf.center.x), float(ent.dxf.center.y)),
                        "radius": float(ent.dxf.radius),
                    })
                    continue
                if btype in ("FIXED", "DISP", "FORCE", "PROBE", "AUTO"):
                    bc_layers.setdefault(ent.dxf.layer, []).extend(DXFEditingHelper.entity_to_segments(ent))
        return {
            "loops_by_layer": loops,
            "solid_loops": solid,
            "solid_holes": solid_holes,
            "auto_loops": auto,
            "bc_layers": bc_layers,
            "probe_circles": probe_circles,
        }

    @classmethod
    def blank_area(cls, solid_loops, auto_loops) -> float:
        outer, holes = cls.boolean_loops(list(solid_loops or []) + list(auto_loops or []), [])
        if outer:
            return float(sum(cls.polygon_area(o) for o in outer) - sum(cls.polygon_area(h) for h in holes))
        return float(sum(cls.polygon_area(p) for p in (solid_loops or [])))

    # ------------------------------------------------------------ 合法性檢查
    @classmethod
    def remaining_material_connected(cls, solid_loops, void_loops, cfg, extra_voids=None) -> bool:
        if not solid_loops:
            return True
        outer = np.asarray(solid_loops[0], dtype=float)
        all_pts = [outer] + [np.asarray(v, dtype=float) for v in (void_loops or [])]
        if extra_voids:
            all_pts += [np.asarray(v, dtype=float) for v in extra_voids]
        stacked = np.vstack(all_pts)
        xmin, ymin = stacked.min(axis=0)
        xmax, ymax = stacked.max(axis=0)
        pitch = max(float(cfg.raster_pitch), 1e-3)
        nx = int(np.clip(np.ceil((xmax - xmin) / pitch), 8, 1200))
        ny = int(np.clip(np.ceil((ymax - ymin) / pitch), 8, 1200))
        xs = np.linspace(xmin, xmax, nx)
        ys = np.linspace(ymin, ymax, ny)
        gx, gy = np.meshgrid(xs, ys)
        grid = np.column_stack([gx.ravel(), gy.ravel()])
        solid_mask = cls._as_path(outer).contains_points(grid).reshape(ny, nx)
        for loop in solid_loops[1:]:
            solid_mask &= ~cls._as_path(loop).contains_points(grid).reshape(ny, nx)
        void_mask = np.zeros_like(solid_mask)
        for loop in list(void_loops or []) + list(extra_voids or []):
            void_mask |= cls._as_path(loop).contains_points(grid).reshape(ny, nx)
        material = solid_mask & ~void_mask
        cells = max(int(cfg.min_wall_thickness / pitch), 1)
        if cells > 1:
            material = binary_erosion(material, iterations=cells, border_value=1)
        if not material.any():
            return False
        lab, n = nd_label(material)
        if n <= 1:
            return n == 1
        sizes = np.bincount(lab.ravel())
        sizes[0] = 0
        main = float(sizes.max())
        return bool(np.count_nonzero(sizes) <= 1 or sizes.max() >= 0.92 * sizes.sum())

    @classmethod
    def validate_contour(cls, pts, solid_loops, blank_loops, auto_loops, other_contours, cfg) -> tuple:
        arr = np.asarray(pts, dtype=float)
        if len(arr) < 3:
            return False, "too_few_points"
        if cls.polygon_area(arr) < 1e-6:
            return False, "zero_area"
        if cls.self_intersects(arr):
            return False, "self_intersect"
        auto_paths = [cls._as_path(p) for p in auto_loops]
        solid_paths = [cls._as_path(p) for p in solid_loops]
        blank_paths = [cls._as_path(p) for p in blank_loops] or solid_paths
        allow_cut = bool(cfg.allow_outer_boundary_cut)
        t_min = float(cfg.min_wall_thickness)

        # '0' 圖層為不可修改的受保護區：不得侵入、也不得貼近
        for sp in solid_paths:
            if sp.contains_points(arr).mean() > 0.0:
                return False, "hit_zero"
        if cls.min_distance_to_loops(arr, solid_loops) < t_min * 0.5:
            return False, "near_zero"

        if allow_cut:
            inside_blank = bool(blank_paths) and any(bp.contains_points(arr).mean() > 0.999 for bp in blank_paths)
            if not inside_blank:
                cen0 = cls.polygon_centroid(arr)
                if not (auto_paths and any(p.contains_point(cen0) for p in auto_paths)):
                    return False, "outside_blank"
        else:
            if auto_paths and not any(p.contains_points(arr).mean() > 0.999 for p in auto_paths):
                return False, "outside_auto"
            if cls.min_distance_to_loops(arr, auto_loops) < t_min * 0.5:
                return False, "near_auto_edge"

        cen = cls.polygon_centroid(arr)
        radius = float(np.mean(np.hypot(arr[:, 0] - cen[0], arr[:, 1] - cen[1])))
        if radius < float(cfg.min_hole_radius) * 0.5:
            return False, "too_small"
        for other in other_contours or []:
            if cls.min_distance_to_loops(arr, [other]) < t_min:
                return False, "pair_too_close"

        outer, _holes = cls.boolean_loops(blank_loops or solid_loops, list(other_contours or []) + [arr])
        if len(outer) != 1:
            return False, "disconnect"

        # 外缺角：額外用光柵侵蝕確認剩餘壁厚與連通性
        if allow_cut and not cls.remaining_material_connected(
            blank_loops or solid_loops, list(other_contours or []), cfg, extra_voids=[arr]
        ):
            return False, "near_wall"
        return True, ""

    # ------------------------------------------------------------ 圓角
    @classmethod
    def build_filleted_contour(cls, pts, cfg, protected_pts=None, reorder: bool = True) -> tuple:
        arr = cls._dedup(pts)
        if reorder:
            arr = cls.sort_points_ccw(arr)
        n = len(arr)
        if n < 3:
            return arr, [], []
        out_pts = []
        fillets = []
        min_ang = math.radians(float(cfg.min_angle_deg))
        protected = np.asarray(protected_pts, dtype=float) if protected_pts is not None and len(protected_pts) else np.zeros((0, 2))
        for i in range(n):
            prev_p = arr[(i - 1) % n]
            cur = arr[i]
            next_p = arr[(i + 1) % n]
            u1 = prev_p - cur
            u2 = next_p - cur
            l1 = float(np.linalg.norm(u1))
            l2 = float(np.linalg.norm(u2))
            if l1 < 1e-9 or l2 < 1e-9:
                out_pts.append(tuple(cur))
                continue
            u1 /= l1
            u2 /= l2
            cos_t = float(np.clip(u1 @ u2, -1.0, 1.0))
            theta = math.acos(cos_t)
            if protected.size and float(np.min(np.hypot(protected[:, 0] - cur[0], protected[:, 1] - cur[1]))) < 0.25:
                out_pts.append(tuple(cur))
                continue
            if theta >= min_ang or theta < 1e-3:
                out_pts.append(tuple(cur))
                continue
            r = max(float(cfg.min_fillet_radius), float(cfg.fillet_ratio) * min(l1, l2))
            t_len = r / max(math.tan(theta * 0.5), 1e-6)
            if t_len > 0.48 * min(l1, l2):
                t_len = 0.48 * min(l1, l2)
                r = t_len * math.tan(theta * 0.5)
            if r < 1e-6:
                out_pts.append(tuple(cur))
                continue
            t1 = cur + u1 * t_len
            t2 = cur + u2 * t_len
            bis = (u1 + u2)
            nb = float(np.linalg.norm(bis))
            if nb < 1e-9:
                out_pts.append(tuple(cur))
                continue
            bis /= nb
            center = cur + bis * (r / max(math.sin(theta * 0.5), 1e-6))
            a1 = math.degrees(math.atan2(t1[1] - center[1], t1[0] - center[0])) % 360.0
            a2 = math.degrees(math.atan2(t2[1] - center[1], t2[0] - center[0])) % 360.0
            ccw = (a2 - a1) % 360.0
            if ccw <= 180.0:
                start_a, end_a = a1, a2
            else:
                start_a, end_a = a2, a1
            fillets.append(FilletCornerPrimitive(
                corner_index=i,
                center=(float(center[0]), float(center[1])),
                radius=float(r),
                start_deg=float(start_a),
                end_deg=float(end_a),
                t1=(float(t1[0]), float(t1[1])),
                t2=(float(t2[0]), float(t2[1])),
            ))
            out_pts.append(tuple(t1))
            sweep = (end_a - start_a) % 360.0
            steps = max(2, int(cfg.arc_discretize_steps))
            for k in range(1, steps):
                ang = math.radians(start_a + sweep * k / steps)
                out_pts.append((float(center[0] + r * math.cos(ang)),
                                float(center[1] + r * math.sin(ang))))
            out_pts.append(tuple(t2))
        return np.array(out_pts, dtype=float), fillets, list(arr)

    @staticmethod
    def _dedup(pts, tol: float = 1e-9) -> np.ndarray:
        arr = np.asarray(pts, dtype=float)
        if len(arr) < 2:
            return arr
        keep = [arr[0]]
        for p in arr[1:]:
            if float(np.linalg.norm(p - keep[-1])) > tol:
                keep.append(p)
        if len(keep) > 2 and float(np.linalg.norm(keep[0] - keep[-1])) <= tol:
            keep.pop()
        return np.array(keep, dtype=float)

    # ------------------------------------------------------------ 抽樣與修復管線
    @classmethod
    def sample_random_raw_contours_in_auto(cls, auto_loops, solid_loops, cfg, rng=None) -> list:
        if not auto_loops:
            return []
        if rng is None:
            rng = np.random.default_rng(cfg.random_seed)
        zone = np.asarray(auto_loops[0], dtype=float)
        zx = float(zone[:, 0].max() - zone[:, 0].min())
        zy = float(zone[:, 1].max() - zone[:, 1].min())
        base_r = max(min(zx, zy) * 0.10, float(cfg.min_hole_radius))
        x0, x1 = float(zone[:, 0].min()), float(zone[:, 0].max())
        y0, y1 = float(zone[:, 1].min()), float(zone[:, 1].max())
        contours = []
        for _ in range(int(max(1, cfg.num_contours))):
            if cfg.allow_outer_boundary_cut:
                cx = rng.uniform(x0 - 0.5 * base_r, x1 + 0.5 * base_r)
                cy = rng.uniform(y0 - 0.5 * base_r, y1 + 0.5 * base_r)
                scale = rng.uniform(0.8, 2.2)
            else:
                cx = rng.uniform(x0 + base_r, x1 - base_r)
                cy = rng.uniform(y0 + base_r, y1 - base_r)
                scale = rng.uniform(0.6, 1.5)
            ang = np.sort(rng.uniform(0.0, 2.0 * math.pi, int(max(3, cfg.num_pts))))
            radius = base_r * scale * rng.uniform(0.75, 1.25, len(ang))
            pts = np.column_stack([cx + radius * np.cos(ang), cy + radius * np.sin(ang)])
            contours.append(cls.sort_points_ccw(pts))
        return contours

    @classmethod
    def repair_contours(cls, raw_contours, solid_loops, auto_loops, cfg, blank_loops=None) -> tuple:
        repaired = []
        repaired_pts = []
        results = []
        for idx, raw in enumerate(raw_contours):
            cur = cls.sort_points_ccw(np.asarray(raw, dtype=float))
            ok, reason = False, ""
            iters = 0
            pushed = False
            for iters in range(1, int(max(1, cfg.max_shrink_iters)) + 1):
                ok, reason = cls.validate_contour(cur, solid_loops, blank_loops or solid_loops, auto_loops, repaired_pts, cfg)
                if ok:
                    break
                cen = np.array(cls.polygon_centroid(cur), dtype=float)
                if reason in ("outside_auto", "near_auto_edge") and auto_loops:
                    zone = np.asarray(auto_loops[0], dtype=float)
                    zc = np.array([zone[:, 0].mean(), zone[:, 1].mean()], dtype=float)
                    cur = cen + (cur - cen) * 0.92 + (zc - cen) * 0.08
                    pushed = True
                elif reason in ("hit_zero", "near_zero", "near_wall") and solid_loops:
                    worst = None
                    best = float("inf")
                    for loop in solid_loops:
                        arr = np.asarray(loop, dtype=float)
                        d = np.hypot(arr[:, 0] - cen[0], arr[:, 1] - cen[1])
                        k = int(np.argmin(d))
                        if float(d[k]) < best:
                            best = float(d[k])
                            worst = arr[k]
                    if worst is not None:
                        direction = cen - np.asarray(worst, dtype=float)
                        nd = float(np.linalg.norm(direction))
                        if nd > 1e-9:
                            direction /= nd
                        cur = cen + (cur - cen) * 0.95 + direction * 0.5
                        pushed = True
                elif reason == "pair_too_close" and repaired_pts:
                    other_c = np.array(cls.polygon_centroid(repaired_pts[-1]), dtype=float)
                    direction = cen - other_c
                    nd = float(np.linalg.norm(direction))
                    if nd > 1e-9:
                        direction /= nd
                    cur = cen + (cur - cen) * 0.95 + direction * 0.4
                    pushed = True
                if reason in ("near_auto_edge", "pair_too_close", "disconnect", "too_small",
                              "outside_auto", "near_wall", "hit_zero", "near_zero"):
                    cur = cls.shrink_points_around_centroid(cur, cfg.shrink_gamma)
                else:
                    cur = cls.shrink_points_around_centroid(cur, 0.98)
                if cls.polygon_area(cur) < 0.05:
                    break
            else:
                ok, reason = cls.validate_contour(cur, solid_loops, blank_loops or solid_loops, auto_loops, repaired_pts, cfg)
            if ok:
                ccw = cls.sort_points_ccw(cls._dedup(cur))
                results.append(SingleContourRepairResult(
                    index=idx, raw_pts=[tuple(p) for p in np.asarray(raw, dtype=float)],
                    repaired_pts=[tuple(p) for p in ccw], fillets=[],
                    shrunk_iters=iters, pushed=pushed, valid=True, reason="",
                ))
                repaired.append({"pts": ccw, "bo_pts": ccw, "fillets": []})
                repaired_pts.append(ccw)
            else:
                results.append(SingleContourRepairResult(
                    index=idx, raw_pts=[tuple(p) for p in np.asarray(raw, dtype=float)],
                    repaired_pts=[], fillets=[], shrunk_iters=iters,
                    pushed=pushed, valid=False, reason=reason,
                ))
        return repaired, results

    @classmethod
    def _fillet_loop(cls, loop, cfg, protected_pts=None) -> tuple:
        """布林差集後的迴路導圓角：保持原頂點順序，CW 迴路先反向再導回。"""
        arr = np.asarray(loop, dtype=float)
        if len(arr) < 3:
            return arr, []
        reverse = cls._signed_area(arr) < 0
        work = arr[::-1] if reverse else arr
        pts, fillets, _ccw = cls.build_filleted_contour(work, cfg, protected_pts=protected_pts, reorder=False)
        if reverse:
            pts = pts[::-1]
        return pts, fillets

    @staticmethod
    def _protected_points(solid_loops) -> np.ndarray:
        pts = []
        for loop in solid_loops or []:
            arr = np.asarray(loop, dtype=float)
            if len(arr):
                pts.append(arr)
        return np.vstack(pts) if pts else np.zeros((0, 2))

    @classmethod
    def build_output_doc(cls, src_doc, outer_loops, hole_loops, cfg) -> object:
        """輸出乾淨 DXF：外輪廓 + 內孔寫在 '0'，其餘 BC / PROBE 圖元原樣複製（AUTO 不輸出）。"""
        doc = ezdxf.new(dxfversion="R2010")
        doc.units = ezdxf.units.MM
        msp = doc.modelspace()
        if src_doc is not None:
            for ent in src_doc.modelspace():
                etype = ent.dxftype()
                lay = ent.dxf.layer
                info = DXFEditingHelper.parse_bc_layer_name(lay)
                if info.get("type") == "AUTO":
                    continue
                if str(lay) == SOLID_LAYER:
                    continue
                if lay not in doc.layers:
                    doc.layers.add(name=lay, color=7)
                if etype == "LINE":
                    msp.add_line(
                        (float(ent.dxf.start.x), float(ent.dxf.start.y)),
                        (float(ent.dxf.end.x), float(ent.dxf.end.y)),
                        dxfattribs={"layer": lay},
                    )
                elif etype == "CIRCLE":
                    msp.add_circle(
                        (float(ent.dxf.center.x), float(ent.dxf.center.y)),
                        float(ent.dxf.radius),
                        dxfattribs={"layer": lay},
                    )
                elif etype == "ARC":
                    msp.add_arc(
                        (float(ent.dxf.center.x), float(ent.dxf.center.y)),
                        float(ent.dxf.radius),
                        float(ent.dxf.start_angle), float(ent.dxf.end_angle),
                        dxfattribs={"layer": lay},
                    )
        if SOLID_LAYER not in doc.layers:
            doc.layers.add(name=SOLID_LAYER, color=7)
        for loop in list(outer_loops or []) + list(hole_loops or []):
            pts = np.asarray(loop, dtype=float)
            if len(pts) < 3:
                continue
            closed = np.vstack([pts, pts[0]])
            for a, b in zip(closed[:-1], closed[1:]):
                if float(np.linalg.norm(b - a)) < 1e-9:
                    continue
                msp.add_line((float(a[0]), float(a[1])), (float(b[0]), float(b[1])),
                             dxfattribs={"layer": SOLID_LAYER})
        return doc

    @classmethod
    def _flatten_contours(cls, contours, cfg, fallback=None) -> list:
        n = int(max(1, cfg.num_contours))
        m = int(max(3, cfg.num_pts))
        out = []
        for i in range(n):
            pts = None
            if contours is not None and i < len(contours) and contours[i] is not None:
                pts = np.asarray(contours[i], dtype=float)
            elif fallback is not None and i < len(fallback) and fallback[i] is not None:
                pts = np.asarray(fallback[i], dtype=float)
            if pts is None or len(pts) == 0:
                out.extend([0.0] * (2 * m))
                continue
            arr = pts[:m]
            flat = [float(v) for p in arr for v in p]
            if len(arr) < m:
                flat.extend([float(arr[-1][0]), float(arr[-1][1])] * (m - len(arr)))
            out.extend(flat[:2 * m])
        return out

    @classmethod
    def run_pipeline(cls, doc_in, raw_contours, cfg) -> AutoContourPipelineResult:
        t0 = time.perf_counter()
        geo = cls.collect_entities(doc_in)
        solid = geo["solid_loops"]
        auto = geo["auto_loops"]
        warnings = []
        if not auto:
            warnings.append("no AUTO/SEARCH_ZONE layer - fallback to shrunk 0 outline as search zone")
            if solid:
                auto = [cls.shrink_points_around_centroid(solid[0], 0.7)]
        solid_holes = geo.get("solid_holes") or []
        blank = list(solid) + list(auto)
        repaired, results = cls.repair_contours(raw_contours, solid, auto, cfg, blank_loops=blank)
        cut_loops = [item["pts"] for item in repaired]
        outer, holes = cls.boolean_loops(blank, cut_loops, solid_holes=solid_holes)
        severed = len(outer) != 1
        if severed and len(outer) > 1:
            warnings.append(f"part severed into {len(outer)} islands - shrink the cut zone")

        # 圓角在布林差集之後執行：外缺角與外框交界的新銳角才會被導圓
        protect = cls._protected_points(solid)
        final_outer, outer_fillets = [], []
        for lp in outer:
            fpts, fils = cls._fillet_loop(lp, cfg, protected_pts=protect)
            final_outer.append(fpts)
            outer_fillets.append(fils)
        final_holes, hole_fillets = [], []
        for lp in holes:
            fpts, fils = cls._fillet_loop(lp, cfg)
            final_holes.append(fpts)
            hole_fillets.append(fils)

        if final_outer:
            out_doc = cls.build_output_doc(doc_in, final_outer, final_holes, cfg)
        else:
            warnings.append("boolean produced no outer loop - fallback to holes only")
            out_doc = cls.build_output_doc(doc_in, [solid[0]] if solid else [], cut_loops, cfg)
        cut_area = sum(cls.polygon_area(r["pts"]) for r in repaired)
        gaps = []
        for i in range(len(repaired)):
            for j in range(i + 1, len(repaired)):
                gaps.append(cls.min_distance_to_loops(repaired[i]["pts"], [repaired[j]["pts"]]))
        raw_vec = cls._flatten_contours(raw_contours, cfg)
        rep_vec = cls._flatten_contours(
            [item.get("bo_pts") for item in repaired], cfg, fallback=raw_contours
        )
        return AutoContourPipelineResult(
            output_doc=out_doc,
            raw_contours=[np.asarray(c, dtype=float) for c in raw_contours],
            repaired_contours=[np.asarray(r["pts"], dtype=float) for r in repaired],
            contour_results=results,
            final_outer=[np.asarray(r, dtype=float) for r in final_outer],
            final_holes=[np.asarray(r, dtype=float) for r in final_holes],
            final_outer_fillets=outer_fillets,
            final_hole_fillets=hole_fillets,
            severed=bool(severed),
            bo_vector_raw=raw_vec,
            bo_vector_repaired=rep_vec,
            blank_area_mm2=cls.blank_area(solid, auto),
            cut_area_mm2=float(cut_area),
            min_gap_mm=float(min(gaps)) if gaps else float("inf"),
            elapsed_ms=(time.perf_counter() - t0) * 1000.0,
            warnings=warnings,
        )

    @staticmethod
    def export_result_to_dxf(pipe_res, filepath):
        if pipe_res is None or getattr(pipe_res, "output_doc", None) is None or not filepath:
            return None
        pipe_res.output_doc.saveas(filepath)
        return filepath

    # ------------------------------------------------------------ 繪圖
    @classmethod
    def plot_blank_on_ax(cls, ax, geo, repaired_contours=None, title=""):
        if ax is None:
            return None
        ax.clear()
        ax.set_facecolor("#0a0a0a")
        if ax.figure is not None:
            ax.figure.patch.set_facecolor("#0a0a0a")
        solid = geo.get("solid_loops") or []
        auto = geo.get("auto_loops") or []
        if solid:
            ax.add_collection(PolyCollection(
                [np.asarray(p, dtype=float) for p in solid],
                facecolors="#22c55e", edgecolors="#16a34a", alpha=0.18, zorder=2, label="0 (protected)",
            ))
        if auto:
            ax.add_collection(PolyCollection(
                [np.asarray(p, dtype=float) for p in auto],
                facecolors="#00e5ff", edgecolors="#00e5ff", alpha=0.16, zorder=3, label="AUTO (carve zone)",
            ))
        for lay, segs in (geo.get("bc_layers") or {}).items():
            if not segs:
                continue
            style = DXFEditingHelper.get_layer_style(lay)
            ax.add_collection(LineCollection(
                [np.array(s, dtype=float) for s in segs],
                colors=style["colors"], linewidths=style["linewidths"], zorder=6, label=str(lay),
            ))
        for pc in (geo.get("probe_circles") or []):
            cx, cy = pc["center"]
            th = np.linspace(0.0, 2.0 * np.pi, 49)
            r = float(pc["radius"])
            ax.plot(cx + r * np.cos(th), cy + r * np.sin(th), color="#00ff88", lw=1.4, ls="--", zorder=7)
            ax.plot([cx], [cy], marker="+", ms=10, color="#00ff88", mew=1.8, zorder=7)
        if repaired_contours:
            for item in repaired_contours:
                pts = item["pts"] if isinstance(item, dict) else np.asarray(item, dtype=float)
                arr = np.asarray(pts, dtype=float)
                closed = np.vstack([arr, arr[0]])
                ax.plot(closed[:, 0], closed[:, 1], color="#ff3355", lw=1.4, ls="-", zorder=8)
                raw = item.get("raw") if isinstance(item, dict) else None
                if raw is not None:
                    ra = np.asarray(raw, dtype=float)
                    rc = np.vstack([ra, ra[0]])
                    ax.plot(rc[:, 0], rc[:, 1], color="#f59e0b", lw=0.9, ls=":", zorder=7)
        ax.set_aspect("equal", adjustable="datalim")
        ax.tick_params(colors="#888888", labelsize=7)
        all_pts = [np.asarray(p, dtype=float) for p in solid + auto]
        if all_pts:
            stacked = np.vstack(all_pts)
            xmin, ymin = stacked.min(axis=0)
            xmax, ymax = stacked.max(axis=0)
            dx = max(xmax - xmin, 1.0) * 0.06
            dy = max(ymax - ymin, 1.0) * 0.06
            ax.set_xlim(xmin - dx, xmax + dx)
            ax.set_ylim(ymin - dy, ymax + dy)
        hud = [f"BLANK | 0 loops {len(solid)} | AUTO loops {len(auto)}"]
        if repaired_contours:
            hud.append(f"Repaired voids: {len(repaired_contours)}")
        if title:
            hud.append(title)
        ax.text(
            0.012, 0.985, "\n".join(hud), transform=ax.transAxes, color="#7dd3fc",
            fontsize=8.5, va="top", ha="left", zorder=20,
            bbox=dict(boxstyle="round,pad=0.35", facecolor="#161616", edgecolor="#444444", alpha=0.92),
        )
        handles, labels = ax.get_legend_handles_labels()
        if handles:
            ax.legend(loc="lower right", facecolor="#181818", edgecolor="#444444", labelcolor="#dddddd", fontsize=7)
        return ax

    @classmethod
    def plot_cut_result_on_ax(cls, ax, pipe_res, geo=None, show_fill: bool = True):
        if ax is None or pipe_res is None:
            return None
        ax.clear()
        ax.set_facecolor("#0a0a0a")
        if ax.figure is not None:
            ax.figure.patch.set_facecolor("#0a0a0a")
        if geo is None:
            geo = {}
        solids = geo.get("solid_loops") or []
        if solids:
            ax.add_collection(PolyCollection(
                [np.asarray(p, dtype=float) for p in solids],
                facecolors="#22c55e", edgecolors="#16a34a", alpha=0.12, zorder=1, label="0 (protected)",
            ))
        voids = [np.asarray(r, dtype=float) for r in pipe_res.repaired_contours]
        final_outer = [np.asarray(r, dtype=float) for r in (pipe_res.final_outer or [])]
        final_holes = [np.asarray(r, dtype=float) for r in (pipe_res.final_holes or [])]
        if final_outer:
            ax.add_collection(PolyCollection(
                final_outer, facecolors="#16a34a", edgecolors="#22c55e",
                alpha=0.28 if show_fill else 0.0, zorder=2, label="blank (0 U AUTO)",
            ))
        if final_holes:
            ax.add_collection(PolyCollection(
                final_holes, facecolors="#e11d48", edgecolors="#f43f5e",
                alpha=0.45 if show_fill else 0.0, zorder=4, label="holes (cut)",
            ))
        elif voids:
            ax.add_collection(PolyCollection(
                voids, facecolors="#e11d48", edgecolors="none", alpha=0.35, zorder=4, label="cut voids",
            ))
        n_arc = 0
        draw_loops = [(lp, "#ffffff") for lp in (pipe_res.final_outer or [])]
        draw_loops += [(lp, "#f43f5e") for lp in (pipe_res.final_holes or [])]
        for item, color in draw_loops:
            arr = np.asarray(item, dtype=float)
            closed = np.vstack([arr, arr[0]])
            ax.plot(closed[:, 0], closed[:, 1], color=color, lw=1.0, zorder=6)
            ax.plot(arr[:, 0], arr[:, 1], linestyle="none", marker="o", ms=2.2, color="#00ff88", zorder=8)
        for fillets in list(pipe_res.final_outer_fillets or []) + list(pipe_res.final_hole_fillets or []):
            for fil in fillets:
                ax.add_patch(MplArc(
                    fil.center, 2 * fil.radius, 2 * fil.radius,
                    theta1=fil.start_deg, theta2=fil.end_deg,
                    color="#f59e0b", lw=1.6, zorder=7,
                ))
                n_arc += 1
        total = len(voids)
        n_notch = 0
        if final_outer and geo.get("solid_loops"):
            base = sum(DXFAutoContourRepairHelper.polygon_area(p) for p in geo.get("solid_loops") or [])
            n_notch = 1 if abs(DXFAutoContourRepairHelper.polygon_area(final_outer[0]) - base) > 1e-6 else 0
        hud = [
            f"CUT RESULT | voids {total}/{len(pipe_res.raw_contours)} | holes {len(final_holes)} "
            f"| fillets {n_arc} | notch {n_notch} | "
            f"{'SEVERED' if pipe_res.severed else ('CLEAN' if total and all(r.valid for r in pipe_res.contour_results) else 'PARTIAL')}",
            f"cut area {pipe_res.cut_area_mm2:.2f} mm2 | blank {pipe_res.blank_area_mm2:.1f} mm2 "
            f"| min gap {pipe_res.min_gap_mm:.2f} mm | {pipe_res.elapsed_ms:.0f} ms",
        ]
        for w in pipe_res.warnings:
            hud.append(f"WARN: {w}")
        ax.text(
            0.012, 0.985, "\n".join(hud), transform=ax.transAxes, color="#f472b6",
            fontsize=8.5, va="top", ha="left", zorder=20,
            bbox=dict(boxstyle="round,pad=0.35", facecolor="#161616", edgecolor="#444444", alpha=0.92),
        )
        ax.set_aspect("equal", adjustable="datalim")
        ax.tick_params(colors="#888888", labelsize=7)
        pts = [np.asarray(p, dtype=float) for p in solids + voids]
        if pts:
            stacked = np.vstack(pts)
            xmin, ymin = stacked.min(axis=0)
            xmax, ymax = stacked.max(axis=0)
            dx = max(xmax - xmin, 1.0) * 0.06
            dy = max(ymax - ymin, 1.0) * 0.06
            ax.set_xlim(xmin - dx, xmax + dx)
            ax.set_ylim(ymin - dy, ymax + dy)
        handles, labels = ax.get_legend_handles_labels()
        if handles:
            ax.legend(loc="lower right", facecolor="#181818", edgecolor="#444444", labelcolor="#dddddd", fontsize=7)
        return ax


class LamarckianBayesianOptimizer:
    def __init__(self, doc_in, repair_cfg, mesh_hp=None, solver_hp=None,
                 n_init_random: int = 4, n_bo_iters: int = 6,
                 stress_limit_mpa: float = 400.0, random_seed: int = 42):
        self.doc_in = doc_in
        self.cfg = repair_cfg
        self.mesh_hp = mesh_hp or MeshHyperParams()
        self.solver_hp = solver_hp or SolverHyperParams()
        self.n_init_random = int(max(1, n_init_random))
        self.n_bo_iters = int(max(1, n_bo_iters))
        self.stress_limit = float(stress_limit_mpa)
        self.rng = np.random.default_rng(random_seed)
        self.records = []
        self.best_record = None
        self.stop_flag = False
        self.dim = 2 * int(repair_cfg.num_contours) * int(repair_cfg.num_pts)

    # -------------------------------------------------------------- 評估
    def evaluate_single_design(self, raw_cnts, iter_idx=0, is_warmup=False) -> BOIterationRecord:
        t0 = time.perf_counter()
        pipe = DXFAutoContourRepairHelper.run_pipeline(self.doc_in, raw_cnts, self.cfg)
        dxy = 0.0
        vm = 0.0
        feasible = False
        note = ""
        if pipe.repaired_contours:
            try:
                mesh = FiniteEleMeshHelper.build_t6_mesh_from_dxf(pipe.output_doc, hp=self.mesh_hp)
                fea = FiniteEleSolverHelper.solve(mesh, hp=self.solver_hp)
                vm = float(fea["max_von_mises"])
                probes = fea.get("probes") or {}
                if probes:
                    dxy = float(next(iter(probes.values()))["dxy"])
                feasible = True
            except Exception as exc:
                note = f"FEA 失敗: {exc}"
        else:
            note = "無有效修復輪廓"
        penalty = max(0.0, vm - self.stress_limit) * 0.01
        score = float(dxy) * 1000.0 - penalty
        if not feasible:
            score = -1e3
        rec = BOIterationRecord(
            iter_idx=int(iter_idx),
            is_warmup=bool(is_warmup),
            x_raw=np.asarray(pipe.bo_vector_raw, dtype=float),
            x_repaired=np.asarray(pipe.bo_vector_repaired, dtype=float),
            obj_score=score,
            dxy_mm=float(dxy),
            max_vm_mpa=float(vm),
            cut_area_mm2=float(pipe.cut_area_mm2),
            feasible=bool(feasible),
            elapsed_ms=(time.perf_counter() - t0) * 1000.0,
            note=note,
        )
        self.records.append(rec)
        if self.best_record is None or rec.obj_score > self.best_record.obj_score:
            self.best_record = rec
        return rec

    def _random_design(self):
        geo = DXFAutoContourRepairHelper.collect_entities(self.doc_in)
        return DXFAutoContourRepairHelper.sample_random_raw_contours_in_auto(
            geo["auto_loops"], geo["solid_loops"], self.cfg, rng=self.rng
        )

    # -------------------------------------------------------------- GP / EI
    @staticmethod
    def _matern52(x1, x2, ls=1.0):
        r = np.linalg.norm((x1[:, None, :] - x2[None, :, :]) / max(ls, 1e-6), axis=2)
        return (1.0 + math.sqrt(5.0) * r + 5.0 / 3.0 * r ** 2) * np.exp(-math.sqrt(5.0) * r)

    def _fit_gp(self, X, y):
        X = np.asarray(X, dtype=float)
        y = np.asarray(y, dtype=float)
        if len(X) < 2:
            return None
        x_mean = X.mean(axis=0)
        x_std = X.std(axis=0) + 1e-9
        Xn = (X - x_mean) / x_std
        y_mean = float(y.mean())
        y_std = float(y.std()) + 1e-6
        y_norm = (y - y_mean) / y_std

        def make_kernel(ell, sf, sn):
            K = (sf ** 2) * self._matern52(Xn, Xn, ell) + (sn ** 2 + 1e-6) * np.eye(len(Xn))
            return K

        def nll(theta):
            ell, sf, sn = float(np.exp(theta[0])), float(np.exp(theta[1])), float(np.exp(theta[2]))
            K = make_kernel(ell, sf, sn)
            try:
                c, low = cho_factor(K, lower=True)
            except Exception:
                return 1e10
            alpha = cho_solve((c, low), y_norm)
            val = 0.5 * float(y_norm @ alpha) + float(np.sum(np.log(np.diag(c))))
            return val + 1e-3 * float(np.sum(theta ** 2))

        res = minimize(
            nll, x0=np.log(np.array([1.0, 1.0, 0.1])),
            bounds=[(np.log(0.05), np.log(100.0)), (np.log(1e-3), np.log(10.0)), (np.log(1e-4), np.log(1.0))],
            method="L-BFGS-B",
        )
        ell, sf, sn = (float(v) for v in np.exp(res.x))
        K = make_kernel(ell, sf, sn)
        return {
            "Xn": Xn, "y": y_norm, "mean": y_mean, "std": y_std, "K": K,
            "params": (ell, sf, sn), "x_mean": x_mean, "x_std": x_std,
        }

    def _expected_improvement(self, gp, cand):
        if gp is None:
            return 0.0
        cand = np.asarray(cand, dtype=float)
        if cand.size != gp["x_mean"].size:
            return -1e9
        Xc = (cand[None, :] - gp["x_mean"]) / gp["x_std"]
        ell, sf, sn = gp["params"]
        Ks = (sf ** 2) * self._matern52(Xc, gp["Xn"], ell)
        c, low = cho_factor(gp["K"], lower=True)
        mu = float(Ks @ cho_solve((c, low), gp["y"]))
        v = (sf ** 2) - float(Ks @ cho_solve((c, low), Ks.T))
        s_dev = math.sqrt(max(v, 1e-12))
        best = float(np.max(gp["y"]))
        z = (mu - best) / s_dev
        return float((mu - best) * norm.cdf(z) + s_dev * norm.pdf(z))

    def _perturb_design(self, base_vec, scale: float = 0.08):
        n, m = int(self.cfg.num_contours), int(self.cfg.num_pts)
        arr = np.asarray(base_vec, dtype=float)
        if arr.size != 2 * n * m:
            return self._random_design()
        arr = arr.reshape(n, m, 2)
        out = []
        for k in range(n):
            blk = arr[k]
            cen = blk.mean(axis=0)
            rad = float(np.mean(np.hypot(blk[:, 0] - cen[0], blk[:, 1] - cen[1]))) or 1.0
            nb = blk + self.rng.normal(0.0, scale * rad, size=blk.shape)
            ang = np.arctan2(nb[:, 1] - cen[1], nb[:, 0] - cen[0])
            out.append(nb[np.argsort(ang)])
        return out

    def _propose(self):
        feas = [r for r in self.records if r.feasible]
        gp = self._fit_gp(
            np.array([r.x_repaired for r in feas]),
            np.array([r.obj_score for r in feas]),
        ) if len(feas) >= 2 else None
        best_vec = None
        if self.best_record is not None and np.asarray(self.best_record.x_repaired).size == self.dim:
            best_vec = np.asarray(self.best_record.x_repaired, dtype=float)
        best_design, best_ei = None, -1e18
        for k in range(24):
            use_local = (k % 2 == 0) and best_vec is not None
            design = self._perturb_design(best_vec, scale=0.10) if use_local else self._random_design()
            if not design:
                continue
            vec = np.array([v for c in design for p in np.asarray(c, dtype=float) for v in p], dtype=float)
            score = self._expected_improvement(gp, vec) if (gp is not None and vec.size == self.dim) else float(self.rng.random())
            if score > best_ei:
                best_ei = score
                best_design = design
        return best_design if best_design is not None else self._random_design()

    # -------------------------------------------------------------- 主流程
    def step_once(self) -> BOIterationRecord:
        idx = len(self.records)
        if idx < self.n_init_random:
            return self.evaluate_single_design(self._random_design(), iter_idx=idx, is_warmup=True)
        return self.evaluate_single_design(self._propose(), iter_idx=idx, is_warmup=False)

    def total_steps(self) -> int:
        return int(self.n_init_random + self.n_bo_iters)

    def render_convergence_to_image(self, w: int = 900, h: int = 650) -> np.ndarray:
        from matplotlib.figure import Figure
        from matplotlib.backends.backend_agg import FigureCanvasAgg
        fig = Figure(figsize=(w / 100.0, h / 100.0), dpi=100)
        FigureCanvasAgg(fig)
        ax = fig.add_subplot(111)
        ax.set_facecolor("#0a0a0a")
        fig.patch.set_facecolor("#0a0a0a")
        if self.records:
            it = np.array([r.iter_idx for r in self.records], dtype=float)
            sc = np.array([r.obj_score for r in self.records], dtype=float)
            best = np.maximum.accumulate(sc)
            warm = np.array([r.is_warmup for r in self.records], dtype=bool)
            ax.scatter(it[warm], sc[warm], c="#38bdf8", s=26, label="warmup", zorder=4)
            ax.scatter(it[~warm], sc[~warm], c="#f472b6", s=30, label="BO", zorder=4)
            ax.plot(it, best, color="#22c55e", lw=1.8, label="best-so-far", zorder=5)
            ax.set_xlabel("iteration", color="#cbd5e1", fontsize=8)
            ax.set_ylabel("objective  |dxy| - stress penalty", color="#cbd5e1", fontsize=8)
            ax.legend(facecolor="#181818", edgecolor="#444444", labelcolor="#dddddd", fontsize=7, loc="lower right")
        else:
            ax.text(0.5, 0.5, "Lamarckian BO: no data yet", color="#94a3b8",
                    ha="center", va="center", transform=ax.transAxes, fontsize=11)
        ax.tick_params(colors="#94a3b8", labelsize=7)
        for spine in ax.spines.values():
            spine.set_color("#334155")
        ax.set_title("Lamarckian Bayesian Optimization", color="#e2e8f0", fontsize=9)
        fig.tight_layout()
        fig.canvas.draw()
        buf = np.asarray(fig.canvas.buffer_rgba())
        return buf[:, :, :3][:, :, ::-1].copy()
