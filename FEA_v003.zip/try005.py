import math
import os
import re
import sys
import time
from dataclasses import dataclass, field
import numpy as np
import ezdxf
import matplotlib
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection, PolyCollection
from matplotlib.path import Path
from scipy.sparse import csc_matrix
from scipy.sparse.linalg import splu
from scipy.spatial import Delaunay, cKDTree
matplotlib.rcParams["font.sans-serif"] = ["Microsoft JhengHei", "SimHei", "Arial"]
matplotlib.rcParams["axes.unicode_minus"] = False


@dataclass
class ContourHyperParams:
    snap_tol: float = 1e-4
    angle_tol_rad: float = 1e-4
    min_seg_len: float = 1e-3
    gap_warn_tol: float = 0.15

@dataclass
class LineSegment:
    seg_id: int
    handle: str
    entity_type: str
    layer: str
    p1: tuple[float, float]
    p2: tuple[float, float]
    @property
    def length(self) -> float:
        return math.hypot(self.p2[0] - self.p1[0], self.p2[1] - self.p1[1])
    @property
    def direction(self) -> tuple[float, float]:
        L = self.length
        if L <= 1e-12:
            return (0.0, 0.0)
        dx = (self.p2[0] - self.p1[0]) / L
        dy = (self.p2[1] - self.p1[1]) / L
        if dx < -1e-9 or (abs(dx) <= 1e-9 and dy < 0):
            dx, dy = -dx, -dy
        return (dx, dy)

@dataclass
class ContourIssue:
    issue_id: int
    issue_type: str
    severity: str
    layer_a: str
    layer_b: str
    handles: list[str]
    marker_pts: list[tuple[float, float]]
    highlight_seg: tuple[tuple[float, float], tuple[float, float]] | None
    description: str
    focus_xy: tuple[float, float] = (0.0, 0.0)
    island_poly: list[tuple[float, float]] | None = None

@dataclass
class ContourCheckResult:
    dxf_path: str
    raw_line_segments: list[LineSegment] = field(default_factory=list)
    clean_line_segments: list[LineSegment] = field(default_factory=list)
    display_curve_segments: list[tuple[tuple[float, float], tuple[float, float], str]] = field(default_factory=list)
    issues: list[ContourIssue] = field(default_factory=list)
    node_coords: np.ndarray = field(default_factory=lambda: np.empty((0, 2)))
    node_degrees: np.ndarray = field(default_factory=lambda: np.empty(0, dtype=int))
    loops: list[dict] = field(default_factory=list)
    probe_circles: list[dict] = field(default_factory=list)
    @property
    def is_clean(self) -> bool:
        return not any(i.severity == "ERROR" for i in self.issues)
    def summary_dict(self) -> dict[str, int]:
        counts = {
            "DEGENERATE": 0,
            "EXACT_DUPLICATE": 0,
            "CONTAINMENT": 0,
            "PARTIAL_OVERLAP": 0,
            "HEAD_TO_TAIL": 0,
            "OPEN_ENDPOINT": 0,
            "MULTI_JUNCTION": 0,
            "MICRO_GAP": 0,
            "EXTERIOR_ISLAND": 0,
            "NESTED_ISLAND": 0,
            "LOOP_INTERSECT": 0,
        }
        for iss in self.issues:
            counts[iss.issue_type] = counts.get(iss.issue_type, 0) + 1
        return counts

class DXFContourHelper:
    PROBE_RE = re.compile(r"^PROBE(?:#|_)?(\d+)?$")
    VECTOR_RE = re.compile(r"^(DISP|FORCE)(?:#(\d+))?_X([+-]?\d+(?:\.\d+)?)Y([+-]?\d+(?:\.\d+)?)$")

    @staticmethod
    def parse_bc_layer_name(layer_name: str) -> dict:
        lname = str(layer_name).strip()
        u_name = lname.upper()
        if lname == "0":
            return {"type": "FREE", "x": 0.0, "y": 0.0, "unit": None}
        if u_name == "FIXED":
            return {"type": "FIXED", "x": 0.0, "y": 0.0, "unit": "mm"}
        m_probe = DXFContourHelper.PROBE_RE.match(u_name)
        if m_probe:
            idx = int(m_probe.group(1)) if m_probe.group(1) else 1
            return {
                "type": "PROBE",
                "probe_id": f"PROBE#{idx:03d}",
                "x": 0.0,
                "y": 0.0,
                "unit": "mm",
                "raw": lname,
            }
        m = DXFContourHelper.VECTOR_RE.match(u_name)
        if m:
            btype, seq_str, xs, ys = m.groups()
            seq = int(seq_str) if seq_str else None
            return {
                "type": btype,
                "seq": seq,
                "bc_id": f"{btype}#{seq:03d}" if seq is not None else btype,
                "x": float(xs),
                "y": float(ys),
                "unit": "mm" if btype == "DISP" else "gf",
            }
        return {"type": "CUSTOM", "x": 0.0, "y": 0.0, "unit": None, "raw": lname}

    @staticmethod
    def layer_priority(layer_name: str) -> int:
        btype = DXFContourHelper.parse_bc_layer_name(layer_name).get("type")
        if btype == "FREE":
            return 0
        if btype == "FIXED":
            return 10
        if btype == "PROBE":
            return 15
        if btype in ("DISP", "FORCE"):
            return 20
        return 1

    @staticmethod
    def parse_bc_layer(layer_name: str) -> dict:
        out = dict(DXFContourHelper.parse_bc_layer_name(layer_name))
        out["priority"] = DXFContourHelper.layer_priority(layer_name)
        if out.get("type") == "FREE":
            out["type"] = "FREE_CONTOUR"
        elif out.get("type") == "CUSTOM":
            out["type"] = "UNKNOWN"
        return out

    @staticmethod
    def extract_primitives_from_msp(msp) -> tuple[list[LineSegment], list[tuple], list[tuple], list[tuple], list[tuple]]:
        line_segs: list[LineSegment] = []
        curve_topology_edges: list[tuple[tuple[float, float], tuple[float, float], str, str]] = []
        display_curves: list[tuple[tuple[float, float], tuple[float, float], str]] = []
        arc_polys: list[tuple[np.ndarray, str, str]] = []
        circle_polys: list[tuple[np.ndarray, str, str]] = []
        seg_id = 0
        for ent in msp:
            etype = ent.dxftype()
            handle = ent.dxf.handle
            layer = ent.dxf.layer if ent.dxf.hasattr("layer") else "0"
            if etype == "LINE":
                p1 = (float(ent.dxf.start.x), float(ent.dxf.start.y))
                p2 = (float(ent.dxf.end.x), float(ent.dxf.end.y))
                line_segs.append(LineSegment(seg_id, handle, "LINE", layer, p1, p2))
                seg_id += 1
            elif etype == "LWPOLYLINE":
                try:
                    for sub in ent.virtual_entities():
                        stype = sub.dxftype()
                        if stype == "LINE":
                            p1 = (float(sub.dxf.start.x), float(sub.dxf.start.y))
                            p2 = (float(sub.dxf.end.x), float(sub.dxf.end.y))
                            line_segs.append(LineSegment(seg_id, handle, "LWPOLYLINE", layer, p1, p2))
                            seg_id += 1
                        elif stype == "ARC":
                            p1, p2, sub_segs = DXFContourHelper._sample_arc_entity(sub)
                            curve_topology_edges.append((p1, p2, handle, layer))
                            for s1, s2 in sub_segs:
                                display_curves.append((s1, s2, layer))
                            arc_polys.append((DXFContourHelper._segs_to_pts(sub_segs), handle, layer))
                except Exception:
                    pts = list(ent.get_points(format="xyb"))
                    n = len(pts)
                    if n >= 2:
                        num_edges = n if ent.closed else n - 1
                        for i in range(num_edges):
                            x1, y1, bulge = pts[i]
                            x2, y2, _ = pts[(i + 1) % n]
                            if abs(bulge) <= 1e-7:
                                line_segs.append(LineSegment(seg_id, handle, "LWPOLYLINE", layer, (float(x1), float(y1)), (float(x2), float(y2))))
                                seg_id += 1
                            else:
                                curve_topology_edges.append(((float(x1), float(y1)), (float(x2), float(y2)), handle, layer))
                                arc_polys.append((np.array([[float(x1), float(y1)], [float(x2), float(y2)]]), handle, layer))
            elif etype == "ARC":
                p1, p2, sub_segs = DXFContourHelper._sample_arc_entity(ent)
                curve_topology_edges.append((p1, p2, handle, layer))
                for s1, s2 in sub_segs:
                    display_curves.append((s1, s2, layer))
                arc_polys.append((DXFContourHelper._segs_to_pts(sub_segs), handle, layer))
            elif etype == "CIRCLE":
                cx, cy = float(ent.dxf.center.x), float(ent.dxf.center.y)
                r = float(ent.dxf.radius)
                angles = np.linspace(0.0, 2.0 * math.pi, 49)
                pts = np.column_stack([cx + r * np.cos(angles), cy + r * np.sin(angles)])
                for k in range(len(pts) - 1):
                    display_curves.append(((float(pts[k, 0]), float(pts[k, 1])), (float(pts[k + 1, 0]), float(pts[k + 1, 1])), layer))
                circle_polys.append((pts, handle, layer))
        return line_segs, curve_topology_edges, display_curves, arc_polys, circle_polys

    @staticmethod
    def _segs_to_pts(sub_segs: list[tuple]) -> np.ndarray:
        if not sub_segs:
            return np.empty((0, 2))
        return np.array([sub_segs[0][0]] + [s[1] for s in sub_segs], dtype=float)

    @staticmethod
    def _sample_arc_entity(arc_ent) -> tuple[tuple[float, float], tuple[float, float], list[tuple]]:
        cx, cy = float(arc_ent.dxf.center.x), float(arc_ent.dxf.center.y)
        r = float(arc_ent.dxf.radius)
        a1 = float(arc_ent.dxf.start_angle)
        a2 = float(arc_ent.dxf.end_angle)
        span = (a2 - a1) % 360.0
        if span <= 1e-6:
            span = 360.0
        steps = max(int(span / 7.5), 8)
        angs = np.radians(a1 + np.linspace(0.0, span, steps + 1))
        pts = np.column_stack([cx + r * np.cos(angs), cy + r * np.sin(angs)])
        p_start = (float(pts[0, 0]), float(pts[0, 1]))
        p_end = (float(pts[-1, 0]), float(pts[-1, 1]))
        segs = [((float(pts[k, 0]), float(pts[k, 1])), (float(pts[k + 1, 0]), float(pts[k + 1, 1]))) for k in range(len(pts) - 1)]
        return p_start, p_end, segs

    @staticmethod
    def _point_to_line_dist(pt: tuple[float, float], line_p1: tuple[float, float], u: tuple[float, float]) -> float:
        vx = pt[0] - line_p1[0]
        vy = pt[1] - line_p1[1]
        return abs(vx * u[1] - vy * u[0])

    @classmethod
    def check_dxf(
        cls,
        dxf_source: str | object,
        hp: ContourHyperParams | None = None,
    ) -> ContourCheckResult:
        if hp is None:
            hp = ContourHyperParams()
        if isinstance(dxf_source, str):
            doc = ezdxf.readfile(dxf_source)
            dxf_name = dxf_source
        else:
            doc = dxf_source
            dxf_name = "<in-memory-doc>"
        msp = doc.modelspace()
        raw_lines, curve_edges, disp_curves, arc_polys, circle_polys = cls.extract_primitives_from_msp(msp)
        issues: list[ContourIssue] = []
        valid_lines: list[LineSegment] = []
        issue_seq = 1
        for seg in raw_lines:
            if seg.length <= hp.min_seg_len:
                issues.append(
                    ContourIssue(
                        issue_id=issue_seq,
                        issue_type="DEGENERATE",
                        severity="ERROR",
                        layer_a=seg.layer,
                        layer_b="",
                        handles=[seg.handle],
                        marker_pts=[seg.p1],
                        highlight_seg=None,
                        description=f"退化零長線段 #{seg.handle} (Layer={seg.layer}, Len={seg.length:.2e})",
                        focus_xy=seg.p1,
                    )
                )
                issue_seq += 1
            else:
                valid_lines.append(seg)
        n = len(valid_lines)
        for i in range(n):
            sa = valid_lines[i]
            u = sa.direction
            for j in range(i + 1, n):
                sb = valid_lines[j]
                v = sb.direction
                cross = abs(u[0] * v[1] - u[1] * v[0])
                if cross > hp.angle_tol_rad:
                    continue
                d1 = cls._point_to_line_dist(sb.p1, sa.p1, u)
                d2 = cls._point_to_line_dist(sb.p2, sa.p1, u)
                if max(d1, d2) > hp.snap_tol:
                    continue
                def proj(pt: tuple[float, float]) -> float:
                    return (pt[0] - sa.p1[0]) * u[0] + (pt[1] - sa.p1[1]) * u[1]
                def unproj(t_val: float) -> tuple[float, float]:
                    return (sa.p1[0] + t_val * u[0], sa.p1[1] + t_val * u[1])
                a_min, a_max = sorted([proj(sa.p1), proj(sa.p2)])
                b_min, b_max = sorted([proj(sb.p1), proj(sb.p2)])
                inter_min = max(a_min, b_min)
                inter_max = min(a_max, b_max)
                overlap = inter_max - inter_min
                if overlap < -hp.snap_tol:
                    continue
                ov_p1 = unproj(inter_min)
                ov_p2 = unproj(inter_max)
                ov_mid = ((ov_p1[0] + ov_p2[0]) * 0.5, (ov_p1[1] + ov_p2[1]) * 0.5)
                if abs(overlap) <= hp.snap_tol:
                    issues.append(
                        ContourIssue(
                            issue_id=issue_seq,
                            issue_type="HEAD_TO_TAIL",
                            severity="INFO",
                            layer_a=sa.layer,
                            layer_b=sb.layer,
                            handles=[sa.handle, sb.handle],
                            marker_pts=[ov_p1],
                            highlight_seg=None,
                            description=f"共線端點相接 #{sa.handle}({sa.layer}) & #{sb.handle}({sb.layer}) @ ({ov_p1[0]:.2f},{ov_p1[1]:.2f})",
                            focus_xy=ov_p1,
                        )
                    )
                    issue_seq += 1
                    continue
                same_min = abs(a_min - b_min) <= hp.snap_tol
                same_max = abs(a_max - b_max) <= hp.snap_tol
                if same_min and same_max:
                    itype = "EXACT_DUPLICATE"
                    desc = f"完全重疊 #{sa.handle}({sa.layer}) == #{sb.handle}({sb.layer}), Len={overlap:.2f}"
                elif (a_min - hp.snap_tol <= b_min) and (b_max <= a_max + hp.snap_tol):
                    itype = "CONTAINMENT"
                    desc = f"包含重疊 長#{sa.handle}({sa.layer}) 蓋住 短#{sb.handle}({sb.layer}), Len={overlap:.2f}"
                elif (b_min - hp.snap_tol <= a_min) and (a_max <= b_max + hp.snap_tol):
                    itype = "CONTAINMENT"
                    desc = f"包含重疊 長#{sb.handle}({sb.layer}) 蓋住 短#{sa.handle}({sa.layer}), Len={overlap:.2f}"
                else:
                    itype = "PARTIAL_OVERLAP"
                    desc = f"部分交錯重疊 #{sa.handle}({sa.layer}) & #{sb.handle}({sb.layer}), Len={overlap:.2f}"
                issues.append(
                    ContourIssue(
                        issue_id=issue_seq,
                        issue_type=itype,
                        severity="ERROR",
                        layer_a=sa.layer,
                        layer_b=sb.layer,
                        handles=[sa.handle, sb.handle],
                        marker_pts=[ov_p1, ov_p2],
                        highlight_seg=(ov_p1, ov_p2),
                        description=desc,
                        focus_xy=ov_mid,
                    )
                )
                issue_seq += 1
        clean_lines = cls.split_and_dedup_lines(valid_lines, hp=hp)
        node_coords, node_degrees, topo_issues = cls._check_endpoint_topology(clean_lines, curve_edges, hp, issue_seq)
        issues.extend(topo_issues)
        probe_circles = []
        solid_circles = []
        for pts, handle, layer in circle_polys:
            info = cls.parse_bc_layer(layer)
            if info.get("type") == "PROBE":
                arr = np.asarray(pts, dtype=float)
                if len(arr) >= 3:
                    cx = float(arr[:, 0].mean())
                    cy = float(arr[:, 1].mean())
                    r = float(np.mean(np.hypot(arr[:, 0] - cx, arr[:, 1] - cy)))
                    probe_circles.append({
                        "probe_id": info.get("probe_id", "PROBE#001"),
                        "layer": layer,
                        "handle": handle,
                        "center": (cx, cy),
                        "radius": r,
                    })
            else:
                solid_circles.append((pts, handle, layer))
        loops, island_issues = cls._assemble_and_classify_loops(
            clean_lines, arc_polys + solid_circles, hp, issue_seq + len(topo_issues)
        )
        issues.extend(island_issues)
        return ContourCheckResult(
            dxf_path=dxf_name,
            raw_line_segments=raw_lines,
            clean_line_segments=clean_lines,
            display_curve_segments=disp_curves,
            issues=issues,
            node_coords=node_coords,
            node_degrees=node_degrees,
            loops=loops,
            probe_circles=probe_circles,
        )

    @classmethod
    def split_and_dedup_lines(
        cls,
        segments: list[LineSegment],
        hp: ContourHyperParams | None = None,
    ) -> list[LineSegment]:
        if hp is None:
            hp = ContourHyperParams()
        valid = [s for s in segments if s.length > hp.min_seg_len]
        if not valid:
            return []
        used = [False] * len(valid)
        groups: list[list[LineSegment]] = []
        for i in range(len(valid)):
            if used[i]:
                continue
            sa = valid[i]
            u = sa.direction
            grp = [sa]
            used[i] = True
            for j in range(i + 1, len(valid)):
                if used[j]:
                    continue
                sb = valid[j]
                v = sb.direction
                if abs(u[0] * v[1] - u[1] * v[0]) <= hp.angle_tol_rad:
                    d1 = cls._point_to_line_dist(sb.p1, sa.p1, u)
                    d2 = cls._point_to_line_dist(sb.p2, sa.p1, u)
                    if max(d1, d2) <= hp.snap_tol:
                        grp.append(sb)
                        used[j] = True
            groups.append(grp)
        result: list[LineSegment] = []
        new_id = 0
        for grp in groups:
            if len(grp) == 1:
                s = grp[0]
                result.append(LineSegment(new_id, s.handle, s.entity_type, s.layer, s.p1, s.p2))
                new_id += 1
                continue
            ref = grp[0]
            u = ref.direction
            origin = ref.p1
            def proj(pt: tuple[float, float]) -> float:
                return (pt[0] - origin[0]) * u[0] + (pt[1] - origin[1]) * u[1]
            def unproj(t_val: float) -> tuple[float, float]:
                return (origin[0] + t_val * u[0], origin[1] + t_val * u[1])
            raw_t = []
            intervals = []
            for s in grp:
                t1, t2 = sorted([proj(s.p1), proj(s.p2)])
                raw_t.extend([t1, t2])
                intervals.append((t1, t2, cls.layer_priority(s.layer), s))
            raw_t.sort()
            uniq_t = [raw_t[0]]
            for tv in raw_t[1:]:
                if tv - uniq_t[-1] > hp.snap_tol:
                    uniq_t.append(tv)
                else:
                    uniq_t[-1] = 0.5 * (uniq_t[-1] + tv)
            elem_segs: list[LineSegment] = []
            for k in range(len(uniq_t) - 1):
                ta, tb = uniq_t[k], uniq_t[k + 1]
                if tb - ta <= hp.min_seg_len:
                    continue
                t_mid = 0.5 * (ta + tb)
                covering = [iv for iv in intervals if (iv[0] - hp.snap_tol <= t_mid <= iv[1] + hp.snap_tol)]
                if not covering:
                    continue
                covering.sort(key=lambda x: (x[2], -x[3].seg_id), reverse=True)
                winner = covering[0][3]
                elem_segs.append(
                    LineSegment(
                        new_id,
                        winner.handle,
                        winner.entity_type,
                        winner.layer,
                        unproj(ta),
                        unproj(tb),
                    )
                )
                new_id += 1
            merged_grp: list[LineSegment] = []
            for es in elem_segs:
                if (
                    merged_grp
                    and merged_grp[-1].layer == es.layer
                    and merged_grp[-1].handle == es.handle
                    and math.hypot(merged_grp[-1].p2[0] - es.p1[0], merged_grp[-1].p2[1] - es.p1[1]) <= hp.snap_tol
                ):
                    prev = merged_grp[-1]
                    merged_grp[-1] = LineSegment(prev.seg_id, prev.handle, prev.entity_type, prev.layer, prev.p1, es.p2)
                else:
                    merged_grp.append(es)
            result.extend(merged_grp)
        return result

    @classmethod
    def _check_endpoint_topology(
        cls,
        line_segs: list[LineSegment],
        curve_edges: list[tuple],
        hp: ContourHyperParams,
        start_issue_id: int,
    ) -> tuple[np.ndarray, np.ndarray, list[ContourIssue]]:
        raw_pts = []
        edge_Work = []
        for s in line_segs:
            i1 = len(raw_pts)
            raw_pts.append(s.p1)
            i2 = len(raw_pts)
            raw_pts.append(s.p2)
            edge_Work.append((i1, i2, s.handle, s.layer))
        for p1, p2, h, lyr in curve_edges:
            i1 = len(raw_pts)
            raw_pts.append(p1)
            i2 = len(raw_pts)
            raw_pts.append(p2)
            edge_Work.append((i1, i2, h, lyr))
        if not raw_pts:
            return np.empty((0, 2)), np.empty(0, dtype=int), []
        pts_arr = np.array(raw_pts, dtype=float)
        parent = list(range(len(pts_arr)))

        def _find(a):
            while parent[a] != a:
                parent[a] = parent[parent[a]]
                a = parent[a]
            return a

        if len(pts_arr) > 1:
            pairs = cKDTree(pts_arr).query_pairs(r=hp.snap_tol, output_type="ndarray")
            for a, b in pairs:
                ra, rb = _find(int(a)), _find(int(b))
                if ra != rb:
                    parent[rb] = ra
        root_node: dict[int, int] = {}
        root_coord: dict[int, np.ndarray] = {}
        pt_to_node = np.zeros(len(pts_arr), dtype=int)
        for idx in range(len(pts_arr)):
            r = _find(idx)
            if r not in root_node:
                root_node[r] = len(root_node)
                root_coord[r] = pts_arr[idx]
            pt_to_node[idx] = root_node[r]
        nodes = np.array(
            [root_coord[r] for r in sorted(root_node, key=lambda k: root_node[k])], dtype=float
        )
        degrees = np.zeros(len(nodes), dtype=int)
        node_handles: dict[int, list[str]] = {i: [] for i in range(len(nodes))}
        node_layers: dict[int, list[str]] = {i: [] for i in range(len(nodes))}
        for i1, i2, h, lyr in edge_Work:
            u_id = int(pt_to_node[i1])
            v_id = int(pt_to_node[i2])
            if u_id == v_id:
                continue
            degrees[u_id] += 1
            degrees[v_id] += 1
            node_handles[u_id].append(h)
            node_handles[v_id].append(h)
            node_layers[u_id].append(lyr)
            node_layers[v_id].append(lyr)
        topo_issues: list[ContourIssue] = []
        seq = start_issue_id
        open_node_ids = []
        for nid, deg in enumerate(degrees):
            pt = (float(nodes[nid, 0]), float(nodes[nid, 1]))
            h_list = sorted(set(node_handles[nid]))
            l_list = sorted(set(node_layers[nid]))
            l_a = l_list[0] if l_list else "0"
            l_b = l_list[1] if len(l_list) > 1 else l_a
            if deg == 1:
                open_node_ids.append(nid)
                topo_issues.append(
                    ContourIssue(
                        issue_id=seq,
                        issue_type="OPEN_ENDPOINT",
                        severity="ERROR",
                        layer_a=l_a,
                        layer_b="",
                        handles=h_list,
                        marker_pts=[pt],
                        highlight_seg=None,
                        description=f"懸空未閉合端點 (Degree=1) @ ({pt[0]:.2f}, {pt[1]:.2f}), 圖元={h_list}",
                        focus_xy=pt,
                    )
                )
                seq += 1
            elif deg >= 3:
                topo_issues.append(
                    ContourIssue(
                        issue_id=seq,
                        issue_type="MULTI_JUNCTION",
                        severity="WARNING",
                        layer_a=l_a,
                        layer_b=l_b,
                        handles=h_list,
                        marker_pts=[pt],
                        highlight_seg=None,
                        description=f"多重交會點/T字點 (Degree={deg}) @ ({pt[0]:.2f}, {pt[1]:.2f}), 圖元={h_list}",
                        focus_xy=pt,
                    )
                )
                seq += 1
        for a_idx in range(len(open_node_ids)):
            na = open_node_ids[a_idx]
            pa = nodes[na]
            for b_idx in range(a_idx + 1, len(open_node_ids)):
                nb = open_node_ids[b_idx]
                pb = nodes[nb]
                # 同一條懸空碎線的兩端不算「縫隙」，避免與 OPEN_ENDPOINT 重複告警
                if set(node_handles[na]) & set(node_handles[nb]):
                    continue
                dist = float(math.hypot(pa[0] - pb[0], pa[1] - pb[1]))
                if hp.snap_tol < dist <= hp.gap_warn_tol:
                    p1 = (float(pa[0]), float(pa[1]))
                    p2 = (float(pb[0]), float(pb[1]))
                    mid = ((p1[0] + p2[0]) * 0.5, (p1[1] + p2[1]) * 0.5)
                    topo_issues.append(
                        ContourIssue(
                            issue_id=seq,
                            issue_type="MICRO_GAP",
                            severity="ERROR",
                            layer_a="",
                            layer_b="",
                            handles=sorted(set(node_handles[na] + node_handles[nb])),
                            marker_pts=[p1, p2],
                            highlight_seg=(p1, p2),
                            description=f"微小未接縫隙 Gap={dist:.4f} mm @ ({mid[0]:.2f}, {mid[1]:.2f})",
                            focus_xy=mid,
                        )
                    )
                    seq += 1
        return nodes, degrees, topo_issues

    @classmethod
    def _assemble_and_classify_loops(
        cls,
        clean_lines: list[LineSegment],
        arc_polys: list[tuple],
        hp: ContourHyperParams,
        start_issue_id: int,
    ) -> tuple[list[dict], list[ContourIssue]]:
        """將直線段與圓弧/圓頂點序列串成封閉迴圈，並以包含深度 (Nesting Depth) 判定孤島。"""
        edges = []
        for s in clean_lines:
            edges.append({
                "pts": [(float(s.p1[0]), float(s.p1[1])), (float(s.p2[0]), float(s.p2[1]))],
                "handles": {s.handle},
                "layers": {s.layer},
            })
        for pts, handle, layer in arc_polys:
            arr = np.asarray(pts, dtype=float)
            if len(arr) < 2:
                continue
            edges.append({
                "pts": [(float(p[0]), float(p[1])) for p in arr],
                "handles": {handle},
                "layers": {layer},
            })

        def _dist(a, b):
            return math.hypot(a[0] - b[0], a[1] - b[1])

        closed_polys = []
        open_edges = []
        for e in edges:
            p = e["pts"]
            if len(p) >= 4 and _dist(p[0], p[-1]) <= hp.snap_tol:
                closed_polys.append({"pts": p, "handles": set(e["handles"]), "layers": set(e["layers"])})
            else:
                open_edges.append(e)

        used = [False] * len(open_edges)
        for i in range(len(open_edges)):
            if used[i]:
                continue
            cur = list(open_edges[i]["pts"])
            h_set = set(open_edges[i]["handles"])
            l_set = set(open_edges[i]["layers"])
            used[i] = True
            while True:
                if len(cur) >= 3 and _dist(cur[0], cur[-1]) <= hp.snap_tol:
                    closed_polys.append({"pts": cur, "handles": h_set, "layers": l_set})
                    break
                tail = cur[-1]
                found = -1
                reversed_edge = False
                for j, e in enumerate(open_edges):
                    if used[j]:
                        continue
                    p = e["pts"]
                    if _dist(p[0], tail) <= hp.snap_tol:
                        found = j
                        reversed_edge = False
                        break
                    if _dist(p[-1], tail) <= hp.snap_tol:
                        found = j
                        reversed_edge = True
                        break
                if found < 0:
                    break
                e = open_edges[found]
                used[found] = True
                seg = list(reversed(e["pts"])) if reversed_edge else list(e["pts"])
                cur.extend(seg[1:])
                h_set |= e["handles"]
                l_set |= e["layers"]

        if not closed_polys:
            return [], []

        for poly in closed_polys:
            pts = np.asarray(poly["pts"], dtype=float)
            x, y = pts[:, 0], pts[:, 1]
            poly["area"] = 0.5 * abs(float(np.dot(x, np.roll(y, -1)) - np.dot(y, np.roll(x, -1))))
            poly["path"] = Path(pts, closed=True)
        closed_polys.sort(key=lambda p: p["area"], reverse=True)

        loops = []
        island_issues = []
        seq = start_issue_id
        for i, poly in enumerate(closed_polys):
            pts = np.asarray(poly["pts"], dtype=float)
            if len(pts) >= 2 and _dist(poly["pts"][0], poly["pts"][-1]) <= hp.snap_tol:
                pts = pts[:-1]
            mid_pts = 0.5 * (pts + np.roll(pts, -1, axis=0))
            parents = []
            intersect_pairs = []
            for p in range(i):
                inside_mask = closed_polys[p]["path"].contains_points(mid_pts, radius=1e-5)
                ratio_in = float(np.mean(inside_mask)) if len(inside_mask) else 0.0
                if ratio_in > 0.98:
                    parents.append(p)
                elif 0.02 <= ratio_in <= 0.98:
                    intersect_pairs.append((p, ratio_in))
            depth = len(parents)
            parent_id = parents[-1] if depth > 0 else None
            if i == 0:
                role = "OUTER_BOUNDARY"
            elif depth == 0:
                role = "EXTERIOR_ISLAND"
            elif depth == 1 and parent_id == 0:
                role = "INNER_HOLE"
            else:
                role = "NESTED_ISLAND"
            center = (float(pts[:, 0].mean()), float(pts[:, 1].mean()))
            layers = sorted(poly["layers"])
            handles = sorted(poly["handles"])
            loops.append({
                "index": i,
                "role": role,
                "area": poly["area"],
                "depth": depth,
                "handles": handles,
                "layers": layers,
                "center": center,
                "pts": pts,
            })
            if role in ("EXTERIOR_ISLAND", "NESTED_ISLAND"):
                island_issues.append(
                    ContourIssue(
                        issue_id=seq,
                        issue_type=role,
                        severity="ERROR",
                        layer_a=(layers[0] if layers else ""),
                        layer_b="",
                        handles=handles,
                        marker_pts=[center],
                        highlight_seg=None,
                        description=(
                            f"{'外框外的分離孤島' if role == 'EXTERIOR_ISLAND' else '孔洞中的懸浮孤島'} "
                            f"(Depth={depth}, Area={poly['area']:.2f}) @ ({center[0]:.2f}, {center[1]:.2f}), "
                            f"圖元={handles}"
                        ),
                        focus_xy=center,
                        island_poly=[(float(p[0]), float(p[1])) for p in pts],
                    )
                )
                seq += 1
            for p_idx, ratio_in in intersect_pairs:
                other = loops[p_idx] if p_idx < len(loops) else None
                other_handles = other["handles"] if other else []
                island_issues.append(
                    ContourIssue(
                        issue_id=seq,
                        issue_type="LOOP_INTERSECT",
                        severity="ERROR",
                        layer_a=(layers[0] if layers else ""),
                        layer_b=(other["layers"][0] if other and other["layers"] else ""),
                        handles=sorted(set(handles) | set(other_handles)),
                        marker_pts=[center],
                        highlight_seg=None,
                        description=(
                            f"迴圈交叉刺穿 (與迴圈#{p_idx} 邊中點在內比例 {ratio_in * 100:.1f}%) "
                            f"@ ({center[0]:.2f}, {center[1]:.2f})"
                        ),
                        focus_xy=center,
                        island_poly=[(float(p[0]), float(p[1])) for p in pts],
                    )
                )
                seq += 1
        return loops, island_issues

    @classmethod
    def plot_check_result(
        cls,
        result: ContourCheckResult,
        ax=None,
        show_clean_endpoints: bool = True,
    ):
        created_fig = None
        if ax is None:
            created_fig, ax = plt.subplots(figsize=(10, 6.5))
        ax.clear()
        ax.set_facecolor("#0a0a0a")
        if ax.figure is not None:
            ax.figure.patch.set_facecolor("#0a0a0a")
        bg_segs = [(s.p1, s.p2) for s in result.raw_line_segments]
        for c1, c2, _ in result.display_curve_segments:
            bg_segs.append((c1, c2))
        if bg_segs:
            bg_col = LineCollection(bg_segs, colors="#555555", linewidths=1.2, zorder=2)
            ax.add_collection(bg_col)
        if show_clean_endpoints and len(result.node_coords) > 0:
            ok_mask = result.node_degrees == 2
            if np.any(ok_mask):
                ok_pts = result.node_coords[ok_mask]
                ax.scatter(ok_pts[:, 0], ok_pts[:, 1], c="#22aa55", s=14, alpha=0.75, zorder=4, label="Closed Node (Deg=2)")
        ov_segs = []
        ov_pts = []
        open_pts = []
        junc_pts = []
        gap_pts = []
        island_polys = []
        island_pts = []
        intersect_polys = []
        intersect_pts = []
        for iss in result.issues:
            if iss.issue_type in ("EXACT_DUPLICATE", "CONTAINMENT", "PARTIAL_OVERLAP"):
                if iss.highlight_seg is not None:
                    ov_segs.append(iss.highlight_seg)
                ov_pts.extend(iss.marker_pts)
            elif iss.issue_type == "OPEN_ENDPOINT":
                open_pts.extend(iss.marker_pts)
            elif iss.issue_type == "MULTI_JUNCTION":
                junc_pts.extend(iss.marker_pts)
            elif iss.issue_type in ("DEGENERATE", "MICRO_GAP"):
                gap_pts.extend(iss.marker_pts)
            elif iss.issue_type in ("EXTERIOR_ISLAND", "NESTED_ISLAND"):
                if iss.island_poly:
                    island_polys.append(np.asarray(iss.island_poly, dtype=float))
                island_pts.extend(iss.marker_pts)
            elif iss.issue_type == "LOOP_INTERSECT":
                if iss.island_poly:
                    intersect_polys.append(np.asarray(iss.island_poly, dtype=float))
                intersect_pts.extend(iss.marker_pts)
        if island_polys:
            island_col = PolyCollection(
                island_polys,
                facecolors="#00ffff", edgecolors="#00ffff",
                alpha=0.28, linestyles="dashed", zorder=7,
                label="Island (Floating)",
            )
            ax.add_collection(island_col)
        if island_pts:
            arr = np.array(island_pts, dtype=float)
            ax.scatter(arr[:, 0], arr[:, 1], s=190, facecolors="none", edgecolors="#00ffff", linewidths=2.4, zorder=14, label="Island Center")
            ax.scatter(arr[:, 0], arr[:, 1], s=90, c="#00ffff", marker="x", linewidths=2.0, zorder=14)
        if intersect_polys:
            inter_col = PolyCollection(
                intersect_polys,
                facecolors="none", edgecolors="#ffcc00",
                linestyles="dashed", linewidths=2.2, zorder=9,
                label="Loop Intersect",
            )
            ax.add_collection(inter_col)
        if intersect_pts:
            arr = np.array(intersect_pts, dtype=float)
            ax.scatter(arr[:, 0], arr[:, 1], s=170, facecolors="none", edgecolors="#ffcc00", marker="D", linewidths=2.2, zorder=15, label="Loop Intersect Center")
        for probe in (result.probe_circles or []):
            cx, cy = probe["center"]
            r = float(probe.get("radius", 0.0))
            if r > 0:
                th = np.linspace(0.0, 2.0 * math.pi, 49)
                ax.plot(cx + r * np.cos(th), cy + r * np.sin(th), color="#00ff88", lw=1.8, ls="--", zorder=16)
            ax.plot([cx], [cy], marker="+", markersize=12, color="#00ff88", mew=2.0, zorder=16)
            ax.annotate(
                str(probe.get("probe_id", "PROBE")), xy=(cx, cy), xytext=(cx + 2.0, cy + 2.0),
                color="#00ff88", fontsize=8, zorder=17,
            )
        if ov_segs:
            ov_col = LineCollection(ov_segs, colors="#ff00ff", linewidths=4.8, alpha=0.85, zorder=8, label="Overlap Segment")
            ax.add_collection(ov_col)
        if ov_pts:
            arr = np.array(ov_pts, dtype=float)
            ax.scatter(arr[:, 0], arr[:, 1], s=130, facecolors="none", edgecolors="#ff00ff", linewidths=2.2, zorder=11, label="Overlap Endpoint")
        if open_pts:
            arr = np.array(open_pts, dtype=float)
            ax.scatter(arr[:, 0], arr[:, 1], s=170, facecolors="none", edgecolors="#ff2244", linewidths=2.5, zorder=12, label="Open Endpoint (Deg=1)")
            ax.scatter(arr[:, 0], arr[:, 1], s=50, c="#ff2244", marker="+", linewidths=1.8, zorder=12)
        if junc_pts:
            arr = np.array(junc_pts, dtype=float)
            ax.scatter(arr[:, 0], arr[:, 1], s=150, facecolors="none", edgecolors="#ff9900", marker="o", linewidths=2.2, zorder=10, label="Multi-Junction (Deg>=3)")
        if gap_pts:
            arr = np.array(gap_pts, dtype=float)
            ax.scatter(arr[:, 0], arr[:, 1], s=160, facecolors="none", edgecolors="#ffff00", marker="D", linewidths=2.2, zorder=13, label="Micro-Gap / Degenerate")
        counts = result.summary_dict()
        n_ov = counts["EXACT_DUPLICATE"] + counts["CONTAINMENT"] + counts["PARTIAL_OVERLAP"]
        status_color = "#00ff88" if result.is_clean else "#ff3355"
        hud_text = (
            f"STATUS: {'CLEAN (PASS)' if result.is_clean else 'ISSUES FOUND'}\n"
            f"Raw Lines: {len(result.raw_line_segments)} -> Clean Lines: {len(result.clean_line_segments)}   |   "
            f"Overlaps(Purple): {n_ov}   |   Open Ends(Red): {counts['OPEN_ENDPOINT']}   |   "
            f"Junctions(Orange): {counts['MULTI_JUNCTION']}   |   Gaps(Yellow): {counts['MICRO_GAP'] + counts['DEGENERATE']}   |   "
            f"Islands(Cyan): {counts['EXTERIOR_ISLAND'] + counts['NESTED_ISLAND']}   |   "
            f"Loop X(Yellow): {counts['LOOP_INTERSECT']}"
        )
        ax.text(
            0.015, 0.975, hud_text, transform=ax.transAxes,
            color=status_color, fontsize=9.5, fontweight="bold", va="top", ha="left", zorder=20,
            bbox=dict(boxstyle="round,pad=0.35", facecolor="#161616", edgecolor="#444444", alpha=0.92),
        )
        ax.set_aspect("equal", adjustable="box")
        if bg_segs:
            all_xy = np.vstack([np.array(bg_segs).reshape(-1, 2)])
            xmin, ymin = all_xy.min(axis=0)
            xmax, ymax = all_xy.max(axis=0)
            dx = max(xmax - xmin, 10.0) * 0.12
            dy = max(ymax - ymin, 10.0) * 0.12
            ax.set_xlim(xmin - dx, xmax + dx)
            ax.set_ylim(ymin - dy, ymax + dy)
        handles_leg, labels_leg = ax.get_legend_handles_labels()
        if handles_leg:
            ax.legend(loc="lower right", facecolor="#181818", edgecolor="#444444", labelcolor="#dddddd", fontsize=8)
        return created_fig, ax

@dataclass
class MeshHyperParams:
    h_max: float = 3.0
    h_min: float = 0.45
    gradation: float = 0.25
    snap_tol: float = 1e-2
    smooth_iter: int = 4
    auto_density: bool = True

class FiniteEleMeshHelper:
    @staticmethod
    def _polygon_area_signed(pts: np.ndarray) -> float:
        x, y = pts[:, 0], pts[:, 1]
        return 0.5 * float(np.dot(x, np.roll(y, -1)) - np.dot(y, np.roll(x, -1)))

    @staticmethod
    def _polygon_area(pts: np.ndarray) -> float:
        return abs(FiniteEleMeshHelper._polygon_area_signed(pts))

    @classmethod
    def _dedup_with_edge_layers(cls, pts, layers, tol: float = 1e-6):
        pts = np.asarray(pts, dtype=float)
        layers = list(layers)
        n = len(pts)
        if n < 2:
            return pts, layers
        keep_pts = [0]
        keep_lays = []
        for i in range(1, n):
            d = float(np.linalg.norm(pts[i] - pts[keep_pts[-1]]))
            if d <= tol:
                continue
            keep_pts.append(i)
            keep_lays.append(layers[i - 1] if i - 1 < len(layers) else (layers[-1] if layers else "0"))
        res = pts[keep_pts]
        if len(res) > 1 and float(np.linalg.norm(res[0] - res[-1])) <= tol:
            res = res[:-1]
        while len(keep_lays) < len(res):
            keep_lays.append(keep_lays[-1] if keep_lays else "0")
        keep_lays = keep_lays[: len(res)]
        return res, keep_lays

    @classmethod
    def _chain_segments_with_layers(cls, segments: list[tuple], snap_tol: float = 1e-3) -> list[tuple]:
        chains = []
        used = [False] * len(segments)
        for i in range(len(segments)):
            if used[i]:
                continue
            pts = [np.asarray(p, dtype=float) for p in segments[i][0]]
            lay = segments[i][1]
            lays = [lay] * (len(pts) - 1)
            used[i] = True
            changed = True
            while changed:
                changed = False
                if len(pts) >= 4 and float(np.linalg.norm(pts[0] - pts[-1])) <= snap_tol:
                    break
                for j in range(len(segments)):
                    if used[j]:
                        continue
                    seg_pts = [np.asarray(p, dtype=float) for p in segments[j][0]]
                    seg_lay = segments[j][1]
                    add_lays = [seg_lay] * (len(seg_pts) - 1)
                    if np.linalg.norm(pts[-1] - seg_pts[0]) <= snap_tol:
                        pts.extend(seg_pts[1:])
                        lays.extend(add_lays)
                        used[j] = True
                        changed = True
                        break
                    if np.linalg.norm(pts[-1] - seg_pts[-1]) <= snap_tol:
                        pts.extend(seg_pts[-2::-1])
                        lays.extend(add_lays)
                        used[j] = True
                        changed = True
                        break
                    if np.linalg.norm(pts[0] - seg_pts[-1]) <= snap_tol:
                        pts = seg_pts[:-1] + pts
                        lays = add_lays + lays
                        used[j] = True
                        changed = True
                        break
                    if np.linalg.norm(pts[0] - seg_pts[0]) <= snap_tol:
                        pts = seg_pts[:0:-1] + pts
                        lays = add_lays + lays
                        used[j] = True
                        changed = True
                        break
            arr = np.array(pts, dtype=float)
            arr, lays = cls._dedup_with_edge_layers(arr, lays, tol=snap_tol)
            if len(arr) >= 3:
                chains.append((arr, lays))
        return chains

    @staticmethod
    def _reverse_loop_with_layers(loop: np.ndarray, layers: list) -> tuple[np.ndarray, list]:
        n = len(loop)
        new_loop = loop[::-1].copy()
        new_layers = [layers[(n - 2 - j) % n] for j in range(n)]
        return new_loop, new_layers

    @classmethod
    def read_dxf_loops(cls, dxf_source, hp: "MeshHyperParams | None" = None) -> dict:
        if hp is None:
            hp = MeshHyperParams()
        if isinstance(dxf_source, str):
            doc = ezdxf.readfile(dxf_source)
            src_name = dxf_source
        else:
            doc = dxf_source
            src_name = "<in-memory-doc>"
        msp = doc.modelspace()
        raw_lines, _curve_edges, _disp, arc_polys, circle_polys = DXFContourHelper.extract_primitives_from_msp(msp)
        clean_lines = DXFContourHelper.split_and_dedup_lines(raw_lines, ContourHyperParams(snap_tol=hp.snap_tol))

        segs = []
        for s in clean_lines:
            pts = np.array([s.p1, s.p2], dtype=float)
            segs.append((pts, s.layer))
        for pts, _handle, layer in arc_polys:
            arr = np.asarray(pts, dtype=float)
            if len(arr) < 2:
                continue
            segs.append((arr, layer))

        closed_loops = []
        closed_layers = []
        probe_circles = []
        for pts, handle, layer in circle_polys:
            arr = np.asarray(pts, dtype=float)
            if len(arr) < 4:
                continue
            info = DXFContourHelper.parse_bc_layer(layer)
            if info.get("type") == "PROBE":
                cx = float(arr[:, 0].mean())
                cy = float(arr[:, 1].mean())
                r = float(np.mean(np.hypot(arr[:, 0] - cx, arr[:, 1] - cy)))
                probe_circles.append({
                    "probe_id": info.get("probe_id", "PROBE#001"),
                    "layer": layer,
                    "handle": handle,
                    "center": (cx, cy),
                    "radius": r,
                })
                continue
            loop, lays = cls._dedup_with_edge_layers(arr, [layer] * (len(arr) - 1), tol=hp.snap_tol)
            if len(loop) >= 3:
                closed_loops.append(loop)
                closed_layers.append(lays)
        for loop, lays in cls._chain_segments_with_layers(segs, snap_tol=hp.snap_tol):
            closed_loops.append(loop)
            closed_layers.append(lays)
        if not closed_loops:
            raise ValueError(f"無法從 DXF 提取封閉輪廓: {src_name}")

        order = sorted(range(len(closed_loops)), key=lambda k: cls._polygon_area(closed_loops[k]), reverse=True)
        closed_loops = [closed_loops[k] for k in order]
        closed_layers = [closed_layers[k] for k in order]

        outer_loop = closed_loops[0]
        outer_layers = list(closed_layers[0])
        if cls._polygon_area_signed(outer_loop) < 0:
            outer_loop, outer_layers = cls._reverse_loop_with_layers(outer_loop, outer_layers)
        hole_loops = []
        hole_layers = []
        outer_path = Path(np.vstack([outer_loop, outer_loop[0]]), closed=True)
        for h_loop, h_lays in zip(closed_loops[1:], closed_layers[1:]):
            if cls._polygon_area(h_loop) <= 0:
                continue
            inside = outer_path.contains_points(h_loop)
            if float(np.mean(inside)) < 0.5:
                continue
            if cls._polygon_area_signed(h_loop) > 0:
                h_loop, h_lays = cls._reverse_loop_with_layers(h_loop, h_lays)
            hole_loops.append(h_loop)
            hole_layers.append(list(h_lays))
        return {
            "outer_loop": outer_loop,
            "outer_layers": outer_layers,
            "hole_loops": hole_loops,
            "hole_layers": hole_layers,
            "probe_circles": probe_circles,
            "source": src_name,
        }

    @classmethod
    def _build_sizing_probe_data(
        cls,
        outer_loop: np.ndarray,
        hole_loops: list[np.ndarray],
        h_max: float,
        h_min: float,
        gradation: float = 0.25,
        probe_centers=None,
    ) -> tuple[cKDTree, np.ndarray]:
        feat_pts = []
        feat_h = []
        all_loops = [outer_loop] + hole_loops
        for loop_idx, loop in enumerate(all_loops):
            n = len(loop)
            prev_pts = np.roll(loop, 1, axis=0)
            next_pts = np.roll(loop, -1, axis=0)
            v1 = loop - prev_pts
            v2 = next_pts - loop
            len1 = np.linalg.norm(v1, axis=1)
            len2 = np.linalg.norm(v2, axis=1)
            u1 = v1 / np.maximum(len1[:, None], 1e-12)
            u2 = v2 / np.maximum(len2[:, None], 1e-12)
            cross = u1[:, 0] * u2[:, 1] - u1[:, 1] * u2[:, 0]
            dot = np.clip(np.sum(u1 * u2, axis=1), -1.0, 1.0)
            turn_angle = np.arccos(dot)
            is_concave = cross < -1e-3
            is_sharp_corner = turn_angle > np.deg2rad(25.0)
            is_curved_seg = np.minimum(len1, len2) < 0.85 * h_max
            for i in range(n):
                if is_concave[i]:
                    feat_pts.append(loop[i])
                    feat_h.append(h_min)
                elif is_sharp_corner[i]:
                    feat_pts.append(loop[i])
                    feat_h.append(max(h_min, 0.45 * h_max))
                elif is_curved_seg[i]:
                    local_len = max(len1[i], len2[i])
                    feat_pts.append(loop[i])
                    feat_h.append(np.clip(local_len * 1.2, h_min, 0.6 * h_max))
            if loop_idx > 0:
                bbox_diag = float(np.linalg.norm(loop.max(axis=0) - loop.min(axis=0)))
                hole_h = np.clip(bbox_diag * 0.18, h_min, 0.65 * h_max)
                for p in loop:
                    feat_pts.append(p)
                    feat_h.append(hole_h)
        for pc in (probe_centers or []):
            feat_pts.append(np.asarray(pc, dtype=float))
            feat_h.append(h_min)
        probe_step = max(h_min, 0.5 * h_max)
        dense_boundary = []
        for loop in all_loops:
            n = len(loop)
            for i in range(n):
                p0, p1 = loop[i], loop[(i + 1) % n]
                seg_l = float(np.linalg.norm(p1 - p0))
                nd = max(1, int(np.ceil(seg_l / probe_step)))
                t = np.linspace(0.0, 1.0, nd, endpoint=False)[:, None]
                dense_boundary.append(p0 * (1.0 - t) + p1 * t)
        dense_pts = np.vstack(dense_boundary)
        if len(dense_pts) > 4:
            xmin, ymin = outer_loop.min(axis=0)
            xmax, ymax = outer_loop.max(axis=0)
            outer_path = Path(np.vstack([outer_loop, outer_loop[0]]), closed=True)
            hole_paths = [Path(np.vstack([h, h[0]]), closed=True) for h in hole_loops]
            bbox = (xmin, ymin, xmax, ymax)
            b_tree = cKDTree(dense_pts)
            k_query = min(16, len(dense_pts))
            dists, idxs = b_tree.query(dense_pts, k=k_query)
            if k_query == 1:
                dists = dists[:, None]
                idxs = idxs[:, None]
            for i in range(len(dense_pts)):
                for k_i in range(1, dists.shape[1]):
                    d_val = float(dists[i, k_i])
                    j = int(idxs[i, k_i])
                    if abs(i - j) <= 3 or abs(i - j) >= len(dense_pts) - 3:
                        continue
                    if not (1e-4 < d_val < 2.5 * h_max):
                        continue
                    mid_pt = (0.5 * (dense_pts[i] + dense_pts[j])).reshape(1, 2)
                    if not bool(cls._points_in_domain(mid_pt, outer_path, hole_paths, bbox)[0]):
                        continue
                    gap_h = float(np.clip(d_val / 2.8, h_min, 0.7 * h_max))
                    feat_pts.append(dense_pts[i])
                    feat_h.append(gap_h)
                    break
        if not feat_pts:
            feat_pts = [outer_loop[0]]
            feat_h = [h_max]
        return cKDTree(np.array(feat_pts, dtype=float)), np.array(feat_h, dtype=float)

    @staticmethod
    def _eval_sizing_field(
        pts: np.ndarray,
        feat_tree: cKDTree,
        feat_h: np.ndarray,
        h_max: float,
        h_min: float,
        gradation: float = 0.25,
    ) -> np.ndarray:
        if len(pts) == 0:
            return np.empty(0, dtype=float)
        k_query = min(8, len(feat_h))
        dists, idxs = feat_tree.query(pts, k=k_query)
        if k_query == 1:
            dists = dists[:, None]
            idxs = idxs[:, None]
        h_candidates = feat_h[idxs] + gradation * dists
        h_local = np.min(h_candidates, axis=1)
        return np.clip(h_local, h_min, h_max)

    @classmethod
    def _resample_loop_adaptive(
        cls,
        loop: np.ndarray,
        feat_tree: cKDTree | None,
        feat_h: np.ndarray | None,
        h_max: float,
        h_min: float,
        gradation: float,
        edge_layers: list | None = None,
    ) -> tuple[np.ndarray, list]:
        n = len(loop)
        sampled = []
        sampled_layers = []
        for i in range(n):
            p_start = loop[i]
            p_end = loop[(i + 1) % n]
            seg_len = float(np.linalg.norm(p_end - p_start))
            if seg_len <= 1e-9:
                continue
            if feat_tree is None:
                n_div = max(1, int(np.ceil(seg_len / h_max)))
                t_vals = np.linspace(0.0, 1.0, n_div, endpoint=False)
            else:
                n_probe = max(2, int(np.ceil(seg_len / h_min)) + 1)
                t_probe = np.linspace(0.0, 1.0, n_probe)
                pts_probe = p_start[None, :] * (1.0 - t_probe[:, None]) + p_end[None, :] * t_probe[:, None]
                h_probe = cls._eval_sizing_field(pts_probe, feat_tree, feat_h, h_max, h_min, gradation)
                dt = 1.0 / (n_probe - 1)
                density = seg_len / h_probe
                cum_phase = np.concatenate(([0.0], np.cumsum(0.5 * (density[:-1] + density[1:]) * dt)))
                total_divs = max(1, int(np.round(cum_phase[-1])))
                target_phases = np.linspace(0.0, cum_phase[-1], total_divs, endpoint=False)
                t_vals = np.interp(target_phases, cum_phase, t_probe)
            seg_pts = p_start[None, :] * (1.0 - t_vals[:, None]) + p_end[None, :] * t_vals[:, None]
            sampled.append(seg_pts)
            lay = edge_layers[i] if (edge_layers is not None and i < len(edge_layers)) else "0"
            sampled_layers.extend([lay] * len(t_vals))
        if not sampled:
            return np.empty((0, 2), dtype=float), []
        return np.vstack(sampled), sampled_layers

    @staticmethod
    def _points_in_domain(pts: np.ndarray, outer_path: Path, hole_paths: list[Path], outer_bbox: tuple) -> np.ndarray:
        if len(pts) == 0:
            return np.zeros(0, dtype=bool)
        xmin, ymin, xmax, ymax = outer_bbox
        in_box = (pts[:, 0] >= xmin) & (pts[:, 0] <= xmax) & (pts[:, 1] >= ymin) & (pts[:, 1] <= ymax)
        mask = np.zeros(len(pts), dtype=bool)
        if not np.any(in_box):
            return mask
        sub_pts = pts[in_box]
        sub_keep = outer_path.contains_points(sub_pts)
        for hp in hole_paths:
            if np.any(sub_keep):
                sub_keep &= ~hp.contains_points(sub_pts)
        mask[in_box] = sub_keep
        return mask

    @staticmethod
    def _filter_near_boundary(cand: np.ndarray, cand_h: np.ndarray, boundary_nodes: np.ndarray,
                              boundary_edges: np.ndarray | None = None) -> tuple[np.ndarray, np.ndarray]:
        if len(cand) == 0:
            return cand, cand_h
        b_dists, _ = cKDTree(boundary_nodes).query(cand)
        keep = b_dists >= 0.50 * cand_h
        if boundary_edges is not None and len(boundary_edges) > 0:
            e_a = boundary_nodes[boundary_edges[:, 0]]
            e_b = boundary_nodes[boundary_edges[:, 1]]
            e_vec = e_b - e_a
            half_len = 0.5 * np.hypot(e_vec[:, 0], e_vec[:, 1])
            k_nb = min(16, len(half_len))
            d_nb, i_nb = cKDTree(0.5 * (e_a + e_b)).query(cand, k=k_nb)
            if k_nb == 1:
                d_nb = d_nb[:, None]
                i_nb = i_nb[:, None]
            keep &= ~np.any(d_nb <= 1.15 * half_len[i_nb], axis=1)
        return cand[keep], cand_h[keep]

    @classmethod
    def _generate_interior_points(
        cls,
        outer_loop: np.ndarray,
        outer_path: Path,
        hole_paths: list[Path],
        boundary_nodes: np.ndarray,
        feat_tree: cKDTree | None,
        feat_h: np.ndarray | None,
        h_max: float,
        h_min: float,
        gradation: float,
        boundary_edges: np.ndarray | None = None,
    ) -> np.ndarray:
        xmin, ymin = outer_loop.min(axis=0)
        xmax, ymax = outer_loop.max(axis=0)
        outer_bbox = (xmin, ymin, xmax, ymax)
        if feat_tree is None:
            dx = h_max
            dy = h_max * np.sqrt(3.0) * 0.5
            ys = np.arange(ymin + 0.5 * dy, ymax, dy)
            xs_base = np.arange(xmin + 0.5 * dx, xmax, dx)
            grid_x, grid_y = np.meshgrid(xs_base, ys)
            odd_rows = (np.arange(len(ys)) % 2) == 1
            grid_x[odd_rows] += 0.5 * dx
            cand = np.column_stack([grid_x.ravel(), grid_y.ravel()])
            cand = cand[cls._points_in_domain(cand, outer_path, hole_paths, outer_bbox)]
            if len(cand) > 0:
                cand, _ = cls._filter_near_boundary(cand, np.full(len(cand), h_max), boundary_nodes, boundary_edges)
            return cand
        nx = max(2, int(np.ceil((xmax - xmin) / h_max)))
        ny = max(2, int(np.ceil((ymax - ymin) / h_max)))
        xs = np.linspace(xmin, xmax, nx + 1)
        ys = np.linspace(ymin, ymax, ny + 1)
        gx, gy = np.meshgrid(0.5 * (xs[:-1] + xs[1:]), 0.5 * (ys[:-1] + ys[1:]))
        cell_centers = np.column_stack([gx.ravel(), gy.ravel()])
        cell_hx = np.full(len(cell_centers), (xmax - xmin) / nx, dtype=float)
        cell_hy = np.full(len(cell_centers), (ymax - ymin) / ny, dtype=float)
        leaf_pts = []
        leaf_h = []
        max_levels = max(1, int(np.ceil(np.log2(h_max / max(h_min, 1e-6)))) + 1)
        for _ in range(max_levels):
            if len(cell_centers) == 0:
                break
            cell_size = np.maximum(cell_hx, cell_hy)
            h_target = cls._eval_sizing_field(cell_centers, feat_tree, feat_h, h_max, h_min, gradation)
            b_tree_tmp = cKDTree(boundary_nodes)
            b_dist, _ = b_tree_tmp.query(cell_centers)
            in_dom = cls._points_in_domain(cell_centers, outer_path, hole_paths, outer_bbox)
            near_b = b_dist <= 0.85 * cell_size
            active = in_dom | near_b
            cell_centers = cell_centers[active]
            cell_hx = cell_hx[active]
            cell_hy = cell_hy[active]
            cell_size = cell_size[active]
            h_target = h_target[active]
            split_mask = (cell_size > 1.15 * h_target) & (cell_size * 0.5 >= 0.75 * h_min)
            if np.any(~split_mask):
                kept_c = cell_centers[~split_mask]
                kept_hx = cell_hx[~split_mask]
                kept_hy = cell_hy[~split_mask]
                kept_h = h_target[~split_mask]
                leaf_pts.append(kept_c)
                leaf_h.append(kept_h)
                stag = kept_c + np.column_stack([0.25 * kept_hx, 0.25 * kept_hy])
                leaf_pts.append(stag)
                leaf_h.append(kept_h)
            if not np.any(split_mask):
                break
            sp_c = cell_centers[split_mask]
            sp_hx = 0.5 * cell_hx[split_mask]
            sp_hy = 0.5 * cell_hy[split_mask]
            offsets = np.array([[-0.5, -0.5], [0.5, -0.5], [-0.5, 0.5], [0.5, 0.5]])
            new_c = (sp_c[:, None, :] + offsets[None, :, :] * np.column_stack([sp_hx, sp_hy])[:, None, :]).reshape(-1, 2)
            cell_centers = new_c
            cell_hx = np.repeat(sp_hx, 4)
            cell_hy = np.repeat(sp_hy, 4)
        if len(cell_centers) > 0:
            h_rem = cls._eval_sizing_field(cell_centers, feat_tree, feat_h, h_max, h_min, gradation)
            leaf_pts.append(cell_centers)
            leaf_h.append(h_rem)
        if not leaf_pts:
            return np.empty((0, 2), dtype=float)
        cand = np.vstack(leaf_pts)
        cand_h = np.concatenate(leaf_h)
        dom_mask = cls._points_in_domain(cand, outer_path, hole_paths, outer_bbox)
        cand = cand[dom_mask]
        cand_h = cand_h[dom_mask]
        if len(cand) == 0:
            return cand
        cand, cand_h = cls._filter_near_boundary(cand, cand_h, boundary_nodes, boundary_edges)
        if len(cand) > 1:
            order = np.argsort(cand_h)
            cand = cand[order]
            cand_h = cand_h[order]
            quant = np.round(cand / (0.25 * h_min)).astype(np.int64)
            _, uniq_idx = np.unique(quant, axis=0, return_index=True)
            uniq_idx.sort()
            cand = cand[uniq_idx]
        return cand

    @staticmethod
    def _laplacian_smooth_vectorized(
        nodes: np.ndarray,
        elements_t3: np.ndarray,
        n_boundary: int,
        iterations: int = 4,
    ) -> np.ndarray:
        if iterations <= 0 or len(nodes) <= n_boundary or len(elements_t3) == 0:
            return nodes
        coords = nodes.copy()
        e01 = elements_t3[:, [0, 1]]
        e12 = elements_t3[:, [1, 2]]
        e20 = elements_t3[:, [2, 0]]
        directed = np.vstack([e01, e12, e20, e01[:, ::-1], e12[:, ::-1], e20[:, ::-1]])
        u = directed[:, 0]
        v = directed[:, 1]
        n_nodes = len(coords)
        edge_sorted = np.sort(np.vstack([e01, e12, e20]), axis=1)
        uni_e, cnt_e = np.unique(edge_sorted, axis=0, return_counts=True)
        locked = np.zeros(n_nodes, dtype=bool)
        locked[:n_boundary] = True
        locked[uni_e[cnt_e == 1].ravel()] = True
        for _ in range(iterations):
            edge_lengths = np.linalg.norm(coords[u] - coords[v], axis=1)
            w = 1.0 / np.maximum(edge_lengths, 1e-6)
            accum = np.zeros_like(coords)
            w_sum = np.zeros(n_nodes, dtype=float)
            np.add.at(accum, u, coords[v] * w[:, None])
            np.add.at(w_sum, u, w)
            idx_int = np.where((w_sum > 0.0) & ~locked)[0]
            coords[idx_int] = 0.4 * coords[idx_int] + 0.6 * (accum[idx_int] / w_sum[idx_int, None])
        return coords

    @staticmethod
    def _upgrade_t3_to_t6_vectorized(
        nodes_t3: np.ndarray,
        elements_t3: np.ndarray,
        boundary_edges_t3: np.ndarray,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        n_corner = len(nodes_t3)
        n_elem = len(elements_t3)
        raw_edges = np.stack(
            [elements_t3[:, [0, 1]], elements_t3[:, [1, 2]], elements_t3[:, [2, 0]]],
            axis=1,
        ).reshape(-1, 2)
        sorted_edges = np.sort(raw_edges, axis=1)
        unique_edges, inv = np.unique(sorted_edges, axis=0, return_inverse=True)
        mid_coords = 0.5 * (nodes_t3[unique_edges[:, 0]] + nodes_t3[unique_edges[:, 1]])
        nodes_t6 = np.vstack([nodes_t3, mid_coords])
        mid_indices = (inv + n_corner).reshape(n_elem, 3)
        elements_t6 = np.hstack([elements_t3, mid_indices])
        b_mid_nodes = np.full(len(boundary_edges_t3), -1, dtype=int)
        if len(boundary_edges_t3) > 0:
            b_sorted = np.sort(boundary_edges_t3, axis=1)
            max_id = n_corner + 1
            edge_keys = unique_edges[:, 0].astype(np.int64) * max_id + unique_edges[:, 1].astype(np.int64)
            b_keys = b_sorted[:, 0].astype(np.int64) * max_id + b_sorted[:, 1].astype(np.int64)
            pos = np.searchsorted(edge_keys, b_keys)
            pos = np.clip(pos, 0, len(edge_keys) - 1)
            matched = edge_keys[pos] == b_keys
            b_mid_nodes[matched] = pos[matched] + n_corner
            b_corner_nodes = np.unique(b_sorted.ravel())
            boundary_nodes_t6 = np.unique(np.concatenate([b_corner_nodes, b_mid_nodes[matched]]))
        else:
            boundary_nodes_t6 = np.empty(0, dtype=int)
        return nodes_t6, elements_t6, boundary_nodes_t6, b_mid_nodes

    @classmethod
    def build_t6_mesh_from_dxf(
        cls,
        dxf_source="./try_mesh.dxf",
        hp: "MeshHyperParams | None" = None,
    ) -> dict:
        if hp is None:
            hp = MeshHyperParams()
        t0 = time.perf_counter()
        loops = cls.read_dxf_loops(dxf_source, hp=hp)
        outer_loop = loops["outer_loop"]
        hole_loops = loops["hole_loops"]
        outer_layers = loops.get("outer_layers") or ["0"] * len(outer_loop)
        hole_layers = loops.get("hole_layers") or [["0"] * len(h) for h in hole_loops]
        h_max = float(hp.h_max)
        h_min = float(hp.h_min)
        if hp.auto_density:
            feat_tree, feat_h = cls._build_sizing_probe_data(
                outer_loop, hole_loops, h_max, h_min, gradation=hp.gradation,
                probe_centers=[p["center"] for p in (loops.get("probe_circles") or [])],
            )
        else:
            feat_tree, feat_h = None, None
        boundary_groups = []
        boundary_edges_list = []
        boundary_layers_list = []
        offset = 0
        for loop, layers in [(outer_loop, outer_layers)] + list(zip(hole_loops, hole_layers)):
            b_pts, b_lays = cls._resample_loop_adaptive(
                loop, feat_tree, feat_h, h_max, h_min, hp.gradation, edge_layers=layers
            )
            m = len(b_pts)
            if m < 3:
                continue
            b_lays = list(b_lays)
            while len(b_lays) < m:
                b_lays.append(b_lays[-1] if b_lays else "0")
            b_lays = b_lays[:m]
            idx_u = offset + np.arange(m, dtype=int)
            idx_v = offset + ((np.arange(m, dtype=int) + 1) % m)
            boundary_edges_list.append(np.column_stack([idx_u, idx_v]))
            boundary_layers_list.append(b_lays)
            boundary_groups.append(b_pts)
            offset += m
        boundary_nodes_t3 = np.vstack(boundary_groups)
        boundary_edges_t3 = np.vstack(boundary_edges_list)
        boundary_edge_layers = np.array([lay for lays in boundary_layers_list for lay in lays], dtype=object)
        n_boundary_t3 = len(boundary_nodes_t3)
        res_outer = boundary_groups[0]
        outer_path = Path(np.vstack([res_outer, res_outer[0]]), closed=True)
        res_holes = boundary_groups[1:] if len(boundary_groups) == len(hole_loops) + 1 else hole_loops
        hole_paths = [Path(np.vstack([h, h[0]]), closed=True) for h in res_holes]
        interior_pts = cls._generate_interior_points(
            res_outer,
            outer_path,
            hole_paths,
            boundary_nodes_t3,
            feat_tree,
            feat_h,
            h_max,
            h_min,
            hp.gradation,
            boundary_edges_t3,
        )
        if len(interior_pts) > 0:
            nodes_t3 = np.vstack([boundary_nodes_t3, interior_pts])
        else:
            nodes_t3 = boundary_nodes_t3.copy()
        tri = Delaunay(nodes_t3)
        elements_t3 = tri.simplices.copy()
        xmin, ymin = res_outer.min(axis=0)
        xmax, ymax = res_outer.max(axis=0)
        bbox = (xmin, ymin, xmax, ymax)
        p0 = nodes_t3[elements_t3[:, 0]]
        p1 = nodes_t3[elements_t3[:, 1]]
        p2 = nodes_t3[elements_t3[:, 2]]
        centroids = (p0 + p1 + p2) / 3.0
        shrink = 0.15
        m01 = (1.0 - shrink) * (0.5 * (p0 + p1)) + shrink * centroids
        m12 = (1.0 - shrink) * (0.5 * (p1 + p2)) + shrink * centroids
        m20 = (1.0 - shrink) * (0.5 * (p2 + p0)) + shrink * centroids
        keep = (
            cls._points_in_domain(centroids, outer_path, hole_paths, bbox)
            & cls._points_in_domain(m01, outer_path, hole_paths, bbox)
            & cls._points_in_domain(m12, outer_path, hole_paths, bbox)
            & cls._points_in_domain(m20, outer_path, hole_paths, bbox)
        )
        elements_t3 = elements_t3[keep]
        if len(elements_t3) == 0:
            raise ValueError("網格三角化後無有效元素（域內過濾全部被剔除）")
        p0 = nodes_t3[elements_t3[:, 0]]
        p1 = nodes_t3[elements_t3[:, 1]]
        p2 = nodes_t3[elements_t3[:, 2]]
        cross_z = (p1[:, 0] - p0[:, 0]) * (p2[:, 1] - p0[:, 1]) - (p1[:, 1] - p0[:, 1]) * (p2[:, 0] - p0[:, 0])
        cw_mask = cross_z < 0
        elements_t3[cw_mask, 1], elements_t3[cw_mask, 2] = (
            elements_t3[cw_mask, 2].copy(),
            elements_t3[cw_mask, 1].copy(),
        )
        elements_t3 = elements_t3[np.abs(cross_z) > 1e-10]
        nodes_t3 = cls._laplacian_smooth_vectorized(nodes_t3, elements_t3, n_boundary_t3, iterations=hp.smooth_iter)
        p0 = nodes_t3[elements_t3[:, 0]]
        p1 = nodes_t3[elements_t3[:, 1]]
        p2 = nodes_t3[elements_t3[:, 2]]
        areas = 0.5 * np.abs((p1[:, 0] - p0[:, 0]) * (p2[:, 1] - p0[:, 1]) - (p1[:, 1] - p0[:, 1]) * (p2[:, 0] - p0[:, 0]))
        nodes_t6, elements_t6, boundary_nodes_t6, b_mid_nodes = cls._upgrade_t3_to_t6_vectorized(
            nodes_t3, elements_t3, boundary_edges_t3
        )
        bc_groups = {}
        if len(b_mid_nodes) == len(boundary_edges_t3) and len(boundary_edge_layers) == len(boundary_edges_t3):
            valid = b_mid_nodes >= 0
            for lay in np.unique(boundary_edge_layers):
                mask = valid & (boundary_edge_layers == lay)
                if not np.any(mask):
                    continue
                e_t6 = np.column_stack([
                    boundary_edges_t3[mask, 0],
                    boundary_edges_t3[mask, 1],
                    b_mid_nodes[mask],
                ]).astype(int)
                bc_groups[str(lay)] = {
                    "node_ids": np.unique(e_t6.ravel()),
                    "edges_t6": e_t6,
                }
        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        n_broken = int(np.count_nonzero(b_mid_nodes < 0)) if len(b_mid_nodes) else 0
        probes = {}
        probe_list = loops.get("probe_circles") or []
        if probe_list:
            centers = np.array([p["center"] for p in probe_list], dtype=float)
            node_tree = cKDTree(nodes_t6)
            dists, nids = node_tree.query(centers)
            elem_tree = cKDTree(nodes_t6[elements_t6[:, :3]].mean(axis=1))
            _, eids = elem_tree.query(centers)
            for k, p in enumerate(probe_list):
                nid = int(np.atleast_1d(nids)[k])
                probes[p["probe_id"]] = {
                    "probe_id": p["probe_id"],
                    "layer": p["layer"],
                    "center_xy": (float(p["center"][0]), float(p["center"][1])),
                    "radius": float(p["radius"]),
                    "node_id": nid,
                    "node_xy": (float(nodes_t6[nid, 0]), float(nodes_t6[nid, 1])),
                    "elem_id": int(np.atleast_1d(eids)[k]),
                    "snap_dist": float(np.atleast_1d(dists)[k]),
                }
        return {
            "element_type": "T6",
            "nodes": nodes_t6,
            "elements": elements_t6,
            "elements_corner": elements_t6[:, :3],
            "n_corner_nodes": len(nodes_t3),
            "boundary_nodes": boundary_nodes_t6,
            "boundary_edges_t3": boundary_edges_t3,
            "boundary_edge_layers": boundary_edge_layers,
            "broken_boundary_edges": n_broken,
            "bc_groups": bc_groups,
            "probes": probes,
            "areas": areas,
            "outer_loop": outer_loop,
            "outer_layers": outer_layers,
            "hole_loops": hole_loops,
            "hole_layers": hole_layers,
            "h_max": h_max,
            "h_min": h_min,
            "gradation": hp.gradation,
            "probe_circles": loops.get("probe_circles") or [],
            "source": loops.get("source", ""),
            "elapsed_ms": elapsed_ms,
        }

    @staticmethod
    def plot_t6_mesh_on_ax(mesh: dict, ax):
        if ax is None:
            return None
        ax.clear()
        ax.set_facecolor("#0a0a0a")
        if ax.figure is not None:
            ax.figure.patch.set_facecolor("#0a0a0a")
        nodes = mesh["nodes"]
        elements = mesh["elements"]
        n_corner = mesh["n_corner_nodes"]
        areas = mesh.get("areas")
        char_len = np.sqrt(2.0 * np.asarray(areas, dtype=float)) if areas is not None and len(areas) else np.array([0.0])
        # T6 純線框：每元素 6 段 (角點-中點-角點)，依節點編號去重後繪製
        half_edges = np.vstack([
            elements[:, [0, 3]],
            elements[:, [3, 1]],
            elements[:, [1, 4]],
            elements[:, [4, 2]],
            elements[:, [2, 5]],
            elements[:, [5, 0]],
        ])
        uniq_edges = np.unique(np.sort(half_edges, axis=1), axis=0)
        wire_segs = np.stack([nodes[uniq_edges[:, 0]], nodes[uniq_edges[:, 1]]], axis=1)
        ax.add_collection(LineCollection(wire_segs, colors="#8fb8c9", linewidths=0.45, alpha=0.9, zorder=2))
        for loop in [mesh.get("outer_loop")] + list(mesh.get("hole_loops") or []):
            if loop is None or len(loop) < 2:
                continue
            closed = np.vstack([loop, loop[0]])
            ax.plot(closed[:, 0], closed[:, 1], color="#dddddd", lw=1.2, zorder=5)
        for lay, ginfo in (mesh.get("bc_groups") or {}).items():
            edges = ginfo.get("edges_t6")
            if edges is None or len(edges) == 0:
                continue
            lay_up = str(lay).upper()
            if lay_up == "FIXED":
                color, label = "#00bfff", "FIXED"
            elif lay_up.startswith("DISP_"):
                color, label = "#ff3355", f"DISP {lay}"
            elif lay_up.startswith("FORCE_"):
                color, label = "#ffaa00", f"FORCE {lay}"
            elif lay_up == "PROBE" or lay_up.startswith("PROBE_"):
                color, label = "#00ff88", f"PROBE {lay}"
            else:
                color, label = "#9aa0a6", str(lay)
            bc_segs = np.vstack([
                np.stack([nodes[edges[:, 0]], nodes[edges[:, 2]]], axis=1),
                np.stack([nodes[edges[:, 2]], nodes[edges[:, 1]]], axis=1),
            ])
            ax.add_collection(LineCollection(bc_segs, colors=color, linewidths=2.4, zorder=8, label=label))
        for pid, pinfo in (mesh.get("probes") or {}).items():
            cx, cy = pinfo.get("center_xy", (0.0, 0.0))
            r = float(pinfo.get("radius", 0.0))
            if r > 0:
                th = np.linspace(0.0, 2.0 * np.pi, 49)
                ax.plot(cx + r * np.cos(th), cy + r * np.sin(th), color="#00ff88", lw=1.6, ls="--", zorder=16)
            ax.plot([cx], [cy], marker="+", markersize=11, color="#00ff88", mew=2.0, zorder=16)
            nx, ny = pinfo.get("node_xy", (cx, cy))
            ax.plot([cx, nx], [cy, ny], color="#00ff88", lw=0.8, ls=":", zorder=15)
            ax.annotate(
                f"{pid} -> Node #{pinfo.get('node_id', -1)}",
                xy=(cx, cy), xytext=(cx + 1.5, cy + 1.5),
                color="#00ff88", fontsize=7.5, zorder=17,
            )
        bc_counts = ", ".join(
            f"{k}:{len(v.get('node_ids', []))}" for k, v in (mesh.get("bc_groups") or {}).items()
        )
        hud_lines = [
            f"T6 MESH | Nodes {len(nodes)} (corner {n_corner} + mid {len(nodes) - n_corner})",
            f"Elements {len(elements)} | Size {float(char_len.min()):.2f} ~ {float(char_len.max()):.2f} mm "
            f"| {float(mesh.get('elapsed_ms', 0.0)):.0f} ms",
        ]
        if bc_counts:
            hud_lines.append(f"BC Nodes: {bc_counts}")
        ax.text(
            0.012, 0.985, "\n".join(hud_lines), transform=ax.transAxes,
            color="#00ff88", fontsize=8.5, va="top", ha="left", zorder=20,
            bbox=dict(boxstyle="round,pad=0.35", facecolor="#161616", edgecolor="#444444", alpha=0.92),
        )
        outer = mesh.get("outer_loop")
        if outer is not None and len(outer) > 0:
            xmin, ymin = np.min(outer, axis=0)
            xmax, ymax = np.max(outer, axis=0)
            dx = max(xmax - xmin, 1.0) * 0.06
            dy = max(ymax - ymin, 1.0) * 0.06
            ax.set_xlim(xmin - dx, xmax + dx)
            ax.set_ylim(ymin - dy, ymax + dy)
        ax.set_aspect("equal", adjustable="box")
        ax.tick_params(colors="#888888", labelsize=7)
        handles, labels = ax.get_legend_handles_labels()
        if handles:
            ax.legend(
                loc="lower right", facecolor="#181818", edgecolor="#444444",
                labelcolor="#dddddd", fontsize=7,
            )
        return ax

GF_TO_N = 0.00980665

VIEW_MODES = [
    "Von Mises 應力",
    "總位移 |dxy|",
    "位移角 disp_theta",
    "X位移 dx",
    "Y位移 dy",
]

VIEW_FIELD = {
    "Von Mises 應力": ("von_mises", "Von Mises (MPa)", "turbo"),
    "總位移 |dxy|": ("u_mag", "|dxy| (mm)", "viridis"),
    "位移角 disp_theta": ("disp_theta_deg", "disp_theta (deg)", "hsv"),
    "X位移 dx": ("u_x", "dx (mm)", "coolwarm"),
    "Y位移 dy": ("u_y", "dy (mm)", "coolwarm"),
}


@dataclass
class SolverHyperParams:
    material: str = "Al-7075-T6"
    E_mpa: float = 71700.0
    nu: float = 0.33
    yield_mpa: float = 503.0
    thickness_mm: float = 10.0
    large_disp: bool = True
    n_steps: int = 5
    max_nr_iter: int = 20
    tol_rel: float = 1e-4
    deform_scale: float = 1.0
    min_det_f: float = 1e-3
    n_gauss: int = 3


class FiniteEleSolverHelper:
    _GP_L = (0.445948490915965, 0.091576213509771)
    _GP_W = (0.223381589678011, 0.109951743655322)
    _EYE2 = np.eye(2)

    @classmethod
    def _quadrature(cls, n_gauss: int = 3):
        """三角形積分點；3 點 (degree-2) 為預設，6 點可作對照。權重已換算到參考面積 0.5。"""
        if int(n_gauss) >= 6:
            a1, a2 = cls._GP_L
            w1, w2 = cls._GP_W
            b1 = 1.0 - 2.0 * a1
            b2 = 1.0 - 2.0 * a2
            pts = []
            for l2, l3 in ((a1, a1), (b1, a1), (a1, b1)):
                pts.append((l2, l3, 0.5 * w1))
            for l2, l3 in ((a2, a2), (b2, a2), (a2, b2)):
                pts.append((l2, l3, 0.5 * w2))
            return pts
        a = 1.0 / 6.0
        b = 2.0 / 3.0
        return [(a, a, 1.0 / 6.0), (b, a, 1.0 / 6.0), (a, b, 1.0 / 6.0)]

    @staticmethod
    def _shape(xi, eta):
        L1 = 1.0 - xi - eta
        L2 = xi
        L3 = eta
        N = np.array([
            L1 * (2.0 * L1 - 1.0),
            L2 * (2.0 * L2 - 1.0),
            L3 * (2.0 * L3 - 1.0),
            4.0 * L1 * L2,
            4.0 * L2 * L3,
            4.0 * L3 * L1,
        ])
        dL = np.array([[-1.0, -1.0], [1.0, 0.0], [0.0, 1.0]])
        dN = np.empty((6, 2))
        dN[0] = (4.0 * L1 - 1.0) * dL[0]
        dN[1] = (4.0 * L2 - 1.0) * dL[1]
        dN[2] = (4.0 * L3 - 1.0) * dL[2]
        dN[3] = 4.0 * (L2 * dL[0] + L1 * dL[1])
        dN[4] = 4.0 * (L3 * dL[1] + L2 * dL[2])
        dN[5] = 4.0 * (L1 * dL[2] + L3 * dL[0])
        return N, dN

    @staticmethod
    def _parse_layer(layer_name: str) -> dict:
        return dict(DXFContourHelper.parse_bc_layer_name(layer_name))

    @staticmethod
    def _plane_stress_matrix(E: float, nu: float) -> np.ndarray:
        c = E / (1.0 - nu * nu)
        return np.array([
            [c, c * nu, 0.0],
            [c * nu, c, 0.0],
            [0.0, 0.0, c * (1.0 - nu) / 2.0],
        ])

    @classmethod
    def _precompute_reference(cls, nodes, elements, thickness, n_gauss: int = 3):
        """回傳 dNdX: (Nel, Ngp, 6, 2) 與 dV0: (Nel, Ngp)。"""
        gps = cls._quadrature(n_gauss)
        Xe = nodes[elements]
        dNdX_list = []
        dV0_list = []
        for xi, eta, w in gps:
            _N, dN = cls._shape(xi, eta)
            J0 = np.einsum('eai,aj->eij', Xe, dN)
            detJ = J0[:, 0, 0] * J0[:, 1, 1] - J0[:, 0, 1] * J0[:, 1, 0]
            detJ = np.where(np.abs(detJ) < 1e-14, 1e-14, detJ)
            invJ = np.empty_like(J0)
            invJ[:, 0, 0] = J0[:, 1, 1] / detJ
            invJ[:, 0, 1] = -J0[:, 0, 1] / detJ
            invJ[:, 1, 0] = -J0[:, 1, 0] / detJ
            invJ[:, 1, 1] = J0[:, 0, 0] / detJ
            dNdX_list.append(np.einsum('ai,eij->eaj', dN, invJ))
            dV0_list.append(np.abs(detJ) * w * thickness)
        return np.stack(dNdX_list, axis=1), np.stack(dV0_list, axis=1)

    @classmethod
    def _kinematics(cls, u_e, dNdX, D):
        grad_u = np.einsum('eai,egaj->egij', u_e, dNdX)
        F = cls._EYE2 + grad_u
        detF = F[..., 0, 0] * F[..., 1, 1] - F[..., 0, 1] * F[..., 1, 0]
        FtF = np.einsum('egji,egjk->egik', F, F)
        E = np.stack([
            0.5 * (FtF[..., 0, 0] - 1.0),
            0.5 * (FtF[..., 1, 1] - 1.0),
            FtF[..., 0, 1],
        ], axis=2)
        S = np.einsum('egk,jk->egj', E, D)
        return F, detF, S

    @classmethod
    def _bmatrix(cls, F, dNdX):
        Nel = F.shape[0]
        ngp = F.shape[1]
        B = np.empty((Nel, ngp, 3, 12))
        for k in (0, 1):
            B[:, :, 0, k::2] = F[:, :, k, 0][:, :, None] * dNdX[:, :, :, 0]
            B[:, :, 1, k::2] = F[:, :, k, 1][:, :, None] * dNdX[:, :, :, 1]
            B[:, :, 2, k::2] = (
                F[:, :, k, 0][:, :, None] * dNdX[:, :, :, 1]
                + F[:, :, k, 1][:, :, None] * dNdX[:, :, :, 0]
            )
        return B

    @classmethod
    def _assemble_residual(cls, u_flat, elements, dNdX, dV0, D, dof_map, n_dof: int):
        u_e = u_flat.reshape(-1, 2)[elements]
        F, detF, S = cls._kinematics(u_e, dNdX, D)
        min_det = float(np.min(detF))
        B = cls._bmatrix(F, dNdX)
        f_int_e = np.einsum('eg,egja,egj->ea', dV0, B, S)
        f_int = np.bincount(dof_map.ravel(), weights=f_int_e.ravel(), minlength=n_dof)
        return f_int, min_det, F, S, B

    @classmethod
    def _assemble_tangent(cls, F, S, B, dNdX, dV0, D):
        DB_t = (B.swapaxes(-1, -2) @ D) * dV0[:, :, None, None]
        K_e = (DB_t @ B).sum(axis=1)
        S_dNdX = np.empty_like(dNdX)
        S_dNdX[..., 0] = (S[..., 0:1] * dNdX[..., 0] + S[..., 2:3] * dNdX[..., 1]) * dV0[..., None]
        S_dNdX[..., 1] = (S[..., 2:3] * dNdX[..., 0] + S[..., 1:2] * dNdX[..., 1]) * dV0[..., None]
        KG = (dNdX @ S_dNdX.swapaxes(-1, -2)).sum(axis=1)
        K_e[:, 0::2, 0::2] += KG
        K_e[:, 1::2, 1::2] += KG
        return K_e

    @classmethod
    def _min_det_f(cls, u_flat, elements, dNdX):
        u_e = u_flat.reshape(-1, 2)[elements]
        grad_u = np.einsum('eai,egaj->egij', u_e, dNdX)
        F = cls._EYE2 + grad_u
        detF = F[..., 0, 0] * F[..., 1, 1] - F[..., 0, 1] * F[..., 1, 0]
        return float(np.min(detF))

    @classmethod
    def _nodal_fields(cls, u_flat, nodes, elements, dNdX, dV0, D):
        n_nodes = len(nodes)
        u_e = u_flat.reshape(-1, 2)[elements]
        F, detF, S = cls._kinematics(u_e, dNdX, D)
        detF = np.where(np.abs(detF) < 1e-12, 1e-12, detF)
        S_mat = np.empty(F.shape)
        S_mat[..., 0, 0] = S[..., 0]
        S_mat[..., 1, 1] = S[..., 1]
        S_mat[..., 0, 1] = S[..., 2]
        S_mat[..., 1, 0] = S[..., 2]
        FS = np.einsum('egij,egjk->egik', F, S_mat)
        sig = np.einsum('egij,egkj->egik', FS, F) / detF[..., None, None]
        sig_v = np.stack([sig[..., 0, 0], sig[..., 1, 1], sig[..., 0, 1]], axis=2)
        w = dV0 / 6.0
        e_sig = np.einsum('eg,egk->ek', w, sig_v)
        e_F = np.einsum('eg,egij->eij', w, F).reshape(len(elements), 4)
        e_w = w.sum(axis=1)
        flat_ids = elements.ravel()
        acc_w = np.bincount(flat_ids, weights=np.repeat(e_w, 6), minlength=n_nodes)
        acc_sig = np.column_stack([
            np.bincount(flat_ids, weights=np.repeat(e_sig[:, k], 6), minlength=n_nodes)
            for k in range(3)
        ])
        acc_F = np.column_stack([
            np.bincount(flat_ids, weights=np.repeat(e_F[:, k], 6), minlength=n_nodes)
            for k in range(4)
        ]).reshape(n_nodes, 2, 2)
        acc_w = np.where(acc_w < 1e-30, 1e-30, acc_w)
        sig_node = acc_sig / acc_w[:, None]
        F_node = acc_F / acc_w[:, None, None]
        sxx, syy, sxy = sig_node[:, 0], sig_node[:, 1], sig_node[:, 2]
        von_mises = np.sqrt(np.maximum(sxx ** 2 - sxx * syy + syy ** 2 + 3.0 * sxy ** 2, 0.0))
        rot_deg = np.degrees(np.arctan2(F_node[:, 1, 0] - F_node[:, 0, 1], F_node[:, 0, 0] + F_node[:, 1, 1]))
        return von_mises, sig_node, rot_deg

    @staticmethod
    def _evaluate_probes(probes_dict, u, von_mises, sig, rot_deg):
        out = {}
        u2 = u.reshape(-1, 2)
        for pid, info in (probes_dict or {}).items():
            nid = int(info.get("node_id", -1))
            if nid < 0 or nid >= len(u2):
                continue
            dx = float(u2[nid, 0])
            dy = float(u2[nid, 1])
            out[pid] = {
                "probe_id": pid,
                "layer": info.get("layer"),
                "node_id": nid,
                "node_xy": info.get("node_xy"),
                "center_xy": info.get("center_xy"),
                "snap_dist": info.get("snap_dist"),
                "dx": dx,
                "dy": dy,
                "dxy": math.hypot(dx, dy),
                "disp_theta": math.degrees(math.atan2(dy, dx)),
                "stress": float(von_mises[nid]) if nid < len(von_mises) else 0.0,
                "sxx": float(sig[nid, 0]) if nid < len(sig) else 0.0,
                "syy": float(sig[nid, 1]) if nid < len(sig) else 0.0,
                "txy": float(sig[nid, 2]) if nid < len(sig) else 0.0,
                "rot_theta": float(rot_deg[nid]) if nid < len(rot_deg) else 0.0,
            }
        return out

    @classmethod
    def _build_bc(cls, mesh, nodes, hp):
        """BC 一律 1:1 真實物理量：DISP 的 x/y 直接是 mm，FORCE 的 x/y 直接是 gf（轉 N）。"""
        n_nodes = len(nodes)
        n_dof = 2 * n_nodes
        constrained = np.zeros(n_dof, dtype=bool)
        u_target = np.zeros(n_dof)
        f_ext = np.zeros(n_dof)
        layer_groups = {}
        for lay, info in (mesh.get("bc_groups") or {}).items():
            ids = np.asarray(info.get("node_ids", []), dtype=int)
            if len(ids) == 0:
                continue
            parsed = cls._parse_layer(lay)
            btype = parsed["type"]
            layer_groups[str(lay)] = (ids, parsed)
            if btype == "FIXED":
                constrained[2 * ids] = True
                constrained[2 * ids + 1] = True
            elif btype == "DISP":
                constrained[2 * ids] = True
                constrained[2 * ids + 1] = True
                u_target[2 * ids] = parsed["x"]
                u_target[2 * ids + 1] = parsed["y"]
            elif btype == "FORCE":
                edges = np.asarray(info.get("edges_t6", []), dtype=int)
                if edges.size == 0:
                    continue
                n0 = edges[:, 0]
                n1 = edges[:, 1]
                m01 = edges[:, 2]
                L = np.linalg.norm(nodes[n1] - nodes[n0], axis=1)
                L_total = max(float(L.sum()), 1e-12)
                force_n = np.array([parsed["x"], parsed["y"]], dtype=float) * GF_TO_N
                trac = force_n / L_total
                for nd, wt in ((n0, 1.0 / 6.0), (n1, 1.0 / 6.0), (m01, 4.0 / 6.0)):
                    np.add.at(f_ext, 2 * nd, wt * L * trac[0])
                    np.add.at(f_ext, 2 * nd + 1, wt * L * trac[1])
        return n_dof, constrained, u_target, f_ext, layer_groups

    @classmethod
    def solve(cls, mesh: dict, hp: SolverHyperParams = None) -> dict:
        if hp is None:
            hp = SolverHyperParams()
        t0 = time.perf_counter()
        nodes = np.asarray(mesh["nodes"], dtype=float)
        elements = np.asarray(mesh["elements"], dtype=int)
        n_dof, constrained, u_target, f_ext, groups = cls._build_bc(mesh, nodes, hp)
        attached = np.zeros(len(nodes), dtype=bool)
        attached[elements.ravel()] = True
        orphan = np.where(~attached)[0]
        if len(orphan):
            constrained[2 * orphan] = True
            constrained[2 * orphan + 1] = True
        free = np.where(~constrained)[0]
        E = float(hp.E_mpa)
        nu = float(hp.nu)
        if not (-0.95 < nu < 0.4999):
            nu = 0.3
        D = cls._plane_stress_matrix(E, nu)
        dof_map = (elements[:, :, None] * 2 + np.arange(2)[None, None, :]).reshape(len(elements), 12)
        dNdX, dV0 = cls._precompute_reference(nodes, elements, hp.thickness_mm, hp.n_gauss)
        n_free = len(free)
        free_idx_map = np.full(n_dof, -1, dtype=np.int32)
        free_idx_map[free] = np.arange(n_free, dtype=np.int32)
        rows_full = np.repeat(dof_map, 12, axis=1).ravel()
        cols_full = np.tile(dof_map, (1, 12)).ravel()
        r_free_idx = free_idx_map[rows_full]
        c_free_idx = free_idx_map[cols_full]
        mask_ff = (r_free_idx >= 0) & (c_free_idx >= 0)
        ff_rows = r_free_idx[mask_ff]
        ff_cols = c_free_idx[mask_ff]

        if n_free > 0:
            keys_1d = ff_cols.astype(np.int64) * np.int64(n_free) + ff_rows.astype(np.int64)
            uniq_keys, coo_to_csc_idx = np.unique(keys_1d, return_inverse=True)
            nnz = len(uniq_keys)
            csc_cols = (uniq_keys // np.int64(n_free)).astype(np.int32)
            csc_indices = (uniq_keys % np.int64(n_free)).astype(np.int32)
            csc_indptr = np.zeros(n_free + 1, dtype=np.int32)
            csc_indptr[1:] = np.cumsum(np.bincount(csc_cols, minlength=n_free))
            K_ff = csc_matrix((np.zeros(nnz, dtype=float), csc_indices, csc_indptr), shape=(n_free, n_free))
        else:
            coo_to_csc_idx = np.empty(0, dtype=np.int32)
            nnz = 0
            K_ff = None

        def _factorize_free(K_e_l):
            K_ff.data[:] = np.bincount(coo_to_csc_idx, weights=K_e_l.ravel()[mask_ff], minlength=nnz)
            try:
                return splu(K_ff, permc_spec="MMD_AT_PLUS_A", diag_pivot_thresh=0.01)
            except RuntimeError:
                return splu(K_ff, permc_spec="COLAMD")

        u = np.zeros(n_dof)
        lam = 0.0
        d_lam = 1.0 / max(1, int(hp.n_steps)) if hp.large_disp else 1.0
        d_lam_prev = 1.0
        du_prev = np.zeros(n_dof)
        step_history = []
        warning = None
        n_iter_total = 0
        has_probes = bool(mesh.get("probes"))
        lu_cached = None
        if hp.large_disp and n_free > 0:
            u_pre = np.zeros(n_dof)
            u_pre[constrained] = u_target[constrained]
            _f0, _md0, F0, S0, B0 = cls._assemble_residual(
                np.zeros(n_dof), elements, dNdX, dV0, D, dof_map, n_dof
            )
            K_e0 = cls._assemble_tangent(F0, S0, B0, dNdX, dV0, D)
            f_lin = np.bincount(
                dof_map.ravel(),
                weights=np.einsum('eab,eb->ea', K_e0, u_pre[dof_map]).ravel(),
                minlength=n_dof,
            )
            lu_cached = _factorize_free(K_e0)
            du_lin = lu_cached.solve(-(f_lin - f_ext)[free])
            du_prev = np.zeros(n_dof)
            du_prev[free] = du_lin
            du_prev[constrained] = u_target[constrained]
            d_lam_prev = 1.0
        while lam < 1.0 - 1e-12:
            lam_try = min(1.0, lam + d_lam)
            step_dl = lam_try - lam
            if d_lam_prev > 1e-12:
                u_try = u + (step_dl / d_lam_prev) * du_prev
            else:
                u_try = u.copy()
            u_try[constrained] = lam_try * u_target[constrained]
            if hp.large_disp and cls._min_det_f(u_try, elements, dNdX) <= 0.05:
                d_lam *= 0.5
                if d_lam < 1e-4:
                    warning = f"已達機構物理大變形極限 (lambda={lam:.3f})"
                    break
                continue
            converged = False
            it = 0
            prev_res_norm = float("inf")
            for it in range(max(1, int(hp.max_nr_iter))):
                n_iter_total += 1
                f_int, min_det, F_cur, S_cur, B_cur = cls._assemble_residual(
                    u_try, elements, dNdX, dV0, D, dof_map, n_dof
                )
                if min_det <= hp.min_det_f and it > 0:
                    break
                resid = f_int - lam_try * f_ext
                ref_scale = max(
                    float(np.linalg.norm(f_int)),
                    float(np.linalg.norm(lam_try * f_ext)),
                    1.0,
                )
                res_norm = float(np.linalg.norm(resid[free])) / ref_scale
                if res_norm < hp.tol_rel or n_free == 0:
                    converged = True
                    break
                if lu_cached is None or it == 0 or res_norm >= 0.20 * prev_res_norm:
                    K_e = cls._assemble_tangent(F_cur, S_cur, B_cur, dNdX, dV0, D)
                    lu_cached = _factorize_free(K_e)
                prev_res_norm = res_norm
                du = lu_cached.solve(-resid[free])
                if float(np.linalg.norm(du)) <= 1e-12 * max(float(np.linalg.norm(u_try)), 1.0):
                    converged = True
                    break
                alpha = 1.0
                accepted = False
                while alpha >= 1.0 / 32.0:
                    u_cand = u_try.copy()
                    u_cand[free] += alpha * du
                    if cls._min_det_f(u_cand, elements, dNdX) > 0.02:
                        u_try = u_cand
                        accepted = True
                        break
                    alpha *= 0.5
                if not accepted:
                    break
            if converged:
                du_prev = u_try - u
                d_lam_prev = step_dl
                u = u_try
                lam = lam_try
                if has_probes:
                    von_mises, sig, rot_deg = cls._nodal_fields(
                        u, nodes, elements, dNdX, dV0, D
                    )
                    probe_snap = cls._evaluate_probes(mesh.get("probes") or {}, u, von_mises, sig, rot_deg)
                else:
                    probe_snap = {}
                step_history.append({
                    "lambda": lam,
                    "probes": probe_snap,
                })
                if hp.large_disp and it <= 3:
                    d_lam = min(d_lam * 1.4, 0.25)
            else:
                lu_cached = None
                d_lam *= 0.5
                if d_lam < 1e-4:
                    warning = f"已達機構物理大變形極限 (lambda={lam:.3f})"
                    break
        von_mises, sig, rot_deg = cls._nodal_fields(u, nodes, elements, dNdX, dV0, D)
        probes = cls._evaluate_probes(mesh.get("probes") or {}, u, von_mises, sig, rot_deg)
        f_int, _min_det, _, _, _ = cls._assemble_residual(u, elements, dNdX, dV0, D, dof_map, n_dof)
        reactions = {}
        balance_vec = np.array([float(np.sum(f_ext[0::2])), float(np.sum(f_ext[1::2]))])
        for lay, (ids_raw, parsed) in groups.items():
            if parsed.get("type") not in ("FIXED", "DISP"):
                continue
            ids = np.unique(np.asarray(ids_raw, dtype=int))
            rx = float(np.sum(f_int[2 * ids]) - np.sum(f_ext[2 * ids]))
            ry = float(np.sum(f_int[2 * ids + 1]) - np.sum(f_ext[2 * ids + 1]))
            balance_vec += np.array([rx, ry])
            reactions[str(lay)] = {
                "rx_n": rx,
                "ry_n": ry,
                "r_n": math.hypot(rx, ry),
                "rx_gf": rx / GF_TO_N,
                "ry_gf": ry / GF_TO_N,
                "r_gf": math.hypot(rx, ry) / GF_TO_N,
                "n_nodes": int(len(ids)),
            }
        balance = float(np.linalg.norm(balance_vec))
        u2 = u.reshape(-1, 2)
        depth = {}
        for pid, pinfo in probes.items():
            hist = [
                {
                    "lambda": rec["lambda"],
                    "dx": rec["probes"][pid]["dx"],
                    "dy": rec["probes"][pid]["dy"],
                    "dxy": rec["probes"][pid]["dxy"],
                    "stress": rec["probes"][pid]["stress"],
                    "disp_theta": rec["probes"][pid]["disp_theta"],
                    "rot_theta": rec["probes"][pid]["rot_theta"],
                }
                for rec in step_history
                if pid in rec["probes"]
            ]
            pinfo["history"] = hist
            depth[pid] = pinfo
        vm_max = float(np.max(von_mises)) if len(von_mises) else 0.0
        return {
            "u": u2,
            "u_x": u2[:, 0],
            "u_y": u2[:, 1],
            "u_mag": np.hypot(u2[:, 0], u2[:, 1]),
            "disp_theta_deg": np.degrees(np.arctan2(u2[:, 1], u2[:, 0])),
            "rot_theta_deg": rot_deg,
            "von_mises": von_mises,
            "stress_tensor": sig,
            "probes": depth,
            "reactions": reactions,
            "converged_lambda": float(lam),
            "max_von_mises": vm_max,
            "safety_factor": (float(hp.yield_mpa) / vm_max) if vm_max > 1e-12 else float("inf"),
            "equilibrium_residual_n": balance,
            "n_dof": n_dof,
            "n_free": int(len(free)),
            "n_iter_total": n_iter_total,
            "step_history": step_history,
            "warning": warning,
            "hp": hp,
            "elapsed_ms": (time.perf_counter() - t0) * 1000.0,
        }

    @staticmethod
    def plot_fea_on_ax(result: dict, mesh: dict, ax, mode: str = "Von Mises 應力",
                       show_undeformed: bool = True, deform_scale: float = None):
        if ax is None or result is None:
            return None
        ax.clear()
        ax.set_facecolor("#0a0a0a")
        if ax.figure is not None:
            ax.figure.patch.set_facecolor("#0a0a0a")
        field_key, field_label, cmap = VIEW_FIELD.get(mode, VIEW_FIELD[VIEW_MODES[0]])
        hp = result.get("hp")
        if deform_scale is None:
            deform_scale = float(getattr(hp, "deform_scale", 1.0)) if hp is not None else 1.0
        scale = float(deform_scale)
        nodes0 = np.asarray(mesh["nodes"], dtype=float)
        elements = np.asarray(mesh["elements"], dtype=int)
        nodes = nodes0 + scale * np.asarray(result["u"], dtype=float)
        values = np.asarray(result[field_key], dtype=float)
        n0, n1, n2 = elements[:, 0], elements[:, 1], elements[:, 2]
        m01, m12, m20 = elements[:, 3], elements[:, 4], elements[:, 5]
        sub = np.stack([
            np.stack([n0, m01, m20], axis=1),
            np.stack([m01, n1, m12], axis=1),
            np.stack([m20, m12, n2], axis=1),
            np.stack([m01, m12, m20], axis=1),
        ], axis=1)
        tri = sub.reshape(-1, 3)
        tri_vals = values[tri].mean(axis=1)
        coll = PolyCollection(
            nodes[tri], array=tri_vals, cmap=cmap,
            edgecolors="none", alpha=0.95, zorder=2,
        )
        ax.add_collection(coll)
        prev_cbar = getattr(ax, "_fea_cbar", None)
        if prev_cbar is not None:
            try:
                prev_cbar.remove()
            except Exception:
                pass
            ax._fea_cbar = None
        cbar = ax.figure.colorbar(coll, ax=ax, shrink=0.8, pad=0.015)
        ax._fea_cbar = cbar
        cbar.set_label(field_label, color="#cccccc", fontsize=8)
        cbar.ax.tick_params(colors="#cccccc", labelsize=7)
        if show_undeformed:
            for loop in [mesh.get("outer_loop")] + list(mesh.get("hole_loops") or []):
                if loop is None or len(loop) < 2:
                    continue
                closed = np.vstack([loop, loop[0]])
                ax.plot(closed[:, 0], closed[:, 1], color="#55606a", lw=0.8, ls="--", zorder=3)
        for pid, pinfo in (result.get("probes") or {}).items():
            nid = int(pinfo.get("node_id", -1))
            if 0 <= nid < len(nodes):
                px, py = float(nodes[nid, 0]), float(nodes[nid, 1])
                ax.plot([px], [py], marker="+", markersize=12, color="#00ff88", mew=2.2, zorder=8)
                ax.annotate(
                    f"{pid}\ndx={pinfo['dx']:+.3f} dy={pinfo['dy']:+.3f}\n|d|={pinfo['dxy']:.3f} mm\n"
                    f"vm={pinfo['stress']:.1f} MPa",
                    xy=(px, py), xytext=(px + 2.5, py + 2.5),
                    color="#00ff88", fontsize=7.5, zorder=9,
                    bbox=dict(boxstyle="round,pad=0.25", facecolor="#101010", edgecolor="#00ff88", alpha=0.85),
                )
        hud = [
            f"T6 TL-SVK FEA | {getattr(hp, 'material', '')} | lambda={result['converged_lambda']:.3f}",
            f"Nodes {len(nodes)} | Elements {len(elements)} | iter {result['n_iter_total']} "
            f"| {result['elapsed_ms']:.0f} ms | Visual: {scale:g}x",
            f"max vm {result['max_von_mises']:.2f} MPa | SF {result['safety_factor']:.2f} | "
            f"eq-res {result['equilibrium_residual_n']:.3e} N",
        ]
        if result.get("warning"):
            hud.append(f"WARNING: {result['warning']}")
        ax.text(
            0.012, 0.985, "\n".join(hud), transform=ax.transAxes,
            color="#ffdd55", fontsize=8, va="top", ha="left", zorder=20,
            bbox=dict(boxstyle="round,pad=0.35", facecolor="#161616", edgecolor="#444444", alpha=0.92),
        )
        outer = mesh.get("outer_loop")
        if outer is not None and len(outer) > 0:
            allpts = np.vstack([nodes[tri].reshape(-1, 2), np.asarray(outer, dtype=float)])
            xmin, ymin = allpts.min(axis=0)
            xmax, ymax = allpts.max(axis=0)
            dx = max(xmax - xmin, 1.0) * 0.06
            dy = max(ymax - ymin, 1.0) * 0.06
            ax.set_xlim(xmin - dx, xmax + dx)
            ax.set_ylim(ymin - dy, ymax + dy)
        ax.set_aspect("equal", adjustable="box")
        ax.tick_params(colors="#888888", labelsize=7)
        return ax


def main():
    matplotlib.use("Agg")
    folder = os.path.dirname(os.path.abspath(__file__))
    dxf_path = sys.argv[1] if len(sys.argv) > 1 else None
    if dxf_path is None:
        dxf_files = sorted(f for f in os.listdir(folder) if f.lower().endswith(".dxf"))
        if not dxf_files:
            print("[錯誤] 資料夾內找不到 .dxf 檔案")
            return
        dxf_path = os.path.join(folder, dxf_files[0])
    print(f"[輸入] {dxf_path}")
    doc = ezdxf.readfile(dxf_path)
    out_dir = os.path.join(folder, "out")
    os.makedirs(out_dir, exist_ok=True)
    stem = os.path.splitext(os.path.basename(dxf_path))[0]
    print("[1/3] 輪廓與去重檢查 ...")
    check = DXFContourHelper.check_dxf(doc, hp=ContourHyperParams())
    counts = check.summary_dict()
    n_ov = counts["EXACT_DUPLICATE"] + counts["CONTAINMENT"] + counts["PARTIAL_OVERLAP"]
    print(f"      {'CLEAN (PASS)' if check.is_clean else 'ISSUES FOUND'} | 直線 {len(check.raw_line_segments)} -> 去重後 {len(check.clean_line_segments)}")
    print(f"      重疊={n_ov} 懸空={counts['OPEN_ENDPOINT']} 分岔={counts['MULTI_JUNCTION']} 微縫/退化={counts['MICRO_GAP'] + counts['DEGENERATE']} 端點相接={counts['HEAD_TO_TAIL']} 問題總數={len(check.issues)}")
    for iss in check.issues:
        print(f"      [#{iss.issue_id:02d}] [{iss.severity}] [{iss.issue_type}] {iss.description}")
    print("[2/3] T6 網格 ...")
    mesh = FiniteEleMeshHelper.build_t6_mesh_from_dxf(doc, hp=MeshHyperParams())
    print(f"      T6: {len(mesh['elements'])} 元素 / {len(mesh['nodes'])} 節點 | {mesh['elapsed_ms']:.0f} ms | 斷裂邊界邊 {mesh.get('broken_boundary_edges', 0)}")
    for lay, ginfo in (mesh.get("bc_groups") or {}).items():
        print(f"      BC {lay}: {len(ginfo.get('node_ids', []))} 節點")
    print("[3/3] FEA 求解 ...")
    fea_hp = SolverHyperParams()
    fea = FiniteEleSolverHelper.solve(mesh, hp=fea_hp)
    print(f"      vm_max={fea['max_von_mises']:.2f} MPa | SF={fea['safety_factor']:.2f} | λ={fea['converged_lambda']:.3f} | {fea['elapsed_ms']:.0f} ms")
    u_mag = np.asarray(fea["u_mag"], dtype=float)
    if len(u_mag):
        i_umax = int(np.argmax(u_mag))
        print(f"      |d|max={u_mag[i_umax]:.4f} mm @Node#{i_umax} | 節點位移中位數={float(np.median(u_mag)):.6f} mm")
    if fea.get("warning"):
        print(f"      [警告] {fea['warning']}")
    for btype, rinfo in (fea.get("reactions") or {}).items():
        print(f"      反力 {btype} Rx={rinfo['rx_n']:+.3f} N Ry={rinfo['ry_n']:+.3f} N (|R|={rinfo['r_gf']:.2f} gf, n={rinfo['n_nodes']})")
    for pid, pinfo in (fea.get("probes") or {}).items():
        print(f"      {pid} -> Node #{pinfo['node_id']} dx={pinfo['dx']:+.4f} dy={pinfo['dy']:+.4f} |d|={pinfo['dxy']:.4f} mm vm={pinfo['stress']:.2f} MPa")
    fig, ax = plt.subplots(figsize=(10, 6.5))
    DXFContourHelper.plot_check_result(check, ax=ax)
    fig.tight_layout()
    f_check = os.path.join(out_dir, f"{stem}_check.png")
    fig.savefig(f_check, dpi=140)
    plt.close(fig)
    fig, ax = plt.subplots(figsize=(10, 6.5))
    FiniteEleMeshHelper.plot_t6_mesh_on_ax(mesh, ax=ax)
    fig.tight_layout()
    f_mesh = os.path.join(out_dir, f"{stem}_mesh.png")
    fig.savefig(f_mesh, dpi=140)
    plt.close(fig)
    fig, ax = plt.subplots(figsize=(10, 6.5))
    FiniteEleSolverHelper.plot_fea_on_ax(fea, mesh, ax=ax, mode=VIEW_MODES[1], deform_scale=fea_hp.deform_scale)
    f_disp = os.path.join(out_dir, f"{stem}_disp.png")
    fig.savefig(f_disp, dpi=140)
    plt.close(fig)
    fig, ax = plt.subplots(figsize=(10, 6.5))
    FiniteEleSolverHelper.plot_fea_on_ax(fea, mesh, ax=ax, mode=VIEW_MODES[0], deform_scale=fea_hp.deform_scale)
    f_stress = os.path.join(out_dir, f"{stem}_stress.png")
    fig.savefig(f_stress, dpi=140)
    plt.close(fig)
    print(f"[輸出] {f_check}")
    print(f"[輸出] {f_mesh}")
    print(f"[輸出] {f_disp}")
    print(f"[輸出] {f_stress}")
    print("===== 結果摘要 =====")
    print(f"  模型      : {os.path.basename(dxf_path)}")
    print(f"  網格      : {len(mesh['elements'])} T6 元素 / {len(mesh['nodes'])} 節點 / 斷裂邊界邊 {mesh.get('broken_boundary_edges', 0)}")
    print(f"  材料      : {fea_hp.material} (E={fea_hp.E_mpa:.0f} MPa, nu={fea_hp.nu}, t={fea_hp.thickness_mm} mm)")
    print(f"  收斂      : lambda={fea['converged_lambda']:.4f}")
    if len(u_mag):
        print(f"  位移      : |d|max={float(u_mag.max()):.4f} mm")
    print(f"  應力      : vm_max={fea['max_von_mises']:.3f} MPa, SF={fea['safety_factor']:.3f}")
    return mesh, fea


if __name__ == "__main__":
    main()
