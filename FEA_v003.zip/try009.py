#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""try009.py — 以 try008 的 TRY# 搜索空間 + try005 的 FEA 作為 Query Score，執行混合實數遺傳演算法。"""

import os

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")

import math
import shutil
import sys
import time
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass
from datetime import datetime
from functools import cmp_to_key

import matplotlib

matplotlib.use("Agg")

import ezdxf
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colors import to_hex
from matplotlib.patches import Patch
from scipy.stats.qmc import LatinHypercube
from scipy.linalg import cho_factor, cho_solve
from scipy.optimize import minimize
from scipy.spatial.distance import cdist
from scipy.special import ndtr

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from try005 import (
    ContourHyperParams,
    DXFContourHelper,
    FiniteEleMeshHelper,
    FiniteEleSolverHelper,
    MeshHyperParams,
    SolverHyperParams,
    VIEW_MODES,
)
from try008 import (
    TrySearchSpaceHelper,
    render_morph_png,
    render_overview_png,
)


# ===================== 優化器選擇與超參數區塊 =====================
# 可選 "BO"（批次約束貝葉斯優化）或 "GA"（混合實數遺傳演算法）
OPTIMIZER_TYPE: str = "BO"


@dataclass
class CommonFeaConfig:
    # 1. 檔案路徑與平行運算
    dxf_path: str = "part01.dxf"
    out_root_dir: str = "optim_result"
    export_every_epoch: bool = True
    figure_dpi: int = 140
    n_workers: int = 0
    seed: int = 42
    cache_tol: float = 1e-5

    # 2. 幾何預檢與自動倒圓角
    min_wall_thickness_mm: float = 0.35
    min_corner_angle_deg: float = 10.0
    contour_snap_tol: float = 1e-3
    auto_fillet: bool = True
    fillet_mode: str = "concave"
    fillet_r_max: float = 0.80
    fillet_r_min: float = 0.05
    fillet_min_remain_len: float = 0.15
    fillet_min_remain_ratio: float = 0.25

    # 3. 網格與 FEA 求解器
    mesh_h_max: float = 2.20
    mesh_h_min: float = 0.45
    mesh_snap_tol: float = 1e-2
    material: str = "Al-7075-T6"
    E_mpa: float = 71700.0
    nu: float = 0.33
    thickness_mm: float = 10.0
    yield_stress_mpa: float = 503.0
    max_allow_stress_mpa: float = None
    min_converged_lambda: float = 0.999
    deform_scale: float = 1.0
    target_probe_id: str = "PROBE#001"


@dataclass
class GAConfig(CommonFeaConfig):
    # A1. 族群規模與世代
    pop_size: int = 60
    max_generations: int = 200
    init_local_count: int = 3
    init_local_sigma: float = 0.08

    # A2. 混合演化算子
    de_prob: float = 0.55
    cauchy_jump_prob: float = 0.20
    p_best_ratio: float = 0.30
    shade_memory_size: int = 6
    init_F: float = 0.50
    init_CR: float = 0.80
    sbx_eta: float = 10.0
    pm_eta: float = 12.0

    # A3. 多樣性、線搜索與停滯跳脫
    niche_radius: float = 0.14
    stagnation_patience: int = 2
    min_diversity_std: float = 0.08
    escape_replace_ratio: float = 0.33
    tabu_radius: float = 0.18
    enable_line_search: bool = True
    line_search_steps: tuple = (-0.25, 0.25, 0.50, 0.75, 1.05, 1.40)


@dataclass
class BOConfig(CommonFeaConfig):
    # B1. 初始 DoE 與批次世代
    init_samples: int = 32
    batch_size: int = 16
    max_epochs: int = 50
    init_local_count: int = 4
    init_local_sigma: float = 0.06

    # B2. 高斯過程代理模型
    gp_noise_var: float = 1e-5
    gp_lengthscale_init: float = 0.25
    gp_lengthscale_bounds: tuple = (0.03, 2.5)
    gp_max_train_size: int = 600

    # B3. 擷取函數與批次多樣化
    ei_xi: float = 0.01
    kb_beta_range: tuple = (-0.30, 1.50)
    candidate_pool_size: int = 2500
    local_candidate_ratio: float = 0.65
    min_batch_dist: float = 0.025

    # B4. TuRBO 信賴域
    tr_init_length: float = 0.40
    tr_min_length: float = 0.04
    tr_max_length: float = 0.80
    tr_expand_factor: float = 1.25
    tr_shrink_factor: float = 0.70
    tr_fail_tolerance: int = 2
# =================== 超參數區塊結束 ===================


@dataclass
class ActiveAxisSpec:
    group_id: str
    seq: int
    axis: str
    lo: float
    hi: float

    @property
    def span(self) -> float:
        return float(self.hi - self.lo)


class GeneCodec:
    def __init__(self, groups: dict):
        self.groups = groups
        self.active_axes = []
        self.group_to_indices = {}
        for gid, grp in sorted(groups.items(), key=lambda kv: kv[1].seq):
            dx_lo, dx_hi = grp.dx_bounds
            dy_lo, dy_hi = grp.dy_bounds
            if abs(dx_hi - dx_lo) > 1e-6:
                idx = len(self.active_axes)
                self.active_axes.append(ActiveAxisSpec(gid, grp.seq, "x", float(dx_lo), float(dx_hi)))
                self.group_to_indices.setdefault(gid, []).append(idx)
            if abs(dy_hi - dy_lo) > 1e-6:
                idx = len(self.active_axes)
                self.active_axes.append(ActiveAxisSpec(gid, grp.seq, "y", float(dy_lo), float(dy_hi)))
                self.group_to_indices.setdefault(gid, []).append(idx)

    @property
    def dim(self) -> int:
        return len(self.active_axes)

    def decode_unit_to_physical(self, u_vec) -> dict:
        u = np.clip(np.asarray(u_vec, dtype=float), 0.0, 1.0)
        out = {gid: [0.0, 0.0] for gid in self.groups}
        for i, spec in enumerate(self.active_axes):
            val = spec.lo + float(u[i]) * spec.span
            if spec.axis == "x":
                out[spec.group_id][0] = val
            else:
                out[spec.group_id][1] = val
        return {gid: (float(v[0]), float(v[1])) for gid, v in out.items()}

    def encode_physical_to_unit(self, disp_map: dict) -> np.ndarray:
        u = np.zeros(self.dim, dtype=float)
        for i, spec in enumerate(self.active_axes):
            dx, dy = disp_map.get(spec.group_id, (0.0, 0.0))
            val = dx if spec.axis == "x" else dy
            u[i] = np.clip((float(val) - spec.lo) / max(spec.span, 1e-12), 0.0, 1.0)
        return u

    def get_baseline_unit_vector(self) -> np.ndarray:
        zero_map = {gid: (0.0, 0.0) for gid in self.groups}
        return self.encode_physical_to_unit(zero_map)


def my_score_func(probe_info: dict, fea_result: dict = None, disp_map: dict = None) -> float:
    """自訂目標評分（GA 一律 Maximize）。預設：PROBE 的 dy 越大越好（mm）。"""
    return float(probe_info.get("dy", 0.0))


@dataclass
class IndividualRecord:
    ind_id: int
    generation: int
    u_vec: np.ndarray
    disp_map: dict
    is_geom_valid: bool = False
    is_fea_converged: bool = False
    probe_dx: float = 0.0
    probe_dy: float = 0.0
    probe_dxy: float = 0.0
    max_von_mises: float = 0.0
    safety_factor: float = 0.0
    converged_lambda: float = 0.0
    min_clearance_mm: float = 0.0
    constraint_violation: float = float("inf")
    query_score: float = -1e9
    eval_ms: float = 0.0
    status_msg: str = ""

    @property
    def is_feasible(self) -> bool:
        return self.is_geom_valid and self.is_fea_converged and (self.constraint_violation <= 1e-9)


@dataclass
class EpochStatRecord:
    epoch: int
    elapsed_sec: float
    epoch_best: IndividualRecord
    best_so_far: IndividualRecord
    n_valid: int = 0
    n_total: int = 0
    score_max: float = 0.0
    score_min: float = 0.0
    score_mean: float = 0.0
    score_median: float = 0.0
    score_mode: float = 0.0
    valid_scores: list = None


def _estimate_continuous_mode(values) -> float:
    arr = np.asarray(values, dtype=float)
    n = len(arr)
    if n == 0:
        return 0.0
    if n <= 2 or float(np.max(arr) - np.min(arr)) <= 1e-9:
        return float(np.mean(arr))
    n_bins = max(4, min(10, int(math.ceil(math.sqrt(n)))))
    counts, edges = np.histogram(arr, bins=n_bins)
    modal_bin = int(np.argmax(counts))
    lo, hi = edges[modal_bin], edges[modal_bin + 1]
    if modal_bin == n_bins - 1:
        in_bin = arr[(arr >= lo) & (arr <= hi)]
    else:
        in_bin = arr[(arr >= lo) & (arr < hi)]
    if len(in_bin) == 0:
        return float(0.5 * (lo + hi))
    return float(np.mean(in_bin))


def compute_epoch_statistics(epoch: int, epoch_candidates: list, best_so_far: IndividualRecord,
                             elapsed_sec: float = 0.0) -> EpochStatRecord:
    valid_inds = [ind for ind in epoch_candidates if ind.is_geom_valid and ind.is_fea_converged]
    target_pool = valid_inds if valid_inds else epoch_candidates
    scores = np.array([ind.query_score for ind in target_pool], dtype=float) if target_pool else np.empty(0)
    epoch_best = epoch_candidates[0]
    for ind in epoch_candidates[1:]:
        if FeaFitnessEvaluator.is_better_by_deb(ind, epoch_best):
            epoch_best = ind
    return EpochStatRecord(
        epoch=epoch,
        elapsed_sec=float(elapsed_sec),
        epoch_best=epoch_best,
        best_so_far=best_so_far,
        n_valid=len(valid_inds),
        n_total=len(epoch_candidates),
        score_max=float(np.max(scores)) if len(scores) else 0.0,
        score_min=float(np.min(scores)) if len(scores) else 0.0,
        score_mean=float(np.mean(scores)) if len(scores) else 0.0,
        score_median=float(np.median(scores)) if len(scores) else 0.0,
        score_mode=_estimate_continuous_mode(scores) if len(scores) else 0.0,
        valid_scores=scores.tolist(),
    )


_WORKER_EVALUATOR = None


def _init_worker_process(dxf_path: str, cfg: GAConfig):
    global _WORKER_EVALUATOR
    src_doc = ezdxf.readfile(dxf_path)
    groups = TrySearchSpaceHelper.extract_try_groups(src_doc)
    TrySearchSpaceHelper.bind_layer0_control_points(src_doc, groups)
    codec = GeneCodec(groups)
    _WORKER_EVALUATOR = FeaFitnessEvaluator(
        src_doc, groups, codec, cfg, score_func=my_score_func,
        dxf_path=None, enable_pool=False,
    )


def _worker_eval_one(task):
    u_vec, generation = task
    return _WORKER_EVALUATOR.evaluate_individual(u_vec, generation=generation)


class FeaFitnessEvaluator:
    def __init__(self, src_doc, groups: dict, codec: GeneCodec, cfg: GAConfig,
                 score_func=my_score_func, dxf_path: str = None, enable_pool: bool = True):
        self.src_doc = src_doc
        self.groups = groups
        self.codec = codec
        self.cfg = cfg
        self.score_func = score_func
        self.dxf_path = dxf_path
        self.contour_hp = ContourHyperParams(snap_tol=cfg.contour_snap_tol)
        self.mesh_hp = MeshHyperParams(
            h_max=cfg.mesh_h_max,
            h_min=cfg.mesh_h_min,
            snap_tol=cfg.mesh_snap_tol,
        )
        self.solver_hp = SolverHyperParams(
            material=cfg.material,
            E_mpa=cfg.E_mpa,
            nu=cfg.nu,
            thickness_mm=cfg.thickness_mm,
            yield_mpa=cfg.yield_stress_mpa,
            deform_scale=cfg.deform_scale,
        )
        self.eval_counter = 0
        self._cache = []
        self.fillet_kwargs = {
            "auto_fillet": cfg.auto_fillet,
            "fillet_r_max": cfg.fillet_r_max,
            "fillet_r_min": cfg.fillet_r_min,
            "fillet_mode": cfg.fillet_mode,
            "min_remain_len": cfg.fillet_min_remain_len,
            "min_remain_ratio": cfg.fillet_min_remain_ratio,
        }
        self.n_workers = int(cfg.n_workers) if (cfg.n_workers and cfg.n_workers > 0) else (os.cpu_count() or 4)
        self._pool = None
        if enable_pool and dxf_path and self.n_workers > 1:
            self._pool = ProcessPoolExecutor(
                max_workers=self.n_workers,
                initializer=_init_worker_process,
                initargs=(dxf_path, cfg),
            )
        zero_doc = TrySearchSpaceHelper.apply_group_displacements(
            src_doc, groups, {gid: (0.0, 0.0) for gid in groups}, **self.fillet_kwargs
        )
        self.base_open = 0
        self.base_inter = 0
        self.base_island = 0
        self.effective_min_wall_mm = cfg.min_wall_thickness_mm
        try:
            base_chk = DXFContourHelper.check_dxf(zero_doc, hp=self.contour_hp)
            base_cnt = base_chk.summary_dict()
            self.base_open = int(base_cnt.get("OPEN_ENDPOINT", 0))
            self.base_inter = int(base_cnt.get("LOOP_INTERSECT", 0))
            self.base_island = int(base_cnt.get("EXTERIOR_ISLAND", 0) + base_cnt.get("NESTED_ISLAND", 0))
            base_clr, _has_x, _min_ang = self.analyze_loop_clearance_and_angles(
                base_chk.loops, cfg.min_wall_thickness_mm
            )
            if base_clr < cfg.min_wall_thickness_mm:
                self.effective_min_wall_mm = max(0.10, 0.90 * base_clr)
        except Exception as exc:
            print(f"[警告] 基準圖面檢查失敗（將以 0 為基準）: {exc}")

    @staticmethod
    def _seg_to_seg_dist(a1, a2, b1, b2) -> float:
        u = a2 - a1
        v = b2 - b1
        w = a1 - b1
        a = float(u @ u)
        b = float(u @ v)
        c = float(v @ v)
        d = float(u @ w)
        e = float(v @ w)
        D = a * c - b * b
        sD, tD = D, D
        if D < 1e-12:
            sN, sD = 0.0, 1.0
            tN, tD = e, c
        else:
            sN = b * e - c * d
            tN = a * e - b * d
            if sN < 0.0:
                sN = 0.0
                tN, tD = e, c
            elif sN > sD:
                sN = sD
                tN, tD = e + b, c
        if tN < 0.0:
            tN = 0.0
            if -d < 0.0:
                sN = 0.0
            elif -d > a:
                sN = sD
            else:
                sN, sD = -d, a
        elif tN > tD:
            tN = tD
            if (-d + b) < 0.0:
                sN = 0.0
            elif (-d + b) > a:
                sN = sD
            else:
                sN, sD = -d + b, a
        sc = 0.0 if abs(sN) < 1e-12 else sN / sD
        tc = 0.0 if abs(tN) < 1e-12 else tN / tD
        dP = w + (sc * u) - (tc * v)
        return float(np.linalg.norm(dP))

    @classmethod
    def analyze_loop_clearance_and_angles(cls, loops: list, min_required: float):
        segs = []
        boxes = []
        min_angle_deg = 180.0
        arc_skip_dist = max(2.5 * min_required, 1.0)
        for lp_idx, lp in enumerate(loops):
            pts = np.asarray(lp.get("pts", []), dtype=float)
            n = len(pts)
            if n < 3:
                continue
            seg_lens = np.linalg.norm(np.roll(pts, -1, axis=0) - pts, axis=1)
            cum_arc = np.concatenate(([0.0], np.cumsum(seg_lens)))
            total_perim = float(cum_arc[-1])
            for k in range(n):
                p_prev = pts[(k - 1) % n]
                p_curr = pts[k]
                p_next = pts[(k + 1) % n]
                v1 = p_prev - p_curr
                v2 = p_next - p_curr
                l1 = float(np.linalg.norm(v1))
                l2 = float(np.linalg.norm(v2))
                if l1 > 1e-6 and l2 > 1e-6:
                    cos_t = float(np.clip((v1 @ v2) / (l1 * l2), -1.0, 1.0))
                    ang = math.degrees(math.acos(cos_t))
                    if ang < min_angle_deg:
                        min_angle_deg = ang
                a = pts[k]
                b = pts[(k + 1) % n]
                mid_s = 0.5 * (cum_arc[k] + cum_arc[k + 1])
                segs.append((lp_idx, k, n, a, b, mid_s, total_perim))
                boxes.append((
                    min(a[0], b[0]), min(a[1], b[1]),
                    max(a[0], b[0]), max(a[1], b[1]),
                ))
        min_dist = float("inf")
        has_self_inter = False
        m = len(segs)
        for i in range(m):
            lp_i, k_i, n_i, a1, a2, s_i, perim_i = segs[i]
            bi = boxes[i]
            for j in range(i + 1, m):
                bj = boxes[j]
                gx = max(0.0, bi[0] - bj[2], bj[0] - bi[2])
                gy = max(0.0, bi[1] - bj[3], bj[1] - bi[3])
                if (gx * gx + gy * gy) >= min_dist * min_dist and not has_self_inter:
                    continue
                lp_j, k_j, _n_j, b1, b2, s_j, _perim_j = segs[j]
                same_loop = (lp_i == lp_j)
                if same_loop:
                    diff = abs(k_i - k_j)
                    if diff <= 1 or diff >= n_i - 1:
                        continue
                    if min(
                        float(np.linalg.norm(a1 - b1)),
                        float(np.linalg.norm(a1 - b2)),
                        float(np.linalg.norm(a2 - b1)),
                        float(np.linalg.norm(a2 - b2)),
                    ) <= 1e-3:
                        continue
                d = cls._seg_to_seg_dist(a1, a2, b1, b2)
                if d <= 1e-5:
                    return 0.0, True, min_angle_deg
                if same_loop:
                    ds = abs(s_i - s_j)
                    geodesic_d = min(ds, perim_i - ds)
                    if geodesic_d <= arc_skip_dist:
                        continue
                if d < min_dist:
                    min_dist = d
        return (min_dist if min_dist < float("inf") else 999.0), has_self_inter, min_angle_deg

    def precheck_geometry_validity(self, morphed_doc):
        try:
            chk = DXFContourHelper.check_dxf(morphed_doc, hp=self.contour_hp)
        except Exception as exc:
            return False, 2000.0, 0.0, f"check_err:{exc}"
        counts = chk.summary_dict()
        d_open = max(0, int(counts.get("OPEN_ENDPOINT", 0)) - self.base_open)
        d_inter = max(0, int(counts.get("LOOP_INTERSECT", 0)) - self.base_inter)
        d_island = max(
            0,
            int(counts.get("EXTERIOR_ISLAND", 0) + counts.get("NESTED_ISLAND", 0)) - self.base_island,
        )
        n_junc = int(counts.get("MULTI_JUNCTION", 0))
        n_ov = int(counts.get("PARTIAL_OVERLAP", 0) + counts.get("CONTAINMENT", 0))
        if d_open > 0 or d_inter > 0 or d_island > 0 or n_junc > 0 or n_ov > 0:
            viol = 1000.0 + 250.0 * d_open + 350.0 * d_inter + 200.0 * d_island + 150.0 * (n_junc + n_ov)
            return False, viol, 0.0, f"topo(dOPEN={d_open},dX={d_inter},dISL={d_island},JUNC={n_junc},OV={n_ov})"
        min_clr, has_self_x, min_ang = self.analyze_loop_clearance_and_angles(
            chk.loops, self.effective_min_wall_mm
        )
        if has_self_x:
            return False, 1200.0, 0.0, "self_intersect"
        if min_ang < self.cfg.min_corner_angle_deg:
            deficit_ang = self.cfg.min_corner_angle_deg - min_ang
            return False, 900.0 + 20.0 * deficit_ang, min_clr, f"sharp_spike({min_ang:.1f}deg)"
        if min_clr < self.effective_min_wall_mm:
            deficit = self.effective_min_wall_mm - min_clr
            return False, 800.0 + 500.0 * deficit, min_clr, f"thin({min_clr:.3f}<{self.effective_min_wall_mm:.3f})"
        return True, 0.0, min_clr, "ok"

    def close_pool(self):
        if self._pool is not None:
            self._pool.shutdown(wait=True)
            self._pool = None

    def _lookup_cache(self, u_clean, generation: int):
        for u_prev, rec_prev in self._cache:
            if float(np.max(np.abs(u_clean - u_prev))) < self.cfg.cache_tol:
                self.eval_counter += 1
                return IndividualRecord(
                    ind_id=self.eval_counter,
                    generation=generation,
                    u_vec=u_clean.copy(),
                    disp_map=dict(rec_prev.disp_map),
                    is_geom_valid=rec_prev.is_geom_valid,
                    is_fea_converged=rec_prev.is_fea_converged,
                    probe_dx=rec_prev.probe_dx,
                    probe_dy=rec_prev.probe_dy,
                    probe_dxy=rec_prev.probe_dxy,
                    max_von_mises=rec_prev.max_von_mises,
                    safety_factor=rec_prev.safety_factor,
                    converged_lambda=rec_prev.converged_lambda,
                    min_clearance_mm=rec_prev.min_clearance_mm,
                    constraint_violation=rec_prev.constraint_violation,
                    query_score=rec_prev.query_score,
                    eval_ms=0.0,
                    status_msg=rec_prev.status_msg + "(cached)",
                )
        return None

    def evaluate_batch(self, u_list: list, generation: int = 0) -> list:
        if not u_list:
            return []
        if self._pool is None or len(u_list) < 2:
            return [self.evaluate_individual(u, generation=generation) for u in u_list]
        results = [None] * len(u_list)
        pending_tasks = []
        pos_of_key = {}
        slots = []
        for u_raw in u_list:
            u_clean = np.clip(np.asarray(u_raw, dtype=float), 0.0, 1.0)
            hit = self._lookup_cache(u_clean, generation)
            if hit is not None:
                slots.append(("hit", hit))
                continue
            key = tuple(np.round(u_clean, 5).tolist())
            if key not in pos_of_key:
                pos_of_key[key] = len(pending_tasks)
                pending_tasks.append((u_clean, generation))
            slots.append(("task", key))
        worker_recs = []
        if pending_tasks:
            try:
                worker_recs = list(self._pool.map(_worker_eval_one, pending_tasks))
            except Exception as exc:
                print(f"[警告] 多工評估失敗，回退單進程: {exc}")
                try:
                    self._pool.shutdown(wait=False)
                except Exception:
                    pass
                self._pool = None
                return [self.evaluate_individual(u, generation=generation) for u in u_list]
            for pos, (u_clean, _gen) in enumerate(pending_tasks):
                self.eval_counter += 1
                worker_recs[pos].ind_id = self.eval_counter
                self._cache.append((u_clean.copy(), worker_recs[pos]))
        used_pos = set()
        for idx, (kind, payload) in enumerate(slots):
            if kind == "hit":
                results[idx] = payload
            else:
                pos = pos_of_key[payload]
                base_rec = worker_recs[pos]
                if pos not in used_pos:
                    used_pos.add(pos)
                    results[idx] = base_rec
                else:
                    self.eval_counter += 1
                    results[idx] = IndividualRecord(
                        ind_id=self.eval_counter,
                        generation=generation,
                        u_vec=base_rec.u_vec.copy(),
                        disp_map=dict(base_rec.disp_map),
                        is_geom_valid=base_rec.is_geom_valid,
                        is_fea_converged=base_rec.is_fea_converged,
                        probe_dx=base_rec.probe_dx,
                        probe_dy=base_rec.probe_dy,
                        probe_dxy=base_rec.probe_dxy,
                        max_von_mises=base_rec.max_von_mises,
                        safety_factor=base_rec.safety_factor,
                        converged_lambda=base_rec.converged_lambda,
                        min_clearance_mm=base_rec.min_clearance_mm,
                        constraint_violation=base_rec.constraint_violation,
                        query_score=base_rec.query_score,
                        eval_ms=0.0,
                        status_msg=base_rec.status_msg + "(batch_dup)",
                    )
        return results

    def evaluate_individual(self, u_vec, generation: int = 0) -> IndividualRecord:
        t0 = time.perf_counter()
        u_clean = np.clip(np.asarray(u_vec, dtype=float), 0.0, 1.0)
        hit = self._lookup_cache(u_clean, generation)
        if hit is not None:
            return hit
        self.eval_counter += 1
        disp_map = self.codec.decode_unit_to_physical(u_clean)
        rec = IndividualRecord(
            ind_id=self.eval_counter,
            generation=generation,
            u_vec=u_clean.copy(),
            disp_map=disp_map,
        )
        try:
            morphed_doc = TrySearchSpaceHelper.apply_group_displacements(
            self.src_doc, self.groups, disp_map, **self.fillet_kwargs
        )
        except Exception as exc:
            rec.is_geom_valid = False
            rec.constraint_violation = 2000.0
            rec.query_score = -2000.0
            rec.status_msg = f"morph_err:{exc}"
            rec.eval_ms = (time.perf_counter() - t0) * 1000.0
            self._cache.append((u_clean.copy(), rec))
            return rec
        ok_geom, geom_viol, min_clr, msg = self.precheck_geometry_validity(morphed_doc)
        rec.min_clearance_mm = min_clr
        if not ok_geom:
            rec.is_geom_valid = False
            rec.constraint_violation = geom_viol
            rec.query_score = -geom_viol
            rec.status_msg = msg
            rec.eval_ms = (time.perf_counter() - t0) * 1000.0
            self._cache.append((u_clean.copy(), rec))
            return rec
        rec.is_geom_valid = True
        try:
            mesh = FiniteEleMeshHelper.build_t6_mesh_from_dxf(morphed_doc, hp=self.mesh_hp)
            fea = FiniteEleSolverHelper.solve(mesh, hp=self.solver_hp)
        except Exception as exc:
            rec.is_fea_converged = False
            rec.constraint_violation = 600.0
            rec.query_score = -600.0
            rec.status_msg = f"fea_err:{exc}"
            rec.eval_ms = (time.perf_counter() - t0) * 1000.0
            self._cache.append((u_clean.copy(), rec))
            return rec
        lam = float(fea.get("converged_lambda", 0.0))
        vm_max = float(fea.get("max_von_mises", 0.0))
        sf = float(fea.get("safety_factor", 0.0))
        probes = fea.get("probes") or {}
        pinfo = probes.get(self.cfg.target_probe_id) or (next(iter(probes.values())) if probes else {})
        rec.probe_dx = float(pinfo.get("dx", 0.0))
        rec.probe_dy = float(pinfo.get("dy", 0.0))
        rec.probe_dxy = float(pinfo.get("dxy", 0.0))
        rec.max_von_mises = vm_max
        rec.safety_factor = sf
        rec.converged_lambda = lam
        rec.is_fea_converged = (lam >= self.cfg.min_converged_lambda)
        cv = 0.0
        if lam < self.cfg.min_converged_lambda:
            cv += 400.0 * (1.0 - lam)
        if self.cfg.max_allow_stress_mpa is not None and vm_max > self.cfg.max_allow_stress_mpa:
            cv += (vm_max - self.cfg.max_allow_stress_mpa)
        rec.constraint_violation = float(cv)
        rec.query_score = float(self.score_func(pinfo, fea, disp_map))
        rec.status_msg = "OK" if cv <= 1e-9 else f"CV({cv:.1f})"
        rec.eval_ms = (time.perf_counter() - t0) * 1000.0
        self._cache.append((u_clean.copy(), rec))
        return rec

    @staticmethod
    def is_better_by_deb(ind_a: IndividualRecord, ind_b: IndividualRecord) -> bool:
        if ind_a.is_feasible and not ind_b.is_feasible:
            return True
        if not ind_a.is_feasible and ind_b.is_feasible:
            return False
        if ind_a.is_feasible and ind_b.is_feasible:
            return ind_a.query_score > ind_b.query_score
        if abs(ind_a.constraint_violation - ind_b.constraint_violation) > 1e-6:
            return ind_a.constraint_violation < ind_b.constraint_violation
        return ind_a.query_score > ind_b.query_score


class HybridRealCodedGA:
    def __init__(self, evaluator: FeaFitnessEvaluator, codec: GeneCodec, cfg: GAConfig):
        self.evaluator = evaluator
        self.codec = codec
        self.cfg = cfg
        self.rng = np.random.default_rng(seed=cfg.seed)
        self.memory_size = int(cfg.shade_memory_size)
        self.M_F = np.full(self.memory_size, cfg.init_F, dtype=float)
        self.M_CR = np.full(self.memory_size, cfg.init_CR, dtype=float)
        self.mem_idx = 0
        self.archive = []
        self.tabu_optima = []
        self.history = []
        self.best_per_gen = []
        self.epoch_stats = []
        self._last_export = None

    def sort_population(self, pop):
        def _cmp(a, b):
            if FeaFitnessEvaluator.is_better_by_deb(a, b):
                return -1
            if FeaFitnessEvaluator.is_better_by_deb(b, a):
                return 1
            return 0
        return sorted(pop, key=cmp_to_key(_cmp))

    def initialize_population_lhs(self):
        D = self.codec.dim
        P = self.cfg.pop_size
        u_list = []
        u0 = self.codec.get_baseline_unit_vector()
        u_list.append(u0.copy())
        n_local = min(self.cfg.init_local_count, max(0, P - 1))
        for _ in range(n_local):
            u_list.append(np.clip(u0 + self.rng.normal(0.0, self.cfg.init_local_sigma, size=D), 0.0, 1.0))
        n_rem = P - len(u_list)
        if n_rem > 0:
            sampler = LatinHypercube(d=D, seed=int(self.rng.integers(1, 1000000)))
            for row in sampler.random(n=n_rem):
                u_list.append(np.asarray(row, dtype=float))
        pop = self.evaluator.evaluate_batch(u_list, generation=0)
        self.history.extend(pop)
        return self.sort_population(pop)

    def _boundary_handle(self, v, parent):
        out = v.copy()
        for j in range(len(out)):
            if out[j] < 0.0:
                out[j] = 0.0 if self.rng.random() < 0.5 else min(1.0, -out[j])
            elif out[j] > 1.0:
                out[j] = 1.0 if self.rng.random() < 0.5 else max(0.0, 2.0 - out[j])
        return np.clip(out, 0.0, 1.0)

    def operator_cauchy_or_opposition_jump(self, u_base, best_u, stagnation: int):
        D = self.codec.dim
        child = u_base.copy()
        scale = 0.18 * (1.0 + 0.5 * stagnation)
        if self.rng.random() < 0.5:
            n_mut = int(self.rng.integers(1, max(2, D // 2 + 1)))
            dims = self.rng.choice(D, size=n_mut, replace=False)
            child[dims] = child[dims] + scale * self.rng.standard_cauchy(size=n_mut)
        else:
            gids = list(self.codec.group_to_indices.keys())
            pick_gid = gids[int(self.rng.integers(0, len(gids)))]
            for ax_idx in self.codec.group_to_indices[pick_gid]:
                if self.rng.random() < 0.5:
                    child[ax_idx] = 1.0 - u_base[ax_idx]
                else:
                    child[ax_idx] = float(self.rng.uniform(0.0, 1.0))
        child = self._boundary_handle(child, u_base)
        if float(np.linalg.norm(child - best_u)) < 0.05:
            child = self._boundary_handle(self.rng.uniform(0.0, 1.0, size=D), u_base)
        return child

    def operator_de_current_to_pbest(self, sorted_pop, idx, F, CR):
        D = self.codec.dim
        P = len(sorted_pop)
        p_num = max(2, int(round(self.cfg.p_best_ratio * P)))
        pbest_idx = int(self.rng.integers(0, p_num))
        u_i = sorted_pop[idx].u_vec
        u_pbest = sorted_pop[pbest_idx].u_vec
        r1 = int(self.rng.integers(0, P))
        while r1 == idx and P > 1:
            r1 = int(self.rng.integers(0, P))
        u_r1 = sorted_pop[r1].u_vec
        union_pool = [ind.u_vec for ind in sorted_pop] + self.archive
        r2 = int(self.rng.integers(0, len(union_pool)))
        while (r2 == idx or r2 == r1) and len(union_pool) > 2:
            r2 = int(self.rng.integers(0, len(union_pool)))
        u_r2 = union_pool[r2]
        v = u_i + F * (u_pbest - u_i) + F * (u_r1 - u_r2)
        v = self._boundary_handle(v, u_i)
        j_rand = int(self.rng.integers(0, D))
        mask = self.rng.random(size=D) < CR
        mask[j_rand] = True
        return np.where(mask, v, u_i)

    def operator_sbx_and_poly_mutation(self, u1, u2):
        D = self.codec.dim
        child = 0.5 * (u1 + u2)
        eta_c = self.cfg.sbx_eta
        for j in range(D):
            if self.rng.random() <= 0.5 and abs(u1[j] - u2[j]) > 1e-9:
                y1, y2 = min(u1[j], u2[j]), max(u1[j], u2[j])
                rand = self.rng.random()
                beta = 1.0 + (2.0 * y1 / (y2 - y1))
                alpha = 2.0 - beta ** -(eta_c + 1.0)
                if rand <= (1.0 / alpha):
                    betaq = (rand * alpha) ** (1.0 / (eta_c + 1.0))
                else:
                    betaq = (1.0 / (2.0 - rand * alpha)) ** (1.0 / (eta_c + 1.0))
                child[j] = 0.5 * ((y1 + y2) - betaq * (y2 - y1))
        eta_m = self.cfg.pm_eta
        pm_prob = 1.0 / max(D, 1)
        for j in range(D):
            if self.rng.random() <= pm_prob:
                y = float(np.clip(child[j], 0.0, 1.0))
                r = self.rng.random()
                if r < 0.5:
                    dq = (2.0 * r + (1.0 - 2.0 * r) * ((1.0 - y) ** (eta_m + 1.0))) ** (1.0 / (eta_m + 1.0)) - 1.0
                else:
                    dq = 1.0 - (2.0 * (1.0 - r) + 2.0 * (r - 0.5) * (y ** (eta_m + 1.0))) ** (1.0 / (eta_m + 1.0))
                child[j] = y + dq
        return np.clip(child, 0.0, 1.0)

    def local_directional_line_search(self, new_best, prev_best, gen: int):
        direction = new_best.u_vec - prev_best.u_vec
        dir_norm = float(np.linalg.norm(direction))
        if dir_norm < 1e-4:
            return new_best
        target_batch = max(4, self.evaluator.n_workers)
        probe_u_list = []
        for step_scale in self.cfg.line_search_steps:
            u_probe = self._boundary_handle(new_best.u_vec + step_scale * direction, new_best.u_vec)
            if float(np.linalg.norm(u_probe - new_best.u_vec)) >= 1e-4:
                probe_u_list.append(u_probe)
        gids = list(self.codec.group_to_indices.keys())
        radius = float(np.clip(0.5 * dir_norm, 0.03, 0.15))
        while len(probe_u_list) < target_batch:
            u_loc = new_best.u_vec.copy()
            if gids:
                gid = gids[len(probe_u_list) % len(gids)]
                for ax_idx in self.codec.group_to_indices[gid]:
                    u_loc[ax_idx] += float(self.rng.normal(0.0, radius))
            else:
                u_loc += self.rng.normal(0.0, radius, size=self.codec.dim)
            probe_u_list.append(self._boundary_handle(u_loc, new_best.u_vec))
        cands = self.evaluator.evaluate_batch(probe_u_list[:target_batch], generation=gen)
        self.history.extend(cands)
        cur_best = new_best
        for cand in cands:
            if FeaFitnessEvaluator.is_better_by_deb(cand, cur_best):
                cur_best = cand
        return cur_best

    def select_population_crowding_and_niche(self, parents, offspring):
        D = max(1, self.codec.dim)
        eff_niche_r = self.cfg.niche_radius * math.sqrt(D)
        survivors = list(parents)
        for child in offspring:
            dists = [float(np.linalg.norm(child.u_vec - p.u_vec)) for p in survivors]
            nearest_idx = int(np.argmin(dists))
            if FeaFitnessEvaluator.is_better_by_deb(child, survivors[nearest_idx]):
                survivors[nearest_idx] = child
        P = self.cfg.pop_size
        sorted_pool = self.sort_population(survivors)
        selected = []
        crowded = []
        for cand in sorted_pool:
            if len(selected) >= P:
                break
            if any(float(np.linalg.norm(cand.u_vec - s.u_vec)) < eff_niche_r for s in selected):
                crowded.append(cand)
            else:
                selected.append(cand)
        for c in crowded[:2]:
            if len(selected) >= P:
                break
            selected.append(c)
        return self.sort_population(selected)

    def _sample_escape_vector(self, best_u, idx: int):
        gids = list(self.codec.group_to_indices.keys())
        if idx % 2 == 1 and gids:
            u_jump = best_u.copy()
            pick_gid = gids[int(self.rng.integers(0, len(gids)))]
            for ax_idx in self.codec.group_to_indices[pick_gid]:
                u_jump[ax_idx] = float(self.rng.uniform(0.0, 1.0))
            return u_jump
        u_jump = self.rng.uniform(0.0, 1.0, size=self.codec.dim)
        for _ in range(8):
            if all(float(np.linalg.norm(u_jump - t)) >= self.cfg.tabu_radius for t in self.tabu_optima):
                break
            u_jump = self.rng.uniform(0.0, 1.0, size=self.codec.dim)
        return u_jump

    def _record_and_export_epoch(self, epoch: int, epoch_pool: list, best_overall: IndividualRecord,
                                 out_dir, elapsed_sec: float = 0.0):
        stat = compute_epoch_statistics(epoch, epoch_pool, best_overall, elapsed_sec=elapsed_sec)
        self.epoch_stats.append(stat)
        print(
            f"         [Epoch {epoch:02d} 統計] t={stat.elapsed_sec:.1f}s | valid={stat.n_valid}/{stat.n_total} | "
            f"Max={stat.score_max:+.4f} | Mean={stat.score_mean:+.4f} | "
            f"Median={stat.score_median:+.4f} | Min={stat.score_min:+.4f}"
        )
        if out_dir is None:
            return
        prefix = f"ep{epoch}"
        if self.cfg.export_every_epoch:
            reuse_from = None
            if self._last_export is not None and self._last_export["ind_id"] == stat.best_so_far.ind_id:
                reuse_from = self._last_export["prefix"]
            export_single_epoch_artifacts(
                self.evaluator.src_doc, self.evaluator.groups, stat, self.evaluator,
                out_dir, prefix=prefix, reuse_from=reuse_from,
            )
            self._last_export = {"prefix": prefix, "ind_id": stat.best_so_far.ind_id}
        render_epoch_statistics_png(
            self.epoch_stats, os.path.join(out_dir, "epoch_stats_distribution.png"),
            dpi=self.cfg.figure_dpi,
        )

    def run_evolution(self, out_dir=None):
        if self.codec.dim == 0:
            raise ValueError("所有 TRY# 群組的 (dx, dy) 範圍皆為 0，無可優化維度！")
        t_start = time.perf_counter()
        pop = self.initialize_population_lhs()
        best_overall = pop[0]
        self.best_per_gen.append(best_overall)
        print(
            f"[Gen 00] Best #{best_overall.ind_id:03d} | feasible={best_overall.is_feasible} "
            f"| score={best_overall.query_score:+.4f} "
            f"(dx={best_overall.probe_dx:+.4f}, dy={best_overall.probe_dy:+.4f}) "
            f"| vm={best_overall.max_von_mises:.1f} MPa | {best_overall.status_msg}"
        )
        self._record_and_export_epoch(0, pop, best_overall, out_dir,
                                      elapsed_sec=time.perf_counter() - t_start)
        stagnation = 0
        for gen in range(1, self.cfg.max_generations + 1):
            S_F, S_CR, S_gain = [], [], []
            P = len(pop)
            trial_u_list = []
            trial_F_CR = []
            for i in range(P):
                r_mem = int(self.rng.integers(0, self.memory_size))
                F_i = float(np.clip(self.rng.standard_cauchy() * 0.1 + self.M_F[r_mem], 0.1, 1.0))
                CR_i = float(np.clip(self.rng.normal(self.M_CR[r_mem], 0.1), 0.0, 1.0))
                r_op = self.rng.random()
                if r_op < self.cfg.de_prob:
                    u_trial = self.operator_de_current_to_pbest(pop, i, F_i, CR_i)
                elif r_op < self.cfg.de_prob + self.cfg.cauchy_jump_prob:
                    u_trial = self.operator_cauchy_or_opposition_jump(
                        pop[i].u_vec, best_overall.u_vec, stagnation
                    )
                else:
                    p2_idx = int(self.rng.integers(0, P))
                    u_trial = self.operator_sbx_and_poly_mutation(pop[i].u_vec, pop[p2_idx].u_vec)
                trial_u_list.append(u_trial)
                trial_F_CR.append((F_i, CR_i))
            offspring = self.evaluator.evaluate_batch(trial_u_list, generation=gen)
            self.history.extend(offspring)
            for i, (child, (F_i, CR_i)) in enumerate(zip(offspring, trial_F_CR)):
                if FeaFitnessEvaluator.is_better_by_deb(child, pop[i]):
                    self.archive.append(pop[i].u_vec.copy())
                    S_F.append(F_i)
                    S_CR.append(CR_i)
                    if child.is_feasible and pop[i].is_feasible:
                        gain = max(0.0, child.query_score - pop[i].query_score) + 1e-5
                    else:
                        gain = 1e-3
                    S_gain.append(gain)
            if len(self.archive) > P * 2:
                self.archive = self.archive[-P * 2:]
            if S_F:
                w = np.asarray(S_gain, dtype=float)
                w /= w.sum()
                sf_arr = np.asarray(S_F, dtype=float)
                scr_arr = np.asarray(S_CR, dtype=float)
                self.M_F[self.mem_idx] = float(np.sum(w * (sf_arr ** 2)) / max(np.sum(w * sf_arr), 1e-12))
                self.M_CR[self.mem_idx] = float(np.sum(w * scr_arr))
                self.mem_idx = (self.mem_idx + 1) % self.memory_size
            prev_best = best_overall
            pop = self.select_population_crowding_and_niche(pop, offspring)
            improved = FeaFitnessEvaluator.is_better_by_deb(pop[0], prev_best)
            if improved:
                n_need = P - len(pop)
                if n_need > 0:
                    fill_u = [self._sample_escape_vector(pop[0].u_vec, k) for k in range(n_need)]
                    reps = self.evaluator.evaluate_batch(fill_u, generation=gen)
                    self.history.extend(reps)
                    pop.extend(reps)
                pop = self.sort_population(pop)
                if self.cfg.enable_line_search:
                    refined = self.local_directional_line_search(pop[0], prev_best, gen=gen)
                    if FeaFitnessEvaluator.is_better_by_deb(refined, pop[0]):
                        pop[0] = refined
                        pop = self.sort_population(pop)
                best_overall = pop[0]
                stagnation = 0
            else:
                stagnation += 1
                u_mat = np.array([ind.u_vec for ind in pop], dtype=float)
                pop_diversity = float(np.mean(np.std(u_mat, axis=0))) if len(u_mat) > 1 else 0.0
                need_escape = (stagnation >= self.cfg.stagnation_patience
                               or pop_diversity < self.cfg.min_diversity_std)
                if need_escape:
                    self.tabu_optima.append(pop[0].u_vec.copy())
                    n_esc = max(2, int(round(P * self.cfg.escape_replace_ratio)))
                    n_replace = max(P - len(pop), n_esc)
                    n_keep = max(2, P - n_replace)
                    pop = pop[:n_keep]
                n_need = P - len(pop)
                if n_need > 0:
                    jump_u = [self._sample_escape_vector(pop[0].u_vec, k) for k in range(n_need)]
                    reps = self.evaluator.evaluate_batch(jump_u, generation=gen)
                    self.history.extend(reps)
                    pop.extend(reps)
                pop = self.sort_population(pop)
                if FeaFitnessEvaluator.is_better_by_deb(pop[0], best_overall):
                    best_overall = pop[0]
                    stagnation = 0
            self.best_per_gen.append(best_overall)
            n_geom_ok = sum(1 for c in offspring if c.is_geom_valid)
            elapsed = time.perf_counter() - t_start
            print(
                f"[Gen {gen:02d}] Best #{best_overall.ind_id:03d} | feasible={best_overall.is_feasible} "
                f"| score={best_overall.query_score:+.4f} (dx={best_overall.probe_dx:+.4f}, dy={best_overall.probe_dy:+.4f}) "
                f"| vm={best_overall.max_von_mises:.1f} MPa | geom_ok={n_geom_ok}/{len(offspring)} "
                f"| stag={stagnation} | {elapsed:.1f}s"
            )
            self._record_and_export_epoch(gen, pop, best_overall, out_dir, elapsed_sec=elapsed)
        return best_overall, self.epoch_stats


class _ARDMatern52GP:
    def __init__(self, dim: int, noise_var: float = 1e-5, ls_init: float = 0.25,
                 ls_bounds=(0.03, 2.5), use_linear_trend: bool = True):
        self.dim = int(dim)
        self.noise_var = float(noise_var)
        self.ls = np.full(self.dim, float(ls_init), dtype=float)
        self.ls_bounds = ls_bounds
        self.use_linear_trend = bool(use_linear_trend)
        self.X = None
        self.trend_w = None
        self.y_mean = 0.0
        self.y_std = 1.0
        self.y_norm = None
        self.c_factor = None
        self.alpha = None

    @staticmethod
    def _kernel(X1, X2, ls):
        r = cdist(X1 / np.maximum(ls, 1e-6), X2 / np.maximum(ls, 1e-6), metric="euclidean")
        s5r = math.sqrt(5.0) * r
        return (1.0 + s5r + (5.0 / 3.0) * (r ** 2)) * np.exp(-s5r)

    def _eval_trend(self, X):
        if self.trend_w is None:
            return np.full(len(X), self.y_mean, dtype=float)
        return np.hstack([np.ones((len(X), 1)), X]) @ self.trend_w

    def fit(self, X, y, optimize_hypers: bool = True):
        self.X = np.asarray(X, dtype=float)
        y_arr = np.asarray(y, dtype=float)
        n = len(self.X)
        self.y_mean = float(np.mean(y_arr))
        if self.use_linear_trend and n >= self.dim + 4:
            X_aug = np.hstack([np.ones((n, 1)), self.X])
            reg = np.eye(self.dim + 1) * 0.15
            reg[0, 0] = 1e-6
            self.trend_w, _, _, _ = np.linalg.lstsq(X_aug.T @ X_aug + reg, X_aug.T @ y_arr, rcond=None)
            residual = y_arr - X_aug @ self.trend_w
        else:
            self.trend_w = None
            residual = y_arr - self.y_mean
        self.y_std = max(float(np.std(residual)), 1e-6)
        self.y_norm = residual / self.y_std
        if optimize_hypers and n >= 8:
            lo, hi = math.log(self.ls_bounds[0]), math.log(self.ls_bounds[1])

            def _neg_lml(log_ls):
                ls_cand = np.exp(log_ls)
                K = self._kernel(self.X, self.X, ls_cand)
                K[np.diag_indices(n)] += self.noise_var
                try:
                    cf = cho_factor(K, lower=True, check_finite=False)
                    alp = cho_solve(cf, self.y_norm, check_finite=False)
                    log_det = 2.0 * float(np.sum(np.log(np.diag(cf[0]))))
                    return 0.5 * float(np.dot(self.y_norm, alp)) + 0.5 * log_det
                except Exception:
                    return 1e10

            res = minimize(_neg_lml, np.log(self.ls), method="L-BFGS-B",
                           bounds=[(lo, hi)] * self.dim, options={"maxiter": 25})
            if np.all(np.isfinite(res.x)):
                self.ls = np.exp(np.clip(res.x, lo, hi))
        K = self._kernel(self.X, self.X, self.ls)
        K[np.diag_indices(n)] += self.noise_var
        self.c_factor = cho_factor(K, lower=True, check_finite=False)
        self.alpha = cho_solve(self.c_factor, self.y_norm, check_finite=False)

    def predict(self, X_cand):
        X_c = np.asarray(X_cand, dtype=float)
        K_trans = self._kernel(X_c, self.X, self.ls)
        mu_norm = K_trans @ self.alpha
        v = cho_solve(self.c_factor, K_trans.T, check_finite=False)
        var_norm = np.maximum(1.0 - np.einsum("ij,ji->i", K_trans, v), 1e-9)
        mu = self._eval_trend(X_c) + mu_norm * self.y_std
        return mu, np.sqrt(var_norm) * self.y_std


class BatchBayesianOptimizer:
    def __init__(self, evaluator, codec, cfg):
        self.evaluator = evaluator
        self.codec = codec
        self.cfg = cfg
        self.rng = np.random.default_rng(seed=cfg.seed)
        self.history = []
        self.best_per_gen = []
        self.epoch_stats = []
        self._last_export = None
        self.tr_length = float(cfg.tr_init_length)
        self.tr_fail_count = 0
        self.tabu_centers = []
        self.prev_best_u = None

    def sort_records(self, recs: list) -> list:
        def _cmp(a, b):
            if FeaFitnessEvaluator.is_better_by_deb(a, b):
                return -1
            if FeaFitnessEvaluator.is_better_by_deb(b, a):
                return 1
            return 0
        return sorted(recs, key=cmp_to_key(_cmp))

    def _initialize_doe(self) -> list:
        D = self.codec.dim
        N0 = max(4, int(self.cfg.init_samples))
        u_list = [self.codec.get_baseline_unit_vector()]
        n_local = min(self.cfg.init_local_count, max(0, N0 - 1))
        for _ in range(n_local):
            u_list.append(np.clip(u_list[0] + self.rng.normal(0.0, self.cfg.init_local_sigma, size=D),
                                  0.0, 1.0))
        n_rem = N0 - len(u_list)
        if n_rem > 0:
            sampler = LatinHypercube(d=D, seed=int(self.rng.integers(1, 1000000)))
            for row in sampler.random(n=n_rem):
                u_list.append(np.asarray(row, dtype=float))
        recs = self.evaluator.evaluate_batch(u_list, generation=0)
        self.history.extend(recs)
        return self.sort_records(recs)

    def _select_training_subset(self, records: list) -> list:
        max_n = int(self.cfg.gp_max_train_size)
        if len(records) <= max_n:
            return records
        sorted_all = self.sort_records(records)
        n_top = max_n // 2
        top_ids = {r.ind_id for r in sorted_all[:n_top]}
        recent = [r for r in records[::-1] if r.ind_id not in top_ids][: max_n - n_top]
        return sorted_all[:n_top] + recent

    def _generate_candidate_pool(self, center_u, ls) -> np.ndarray:
        D = self.codec.dim
        n_total = int(self.cfg.candidate_pool_size)
        n_local = int(round(n_total * self.cfg.local_candidate_ratio))
        n_global = max(100, n_total - n_local)
        weights = np.clip(ls / max(float(np.mean(ls)), 1e-6), 0.4, 2.0)
        half_span = 0.5 * self.tr_length * weights
        lo = np.clip(center_u - half_span, 0.0, 1.0)
        hi = np.clip(center_u + half_span, 0.0, 1.0)
        sampler_loc = LatinHypercube(d=D, seed=int(self.rng.integers(1, 1000000)))
        X_local = lo + sampler_loc.random(n=n_local) * np.maximum(hi - lo, 1e-4)
        sampler_glb = LatinHypercube(d=D, seed=int(self.rng.integers(1, 1000000)))
        X_global = sampler_glb.random(n=n_global)
        X_axis = []
        for _ in range(min(200, max(20, D * 25))):
            u_pert = np.asarray(center_u, dtype=float).copy()
            pick_d = int(self.rng.integers(0, D))
            u_pert[pick_d] = float(self.rng.uniform(lo[pick_d], hi[pick_d]))
            X_axis.append(u_pert)
        X_mom = []
        if self.prev_best_u is not None:
            du = np.asarray(center_u, dtype=float) - np.asarray(self.prev_best_u, dtype=float)
            if float(np.linalg.norm(du)) > 1e-6:
                for scale in (0.5, 1.0, 1.5, 2.2, 3.0, 4.0):
                    for _ in range(4):
                        u_ray = np.asarray(center_u, dtype=float) + scale * du
                        u_ray = u_ray + self.rng.normal(0.0, 0.01, size=D)
                        X_mom.append(np.clip(u_ray, 0.0, 1.0))
        parts = [X_local, X_global, np.asarray(X_axis, dtype=float)]
        if X_mom:
            parts.append(np.asarray(X_mom, dtype=float))
        return np.vstack(parts)

    @staticmethod
    def _compute_ei(mu, std, f_best: float, xi: float):
        imp = mu - f_best - xi
        z = imp / np.maximum(std, 1e-9)
        pdf = (1.0 / math.sqrt(2.0 * math.pi)) * np.exp(-0.5 * (z ** 2))
        return np.maximum(imp * ndtr(z) + std * pdf, 0.0)

    def propose_batch(self, best_overall) -> list:
        D = self.codec.dim
        q = int(self.cfg.batch_size)
        train_recs = self._select_training_subset(self.history)
        X_all = np.array([r.u_vec for r in train_recs], dtype=float)
        z_feas = np.array(
            [1.0 if r.is_feasible else -max(0.05, math.tanh(r.constraint_violation / 500.0))
             for r in train_recs], dtype=float)
        gp_feas = _ARDMatern52GP(D, self.cfg.gp_noise_var, self.cfg.gp_lengthscale_init,
                                 self.cfg.gp_lengthscale_bounds)
        gp_feas.fit(X_all, z_feas, optimize_hypers=True)

        valid_recs = [r for r in train_recs if r.is_geom_valid and r.is_fea_converged]
        has_valid = len(valid_recs) >= 4
        gp_obj = None
        if has_valid:
            X_obj = np.array([r.u_vec for r in valid_recs], dtype=float)
            y_raw = np.array([r.query_score for r in valid_recs], dtype=float)
            y_obj = np.maximum(y_raw, float(np.percentile(y_raw, 10)))
            gp_obj = _ARDMatern52GP(D, self.cfg.gp_noise_var, self.cfg.gp_lengthscale_init,
                                    self.cfg.gp_lengthscale_bounds)
            gp_obj.fit(X_obj, y_obj, optimize_hypers=True)
            active_ls = gp_obj.ls
            feas_scores = [r.query_score for r in valid_recs if r.is_feasible]
            f_best = max(feas_scores) if feas_scores else float(np.max(y_obj))
        else:
            active_ls = gp_feas.ls
            f_best = 0.0

        X_cand = self._generate_candidate_pool(best_overall.u_vec, active_ls)
        dist_to_hist = np.min(cdist(X_cand, X_all), axis=1)
        keep_mask = dist_to_hist >= max(self.cfg.cache_tol * 10.0, 1e-4)
        if np.any(keep_mask):
            X_cand = X_cand[keep_mask]

        mu_c, std_c = gp_feas.predict(X_cand)
        p_feas = ndtr(mu_c / np.maximum(std_c, 1e-6))

        selected_batch = []
        betas = np.linspace(self.cfg.kb_beta_range[0], self.cfg.kb_beta_range[1], max(2, q))
        min_dist = self.cfg.min_batch_dist * math.sqrt(D)
        xi_eff = self.cfg.ei_xi * (gp_obj.y_std if (has_valid and gp_obj is not None) else 1.0)
        X_work = X_obj.copy() if has_valid else X_all.copy()
        y_work = y_obj.copy() if has_valid else z_feas.copy()

        for k in range(q):
            is_explore_slot = (k >= int(round(0.70 * q)))
            if has_valid and gp_obj is not None:
                mu_f, std_f = gp_obj.predict(X_cand)
                ei = self._compute_ei(mu_f, std_f, f_best, xi_eff)
                if is_explore_slot:
                    ucb = (mu_f - f_best) + max(0.5, float(betas[k])) * std_f
                    acq = np.maximum(ucb, 0.0) * (p_feas ** 1.2)
                else:
                    acq = ei * (p_feas ** 1.5)
            else:
                mu_f, std_f = mu_c, std_c
                acq = p_feas + max(0.0, float(betas[k])) * std_c
            if selected_batch:
                d_batch = np.min(cdist(X_cand, np.asarray(selected_batch)), axis=1)
                req_dist = min_dist * (2.5 if is_explore_slot else 1.0)
                acq = np.where(d_batch < req_dist, -1e12, acq)
            best_idx = int(np.argmax(acq))
            u_pick = X_cand[best_idx].copy()
            selected_batch.append(u_pick)
            if has_valid and gp_obj is not None and k < q - 1:
                X_work = np.vstack([X_work, u_pick])
                y_work = np.append(y_work, float(mu_f[best_idx] + betas[k] * std_f[best_idx]))
                gp_obj.fit(X_work, y_work, optimize_hypers=False)
        return selected_batch

    def _record_and_export_epoch(self, epoch: int, epoch_pool: list, best_overall,
                                 out_dir, elapsed_sec: float = 0.0):
        stat = compute_epoch_statistics(epoch, epoch_pool, best_overall, elapsed_sec=elapsed_sec)
        self.epoch_stats.append(stat)
        print(
            f"         [BO Epoch {epoch:02d} 統計] t={stat.elapsed_sec:.1f}s | valid={stat.n_valid}/{stat.n_total} | "
            f"Max={stat.score_max:+.4f} | Median={stat.score_median:+.4f} | "
            f"Mean={stat.score_mean:+.4f} | Min={stat.score_min:+.4f} | TR={self.tr_length:.3f}"
        )
        if out_dir is None:
            return
        prefix = f"ep{epoch}"
        if self.cfg.export_every_epoch:
            reuse_from = None
            if self._last_export is not None and self._last_export["ind_id"] == stat.best_so_far.ind_id:
                reuse_from = self._last_export["prefix"]
            export_single_epoch_artifacts(
                self.evaluator.src_doc, self.evaluator.groups, stat, self.evaluator,
                out_dir, prefix=prefix, reuse_from=reuse_from,
            )
            self._last_export = {"prefix": prefix, "ind_id": stat.best_so_far.ind_id}
        render_epoch_statistics_png(
            self.epoch_stats, os.path.join(out_dir, "epoch_stats_distribution.png"),
            dpi=self.cfg.figure_dpi,
        )

    def run_evolution(self, out_dir=None):
        if self.codec.dim == 0:
            raise ValueError("所有 TRY# 群組的 (dx, dy) 範圍皆為 0，無可優化維度！")
        t_start = time.perf_counter()
        init_sorted = self._initialize_doe()
        best_overall = init_sorted[0]
        self.best_per_gen.append(best_overall)
        elapsed = time.perf_counter() - t_start
        print(
            f"[BO DoE 00] Best #{best_overall.ind_id:03d} | feasible={best_overall.is_feasible} "
            f"| score={best_overall.query_score:+.4f} "
            f"(dx={best_overall.probe_dx:+.4f}, dy={best_overall.probe_dy:+.4f}) "
            f"| vm={best_overall.max_von_mises:.1f} MPa | {elapsed:.1f}s"
        )
        self._record_and_export_epoch(0, init_sorted, best_overall, out_dir, elapsed_sec=elapsed)
        for ep in range(1, self.cfg.max_epochs + 1):
            prev_best_u = best_overall.u_vec.copy()
            cand_u_list = self.propose_batch(best_overall)
            batch_recs = self.evaluator.evaluate_batch(cand_u_list, generation=ep)
            self.history.extend(batch_recs)
            sorted_batch = self.sort_records(batch_recs)
            if FeaFitnessEvaluator.is_better_by_deb(sorted_batch[0], best_overall):
                best_overall = sorted_batch[0]
                self.prev_best_u = prev_best_u
                self.tr_fail_count = 0
                self.tr_length = min(self.cfg.tr_max_length, self.tr_length * self.cfg.tr_expand_factor)
            else:
                self.prev_best_u = None
                self.tr_fail_count += 1
                if self.tr_fail_count >= self.cfg.tr_fail_tolerance:
                    self.tr_length *= self.cfg.tr_shrink_factor
                    self.tr_fail_count = 0
                    if self.tr_length < self.cfg.tr_min_length:
                        self.tabu_centers.append(best_overall.u_vec.copy())
                        self.tr_length = self.cfg.tr_init_length
                        print(f"         [BO 信賴域重啟] TR 觸底，重設 TR={self.tr_length:.2f} 進行全域探索")
            self.best_per_gen.append(best_overall)
            n_geom_ok = sum(1 for c in batch_recs if c.is_geom_valid)
            elapsed = time.perf_counter() - t_start
            print(
                f"[BO Ep {ep:02d}] Best #{best_overall.ind_id:03d} | feasible={best_overall.is_feasible} "
                f"| score={best_overall.query_score:+.4f} (dx={best_overall.probe_dx:+.4f}, dy={best_overall.probe_dy:+.4f}) "
                f"| vm={best_overall.max_von_mises:.1f} MPa | geom_ok={n_geom_ok}/{len(batch_recs)} "
                f"| TR={self.tr_length:.3f} | {elapsed:.1f}s"
            )
            self._record_and_export_epoch(ep, batch_recs, best_overall, out_dir, elapsed_sec=elapsed)
        return best_overall, self.epoch_stats


_DARK_ON_WHITE = {
    "#dddddd": "#1e293b",
    "#ffffff": "#1e293b",
    "white": "#1e293b",
    "#8fb8c9": "#475569",
    "#00bfff": "#0284c7",
    "#ff3355": "#dc2626",
    "#ffaa00": "#d97706",
    "#00ff88": "#15803d",
    "#9aa0a6": "#64748b",
    "#55606a": "#94a3b8",
    "#cccccc": "#1e293b",
    "#888888": "#1e293b",
    "#ffdd55": "#0f172a",
}


def _to_hex_key(c) -> str:
    try:
        arr = np.asarray(c)
        if arr.ndim == 2 and len(arr) > 0:
            c = arr[0]
        return to_hex(c).lower()
    except Exception:
        return str(c).lower()


def apply_light_theme_to_fea_ax(fig, ax):
    fig.patch.set_facecolor("#ffffff")
    ax.set_facecolor("#ffffff")
    ax.tick_params(colors="#1e293b", labelsize=8)
    ax.xaxis.label.set_color("#0f172a")
    ax.yaxis.label.set_color("#0f172a")
    ax.title.set_color("#0f172a")
    for sp in ax.spines.values():
        sp.set_color("#64748b")
    for line in ax.lines:
        key = _to_hex_key(line.get_color())
        if key in _DARK_ON_WHITE:
            line.set_color(_DARK_ON_WHITE[key])
    for coll in ax.collections:
        if not hasattr(coll, "get_segments"):
            continue
        key = None
        for getter in ("get_edgecolor", "get_facecolor", "get_color"):
            fn = getattr(coll, getter, None)
            if fn is None:
                continue
            try:
                cand = fn()
            except Exception:
                continue
            cand_key = _to_hex_key(cand)
            if cand_key in _DARK_ON_WHITE:
                key = cand_key
                break
        if key is not None:
            coll.set_color(_DARK_ON_WHITE[key])
    for txt in ax.texts:
        key = _to_hex_key(txt.get_color())
        txt.set_color(_DARK_ON_WHITE.get(key, "#0f172a"))
        patch = txt.get_bbox_patch()
        if patch is not None:
            patch.set_facecolor("#f8fafc")
            patch.set_edgecolor("#94a3b8")
            patch.set_alpha(0.94)
    cbars = []
    cbar = getattr(ax, "_fea_cbar", None)
    if cbar is not None:
        cbars.append(cbar)
    for other in fig.axes:
        if other is ax:
            continue
        cb_guess = getattr(other, "_colorbar", None)
        if cb_guess is not None:
            cbars.append(cb_guess)
    for cb in cbars:
        try:
            cb.ax.set_facecolor("#ffffff")
            cb.ax.tick_params(colors="#1e293b", labelsize=7.5)
            cb.ax.yaxis.label.set_color("#0f172a")
            cb.outline.set_edgecolor("#64748b")
            for txt in cb.ax.texts:
                txt.set_color("#0f172a")
        except Exception:
            pass
    leg = ax.get_legend()
    if leg is not None:
        frame = leg.get_frame()
        frame.set_facecolor("#f8fafc")
        frame.set_edgecolor("#cbd5e1")
        for ltxt in leg.get_texts():
            ltxt.set_color("#0f172a")


def export_single_epoch_artifacts(src_doc, groups: dict, stat: EpochStatRecord,
                                  evaluator: FeaFitnessEvaluator, out_dir: str,
                                  prefix: str = None, reuse_from: str = None):
    os.makedirs(out_dir, exist_ok=True)
    if prefix is None:
        prefix = f"ep{stat.epoch}"
    target_rec = stat.best_so_far
    dxf_out = os.path.join(out_dir, f"{prefix}_best.dxf")
    disp_out = os.path.join(out_dir, f"{prefix}_disp.png")
    stress_out = os.path.join(out_dir, f"{prefix}_stress.png")
    if reuse_from is not None:
        try:
            shutil.copyfile(os.path.join(out_dir, f"{reuse_from}_best.dxf"), dxf_out)
            shutil.copyfile(os.path.join(out_dir, f"{reuse_from}_disp.png"), disp_out)
            shutil.copyfile(os.path.join(out_dir, f"{reuse_from}_stress.png"), stress_out)
            return
        except Exception:
            pass
    try:
        best_doc = TrySearchSpaceHelper.apply_group_displacements(
            src_doc, groups, target_rec.disp_map, **evaluator.fillet_kwargs
        )
        best_doc.saveas(dxf_out)
    except Exception as exc:
        print(f"  [警告] {prefix} DXF 輸出失敗: {exc}")
        return
    if not target_rec.is_geom_valid:
        return
    try:
        mesh = FiniteEleMeshHelper.build_t6_mesh_from_dxf(best_doc, hp=evaluator.mesh_hp)
        fea = FiniteEleSolverHelper.solve(mesh, hp=evaluator.solver_hp)
        fig, ax = plt.subplots(figsize=(10.5, 6.5))
        FiniteEleSolverHelper.plot_fea_on_ax(
            fea, mesh, ax=ax, mode=VIEW_MODES[1], deform_scale=evaluator.solver_hp.deform_scale
        )
        apply_light_theme_to_fea_ax(fig, ax)
        ax.set_title(
            f"Epoch {stat.epoch:02d} Best #{target_rec.ind_id:03d} | DISP | "
            f"score={target_rec.query_score:+.4f} (dx={target_rec.probe_dx:+.4f}, dy={target_rec.probe_dy:+.4f} mm)",
            color="#0f172a", fontsize=9.5, fontweight="bold",
        )
        fig.tight_layout()
        fig.savefig(disp_out, dpi=evaluator.cfg.figure_dpi, facecolor="#ffffff")
        plt.close(fig)
        fig, ax = plt.subplots(figsize=(10.5, 6.5))
        FiniteEleSolverHelper.plot_fea_on_ax(
            fea, mesh, ax=ax, mode=VIEW_MODES[0], deform_scale=evaluator.solver_hp.deform_scale
        )
        apply_light_theme_to_fea_ax(fig, ax)
        ax.set_title(
            f"Epoch {stat.epoch:02d} Best #{target_rec.ind_id:03d} | STRESS | "
            f"vm_max={target_rec.max_von_mises:.1f} MPa (SF={target_rec.safety_factor:.2f})",
            color="#0f172a", fontsize=9.5, fontweight="bold",
        )
        fig.tight_layout()
        fig.savefig(stress_out, dpi=evaluator.cfg.figure_dpi, facecolor="#ffffff")
        plt.close(fig)
    except Exception as exc:
        print(f"  [警告] {prefix} FEA 繪圖失敗: {exc}")


def render_epoch_statistics_png(epoch_stats: list, out_path: str, dpi: int = 140):
    if not epoch_stats:
        return
    t_sec = np.array([s.elapsed_sec for s in epoch_stats], dtype=float)
    data = [list(s.valid_scores) if s.valid_scores else [s.score_mean] for s in epoch_stats]
    s_min = np.array([s.score_min for s in epoch_stats], dtype=float)
    s_max = np.array([s.score_max for s in epoch_stats], dtype=float)
    s_mean = np.array([s.score_mean for s in epoch_stats], dtype=float)
    s_median = np.array([s.score_median for s in epoch_stats], dtype=float)
    s_best = np.array([s.best_so_far.query_score for s in epoch_stats], dtype=float)
    n_epochs = len(epoch_stats)
    if n_epochs > 1:
        dt = np.diff(t_sec)
        pos_dt = dt[dt > 1e-6]
        min_dt = float(np.percentile(pos_dt, 20)) if len(pos_dt) else 1.0
        span_t = max(float(t_sec[-1] - t_sec[0]), 1e-3)
        box_w = float(np.clip(min_dt * 0.55, span_t / max(n_epochs * 3.0, 10.0), span_t * 0.06))
    else:
        span_t = 1.0
        box_w = 0.5
    fig, ax = plt.subplots(figsize=(12.0, 6.5))
    fig.patch.set_facecolor("#ffffff")
    ax.set_facecolor("#ffffff")
    ax.boxplot(
        data, positions=t_sec, widths=box_w, patch_artist=True,
        showfliers=False, manage_ticks=False, zorder=2,
        boxprops=dict(facecolor="#dbeafe", edgecolor="#334155", linewidth=0.9, alpha=0.55),
        medianprops=dict(color="#c2410c", linewidth=1.8),
        whiskerprops=dict(color="#64748b", linewidth=0.9, linestyle="-"),
        capprops=dict(color="#64748b", linewidth=0.9),
    )
    scatter_x, scatter_y = [], []
    jitter_half = box_w * 0.28
    for t_val, scores_in_ep in zip(t_sec, data):
        m = len(scores_in_ep)
        offsets = [0.0] if m == 1 else np.linspace(-jitter_half, jitter_half, m)
        scatter_x.extend(t_val + np.asarray(offsets, dtype=float))
        scatter_y.extend(scores_in_ep)
    ax.scatter(scatter_x, scatter_y, s=14, c="#475569", alpha=0.42,
               edgecolors="none", zorder=3, label="Samples")
    ax.plot(t_sec, s_max, "o", color="#16a34a", ms=6.0, lw=0, alpha=0.95,
            markerfacecolor="#ffffff", markeredgewidth=1.5, zorder=8, label="Epoch Max")
    ax.plot(t_sec, s_median, "-s", color="#c2410c", lw=1.4, ms=3.8, alpha=0.90, zorder=6, label="Median")
    ax.plot(t_sec, s_mean, "--^", color="#0284c7", lw=1.4, ms=4.2, alpha=0.90, zorder=6, label="Mean")
    ax.plot(t_sec, s_min, ":v", color="#9333ea", lw=1.2, ms=3.8, alpha=0.80, zorder=4, label="Epoch Min")
    ax.plot(t_sec, s_best, "-*", color="#d97706", lw=2.4, ms=8.0, alpha=0.82, zorder=5, label="Best-so-far")
    pad_x = max(box_w * 1.2, span_t * 0.03)
    ax.set_xlim(float(t_sec[0]) - pad_x, float(t_sec[-1]) + pad_x)
    ax.set_xlabel("Run Time (sec)", color="#0f172a", fontsize=10, fontweight="bold")
    ax.set_ylabel("Score (my_score_func)", color="#0f172a", fontsize=10, fontweight="bold")
    ax.set_title(f"Evolution Progression vs. Run Time  (n = {n_epochs} epochs, total = {t_sec[-1]:.1f}s)",
                 color="#0f172a", fontsize=11, fontweight="bold")
    ax.grid(True, which="major", color="#cbd5e1", linestyle="--", linewidth=0.7, alpha=0.8)
    ax.tick_params(colors="#1e293b", labelsize=8.5)
    for sp in ax.spines.values():
        sp.set_color("#64748b")
    box_proxy = Patch(facecolor="#dbeafe", edgecolor="#334155", alpha=0.55, label="IQR [Q1, Q3]")
    handles, _ = ax.get_legend_handles_labels()
    ax.legend(handles=[box_proxy] + handles, loc="lower right", ncol=2,
              facecolor="#f8fafc", edgecolor="#cbd5e1", labelcolor="#0f172a", fontsize=8.0)
    fig.tight_layout()
    fig.savefig(out_path, dpi=dpi, facecolor="#ffffff")
    plt.close(fig)


def export_optimization_outputs(src_doc, groups: dict, best_rec: IndividualRecord, optimizer, out_dir: str):
    os.makedirs(out_dir, exist_ok=True)
    render_overview_png(src_doc, groups, os.path.join(out_dir, "00_search_space_overview.png"))
    dpi = optimizer.cfg.figure_dpi
    best_doc = TrySearchSpaceHelper.apply_group_displacements(
        src_doc, groups, best_rec.disp_map, **optimizer.evaluator.fillet_kwargs
    )
    best_doc.saveas(os.path.join(out_dir, "best_final.dxf"))
    preview_doc = TrySearchSpaceHelper.apply_group_displacements(
        src_doc, groups, best_rec.disp_map, moved_layer_name="FINAL_CONTOUR",
        **optimizer.evaluator.fillet_kwargs,
    )
    render_morph_png(src_doc, preview_doc, best_rec.disp_map,
                     os.path.join(out_dir, "best_final_morph_contour.png"), f"BEST #{best_rec.ind_id:03d}")
    try:
        mesh = FiniteEleMeshHelper.build_t6_mesh_from_dxf(best_doc, hp=optimizer.evaluator.mesh_hp)
        fea = FiniteEleSolverHelper.solve(mesh, hp=optimizer.evaluator.solver_hp)
        fig, ax = plt.subplots(figsize=(10.5, 6.5))
        FiniteEleMeshHelper.plot_t6_mesh_on_ax(mesh, ax=ax)
        apply_light_theme_to_fea_ax(fig, ax)
        fig.tight_layout()
        fig.savefig(os.path.join(out_dir, "best_final_mesh.png"), dpi=dpi, facecolor="#ffffff")
        plt.close(fig)
        fig, ax = plt.subplots(figsize=(10.5, 6.5))
        FiniteEleSolverHelper.plot_fea_on_ax(
            fea, mesh, ax=ax, mode=VIEW_MODES[1], deform_scale=optimizer.evaluator.solver_hp.deform_scale
        )
        apply_light_theme_to_fea_ax(fig, ax)
        fig.tight_layout()
        fig.savefig(os.path.join(out_dir, "best_final_disp.png"), dpi=dpi, facecolor="#ffffff")
        plt.close(fig)
        fig, ax = plt.subplots(figsize=(10.5, 6.5))
        FiniteEleSolverHelper.plot_fea_on_ax(
            fea, mesh, ax=ax, mode=VIEW_MODES[0], deform_scale=optimizer.evaluator.solver_hp.deform_scale
        )
        apply_light_theme_to_fea_ax(fig, ax)
        fig.tight_layout()
        fig.savefig(os.path.join(out_dir, "best_final_stress.png"), dpi=dpi, facecolor="#ffffff")
        plt.close(fig)
    except Exception as exc:
        print(f"[警告] 最佳解 FEA 視覺化輸出失敗: {exc}")
    render_epoch_statistics_png(optimizer.epoch_stats,
                                os.path.join(out_dir, "epoch_stats_distribution.png"), dpi=dpi)
    print(f"[輸出] 結果已寫入資料夾: {out_dir}")


def main():
    folder = os.path.dirname(os.path.abspath(__file__))
    args = list(sys.argv[1:])
    opt_mode = OPTIMIZER_TYPE.strip().upper()
    if args and args[0].upper() in ("GA", "BO"):
        opt_mode = args.pop(0).upper()
    cfg = BOConfig() if opt_mode == "BO" else GAConfig()
    if args and not args[0].isdigit():
        cfg.dxf_path = args.pop(0)
    nums = [int(a) for a in args if a.isdigit()]
    if opt_mode == "BO":
        if len(nums) > 0:
            cfg.batch_size = nums[0]
        if len(nums) > 1:
            cfg.max_epochs = nums[1]
        if len(nums) > 2:
            cfg.n_workers = nums[2]
    else:
        if len(nums) > 0:
            cfg.pop_size = nums[0]
        if len(nums) > 1:
            cfg.max_generations = nums[1]
        if len(nums) > 2:
            cfg.n_workers = nums[2]
    dxf_path = cfg.dxf_path if os.path.isabs(cfg.dxf_path) else os.path.join(folder, cfg.dxf_path)
    out_dir = os.path.join(folder, cfg.out_root_dir, datetime.now().strftime("%Y%m%d_%H%M%S"))
    print(f"[讀取] {dxf_path}")
    print(f"[優化器] {opt_mode}")
    if opt_mode == "BO":
        print(f"[超參數] DoE={cfg.init_samples} batch={cfg.batch_size} epochs={cfg.max_epochs} "
              f"TR={cfg.tr_init_length:.2f} pool={cfg.candidate_pool_size} "
              f"fillet={cfg.auto_fillet}({cfg.fillet_mode} R{cfg.fillet_r_max}) mesh={cfg.mesh_h_max}/{cfg.mesh_h_min}")
    else:
        print(f"[超參數] pop={cfg.pop_size} gen={cfg.max_generations} de={cfg.de_prob} "
              f"fillet={cfg.auto_fillet}({cfg.fillet_mode} R{cfg.fillet_r_max}) mesh={cfg.mesh_h_max}/{cfg.mesh_h_min}")
    src_doc = ezdxf.readfile(dxf_path)
    groups = TrySearchSpaceHelper.extract_try_groups(src_doc)
    TrySearchSpaceHelper.bind_layer0_control_points(src_doc, groups)
    if not groups:
        print("[錯誤] 找不到任何 TRY#編號 圖層，請先於 try006 繪製 TRY# 矩形框或圓圈+射線。")
        return
    codec = GeneCodec(groups)
    print(f"[搜索空間] 共 {len(groups)} 組 TRY# | 有效演化維度 D={codec.dim}")
    for spec in codec.active_axes:
        print(f"  - {spec.group_id}.d{spec.axis} in [{spec.lo:+.3f}, {spec.hi:+.3f}] mm (span={spec.span:.3f} mm)")
    if codec.dim == 0:
        print("[錯誤] 所有群組的位移範圍都是 0，請確認 TRY# 矩形框/射線是否圈到了控制點。")
        return
    evaluator = FeaFitnessEvaluator(src_doc, groups, codec, cfg, dxf_path=dxf_path, enable_pool=True)
    print(f"[多工] 啟用 {evaluator.n_workers} 個 Worker 進程（每進程 BLAS 鎖 1 線程）")
    print(f"[多工] 記憶體估算：每 Worker 約 150~300 MB，{evaluator.n_workers} 路約 "
          f"{evaluator.n_workers * 0.15:.1f}~{evaluator.n_workers * 0.30:.1f} GB；"
          f"記憶體不足時用第 3 個數字參數限制路數。")
    print(
        f"[基準檢查] 原點 (0,0) 圖面拓撲: OPEN={evaluator.base_open}, "
        f"INTERSECT={evaluator.base_inter}, ISLAND={evaluator.base_island}"
    )
    if opt_mode == "BO":
        optimizer = BatchBayesianOptimizer(evaluator, codec, cfg)
        n_eval = cfg.init_samples + cfg.max_epochs * cfg.batch_size
    else:
        optimizer = HybridRealCodedGA(evaluator, codec, cfg)
        n_eval = cfg.pop_size * (cfg.max_generations + 1)
    print(f"[預估] 約 {n_eval} 次 FEA 評估，平行 {evaluator.n_workers} 路 → "
          f"約 {-(-n_eval // max(1, evaluator.n_workers))} 輪。")
    os.makedirs(out_dir, exist_ok=True)
    print(f"[輸出目錄] {out_dir}")
    try:
        best, epoch_stats = optimizer.run_evolution(out_dir)
    finally:
        evaluator.close_pool()
    print(f"===== try009 {opt_mode} 最佳解摘要 =====")
    print(f"  最佳個體編號 : #{best.ind_id:03d} (Generation {best.generation})")
    print(f"  可行性狀態   : {'FEASIBLE' if best.is_feasible else 'INFEASIBLE'} ({best.status_msg})")
    for gid, (dx, dy) in best.disp_map.items():
        print(f"  位移 {gid:<8}: dx={dx:+.4f} mm, dy={dy:+.4f} mm")
    print(f"  PROBE 位移   : dx={best.probe_dx:+.4f} mm, dy={best.probe_dy:+.4f} mm, |d|={best.probe_dxy:.4f} mm")
    print(f"  最大應力     : {best.max_von_mises:.2f} MPa (SF={best.safety_factor:.2f}, lambda={best.converged_lambda:.3f})")
    print(f"  總評估次數   : {evaluator.eval_counter}")
    export_optimization_outputs(src_doc, groups, best, optimizer, out_dir)


if __name__ == "__main__":
    main()
