#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""try008.py — TRY#編號 局部剛體圈選 + 圓心拉線定義搜尋邊界框 + 變形驗證。"""

import math
import os
import re
import sys
from dataclasses import dataclass, field

import matplotlib

matplotlib.use("Agg")

import numpy as np
import ezdxf
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from matplotlib.patches import Circle as MplCircle, Rectangle as MplRect
from matplotlib.path import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from try005 import DXFContourHelper, ContourHyperParams


@dataclass
class TryCircleZone:
    handle: str
    center: tuple[float, float]
    radius: float


@dataclass
class BoundPointRef:
    entity_handle: str
    entity_type: str
    layer: str
    point_role: str
    orig_xy: tuple[float, float]
    circle_index: int


@dataclass
class TryRectBox:
    handle: str
    xmin: float
    xmax: float
    ymin: float
    ymax: float
    captured: list = field(default_factory=list)

    def contains(self, x: float, y: float, tol: float = 1e-6) -> bool:
        return (self.xmin - tol <= x <= self.xmax + tol) and (self.ymin - tol <= y <= self.ymax + tol)


@dataclass
class TryGroupSpec:
    layer_name: str
    group_id: str
    seq: int
    circles: list = field(default_factory=list)
    rects: list = field(default_factory=list)
    range_lines: list = field(default_factory=list)
    dx_bounds: tuple[float, float] = (0.0, 0.0)
    dy_bounds: tuple[float, float] = (0.0, 0.0)
    bound_points: list = field(default_factory=list)
    diag: list = field(default_factory=list)

    def sample_dx_dy(self, ux: float, uy: float) -> tuple[float, float]:
        dx = self.dx_bounds[0] + float(np.clip(ux, 0.0, 1.0)) * (self.dx_bounds[1] - self.dx_bounds[0])
        dy = self.dy_bounds[0] + float(np.clip(uy, 0.0, 1.0)) * (self.dy_bounds[1] - self.dy_bounds[0])
        return float(dx), float(dy)


def _arc_from_3_points(p1, p2, p3):
    ax, ay = p1
    bx, by = p2
    cx, cy = p3
    d = 2.0 * (ax * (by - cy) + bx * (cy - ay) + cx * (ay - by))
    if abs(d) < 1e-12:
        return None, None, None, None
    s1 = ax * ax + ay * ay
    s2 = bx * bx + by * by
    s3 = cx * cx + cy * cy
    ux = (s1 * (by - cy) + s2 * (cy - ay) + s3 * (ay - by)) / d
    uy = (s1 * (cx - bx) + s2 * (ax - cx) + s3 * (bx - ax)) / d
    r = math.hypot(ax - ux, ay - uy)
    t1 = math.degrees(math.atan2(ay - uy, ax - ux)) % 360.0
    t2 = math.degrees(math.atan2(by - uy, bx - ux)) % 360.0
    t3 = math.degrees(math.atan2(cy - uy, cx - ux)) % 360.0
    if (t2 - t1) % 360.0 <= (t3 - t1) % 360.0:
        return (ux, uy), r, t1, t3
    return (ux, uy), r, t3, t1


class TrySearchSpaceHelper:
    TRY_RE = re.compile(r"^TRY(?:#|_)?(\d+)$", re.IGNORECASE)

    @classmethod
    def parse_try_layer_name(cls, layer_name: str):
        m = cls.TRY_RE.match(str(layer_name).strip())
        if not m:
            return None
        seq = int(m.group(1))
        return {
            "type": "TRY",
            "seq": seq,
            "group_id": f"TRY#{seq:03d}",
            "raw_layer": str(layer_name).strip(),
        }

    @staticmethod
    def _point_to_seg_dist(pt, a, b) -> float:
        v = b - a
        l2 = float(v @ v)
        if l2 < 1e-14:
            return float(np.linalg.norm(pt - a))
        t = float(np.clip(((pt - a) @ v) / l2, 0.0, 1.0))
        proj = a + t * v
        return float(np.linalg.norm(pt - proj))

    @staticmethod
    def _arc_endpoints(cx, cy, r, start_deg, end_deg):
        a1 = math.radians(start_deg)
        a2 = math.radians(end_deg)
        return (cx + r * math.cos(a1), cy + r * math.sin(a1)), (cx + r * math.cos(a2), cy + r * math.sin(a2))

    @classmethod
    def extract_try_groups(cls, doc, center_snap_tol: float = 0.25) -> dict:
        msp = doc.modelspace()
        groups = {}
        raw_lines_by_gid = {}
        for ent in msp:
            lay = ent.dxf.layer if ent.dxf.hasattr("layer") else "0"
            info = cls.parse_try_layer_name(lay)
            if info is None:
                continue
            gid = info["group_id"]
            if gid not in groups:
                groups[gid] = TryGroupSpec(layer_name=info["raw_layer"], group_id=gid, seq=info["seq"])
            etype = ent.dxftype()
            handle = ent.dxf.handle if ent.dxf.hasattr("handle") else ""
            if etype == "CIRCLE":
                groups[gid].circles.append(TryCircleZone(
                    handle=handle,
                    center=(float(ent.dxf.center.x), float(ent.dxf.center.y)),
                    radius=float(ent.dxf.radius),
                ))
            elif etype == "LINE":
                p1 = np.array([float(ent.dxf.start.x), float(ent.dxf.start.y)], dtype=float)
                p2 = np.array([float(ent.dxf.end.x), float(ent.dxf.end.y)], dtype=float)
                raw_lines_by_gid.setdefault(gid, []).append((p1, p2))
            elif etype == "LWPOLYLINE":
                pts = [np.array([float(p[0]), float(p[1])], dtype=float) for p in ent.get_points("xy")]
                if ent.closed and len(pts) >= 4:
                    xs = [float(p[0]) for p in pts]
                    ys = [float(p[1]) for p in pts]
                    if max(xs) - min(xs) > 1e-6 and max(ys) - min(ys) > 1e-6:
                        groups[gid].rects.append(TryRectBox(
                            handle=handle, xmin=min(xs), xmax=max(xs),
                            ymin=min(ys), ymax=max(ys),
                        ))
                    continue
                for k in range(len(pts) - 1):
                    raw_lines_by_gid.setdefault(gid, []).append((pts[k], pts[k + 1]))
        for gid, grp in groups.items():
            rel_dx = [0.0]
            rel_dy = [0.0]
            lines = raw_lines_by_gid.get(gid, [])
            used = set()
            grp.diag = []
            if grp.circles:
                for c_idx, cz in enumerate(grp.circles):
                    center = np.array(cz.center, dtype=float)
                    capture_r = float(cz.radius) + float(center_snap_tol)
                    seeds = []
                    for idx, (p1, p2) in enumerate(lines):
                        if idx in used:
                            continue
                        d1 = float(np.linalg.norm(p1 - center))
                        d2 = float(np.linalg.norm(p2 - center))
                        d_seg = cls._point_to_seg_dist(center, p1, p2)
                        if min(d1, d2, d_seg) <= capture_r:
                            seeds.append(idx)
                    nearest = float("inf")
                    for (p1, p2) in lines:
                        nearest = min(nearest, float(np.linalg.norm(p1 - center)),
                                      float(np.linalg.norm(p2 - center)),
                                      cls._point_to_seg_dist(center, p1, p2))
                    for idx in seeds:
                        if idx in used:
                            continue
                        p1, p2 = lines[idx]
                        d1 = float(np.linalg.norm(p1 - center))
                        d2 = float(np.linalg.norm(p2 - center))
                        if d1 <= capture_r and d2 > capture_r:
                            anchor, tips = p1, [p2]
                        elif d2 <= capture_r and d1 > capture_r:
                            anchor, tips = p2, [p1]
                        elif d1 <= capture_r and d2 <= capture_r:
                            if d1 <= d2:
                                anchor, tips = p1, [p2]
                            else:
                                anchor, tips = p2, [p1]
                        else:
                            v = p2 - p1
                            l2 = float(v @ v)
                            t = float(np.clip(((center - p1) @ v) / max(l2, 1e-14), 0.0, 1.0))
                            anchor = p1 + t * v
                            tips = [p1, p2]
                        used.add(idx)
                        grp.range_lines.append((
                            (float(p1[0]), float(p1[1])),
                            (float(p2[0]), float(p2[1])),
                            c_idx,
                        ))
                        for tip in tips:
                            rel_dx.append(float(tip[0] - anchor[0]))
                            rel_dy.append(float(tip[1] - anchor[1]))
                        connected = [p1, p2]
                        changed = True
                        while changed:
                            changed = False
                            for jdx, (q1, q2) in enumerate(lines):
                                if jdx in used:
                                    continue
                                if any(float(np.linalg.norm(q1 - s)) <= center_snap_tol
                                       or float(np.linalg.norm(q2 - s)) <= center_snap_tol for s in connected):
                                    used.add(jdx)
                                    connected.extend([q1, q2])
                                    grp.range_lines.append((
                                        (float(q1[0]), float(q1[1])),
                                        (float(q2[0]), float(q2[1])),
                                        c_idx,
                                    ))
                                    for tip in (q1, q2):
                                        rel_dx.append(float(tip[0] - anchor[0]))
                                        rel_dy.append(float(tip[1] - anchor[1]))
                                    changed = True
                    grp.diag.append({
                        "circle": c_idx,
                        "center": (float(center[0]), float(center[1])),
                        "radius": float(cz.radius),
                        "seed_tol": float(capture_r),
                        "seeded": len(seeds),
                        "nearest": nearest,
                    })
            dx_min, dx_max = float(min(rel_dx)), float(max(rel_dx))
            dy_min, dy_max = float(min(rel_dy)), float(max(rel_dy))
            if abs(dx_max - dx_min) < 1e-6:
                dx_min = dx_max = 0.0
            if abs(dy_max - dy_min) < 1e-6:
                dy_min = dy_max = 0.0
            grp.dx_bounds = (dx_min, dx_max)
            grp.dy_bounds = (dy_min, dy_max)
        return dict(sorted(groups.items(), key=lambda kv: kv[1].seq))

    @classmethod
    def bind_layer0_control_points(cls, doc, groups: dict, target_layers: tuple = ("0",)) -> list:
        for grp in groups.values():
            grp.bound_points.clear()
            for rb in grp.rects:
                rb.captured.clear()
        conflicts = []

        def find_capturing_group(pt_xy):
            px, py = pt_xy
            for grp in groups.values():
                for c_idx, cz in enumerate(grp.circles):
                    if math.hypot(px - cz.center[0], py - cz.center[1]) <= cz.radius + 1e-6:
                        return grp, c_idx
                for rb in grp.rects:
                    if rb.contains(px, py):
                        rb.captured.append((float(px), float(py)))
                        return grp, -1
            return None, -1

        target_set = {s.upper() for s in target_layers}
        for ent in doc.modelspace():
            lay = ent.dxf.layer if ent.dxf.hasattr("layer") else "0"
            if cls.parse_try_layer_name(lay) is not None:
                continue
            if lay.upper() not in target_set:
                continue
            etype = ent.dxftype()
            handle = ent.dxf.handle if ent.dxf.hasattr("handle") else ""
            if etype == "LINE":
                p1 = (float(ent.dxf.start.x), float(ent.dxf.start.y))
                p2 = (float(ent.dxf.end.x), float(ent.dxf.end.y))
                for role, pt in (("start", p1), ("end", p2)):
                    grp, c_idx = find_capturing_group(pt)
                    if grp is not None:
                        grp.bound_points.append(BoundPointRef(handle, "LINE", lay, role, pt, c_idx))
            elif etype == "ARC":
                cx, cy = float(ent.dxf.center.x), float(ent.dxf.center.y)
                r = float(ent.dxf.radius)
                sa, ea = float(ent.dxf.start_angle), float(ent.dxf.end_angle)
                p_start, p_end = cls._arc_endpoints(cx, cy, r, sa, ea)
                for role, pt in (("center", (cx, cy)), ("arc_start", p_start), ("arc_end", p_end)):
                    grp, c_idx = find_capturing_group(pt)
                    if grp is not None:
                        grp.bound_points.append(BoundPointRef(handle, "ARC", lay, role, pt, c_idx))
            elif etype == "CIRCLE":
                c_pt = (float(ent.dxf.center.x), float(ent.dxf.center.y))
                grp, c_idx = find_capturing_group(c_pt)
                if grp is not None:
                    grp.bound_points.append(BoundPointRef(handle, "CIRCLE", lay, "center", c_pt, c_idx))
            elif etype == "LWPOLYLINE":
                pts = [(float(p[0]), float(p[1])) for p in ent.get_points("xy")]
                for idx, pt in enumerate(pts):
                    grp, c_idx = find_capturing_group(pt)
                    if grp is not None:
                        grp.bound_points.append(BoundPointRef(handle, "LWPOLYLINE", lay, f"vertex_{idx}", pt, c_idx))
        seen = {}
        for grp in groups.values():
            for bp in grp.bound_points:
                key = (bp.entity_handle, bp.point_role)
                if key in seen and seen[key][0] != grp.group_id:
                    conflicts.append((bp.entity_handle, bp.point_role, seen[key][0], grp.group_id))
                seen[key] = (grp.group_id, bp.orig_xy)
        for grp in groups.values():
            if not grp.rects:
                continue
            dx_mins, dx_maxs, dy_mins, dy_maxs = [], [], [], []
            for rb in grp.rects:
                if not rb.captured:
                    continue
                xs = [p[0] for p in rb.captured]
                ys = [p[1] for p in rb.captured]
                dx_mins.append(rb.xmin - min(xs))
                dx_maxs.append(rb.xmax - max(xs))
                dy_mins.append(rb.ymin - min(ys))
                dy_maxs.append(rb.ymax - max(ys))
            if dx_mins:
                lo, hi = max(dx_mins), min(dx_maxs)
                grp.dx_bounds = (min(lo, 0.0), max(hi, 0.0)) if lo <= hi else (0.0, 0.0)
                lo, hi = max(dy_mins), min(dy_maxs)
                grp.dy_bounds = (min(lo, 0.0), max(hi, 0.0)) if lo <= hi else (0.0, 0.0)
        return conflicts

    @classmethod
    def apply_group_displacements(cls, src_doc, groups: dict, group_offsets: dict,
                                  keep_try_layers: bool = False, moved_layer_name=None,
                                  sync_coincident: bool = True, coincident_tol: float = 1e-4,
                                  auto_fillet: bool = True, fillet_r_max: float = 0.8,
                                  fillet_r_min: float = 0.05, fillet_mode: str = "concave",
                                  min_remain_len: float = 0.15, min_remain_ratio: float = 0.25):
        moved_map = []
        for gid, grp in groups.items():
            dx, dy = group_offsets.get(gid, (0.0, 0.0))
            if abs(dx) <= 1e-12 and abs(dy) <= 1e-12:
                continue
            for bp in grp.bound_points:
                moved_map.append((bp.orig_xy, (float(dx), float(dy))))

        def _delta(pt):
            for gid, grp in groups.items():
                for cz in grp.circles:
                    if math.hypot(pt[0] - cz.center[0], pt[1] - cz.center[1]) <= cz.radius + 1e-6:
                        return group_offsets.get(gid, (0.0, 0.0))
                for rb in grp.rects:
                    if rb.contains(pt[0], pt[1]):
                        return group_offsets.get(gid, (0.0, 0.0))
            if sync_coincident:
                for orig, d in moved_map:
                    if abs(pt[0] - orig[0]) <= coincident_tol and abs(pt[1] - orig[1]) <= coincident_tol:
                        return d
            return (0.0, 0.0)

        doc = ezdxf.new(dxfversion="R2010")
        doc.units = ezdxf.units.MM
        msp = doc.modelspace()
        for lay in src_doc.layers:
            lname = lay.dxf.name
            if not keep_try_layers and cls.parse_try_layer_name(lname) is not None:
                continue
            if lname not in doc.layers:
                doc.layers.add(name=lname, color=lay.dxf.color if lay.dxf.hasattr("color") else 7)
        if moved_layer_name and moved_layer_name not in doc.layers:
            doc.layers.add(name=moved_layer_name, color=3)
        for ent in src_doc.modelspace():
            lay = ent.dxf.layer if ent.dxf.hasattr("layer") else "0"
            is_try = cls.parse_try_layer_name(lay) is not None
            if is_try:
                if keep_try_layers:
                    cls._copy_entity_raw(msp, ent, lay)
                continue
            etype = ent.dxftype()
            if moved_layer_name:
                cls._copy_entity_raw(msp, ent, lay)
                if lay != "0":
                    continue
                attribs = {"layer": moved_layer_name, "color": 3}
            else:
                attribs = {"layer": lay}
            if etype == "LINE":
                p1 = (float(ent.dxf.start.x), float(ent.dxf.start.y))
                p2 = (float(ent.dxf.end.x), float(ent.dxf.end.y))
                d1 = _delta(p1)
                d2 = _delta(p2)
                msp.add_line((p1[0] + d1[0], p1[1] + d1[1]), (p2[0] + d2[0], p2[1] + d2[1]),
                             dxfattribs=attribs)
            elif etype == "ARC":
                cx, cy = float(ent.dxf.center.x), float(ent.dxf.center.y)
                r = float(ent.dxf.radius)
                sa, ea = float(ent.dxf.start_angle), float(ent.dxf.end_angle)
                p_start, p_end = cls._arc_endpoints(cx, cy, r, sa, ea)
                span = (ea - sa) % 360.0 or 360.0
                amid = math.radians(sa + 0.5 * span)
                p_mid = (cx + r * math.cos(amid), cy + r * math.sin(amid))
                dc = _delta((cx, cy))
                ds = _delta(p_start)
                de = _delta(p_end)
                if dc == ds == de:
                    msp.add_arc((cx + dc[0], cy + dc[1]), r, sa, ea, dxfattribs=attribs)
                else:
                    new_s = (p_start[0] + ds[0], p_start[1] + ds[1])
                    new_e = (p_end[0] + de[0], p_end[1] + de[1])
                    dm = dc if dc != (0.0, 0.0) else ((ds[0] + de[0]) * 0.5, (ds[1] + de[1]) * 0.5)
                    new_m = (p_mid[0] + dm[0], p_mid[1] + dm[1])
                    ncen, nr, na1, na2 = _arc_from_3_points(new_s, new_m, new_e)
                    if ncen is not None and nr > 1e-6:
                        msp.add_arc(ncen, nr, na1, na2, dxfattribs=attribs)
                    else:
                        msp.add_arc((cx + dc[0], cy + dc[1]), r, sa, ea, dxfattribs=attribs)
            elif etype == "CIRCLE":
                cx, cy = float(ent.dxf.center.x), float(ent.dxf.center.y)
                dc = _delta((cx, cy))
                msp.add_circle((cx + dc[0], cy + dc[1]), float(ent.dxf.radius), dxfattribs=attribs)
            elif etype == "LWPOLYLINE":
                pts = [(float(p[0]), float(p[1])) for p in ent.get_points("xy")]
                new_pts = []
                for (px, py) in pts:
                    dv = _delta((px, py))
                    new_pts.append((px + dv[0], py + dv[1]))
                if len(new_pts) >= 2:
                    pl = msp.add_lwpolyline(new_pts, format="xy", dxfattribs=attribs)
                    pl.closed = bool(ent.closed)
        if auto_fillet and fillet_r_max > 0.0:
            target_lay = moved_layer_name if moved_layer_name else "0"
            cls.fillet_layer_line_corners(
                doc, target_layer=target_lay, r_max=fillet_r_max, r_min=fillet_r_min,
                fillet_mode=fillet_mode, min_remain_len=min_remain_len,
                min_remain_ratio=min_remain_ratio,
            )
        return doc

    @classmethod
    def fillet_layer_line_corners(cls, doc, target_layer: str = "0", r_max: float = 0.8,
                                  r_min: float = 0.05, fillet_mode: str = "concave",
                                  min_remain_len: float = 0.15, min_remain_ratio: float = 0.25,
                                  snap_tol: float = 1e-4) -> int:
        msp = doc.modelspace()
        target_u = str(target_layer).strip().upper()
        line_records = []
        edge_items = []
        bc_segments = []

        for ent in list(msp):
            lay = ent.dxf.layer if ent.dxf.hasattr("layer") else "0"
            lay_u = str(lay).strip().upper()
            etype = ent.dxftype()
            if cls.parse_try_layer_name(lay) is not None:
                continue
            filletable = (lay_u == target_u)
            if etype == "LINE":
                p1 = np.array([float(ent.dxf.start.x), float(ent.dxf.start.y)], dtype=float)
                p2 = np.array([float(ent.dxf.end.x), float(ent.dxf.end.y)], dtype=float)
                length = float(np.linalg.norm(p2 - p1))
                if length <= snap_tol:
                    continue
                lid = -1
                if filletable:
                    lid = len(line_records)
                    line_records.append({
                        "id": lid, "ent": ent, "layer": lay,
                        "color": ent.dxf.color if ent.dxf.hasattr("color") else None,
                        "p1": p1, "p2": p2, "len": length,
                    })
                elif lay_u != "0":
                    bc_segments.append((p1, p2))
                edge_items.append({"kind": "LINE", "line_id": lid, "pts": [p1, p2],
                                   "filletable": filletable})
            elif etype == "ARC":
                cx, cy = float(ent.dxf.center.x), float(ent.dxf.center.y)
                r = float(ent.dxf.radius)
                sa, ea = float(ent.dxf.start_angle), float(ent.dxf.end_angle)
                span = (ea - sa) % 360.0 or 360.0
                steps = max(int(span / 10.0), 6)
                angs = np.radians(sa + np.linspace(0.0, span, steps + 1))
                pts = [np.array([cx + r * math.cos(a), cy + r * math.sin(a)], dtype=float) for a in angs]
                edge_items.append({"kind": "ARC", "line_id": -1, "pts": pts, "filletable": False})

        if len(line_records) < 2:
            return 0

        used = [False] * len(edge_items)
        closed_chains = []
        for i in range(len(edge_items)):
            if used[i]:
                continue
            used[i] = True
            e0 = edge_items[i]
            chain = [{"kind": e0["kind"], "line_id": e0["line_id"], "rev": False,
                      "pts": list(e0["pts"]), "filletable": e0["filletable"]}]
            while True:
                head = chain[0]["pts"][0]
                tail = chain[-1]["pts"][-1]
                if len(chain) >= 2 and float(np.linalg.norm(tail - head)) <= snap_tol:
                    closed_chains.append(chain)
                    break
                found = -1
                rev_flag = False
                prepend_flag = False
                for j, ej in enumerate(edge_items):
                    if used[j]:
                        continue
                    q0, q1 = ej["pts"][0], ej["pts"][-1]
                    if float(np.linalg.norm(q0 - tail)) <= snap_tol:
                        found, rev_flag, prepend_flag = j, False, False
                        break
                    if float(np.linalg.norm(q1 - tail)) <= snap_tol:
                        found, rev_flag, prepend_flag = j, True, False
                        break
                    if float(np.linalg.norm(q1 - head)) <= snap_tol:
                        found, rev_flag, prepend_flag = j, False, True
                        break
                    if float(np.linalg.norm(q0 - head)) <= snap_tol:
                        found, rev_flag, prepend_flag = j, True, True
                        break
                if found < 0:
                    break
                used[found] = True
                ef = edge_items[found]
                pts_use = list(reversed(ef["pts"])) if rev_flag else list(ef["pts"])
                item = {"kind": ef["kind"], "line_id": ef["line_id"], "rev": rev_flag,
                        "pts": pts_use, "filletable": ef["filletable"]}
                if prepend_flag:
                    chain.insert(0, item)
                else:
                    chain.append(item)

        if not closed_chains:
            return 0

        loop_infos = []
        for ch in closed_chains:
            poly_pts = []
            for seg in ch:
                poly_pts.extend(seg["pts"][:-1])
            arr = np.asarray(poly_pts, dtype=float)
            if len(arr) < 3:
                continue
            x, y = arr[:, 0], arr[:, 1]
            signed_a = 0.5 * float(np.dot(x, np.roll(y, -1)) - np.dot(y, np.roll(x, -1)))
            loop_infos.append({"chain": ch, "pts": arr, "signed_area": signed_a,
                               "abs_area": abs(signed_a), "path": Path(arr, closed=True)})
        if not loop_infos:
            return 0
        loop_infos.sort(key=lambda d: d["abs_area"], reverse=True)

        for idx, info in enumerate(loop_infos):
            parents = 0
            mid_pts = 0.5 * (info["pts"] + np.roll(info["pts"], -1, axis=0))
            for p_idx in range(idx):
                inside = loop_infos[p_idx]["path"].contains_points(mid_pts, radius=1e-5)
                if len(inside) and float(np.mean(inside)) > 0.6:
                    parents += 1
            want_ccw = (parents % 2 == 0)
            if (want_ccw and info["signed_area"] < 0.0) or ((not want_ccw) and info["signed_area"] > 0.0):
                rev_chain = []
                for seg in reversed(info["chain"]):
                    rev_chain.append({"kind": seg["kind"], "line_id": seg["line_id"],
                                      "rev": not seg["rev"], "pts": list(reversed(seg["pts"])),
                                      "filletable": seg["filletable"]})
                info["chain"] = rev_chain

        line_total_budget = {}
        end_cap = {}
        for rec in line_records:
            lid = rec["id"]
            L = rec["len"]
            keep = max(float(min_remain_len), float(min_remain_ratio) * L)
            budget = max(0.0, L - keep)
            line_total_budget[lid] = budget
            cap_p1 = budget
            cap_p2 = budget
            u_vec = (rec["p2"] - rec["p1"]) / L
            for bc_a, bc_b in bc_segments:
                vc = bc_b - bc_a
                lc = float(np.linalg.norm(vc))
                if lc <= snap_tol:
                    continue
                uc = vc / lc
                if abs(u_vec[0] * uc[1] - u_vec[1] * uc[0]) > 1e-3:
                    continue
                d_perp = max(cls._point_to_seg_dist(bc_a, rec["p1"], rec["p2"]),
                             cls._point_to_seg_dist(bc_b, rec["p1"], rec["p2"]))
                if d_perp > 1e-3:
                    continue
                t1 = float((bc_a - rec["p1"]) @ u_vec)
                t2 = float((bc_b - rec["p1"]) @ u_vec)
                s_lo, s_hi = max(0.0, min(t1, t2)), min(L, max(t1, t2))
                if s_hi - s_lo > snap_tol:
                    cap_p1 = min(cap_p1, max(0.0, s_lo - 0.5 * min_remain_len))
                    cap_p2 = min(cap_p2, max(0.0, (L - s_hi) - 0.5 * min_remain_len))
            end_cap[lid] = [cap_p1, cap_p2]

        corners = []
        mode_l = str(fillet_mode).strip().lower()
        for info in loop_infos:
            ch = info["chain"]
            m = len(ch)
            if m < 2:
                continue
            for k in range(m):
                seg_in = ch[k]
                seg_out = ch[(k + 1) % m]
                if seg_in["kind"] != "LINE" or seg_out["kind"] != "LINE":
                    continue
                if not seg_in["filletable"] or not seg_out["filletable"]:
                    continue
                lid_in = seg_in["line_id"]
                lid_out = seg_out["line_id"]
                if lid_in == lid_out or lid_in < 0 or lid_out < 0:
                    continue
                p_prev = seg_in["pts"][0]
                v_pt = seg_in["pts"][-1]
                p_next = seg_out["pts"][-1]
                v_in = v_pt - p_prev
                v_out = p_next - v_pt
                l_in = float(np.linalg.norm(v_in))
                l_out = float(np.linalg.norm(v_out))
                if l_in <= snap_tol or l_out <= snap_tol:
                    continue
                u_in = v_in / l_in
                u_out = v_out / l_out
                cross = float(u_in[0] * u_out[1] - u_in[1] * u_out[0])
                if abs(cross) <= 1e-3:
                    continue
                if mode_l == "concave" and cross >= 0.0:
                    continue
                if mode_l == "convex" and cross <= 0.0:
                    continue
                d1 = -u_in
                d2 = u_out
                cos_theta = float(np.clip(np.dot(d1, d2), -1.0, 1.0))
                theta = math.acos(cos_theta)
                theta_deg = math.degrees(theta)
                if theta_deg < 3.0 or theta_deg > 177.0:
                    continue
                half_tan = math.tan(0.5 * theta)
                half_sin = math.sin(0.5 * theta)
                if half_tan <= 1e-6 or half_sin <= 1e-6:
                    continue
                end_in = 0 if seg_in["rev"] else 1
                end_out = 1 if seg_out["rev"] else 0
                t_max_local = min(end_cap[lid_in][end_in], end_cap[lid_out][end_out])
                t_want = min(float(r_max) / half_tan, t_max_local)
                if t_want * half_tan < float(r_min):
                    continue
                corners.append({"v": v_pt, "d1": d1, "d2": d2, "theta": theta,
                                "half_tan": half_tan, "half_sin": half_sin,
                                "lid_in": lid_in, "end_in": end_in,
                                "lid_out": lid_out, "end_out": end_out,
                                "t_want": t_want})

        if not corners:
            return 0

        req_trim = {rec["id"]: [0.0, 0.0] for rec in line_records}
        for c in corners:
            req_trim[c["lid_in"]][c["end_in"]] = max(req_trim[c["lid_in"]][c["end_in"]], c["t_want"])
            req_trim[c["lid_out"]][c["end_out"]] = max(req_trim[c["lid_out"]][c["end_out"]], c["t_want"])

        line_scale = {}
        for rec in line_records:
            lid = rec["id"]
            tot_req = req_trim[lid][0] + req_trim[lid][1]
            avail = line_total_budget[lid]
            line_scale[lid] = (avail / tot_req) if (tot_req > avail and tot_req > 1e-12) else 1.0

        final_end_pts = {rec["id"]: [rec["p1"].copy(), rec["p2"].copy()] for rec in line_records}
        fillet_count = 0
        for c in corners:
            scale = min(1.0, line_scale[c["lid_in"]], line_scale[c["lid_out"]])
            t_final = c["t_want"] * scale
            r_final = min(float(r_max), t_final * c["half_tan"])
            if r_final < float(r_min):
                continue
            t_final = r_final / c["half_tan"]
            bisec = c["d1"] + c["d2"]
            b_norm = float(np.linalg.norm(bisec))
            if b_norm <= 1e-12:
                continue
            bisec /= b_norm
            center = c["v"] + (r_final / c["half_sin"]) * bisec
            t1_pt = c["v"] + t_final * c["d1"]
            t2_pt = c["v"] + t_final * c["d2"]
            a1 = math.degrees(math.atan2(t1_pt[1] - center[1], t1_pt[0] - center[0])) % 360.0
            a2 = math.degrees(math.atan2(t2_pt[1] - center[1], t2_pt[0] - center[0])) % 360.0
            if (a2 - a1) % 360.0 <= 180.0:
                sa, ea = a1, a2
                ang_1, ang_2 = sa, ea
            else:
                sa, ea = a2, a1
                ang_1, ang_2 = ea, sa
            p_arc_1 = np.array([center[0] + r_final * math.cos(math.radians(ang_1)),
                                center[1] + r_final * math.sin(math.radians(ang_1))], dtype=float)
            p_arc_2 = np.array([center[0] + r_final * math.cos(math.radians(ang_2)),
                                center[1] + r_final * math.sin(math.radians(ang_2))], dtype=float)
            final_end_pts[c["lid_in"]][c["end_in"]] = p_arc_1
            final_end_pts[c["lid_out"]][c["end_out"]] = p_arc_2
            ref_rec = line_records[c["lid_in"]]
            attribs = {"layer": ref_rec["layer"]}
            if ref_rec["color"] is not None:
                attribs["color"] = ref_rec["color"]
            msp.add_arc((float(center[0]), float(center[1])), float(r_final),
                        float(sa), float(ea), dxfattribs=attribs)
            fillet_count += 1

        if fillet_count > 0:
            for rec in line_records:
                np1, np2 = final_end_pts[rec["id"]]
                rec["ent"].dxf.start = (float(np1[0]), float(np1[1]), 0.0)
                rec["ent"].dxf.end = (float(np2[0]), float(np2[1]), 0.0)
        return fillet_count

    @staticmethod
    def _copy_entity_raw(msp, ent, layer_name: str):
        etype = ent.dxftype()
        if etype == "LINE":
            msp.add_line((float(ent.dxf.start.x), float(ent.dxf.start.y)),
                         (float(ent.dxf.end.x), float(ent.dxf.end.y)), dxfattribs={"layer": layer_name})
        elif etype == "CIRCLE":
            msp.add_circle((float(ent.dxf.center.x), float(ent.dxf.center.y)),
                           float(ent.dxf.radius), dxfattribs={"layer": layer_name})
        elif etype == "ARC":
            msp.add_arc((float(ent.dxf.center.x), float(ent.dxf.center.y)), float(ent.dxf.radius),
                        float(ent.dxf.start_angle), float(ent.dxf.end_angle), dxfattribs={"layer": layer_name})
        elif etype == "LWPOLYLINE":
            pts = [(float(p[0]), float(p[1])) for p in ent.get_points("xy")]
            if len(pts) >= 2:
                pl = msp.add_lwpolyline(pts, format="xy", dxfattribs={"layer": layer_name})
                pl.closed = bool(ent.closed)


def _segments_by_layer(msp) -> dict:
    raw_lines, _curve, _disp, arc_polys, circle_polys = DXFContourHelper.extract_primitives_from_msp(msp)
    by_layer = {}
    for s in raw_lines:
        by_layer.setdefault(s.layer, []).append((s.p1, s.p2))
    for pts, _h, layer in arc_polys:
        arr = np.asarray(pts, dtype=float)
        for a, b in zip(arr[:-1], arr[1:]):
            by_layer.setdefault(layer, []).append((tuple(a), tuple(b)))
    for pts, _h, layer in circle_polys:
        arr = np.asarray(pts, dtype=float)
        for a, b in zip(arr[:-1], arr[1:]):
            by_layer.setdefault(layer, []).append((tuple(a), tuple(b)))
    return by_layer


def _layer_color(layer: str) -> str:
    u = str(layer).upper()
    if u == "0":
        return "#334155"
    if u.startswith("FIXED"):
        return "#0284c7"
    if u.startswith("DISP"):
        return "#dc2626"
    if u.startswith("FORCE"):
        return "#d97706"
    if u.startswith("PROBE"):
        return "#15803d"
    if u.startswith("AUTO"):
        return "#0891b2"
    return "#475569"


def _auto_fit_axes(ax, seg_lists: list, pad_ratio: float = 0.08):
    pts = []
    for segs in seg_lists:
        for p1, p2 in segs:
            pts.append(p1)
            pts.append(p2)
    if not pts:
        return
    arr = np.asarray(pts, dtype=float)
    xmin, ymin = arr.min(axis=0)
    xmax, ymax = arr.max(axis=0)
    dx = max(xmax - xmin, 1.0) * pad_ratio
    dy = max(ymax - ymin, 1.0) * pad_ratio
    ax.set_xlim(xmin - dx, xmax + dx)
    ax.set_ylim(ymin - dy, ymax + dy)


def render_overview_png(doc, groups: dict, out_path: str):
    fig, ax = plt.subplots(figsize=(12.0, 8.0))
    fig.patch.set_facecolor("#ffffff")
    ax.set_facecolor("#ffffff")
    by_layer = _segments_by_layer(doc.modelspace())
    base_segs = []
    for layer, segs in by_layer.items():
        if TrySearchSpaceHelper.parse_try_layer_name(layer) is not None:
            continue
        base_segs.extend(segs)
        ax.add_collection(LineCollection(segs, colors=_layer_color(layer), linewidths=1.2, zorder=2))
    palette = ["#c2410c", "#0369a1", "#15803d", "#a21caf", "#b45309", "#be123c", "#4338ca", "#0f766e"]
    extra_segs = []
    for k, (gid, grp) in enumerate(groups.items()):
        color = palette[k % len(palette)]
        for cz in grp.circles:
            ax.add_patch(MplCircle(cz.center, cz.radius, fill=False, edgecolor=color, lw=1.8, ls="--", zorder=4))
        for rb in grp.rects:
            ax.add_patch(MplRect((rb.xmin, rb.ymin), rb.xmax - rb.xmin, rb.ymax - rb.ymin,
                                 fill=False, edgecolor=color, lw=1.8, ls="--", zorder=4))
        for (p1, p2, _ci) in grp.range_lines:
            ax.plot([p1[0], p2[0]], [p1[1], p2[1]], color=color, lw=1.4, alpha=0.85, zorder=3)
            extra_segs.append((p1, p2))
        if grp.bound_points:
            b_arr = np.array([bp.orig_xy for bp in grp.bound_points], dtype=float)
            c0 = (float(b_arr[:, 0].mean()), float(b_arr[:, 1].mean()))
        elif grp.circles:
            c0 = grp.circles[0].center
        else:
            c0 = None
        if c0 is not None:
            rx0 = c0[0] + grp.dx_bounds[0]
            ry0 = c0[1] + grp.dy_bounds[0]
            rw = max(grp.dx_bounds[1] - grp.dx_bounds[0], 1e-3)
            rh = max(grp.dy_bounds[1] - grp.dy_bounds[0], 1e-3)
            ax.add_patch(MplRect((rx0, ry0), rw, rh, fill=False, edgecolor=color, lw=1.5, ls=":", zorder=5))
            extra_segs.append(((rx0, ry0), (rx0 + rw, ry0 + rh)))
            ax.text(
                c0[0], c0[1], gid, color=color, fontsize=8.5, fontweight="bold",
                ha="left", va="bottom", zorder=6,
                bbox=dict(boxstyle="round,pad=0.18", facecolor="#ffffff", edgecolor=color, alpha=0.88),
            )
        pts = np.array([bp.orig_xy for bp in grp.bound_points], dtype=float)
        if len(pts):
            ax.scatter(pts[:, 0], pts[:, 1], s=28, c=color, edgecolors="#ffffff", linewidths=0.7, zorder=7)
    _auto_fit_axes(ax, [base_segs, extra_segs])
    ax.set_aspect("equal", adjustable="box")
    ax.grid(True, color="#e2e8f0", linestyle="--", linewidth=0.6, zorder=0)
    ax.tick_params(colors="#1e293b", labelsize=8)
    ax.set_title(f"TRY Search-Space Overview | groups={len(groups)}", color="#0f172a", fontsize=11, fontweight="bold")
    for sp in ax.spines.values():
        sp.set_color("#64748b")
    fig.tight_layout()
    fig.savefig(out_path, dpi=140, facecolor="#ffffff")
    plt.close(fig)


def render_morph_png(orig_doc, preview_doc, offsets: dict, out_path: str, title: str):
    fig, ax = plt.subplots(figsize=(11.0, 7.0))
    fig.patch.set_facecolor("#ffffff")
    ax.set_facecolor("#ffffff")
    base = _segments_by_layer(orig_doc.modelspace())
    orig_segs = base.get("0", [])
    if orig_segs:
        ax.add_collection(LineCollection(orig_segs, colors="#94a3b8", linewidths=1.0, ls="--", zorder=2))
    moved = _segments_by_layer(preview_doc.modelspace())
    green_segs = moved.get("FINAL_CONTOUR", [])
    if green_segs:
        ax.add_collection(LineCollection(green_segs, colors="#15803d", linewidths=1.8, zorder=5))
    other_segs = []
    for layer, segs in moved.items():
        if layer in ("FINAL_CONTOUR", "0"):
            continue
        other_segs.extend(segs)
        ax.add_collection(LineCollection(segs, colors=_layer_color(layer), linewidths=1.5, zorder=4))
    _auto_fit_axes(ax, [orig_segs, green_segs, other_segs])
    txt = "  ".join(f"{gid}=({dx:+.2f},{dy:+.2f})" for gid, (dx, dy) in offsets.items())
    ax.set_title(f"{title}   {txt}", color="#0f172a", fontsize=9.5, fontweight="bold")
    ax.set_aspect("equal", adjustable="box")
    ax.grid(True, color="#e2e8f0", linestyle="--", linewidth=0.6, zorder=0)
    ax.tick_params(colors="#1e293b", labelsize=8)
    for sp in ax.spines.values():
        sp.set_color("#64748b")
    fig.tight_layout()
    fig.savefig(out_path, dpi=140, facecolor="#ffffff")
    plt.close(fig)


def _sample_offsets(groups: dict, n_random: int, rng) -> list:
    gids = list(groups.keys())
    samples = []
    samples.append(("zero", {gid: (0.0, 0.0) for gid in gids}))
    for gid in gids:
        grp = groups[gid]
        zero = {g: (0.0, 0.0) for g in gids}
        lo = dict(zero)
        lo[gid] = (grp.dx_bounds[0], grp.dy_bounds[0])
        samples.append((f"{gid}_min", lo))
        hi = dict(zero)
        hi[gid] = (grp.dx_bounds[1], grp.dy_bounds[1])
        samples.append((f"{gid}_max", hi))
    for i in range(n_random):
        offs = {}
        for gid in gids:
            grp = groups[gid]
            offs[gid] = grp.sample_dx_dy(rng.uniform(0, 1), rng.uniform(0, 1))
        samples.append((f"rand{i + 1:02d}", offs))
    return samples


def main():
    folder = os.path.dirname(os.path.abspath(__file__))
    dxf_path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(folder, "part01.dxf")
    n_random = int(sys.argv[2]) if len(sys.argv) > 2 else 8
    out_dir = os.path.join(folder, "out", "try008_preview")
    os.makedirs(out_dir, exist_ok=True)
    print(f"[讀取] {dxf_path}")
    src_doc = ezdxf.readfile(dxf_path)
    layer_count = {}
    for ent in src_doc.modelspace():
        lay = ent.dxf.layer if ent.dxf.hasattr("layer") else "0"
        layer_count[lay] = layer_count.get(lay, 0) + 1
    print(f"[圖元] 共 {sum(layer_count.values())} 個 | " +
          "  ".join(f"{k or '(空)'}={v}" for k, v in sorted(layer_count.items())))
    groups = TrySearchSpaceHelper.extract_try_groups(src_doc)
    conflicts = TrySearchSpaceHelper.bind_layer0_control_points(src_doc, groups)
    if not groups:
        print("[警告] 找不到任何 TRY#編號 圖層（圖層上必須有圖元才算）。")
        print("       請在 DXF 新增圖層 TRY#001 / TRY#002 ...，在該圖層畫 CIRCLE 圈住要同步移動的節點，")
        print("       並從圓心拉一條直線標示 (dx, dy) 範圍，再重跑本程式。")
        return
    print(f"[群組] 共 {len(groups)} 組")
    for gid, grp in groups.items():
        print(f"  {gid}  (圖層 {grp.layer_name})")
        print(f"    選取圓 {len(grp.circles)} 個: " +
              ", ".join(f"({c.center[0]:.2f},{c.center[1]:.2f}) r={c.radius:.2f}" for c in grp.circles))
        print(f"    範圍線 {len(grp.range_lines)} 條")
        print(f"    位移範圍 dx [{grp.dx_bounds[0]:+.3f}, {grp.dx_bounds[1]:+.3f}] mm | "
              f"dy [{grp.dy_bounds[0]:+.3f}, {grp.dy_bounds[1]:+.3f}] mm")
        n_line = sum(1 for b in grp.bound_points if b.entity_type == "LINE")
        n_arc = sum(1 for b in grp.bound_points if b.entity_type == "ARC")
        n_circ = sum(1 for b in grp.bound_points if b.entity_type == "CIRCLE")
        n_pl = sum(1 for b in grp.bound_points if b.entity_type == "LWPOLYLINE")
        print(f"    綁定控制點 {len(grp.bound_points)} 個 (LINE {n_line} / ARC {n_arc} / CIRCLE {n_circ} / LWPOLYLINE {n_pl})")
        if not grp.range_lines:
            for d in grp.diag:
                print(f"    [警告] 圓 #{d['circle']} 沒有任何射線被判定為相連："
                      f"最近的線端點/線段距圓心 {d['nearest']:.3f} mm，容差 {d['seed_tol']:.3f} mm")
                print(f"           射線起點必須落在圓內（或線段通過圓心），否則該組位移範圍恆為 0。")
        if grp.dx_bounds == (0.0, 0.0) and grp.dy_bounds == (0.0, 0.0):
            print(f"    [警告] {gid} 的位移範圍是 (0,0)，這一組在全域採樣時永遠不會移動。")
        if not grp.bound_points:
            print(f"    [警告] {gid} 沒有圈到任何圖層 0 的控制點，就算位移也只會動到射線本身。")
    if conflicts:
        print(f"[警告] 有 {len(conflicts)} 個控制點同時落在不同群組，後者會覆蓋前者：")
        for h, role, a, b in conflicts[:10]:
            print(f"    handle={h} role={role}  {a} vs {b}")
    overview = os.path.join(out_dir, "search_space_overview.png")
    render_overview_png(src_doc, groups, overview)
    print(f"[輸出] {overview}")
    rng = np.random.default_rng(seed=42)
    samples = _sample_offsets(groups, n_random, rng)
    hp = ContourHyperParams()
    rows = []
    baseline = None
    for idx, (tag, offs) in enumerate(samples, start=1):
        morphed = TrySearchSpaceHelper.apply_group_displacements(src_doc, groups, offs)
        cand_dxf = os.path.join(out_dir, f"morph_{idx:03d}_{tag}.dxf")
        morphed.saveas(cand_dxf)
        try:
            result = DXFContourHelper.check_dxf(morphed, hp=hp)
            counts = result.summary_dict()
        except Exception as exc:
            print(f"  [{idx:03d}] {tag:<14} 檢查失敗: {exc}")
            rows.append((tag, -1, -1, -1))
            continue
        if baseline is None:
            baseline = (counts["OPEN_ENDPOINT"], counts["LOOP_INTERSECT"])
            print(f"[基準] 偏移全 0 的原始圖面: OPEN={baseline[0]} INTERSECT={baseline[1]} issues={len(result.issues)}")
            if baseline[0] or baseline[1]:
                print("[基準] 原始圖面本身就有問題，以下逐組以「不惡化基準」判定：")
                for iss in result.issues:
                    if iss.issue_type in ("OPEN_ENDPOINT", "LOOP_INTERSECT"):
                        print(f"         {iss.issue_type} @ ({iss.focus_xy[0]:+.3f}, {iss.focus_xy[1]:+.3f})  {iss.description}")
        preview = TrySearchSpaceHelper.apply_group_displacements(
            src_doc, groups, offs, moved_layer_name="FINAL_CONTOUR"
        )
        cand_png = os.path.join(out_dir, f"morph_{idx:03d}_{tag}.png")
        render_morph_png(src_doc, preview, offs, cand_png, f"morph #{idx:03d} {tag}")
        offs_txt = " ".join(f"{g}->({dx:+.2f},{dy:+.2f})" for g, (dx, dy) in offs.items()
                            if abs(dx) > 1e-9 or abs(dy) > 1e-9) or "(全為 0)"
        rows.append((tag, counts["OPEN_ENDPOINT"], counts["LOOP_INTERSECT"], len(result.issues)))
        flag = ""
        if baseline is not None and (counts["OPEN_ENDPOINT"] > baseline[0] or counts["LOOP_INTERSECT"] > baseline[1]):
            flag = "  <== 比基準差"
        print(f"  [{idx:03d}] {tag:<14} OPEN={counts['OPEN_ENDPOINT']} INTERSECT={counts['LOOP_INTERSECT']} "
              f"issues={len(result.issues)} | {offs_txt}{flag}")
    if baseline is None:
        print("[驗證] 全部樣本都檢查失敗，無法判定。")
        return
    bad = [r for r in rows if r[1] > baseline[0] or r[2] > baseline[1]]
    print(f"[驗證] {len(rows) - len(bad)}/{len(rows)} 組未使情況惡化 "
          f"(基準 OPEN={baseline[0]}, INTERSECT={baseline[1]})")
    if bad:
        print("[惡化] " + ", ".join(f"{t}(OPEN={o},X={x})" for t, o, x, _n in bad))
    if baseline[0] or baseline[1]:
        print("[提醒] 原始圖面就有開口/自交，這項驗證只能證明「變形沒讓它更糟」。"
              "要拿到全 0，請先修好上面列出的座標。")


if __name__ == "__main__":
    main()
