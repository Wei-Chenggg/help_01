import time
from dataclasses import dataclass
import numpy as np
from matplotlib.collections import LineCollection
from matplotlib.path import Path
from scipy.spatial import Delaunay, cKDTree
import ezdxf

try:
    from .dxf_contour_helper import DXFContourHelper, ContourHyperParams
    from .dxf_editting_helper import DXFEditingHelper
except ImportError:
    from dxf_contour_helper import DXFContourHelper, ContourHyperParams
    from dxf_editting_helper import DXFEditingHelper

@dataclass
class MeshHyperParams:
    h_max: float = 3.0
    h_min: float = 0.45
    gradation: float = 0.25
    curve_tol: float = 0.03
    snap_tol: float = 1e-2
    smooth_iter: int = 4
    auto_density: bool = True

class FiniteEleMeshHelper:
    @staticmethod
    def _polygon_area_signed(pts: np.ndarray) -> float:
        x, y = pts[:, 0], pts[:, 1]
        return 0.5 * float(np.dot(x, np.roll(y, -1)) - np.dot(y, np.roll(x, -1)))

    @staticmethod
    def _polygon_area(pts: np.ndarray) -> float:
        return abs(FiniteEleMeshHelper._polygon_area_signed(pts))

    @classmethod
    def _dedup_with_edge_layers(cls, pts, layers, tol: float = 1e-6):
        pts = np.asarray(pts, dtype=float)
        layers = list(layers)
        n = len(pts)
        if n < 2:
            return pts, layers
        keep_pts = [0]
        keep_lays = []
        for i in range(1, n):
            d = float(np.linalg.norm(pts[i] - pts[keep_pts[-1]]))
            if d <= tol:
                continue
            keep_pts.append(i)
            keep_lays.append(layers[i - 1] if i - 1 < len(layers) else (layers[-1] if layers else "0"))
        res = pts[keep_pts]
        if len(res) > 1 and float(np.linalg.norm(res[0] - res[-1])) <= tol:
            res = res[:-1]
        while len(keep_lays) < len(res):
            keep_lays.append(keep_lays[-1] if keep_lays else "0")
        keep_lays = keep_lays[: len(res)]
        return res, keep_lays

    @classmethod
    def _chain_segments_with_layers(cls, segments: list[tuple], snap_tol: float = 1e-3) -> list[tuple]:
        chains = []
        used = [False] * len(segments)
        for i in range(len(segments)):
            if used[i]:
                continue
            pts = [np.asarray(p, dtype=float) for p in segments[i][0]]
            lay = segments[i][1]
            lays = [lay] * (len(pts) - 1)
            used[i] = True
            changed = True
            while changed:
                changed = False
                if len(pts) >= 4 and float(np.linalg.norm(pts[0] - pts[-1])) <= snap_tol:
                    break
                for j in range(len(segments)):
                    if used[j]:
                        continue
                    seg_pts = [np.asarray(p, dtype=float) for p in segments[j][0]]
                    seg_lay = segments[j][1]
                    add_lays = [seg_lay] * (len(seg_pts) - 1)
                    if np.linalg.norm(pts[-1] - seg_pts[0]) <= snap_tol:
                        pts.extend(seg_pts[1:])
                        lays.extend(add_lays)
                        used[j] = True
                        changed = True
                        break
                    if np.linalg.norm(pts[-1] - seg_pts[-1]) <= snap_tol:
                        pts.extend(seg_pts[-2::-1])
                        lays.extend(add_lays)
                        used[j] = True
                        changed = True
                        break
                    if np.linalg.norm(pts[0] - seg_pts[-1]) <= snap_tol:
                        pts = seg_pts[:-1] + pts
                        lays = add_lays + lays
                        used[j] = True
                        changed = True
                        break
                    if np.linalg.norm(pts[0] - seg_pts[0]) <= snap_tol:
                        pts = seg_pts[:0:-1] + pts
                        lays = add_lays + lays
                        used[j] = True
                        changed = True
                        break
            arr = np.array(pts, dtype=float)
            arr, lays = cls._dedup_with_edge_layers(arr, lays, tol=snap_tol)
            if len(arr) >= 3:
                chains.append((arr, lays))
        return chains

    @staticmethod
    def _reverse_loop_with_layers(loop: np.ndarray, layers: list) -> tuple[np.ndarray, list]:
        n = len(loop)
        new_loop = loop[::-1].copy()
        new_layers = [layers[(n - 2 - j) % n] for j in range(n)]
        return new_loop, new_layers

    @classmethod
    def read_dxf_loops(cls, dxf_source, hp: "MeshHyperParams | None" = None,
                       curve_tol: float | None = None, snap_tol: float | None = None) -> dict:
        if hp is None:
            hp = MeshHyperParams()
        if curve_tol is not None:
            hp.curve_tol = float(curve_tol)
        if snap_tol is not None:
            hp.snap_tol = float(snap_tol)
        if isinstance(dxf_source, str):
            doc = ezdxf.readfile(dxf_source)
            src_name = dxf_source
        else:
            doc = dxf_source
            src_name = "<in-memory-doc>"
        msp = doc.modelspace()
        raw_lines, _curve_edges, _disp, arc_polys, circle_polys = DXFContourHelper.extract_primitives_from_msp(msp)
        clean_lines = DXFContourHelper.split_and_dedup_lines(raw_lines, ContourHyperParams(snap_tol=hp.snap_tol))

        segs = []
        raw_entities = []
        for s in clean_lines:
            pts = np.array([s.p1, s.p2], dtype=float)
            segs.append((pts, s.layer))
            raw_entities.append({"layer": s.layer, "points": pts})
        for pts, _handle, layer in arc_polys:
            arr = np.asarray(pts, dtype=float)
            if len(arr) < 2:
                continue
            segs.append((arr, layer))
            raw_entities.append({"layer": layer, "points": arr})

        closed_loops = []
        closed_layers = []
        probe_circles = []
        for pts, handle, layer in circle_polys:
            arr = np.asarray(pts, dtype=float)
            if len(arr) < 4:
                continue
            info = DXFContourHelper.parse_bc_layer(layer)
            if info.get("type") == "PROBE":
                cx = float(arr[:, 0].mean())
                cy = float(arr[:, 1].mean())
                r = float(np.mean(np.hypot(arr[:, 0] - cx, arr[:, 1] - cy)))
                probe_circles.append({
                    "probe_id": info.get("probe_id", "PROBE#001"),
                    "layer": layer,
                    "handle": handle,
                    "center": (cx, cy),
                    "radius": r,
                })
                continue
            loop, lays = cls._dedup_with_edge_layers(arr, [layer] * (len(arr) - 1), tol=hp.snap_tol)
            if len(loop) >= 3:
                closed_loops.append(loop)
                closed_layers.append(lays)
                raw_entities.append({"layer": layer, "points": arr})
        for loop, lays in cls._chain_segments_with_layers(segs, snap_tol=hp.snap_tol):
            closed_loops.append(loop)
            closed_layers.append(lays)
        if not closed_loops:
            raise ValueError(f"無法從 DXF 提取封閉輪廓: {src_name}")

        order = sorted(range(len(closed_loops)), key=lambda k: cls._polygon_area(closed_loops[k]), reverse=True)
        closed_loops = [closed_loops[k] for k in order]
        closed_layers = [closed_layers[k] for k in order]

        outer_loop = closed_loops[0]
        outer_layers = list(closed_layers[0])
        if cls._polygon_area_signed(outer_loop) < 0:
            outer_loop, outer_layers = cls._reverse_loop_with_layers(outer_loop, outer_layers)
        hole_loops = []
        hole_layers = []
        exterior_islands = []
        outer_path = Path(np.vstack([outer_loop, outer_loop[0]]), closed=True)
        for h_loop, h_lays in zip(closed_loops[1:], closed_layers[1:]):
            if cls._polygon_area(h_loop) <= 0:
                continue
            inside = outer_path.contains_points(h_loop)
            if float(np.mean(inside)) < 0.5:
                exterior_islands.append(h_loop)
                continue
            if cls._polygon_area_signed(h_loop) > 0:
                h_loop, h_lays = cls._reverse_loop_with_layers(h_loop, h_lays)
            hole_loops.append(h_loop)
            hole_layers.append(list(h_lays))
        return {
            "outer_loop": outer_loop,
            "outer_layers": outer_layers,
            "hole_loops": hole_loops,
            "hole_layers": hole_layers,
            "raw_entities": raw_entities,
            "probe_circles": probe_circles,
            "exterior_islands": exterior_islands,
            "source": src_name,
        }

    @classmethod
    def _build_sizing_probe_data(
        cls,
        outer_loop: np.ndarray,
        hole_loops: list[np.ndarray],
        h_max: float,
        h_min: float,
        gradation: float = 0.25,
        probe_centers=None,
    ) -> tuple[cKDTree, np.ndarray]:
        feat_pts = []
        feat_h = []
        all_loops = [outer_loop] + hole_loops
        for loop_idx, loop in enumerate(all_loops):
            n = len(loop)
            prev_pts = np.roll(loop, 1, axis=0)
            next_pts = np.roll(loop, -1, axis=0)
            v1 = loop - prev_pts
            v2 = next_pts - loop
            len1 = np.linalg.norm(v1, axis=1)
            len2 = np.linalg.norm(v2, axis=1)
            u1 = v1 / np.maximum(len1[:, None], 1e-12)
            u2 = v2 / np.maximum(len2[:, None], 1e-12)
            cross = u1[:, 0] * u2[:, 1] - u1[:, 1] * u2[:, 0]
            dot = np.clip(np.sum(u1 * u2, axis=1), -1.0, 1.0)
            turn_angle = np.arccos(dot)
            is_concave = cross < -1e-3
            is_sharp_corner = turn_angle > np.deg2rad(25.0)
            is_curved_seg = np.minimum(len1, len2) < 0.85 * h_max
            for i in range(n):
                if is_concave[i]:
                    feat_pts.append(loop[i])
                    feat_h.append(h_min)
                elif is_sharp_corner[i]:
                    feat_pts.append(loop[i])
                    feat_h.append(max(h_min, 0.45 * h_max))
                elif is_curved_seg[i]:
                    local_len = max(len1[i], len2[i])
                    feat_pts.append(loop[i])
                    feat_h.append(np.clip(local_len * 1.2, h_min, 0.6 * h_max))
            if loop_idx > 0:
                bbox_diag = float(np.linalg.norm(loop.max(axis=0) - loop.min(axis=0)))
                hole_h = np.clip(bbox_diag * 0.18, h_min, 0.65 * h_max)
                for p in loop:
                    feat_pts.append(p)
                    feat_h.append(hole_h)
        for pc in (probe_centers or []):
            feat_pts.append(np.asarray(pc, dtype=float))
            feat_h.append(h_min)
        probe_step = max(h_min, 0.5 * h_max)
        dense_boundary = []
        for loop in all_loops:
            n = len(loop)
            for i in range(n):
                p0, p1 = loop[i], loop[(i + 1) % n]
                seg_l = float(np.linalg.norm(p1 - p0))
                nd = max(1, int(np.ceil(seg_l / probe_step)))
                t = np.linspace(0.0, 1.0, nd, endpoint=False)[:, None]
                dense_boundary.append(p0 * (1.0 - t) + p1 * t)
        dense_pts = np.vstack(dense_boundary)
        if len(dense_pts) > 4:
            xmin, ymin = outer_loop.min(axis=0)
            xmax, ymax = outer_loop.max(axis=0)
            outer_path = Path(np.vstack([outer_loop, outer_loop[0]]), closed=True)
            hole_paths = [Path(np.vstack([h, h[0]]), closed=True) for h in hole_loops]
            bbox = (xmin, ymin, xmax, ymax)
            b_tree = cKDTree(dense_pts)
            k_query = min(16, len(dense_pts))
            dists, idxs = b_tree.query(dense_pts, k=k_query)
            if k_query == 1:
                dists = dists[:, None]
                idxs = idxs[:, None]
            for i in range(len(dense_pts)):
                for k_i in range(1, dists.shape[1]):
                    d_val = float(dists[i, k_i])
                    j = int(idxs[i, k_i])
                    if abs(i - j) <= 3 or abs(i - j) >= len(dense_pts) - 3:
                        continue
                    if not (1e-4 < d_val < 2.5 * h_max):
                        continue
                    mid_pt = (0.5 * (dense_pts[i] + dense_pts[j])).reshape(1, 2)
                    if not bool(cls._points_in_domain(mid_pt, outer_path, hole_paths, bbox)[0]):
                        continue
                    gap_h = float(np.clip(d_val / 2.8, h_min, 0.7 * h_max))
                    feat_pts.append(dense_pts[i])
                    feat_h.append(gap_h)
                    break
        if not feat_pts:
            feat_pts = [outer_loop[0]]
            feat_h = [h_max]
        return cKDTree(np.array(feat_pts, dtype=float)), np.array(feat_h, dtype=float)

    @staticmethod
    def _eval_sizing_field(
        pts: np.ndarray,
        feat_tree: cKDTree,
        feat_h: np.ndarray,
        h_max: float,
        h_min: float,
        gradation: float = 0.25,
    ) -> np.ndarray:
        if len(pts) == 0:
            return np.empty(0, dtype=float)
        k_query = min(8, len(feat_h))
        dists, idxs = feat_tree.query(pts, k=k_query)
        if k_query == 1:
            dists = dists[:, None]
            idxs = idxs[:, None]
        h_candidates = feat_h[idxs] + gradation * dists
        h_local = np.min(h_candidates, axis=1)
        return np.clip(h_local, h_min, h_max)

    @classmethod
    def _resample_loop_adaptive(
        cls,
        loop: np.ndarray,
        feat_tree: cKDTree | None,
        feat_h: np.ndarray | None,
        h_max: float,
        h_min: float,
        gradation: float,
        edge_layers: list | None = None,
    ) -> tuple[np.ndarray, list]:
        n = len(loop)
        sampled = []
        sampled_layers = []
        for i in range(n):
            p_start = loop[i]
            p_end = loop[(i + 1) % n]
            seg_len = float(np.linalg.norm(p_end - p_start))
            if seg_len <= 1e-9:
                continue
            if feat_tree is None:
                n_div = max(1, int(np.ceil(seg_len / h_max)))
                t_vals = np.linspace(0.0, 1.0, n_div, endpoint=False)
            else:
                n_probe = max(2, int(np.ceil(seg_len / h_min)) + 1)
                t_probe = np.linspace(0.0, 1.0, n_probe)
                pts_probe = p_start[None, :] * (1.0 - t_probe[:, None]) + p_end[None, :] * t_probe[:, None]
                h_probe = cls._eval_sizing_field(pts_probe, feat_tree, feat_h, h_max, h_min, gradation)
                dt = 1.0 / (n_probe - 1)
                density = seg_len / h_probe
                cum_phase = np.concatenate(([0.0], np.cumsum(0.5 * (density[:-1] + density[1:]) * dt)))
                total_divs = max(1, int(np.round(cum_phase[-1])))
                target_phases = np.linspace(0.0, cum_phase[-1], total_divs, endpoint=False)
                t_vals = np.interp(target_phases, cum_phase, t_probe)
            seg_pts = p_start[None, :] * (1.0 - t_vals[:, None]) + p_end[None, :] * t_vals[:, None]
            sampled.append(seg_pts)
            lay = edge_layers[i] if (edge_layers is not None and i < len(edge_layers)) else "0"
            sampled_layers.extend([lay] * len(t_vals))
        if not sampled:
            return np.empty((0, 2), dtype=float), []
        return np.vstack(sampled), sampled_layers

    @staticmethod
    def _points_in_domain(pts: np.ndarray, outer_path: Path, hole_paths: list[Path], outer_bbox: tuple) -> np.ndarray:
        if len(pts) == 0:
            return np.zeros(0, dtype=bool)
        xmin, ymin, xmax, ymax = outer_bbox
        in_box = (pts[:, 0] >= xmin) & (pts[:, 0] <= xmax) & (pts[:, 1] >= ymin) & (pts[:, 1] <= ymax)
        mask = np.zeros(len(pts), dtype=bool)
        if not np.any(in_box):
            return mask
        sub_pts = pts[in_box]
        sub_keep = outer_path.contains_points(sub_pts)
        for hp in hole_paths:
            if np.any(sub_keep):
                sub_keep &= ~hp.contains_points(sub_pts)
        mask[in_box] = sub_keep
        return mask

    @classmethod
    def _generate_interior_points(
        cls,
        outer_loop: np.ndarray,
        outer_path: Path,
        hole_paths: list[Path],
        boundary_nodes: np.ndarray,
        feat_tree: cKDTree | None,
        feat_h: np.ndarray | None,
        h_max: float,
        h_min: float,
        gradation: float,
    ) -> np.ndarray:
        xmin, ymin = outer_loop.min(axis=0)
        xmax, ymax = outer_loop.max(axis=0)
        outer_bbox = (xmin, ymin, xmax, ymax)
        if feat_tree is None:
            dx = h_max
            dy = h_max * np.sqrt(3.0) * 0.5
            ys = np.arange(ymin + 0.5 * dy, ymax, dy)
            xs_base = np.arange(xmin + 0.5 * dx, xmax, dx)
            grid_x, grid_y = np.meshgrid(xs_base, ys)
            odd_rows = (np.arange(len(ys)) % 2) == 1
            grid_x[odd_rows] += 0.5 * dx
            cand = np.column_stack([grid_x.ravel(), grid_y.ravel()])
            cand = cand[cls._points_in_domain(cand, outer_path, hole_paths, outer_bbox)]
            if len(cand) > 0:
                b_tree = cKDTree(boundary_nodes)
                dists, _ = b_tree.query(cand)
                cand = cand[dists >= 0.45 * h_max]
            return cand
        nx = max(2, int(np.ceil((xmax - xmin) / h_max)))
        ny = max(2, int(np.ceil((ymax - ymin) / h_max)))
        xs = np.linspace(xmin, xmax, nx + 1)
        ys = np.linspace(ymin, ymax, ny + 1)
        gx, gy = np.meshgrid(0.5 * (xs[:-1] + xs[1:]), 0.5 * (ys[:-1] + ys[1:]))
        cell_centers = np.column_stack([gx.ravel(), gy.ravel()])
        cell_hx = np.full(len(cell_centers), (xmax - xmin) / nx, dtype=float)
        cell_hy = np.full(len(cell_centers), (ymax - ymin) / ny, dtype=float)
        leaf_pts = []
        leaf_h = []
        max_levels = max(1, int(np.ceil(np.log2(h_max / max(h_min, 1e-6)))) + 1)
        for _ in range(max_levels):
            if len(cell_centers) == 0:
                break
            cell_size = np.maximum(cell_hx, cell_hy)
            h_target = cls._eval_sizing_field(cell_centers, feat_tree, feat_h, h_max, h_min, gradation)
            b_tree_tmp = cKDTree(boundary_nodes)
            b_dist, _ = b_tree_tmp.query(cell_centers)
            in_dom = cls._points_in_domain(cell_centers, outer_path, hole_paths, outer_bbox)
            near_b = b_dist <= 0.85 * cell_size
            active = in_dom | near_b
            cell_centers = cell_centers[active]
            cell_hx = cell_hx[active]
            cell_hy = cell_hy[active]
            cell_size = cell_size[active]
            h_target = h_target[active]
            split_mask = (cell_size > 1.15 * h_target) & (cell_size * 0.5 >= 0.75 * h_min)
            if np.any(~split_mask):
                kept_c = cell_centers[~split_mask]
                kept_hx = cell_hx[~split_mask]
                kept_hy = cell_hy[~split_mask]
                kept_h = h_target[~split_mask]
                leaf_pts.append(kept_c)
                leaf_h.append(kept_h)
                stag = kept_c + np.column_stack([0.5 * kept_hx, 0.5 * kept_hy])
                leaf_pts.append(stag)
                leaf_h.append(kept_h)
            if not np.any(split_mask):
                break
            sp_c = cell_centers[split_mask]
            sp_hx = 0.5 * cell_hx[split_mask]
            sp_hy = 0.5 * cell_hy[split_mask]
            offsets = np.array([[-0.5, -0.5], [0.5, -0.5], [-0.5, 0.5], [0.5, 0.5]])
            new_c = (sp_c[:, None, :] + offsets[None, :, :] * np.column_stack([sp_hx, sp_hy])[:, None, :]).reshape(-1, 2)
            cell_centers = new_c
            cell_hx = np.repeat(sp_hx, 4)
            cell_hy = np.repeat(sp_hy, 4)
        if len(cell_centers) > 0:
            h_rem = cls._eval_sizing_field(cell_centers, feat_tree, feat_h, h_max, h_min, gradation)
            leaf_pts.append(cell_centers)
            leaf_h.append(h_rem)
        if not leaf_pts:
            return np.empty((0, 2), dtype=float)
        cand = np.vstack(leaf_pts)
        cand_h = np.concatenate(leaf_h)
        dom_mask = cls._points_in_domain(cand, outer_path, hole_paths, outer_bbox)
        cand = cand[dom_mask]
        cand_h = cand_h[dom_mask]
        if len(cand) == 0:
            return cand
        b_tree = cKDTree(boundary_nodes)
        b_dists, _ = b_tree.query(cand)
        keep_b = b_dists >= 0.45 * cand_h
        cand = cand[keep_b]
        cand_h = cand_h[keep_b]
        if len(cand) > 1:
            order = np.argsort(cand_h)
            cand = cand[order]
            cand_h = cand_h[order]
            quant = np.round(cand / (0.25 * h_min)).astype(np.int64)
            _, uniq_idx = np.unique(quant, axis=0, return_index=True)
            uniq_idx.sort()
            cand = cand[uniq_idx]
        return cand

    @staticmethod
    def _laplacian_smooth_vectorized(
        nodes: np.ndarray,
        elements_t3: np.ndarray,
        n_boundary: int,
        iterations: int = 4,
    ) -> np.ndarray:
        if iterations <= 0 or len(nodes) <= n_boundary or len(elements_t3) == 0:
            return nodes
        coords = nodes.copy()
        e01 = elements_t3[:, [0, 1]]
        e12 = elements_t3[:, [1, 2]]
        e20 = elements_t3[:, [2, 0]]
        directed = np.vstack([e01, e12, e20, e01[:, ::-1], e12[:, ::-1], e20[:, ::-1]])
        u = directed[:, 0]
        v = directed[:, 1]
        n_nodes = len(coords)
        for _ in range(iterations):
            edge_lengths = np.linalg.norm(coords[u] - coords[v], axis=1)
            w = 1.0 / np.maximum(edge_lengths, 1e-6)
            accum = np.zeros_like(coords)
            w_sum = np.zeros(n_nodes, dtype=float)
            np.add.at(accum, u, coords[v] * w[:, None])
            np.add.at(w_sum, u, w)
            valid = w_sum[n_boundary:] > 0
            idx_int = np.arange(n_boundary, n_nodes)[valid]
            coords[idx_int] = 0.4 * coords[idx_int] + 0.6 * (accum[idx_int] / w_sum[idx_int, None])
        return coords

    @staticmethod
    def _upgrade_t3_to_t6_vectorized(
        nodes_t3: np.ndarray,
        elements_t3: np.ndarray,
        boundary_edges_t3: np.ndarray,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        n_corner = len(nodes_t3)
        n_elem = len(elements_t3)
        raw_edges = np.stack(
            [elements_t3[:, [0, 1]], elements_t3[:, [1, 2]], elements_t3[:, [2, 0]]],
            axis=1,
        ).reshape(-1, 2)
        sorted_edges = np.sort(raw_edges, axis=1)
        unique_edges, inv = np.unique(sorted_edges, axis=0, return_inverse=True)
        mid_coords = 0.5 * (nodes_t3[unique_edges[:, 0]] + nodes_t3[unique_edges[:, 1]])
        nodes_t6 = np.vstack([nodes_t3, mid_coords])
        mid_indices = (inv + n_corner).reshape(n_elem, 3)
        elements_t6 = np.hstack([elements_t3, mid_indices])
        b_mid_nodes = np.full(len(boundary_edges_t3), -1, dtype=int)
        if len(boundary_edges_t3) > 0:
            b_sorted = np.sort(boundary_edges_t3, axis=1)
            max_id = n_corner + 1
            edge_keys = unique_edges[:, 0].astype(np.int64) * max_id + unique_edges[:, 1].astype(np.int64)
            b_keys = b_sorted[:, 0].astype(np.int64) * max_id + b_sorted[:, 1].astype(np.int64)
            pos = np.searchsorted(edge_keys, b_keys)
            pos = np.clip(pos, 0, len(edge_keys) - 1)
            matched = edge_keys[pos] == b_keys
            b_mid_nodes[matched] = pos[matched] + n_corner
            b_corner_nodes = np.unique(b_sorted.ravel())
            boundary_nodes_t6 = np.unique(np.concatenate([b_corner_nodes, b_mid_nodes[matched]]))
        else:
            boundary_nodes_t6 = np.empty(0, dtype=int)
        return nodes_t6, elements_t6, boundary_nodes_t6, b_mid_nodes

    @classmethod
    def build_t6_mesh_from_dxf(
        cls,
        dxf_source="./try_mesh.dxf",
        hp: "MeshHyperParams | None" = None,
        edge_size: float | None = None,
        auto_density: bool | None = None,
        min_edge_size: float | None = None,
        gradation: float | None = None,
        curve_tol: float | None = None,
        smooth_iter: int | None = None,
    ) -> dict:
        if hp is None:
            hp = MeshHyperParams()
        if edge_size is not None:
            hp.h_max = float(edge_size)
        if min_edge_size is not None:
            hp.h_min = float(min_edge_size)
        if gradation is not None:
            hp.gradation = float(gradation)
        if curve_tol is not None:
            hp.curve_tol = float(curve_tol)
        if smooth_iter is not None:
            hp.smooth_iter = int(smooth_iter)
        if auto_density is not None:
            hp.auto_density = bool(auto_density)
        t0 = time.perf_counter()
        loops = cls.read_dxf_loops(dxf_source, hp=hp)
        outer_loop = loops["outer_loop"]
        hole_loops = loops["hole_loops"]
        outer_layers = loops.get("outer_layers") or ["0"] * len(outer_loop)
        hole_layers = loops.get("hole_layers") or [["0"] * len(h) for h in hole_loops]
        h_max = float(hp.h_max)
        h_min = float(hp.h_min)
        if hp.auto_density:
            feat_tree, feat_h = cls._build_sizing_probe_data(
                outer_loop, hole_loops, h_max, h_min, gradation=hp.gradation,
                probe_centers=[p["center"] for p in (loops.get("probe_circles") or [])],
            )
        else:
            feat_tree, feat_h = None, None
        boundary_groups = []
        boundary_edges_list = []
        boundary_layers_list = []
        offset = 0
        for loop, layers in [(outer_loop, outer_layers)] + list(zip(hole_loops, hole_layers)):
            b_pts, b_lays = cls._resample_loop_adaptive(
                loop, feat_tree, feat_h, h_max, h_min, hp.gradation, edge_layers=layers
            )
            m = len(b_pts)
            if m < 3:
                continue
            b_lays = list(b_lays)
            while len(b_lays) < m:
                b_lays.append(b_lays[-1] if b_lays else "0")
            b_lays = b_lays[:m]
            idx_u = offset + np.arange(m, dtype=int)
            idx_v = offset + ((np.arange(m, dtype=int) + 1) % m)
            boundary_edges_list.append(np.column_stack([idx_u, idx_v]))
            boundary_layers_list.append(b_lays)
            boundary_groups.append(b_pts)
            offset += m
        boundary_nodes_t3 = np.vstack(boundary_groups)
        boundary_edges_t3 = np.vstack(boundary_edges_list)
        boundary_edge_layers = np.array([lay for lays in boundary_layers_list for lay in lays], dtype=object)
        n_boundary_t3 = len(boundary_nodes_t3)
        outer_path = Path(np.vstack([outer_loop, outer_loop[0]]), closed=True)
        hole_paths = [Path(np.vstack([h, h[0]]), closed=True) for h in hole_loops]
        interior_pts = cls._generate_interior_points(
            outer_loop,
            outer_path,
            hole_paths,
            boundary_nodes_t3,
            feat_tree,
            feat_h,
            h_max,
            h_min,
            hp.gradation,
        )
        if len(interior_pts) > 0:
            nodes_t3 = np.vstack([boundary_nodes_t3, interior_pts])
        else:
            nodes_t3 = boundary_nodes_t3.copy()
        tri = Delaunay(nodes_t3)
        elements_t3 = tri.simplices.copy()
        xmin, ymin = outer_loop.min(axis=0)
        xmax, ymax = outer_loop.max(axis=0)
        bbox = (xmin, ymin, xmax, ymax)
        p0 = nodes_t3[elements_t3[:, 0]]
        p1 = nodes_t3[elements_t3[:, 1]]
        p2 = nodes_t3[elements_t3[:, 2]]
        centroids = (p0 + p1 + p2) / 3.0
        shrink = 0.02
        m01 = (1.0 - shrink) * (0.5 * (p0 + p1)) + shrink * centroids
        m12 = (1.0 - shrink) * (0.5 * (p1 + p2)) + shrink * centroids
        m20 = (1.0 - shrink) * (0.5 * (p2 + p0)) + shrink * centroids
        keep = (
            cls._points_in_domain(centroids, outer_path, hole_paths, bbox)
            & cls._points_in_domain(m01, outer_path, hole_paths, bbox)
            & cls._points_in_domain(m12, outer_path, hole_paths, bbox)
            & cls._points_in_domain(m20, outer_path, hole_paths, bbox)
        )
        elements_t3 = elements_t3[keep]
        if len(elements_t3) == 0:
            raise ValueError("網格三角化後無有效元素（域內過濾全部被剔除）")
        p0 = nodes_t3[elements_t3[:, 0]]
        p1 = nodes_t3[elements_t3[:, 1]]
        p2 = nodes_t3[elements_t3[:, 2]]
        cross_z = (p1[:, 0] - p0[:, 0]) * (p2[:, 1] - p0[:, 1]) - (p1[:, 1] - p0[:, 1]) * (p2[:, 0] - p0[:, 0])
        cw_mask = cross_z < 0
        elements_t3[cw_mask, 1], elements_t3[cw_mask, 2] = (
            elements_t3[cw_mask, 2].copy(),
            elements_t3[cw_mask, 1].copy(),
        )
        nodes_t3 = cls._laplacian_smooth_vectorized(nodes_t3, elements_t3, n_boundary_t3, iterations=hp.smooth_iter)
        p0 = nodes_t3[elements_t3[:, 0]]
        p1 = nodes_t3[elements_t3[:, 1]]
        p2 = nodes_t3[elements_t3[:, 2]]
        areas = 0.5 * np.abs((p1[:, 0] - p0[:, 0]) * (p2[:, 1] - p0[:, 1]) - (p1[:, 1] - p0[:, 1]) * (p2[:, 0] - p0[:, 0]))
        nodes_t6, elements_t6, boundary_nodes_t6, b_mid_nodes = cls._upgrade_t3_to_t6_vectorized(
            nodes_t3, elements_t3, boundary_edges_t3
        )
        bc_groups = {}
        if len(b_mid_nodes) == len(boundary_edges_t3) and len(boundary_edge_layers) == len(boundary_edges_t3):
            valid = b_mid_nodes >= 0
            for lay in np.unique(boundary_edge_layers):
                mask = valid & (boundary_edge_layers == lay)
                if not np.any(mask):
                    continue
                e_t6 = np.column_stack([
                    boundary_edges_t3[mask, 0],
                    boundary_edges_t3[mask, 1],
                    b_mid_nodes[mask],
                ]).astype(int)
                bc_groups[str(lay)] = {
                    "node_ids": np.unique(e_t6.ravel()),
                    "edges_t6": e_t6,
                }
        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        probes = {}
        probe_list = loops.get("probe_circles") or []
        if probe_list:
            centers = np.array([p["center"] for p in probe_list], dtype=float)
            node_tree = cKDTree(nodes_t6)
            dists, nids = node_tree.query(centers)
            elem_tree = cKDTree(nodes_t6[elements_t6[:, :3]].mean(axis=1))
            _, eids = elem_tree.query(centers)
            for k, p in enumerate(probe_list):
                nid = int(np.atleast_1d(nids)[k])
                probes[p["probe_id"]] = {
                    "probe_id": p["probe_id"],
                    "layer": p["layer"],
                    "center_xy": (float(p["center"][0]), float(p["center"][1])),
                    "radius": float(p["radius"]),
                    "node_id": nid,
                    "node_xy": (float(nodes_t6[nid, 0]), float(nodes_t6[nid, 1])),
                    "elem_id": int(np.atleast_1d(eids)[k]),
                    "snap_dist": float(np.atleast_1d(dists)[k]),
                }
        return {
            "element_type": "T6",
            "nodes": nodes_t6,
            "elements": elements_t6,
            "elements_corner": elements_t6[:, :3],
            "n_corner_nodes": len(nodes_t3),
            "boundary_nodes": boundary_nodes_t6,
            "boundary_edges_t3": boundary_edges_t3,
            "boundary_edge_layers": boundary_edge_layers,
            "bc_groups": bc_groups,
            "probes": probes,
            "areas": areas,
            "outer_loop": outer_loop,
            "outer_layers": outer_layers,
            "hole_loops": hole_loops,
            "hole_layers": hole_layers,
            "raw_entities": loops["raw_entities"],
            "h_max": h_max,
            "h_min": h_min,
            "gradation": hp.gradation,
            "probe_circles": loops.get("probe_circles") or [],
            "source": loops.get("source", ""),
            "elapsed_ms": elapsed_ms,
        }

    @staticmethod
    def plot_t6_mesh_on_ax(mesh: dict, ax, show_mid_nodes: bool = True, color_by_density: bool = True):
        if ax is None:
            return None
        ax.clear()
        ax.set_facecolor("#0a0a0a")
        if ax.figure is not None:
            ax.figure.patch.set_facecolor("#0a0a0a")
        nodes = mesh["nodes"]
        elements = mesh["elements"]
        n_corner = mesh["n_corner_nodes"]
        areas = mesh.get("areas")
        char_len = np.sqrt(2.0 * np.asarray(areas, dtype=float)) if areas is not None and len(areas) else np.array([0.0])
        # T6 純線框：每元素 6 段 (角點-中點-角點)，依節點編號去重後繪製
        half_edges = np.vstack([
            elements[:, [0, 3]],
            elements[:, [3, 1]],
            elements[:, [1, 4]],
            elements[:, [4, 2]],
            elements[:, [2, 5]],
            elements[:, [5, 0]],
        ])
        uniq_edges = np.unique(np.sort(half_edges, axis=1), axis=0)
        wire_segs = np.stack([nodes[uniq_edges[:, 0]], nodes[uniq_edges[:, 1]]], axis=1)
        ax.add_collection(LineCollection(wire_segs, colors="#8fb8c9", linewidths=0.45, alpha=0.9, zorder=2))
        for loop in [mesh.get("outer_loop")] + list(mesh.get("hole_loops") or []):
            if loop is None or len(loop) < 2:
                continue
            closed = np.vstack([loop, loop[0]])
            ax.plot(closed[:, 0], closed[:, 1], color="#dddddd", lw=1.2, zorder=5)
        for lay, ginfo in (mesh.get("bc_groups") or {}).items():
            edges = ginfo.get("edges_t6")
            if edges is None or len(edges) == 0:
                continue
            lay_up = str(lay).upper()
            if lay_up == "FIXED":
                color, label = "#00bfff", "FIXED"
            elif lay_up.startswith("DISP_"):
                color, label = "#ff3355", f"DISP {lay}"
            elif lay_up.startswith("FORCE_"):
                color, label = "#ffaa00", f"FORCE {lay}"
            elif lay_up == "PROBE" or lay_up.startswith("PROBE_"):
                color, label = "#00ff88", f"PROBE {lay}"
            else:
                color, label = "#9aa0a6", str(lay)
            bc_segs = np.vstack([
                np.stack([nodes[edges[:, 0]], nodes[edges[:, 2]]], axis=1),
                np.stack([nodes[edges[:, 2]], nodes[edges[:, 1]]], axis=1),
            ])
            ax.add_collection(LineCollection(bc_segs, colors=color, linewidths=2.4, zorder=8, label=label))
        for pid, pinfo in (mesh.get("probes") or {}).items():
            cx, cy = pinfo.get("center_xy", (0.0, 0.0))
            r = float(pinfo.get("radius", 0.0))
            if r > 0:
                th = np.linspace(0.0, 2.0 * np.pi, 49)
                ax.plot(cx + r * np.cos(th), cy + r * np.sin(th), color="#00ff88", lw=1.6, ls="--", zorder=16)
            ax.plot([cx], [cy], marker="+", markersize=11, color="#00ff88", mew=2.0, zorder=16)
            nx, ny = pinfo.get("node_xy", (cx, cy))
            ax.plot([cx, nx], [cy, ny], color="#00ff88", lw=0.8, ls=":", zorder=15)
            ax.annotate(
                f"{pid} -> Node #{pinfo.get('node_id', -1)}",
                xy=(cx, cy), xytext=(cx + 1.5, cy + 1.5),
                color="#00ff88", fontsize=7.5, zorder=17,
            )
        bc_counts = ", ".join(
            f"{k}:{len(v.get('node_ids', []))}" for k, v in (mesh.get("bc_groups") or {}).items()
        )
        hud_lines = [
            f"T6 MESH | Nodes {len(nodes)} (corner {n_corner} + mid {len(nodes) - n_corner})",
            f"Elements {len(elements)} | Size {float(char_len.min()):.2f} ~ {float(char_len.max()):.2f} mm "
            f"| {float(mesh.get('elapsed_ms', 0.0)):.0f} ms",
        ]
        if bc_counts:
            hud_lines.append(f"BC Nodes: {bc_counts}")
        ax.text(
            0.012, 0.985, "\n".join(hud_lines), transform=ax.transAxes,
            color="#00ff88", fontsize=8.5, va="top", ha="left", zorder=20,
            bbox=dict(boxstyle="round,pad=0.35", facecolor="#161616", edgecolor="#444444", alpha=0.92),
        )
        outer = mesh.get("outer_loop")
        if outer is not None and len(outer) > 0:
            xmin, ymin = np.min(outer, axis=0)
            xmax, ymax = np.max(outer, axis=0)
            dx = max(xmax - xmin, 1.0) * 0.06
            dy = max(ymax - ymin, 1.0) * 0.06
            ax.set_xlim(xmin - dx, xmax + dx)
            ax.set_ylim(ymin - dy, ymax + dy)
        ax.set_aspect("equal", adjustable="datalim")
        ax.tick_params(colors="#888888", labelsize=7)
        handles, labels = ax.get_legend_handles_labels()
        if handles:
            ax.legend(
                loc="lower right", facecolor="#181818", edgecolor="#444444",
                labelcolor="#dddddd", fontsize=7,
            )
        return ax
