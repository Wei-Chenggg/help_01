import math
import re
import numpy as np
import ezdxf

DEFAULT_BRUSH_STYLES = [
    {"name": "0",              "colors": "#ffffff", "linewidths": 1.3, "linestyles": "solid", "zorder": 4, "dxf_color": 7},
    {"name": "FIXED",          "colors": "#00bfff", "linewidths": 2.2, "linestyles": "solid", "zorder": 5, "dxf_color": 5},
    {"name": "PROBE",          "colors": "#00ff88", "linewidths": 2.2, "linestyles": "solid", "zorder": 5, "dxf_color": 3},
    {"name": "DISP_X-100Y10",  "colors": "#ff3355", "linewidths": 2.2, "linestyles": "solid", "zorder": 6, "dxf_color": 1},
    {"name": "FORCE_X-100Y10", "colors": "#ffaa00", "linewidths": 2.2, "linestyles": "solid", "zorder": 6, "dxf_color": 2},
]

BC_COLOR_DISP = "#ff3355"
BC_COLOR_FORCE = "#ffaa00"
BC_COLOR_PROBE = "#00ff88"
BC_COLOR_FIXED = "#00bfff"
BC_COLOR_DEFAULT = "#cccccc"


class DXFEditingHelper:
    PROBE_RE = re.compile(r"^PROBE(?:#|_)?(\d+)?$")
    VECTOR_RE = re.compile(r"^(DISP|FORCE)(?:#(\d+))?_X([+-]?\d+(?:\.\d+)?)Y([+-]?\d+(?:\.\d+)?)$")

    # ---------------------------------------------------------------- BC 圖層
    @staticmethod
    def format_bc_layer_name(bc_type: str, x: float = 0.0, y: float = 0.0, seq: int = None) -> str:
        btype = str(bc_type).strip().upper()
        if btype == "FIXED":
            return "FIXED"
        if btype == "PROBE":
            return f"PROBE#{int(seq):03d}" if seq is not None else "PROBE"
        if btype not in ("DISP", "FORCE"):
            raise ValueError(f"bc_type 必須為 'FIXED', 'PROBE', 'DISP' 或 'FORCE'，收到: {bc_type}")
        x_s = f"{int(x)}" if float(x).is_integer() else f"{float(x):g}"
        y_s = f"{int(y)}" if float(y).is_integer() else f"{float(y):g}"
        prefix = f"{btype}#{int(seq):03d}" if seq is not None else btype
        return f"{prefix}_X{x_s}Y{y_s}"

    @staticmethod
    def parse_bc_layer_name(layer_name: str) -> dict:
        lname = str(layer_name).strip()
        u_name = lname.upper()
        if lname == "0":
            return {"type": "FREE", "x": 0.0, "y": 0.0, "unit": None}
        if u_name == "FIXED":
            return {"type": "FIXED", "x": 0.0, "y": 0.0, "unit": "mm"}
        m_probe = DXFEditingHelper.PROBE_RE.match(u_name)
        if m_probe:
            idx = int(m_probe.group(1)) if m_probe.group(1) else 1
            return {
                "type": "PROBE",
                "probe_id": f"PROBE#{idx:03d}",
                "x": 0.0,
                "y": 0.0,
                "unit": "mm",
                "raw": lname,
            }
        m = DXFEditingHelper.VECTOR_RE.match(u_name)
        if m:
            btype, seq_str, xs, ys = m.groups()
            seq = int(seq_str) if seq_str else None
            return {
                "type": btype,
                "seq": seq,
                "bc_id": f"{btype}#{seq:03d}" if seq is not None else btype,
                "x": float(xs),
                "y": float(ys),
                "unit": "mm" if btype == "DISP" else "gf",
            }
        return {"type": "CUSTOM", "x": 0.0, "y": 0.0, "unit": None, "raw": lname}

    @staticmethod
    def layer_priority(layer_name: str) -> int:
        info = DXFEditingHelper.parse_bc_layer_name(layer_name)
        btype = info.get("type")
        if btype == "FREE":
            return 0
        if btype == "FIXED":
            return 10
        if btype == "PROBE":
            return 15
        if btype in ("DISP", "FORCE"):
            return 20
        return 1

    @staticmethod
    def get_layer_style(layer_name: str) -> dict:
        u_name = str(layer_name).upper()
        style = DXFEditingHelper.parse_bc_layer_name(layer_name)
        btype = style.get("type")
        if btype in ("DISP", "FORCE"):
            return {
                "colors": BC_COLOR_DISP if btype == "DISP" else BC_COLOR_FORCE,
                "linewidths": 2.2,
                "linestyles": "solid",
                "zorder": 6,
                "dxf_color": 1 if btype == "DISP" else 2,
            }
        if btype == "PROBE":
            return {"colors": BC_COLOR_PROBE, "linewidths": 2.2, "linestyles": "solid", "zorder": 5, "dxf_color": 3}
        if btype == "FIXED":
            return {"colors": BC_COLOR_FIXED, "linewidths": 2.2, "linestyles": "solid", "zorder": 5, "dxf_color": 5}
        if u_name == "0":
            return {"colors": "#ffffff", "linewidths": 1.3, "linestyles": "solid", "zorder": 4, "dxf_color": 7}
        return {"colors": BC_COLOR_DEFAULT, "linewidths": 1.2, "linestyles": "solid", "zorder": 3, "dxf_color": 7}

    @staticmethod
    def get_layer_color(layer_name: str) -> str:
        return DXFEditingHelper.get_layer_style(layer_name)["colors"]

    @staticmethod
    def get_bc_summary(msp) -> dict:
        summary = {}
        for ent in msp:
            lay = ent.dxf.layer if ent.dxf.hasattr("layer") else "0"
            if lay not in summary:
                info = DXFEditingHelper.parse_bc_layer_name(lay)
                info["count"] = 0
                info["handles"] = []
                summary[lay] = info
            summary[lay]["count"] += 1
            summary[lay]["handles"].append(ent.dxf.handle)
        return summary

    # ---------------------------------------------------------------- DXF IO
    @staticmethod
    def load_doc(filepath: str):
        return ezdxf.readfile(filepath)

    @staticmethod
    def explode_all_lwpolylines(msp) -> int:
        count = 0
        for pl in [e for e in msp if e.dxftype() == "LWPOLYLINE"]:
            try:
                pl.explode(msp)
                count += 1
            except Exception:
                pass
        return count

    @staticmethod
    def ensure_layer(doc, layer: str, color: int = 7) -> str:
        if doc is not None and layer not in doc.layers:
            doc.layers.add(name=layer, color=color)
        return layer

    @staticmethod
    def next_probe_layer_name(doc) -> str:
        if doc is None:
            return "PROBE#001"
        max_id = 0
        for lay in doc.layers:
            m = re.match(r"^PROBE#(\d+)$", str(lay.dxf.name).upper())
            if m:
                max_id = max(max_id, int(m.group(1)))
        for ent in doc.modelspace():
            m = re.match(r"^PROBE#(\d+)$", str(ent.dxf.layer).upper())
            if m:
                max_id = max(max_id, int(m.group(1)))
        return f"PROBE#{max_id + 1:03d}"

    # ---------------------------------------------------------------- 幾何
    @staticmethod
    def entity_to_segments(ent):
        etype = ent.dxftype()
        if etype == "INSERT":
            segs = []
            try:
                for sub in ent.virtual_entities():
                    segs.extend(DXFEditingHelper.entity_to_segments(sub))
            except Exception:
                pass
            return segs
        if etype == "LINE":
            p1 = (float(ent.dxf.start.x), float(ent.dxf.start.y))
            p2 = (float(ent.dxf.end.x), float(ent.dxf.end.y))
            return [(p1, p2)]
        if etype == "CIRCLE":
            cx, cy = float(ent.dxf.center.x), float(ent.dxf.center.y)
            r = float(ent.dxf.radius)
            angles = np.linspace(0.0, 2.0 * math.pi, 49)
            pts = np.column_stack([cx + r * np.cos(angles), cy + r * np.sin(angles)])
            return list(zip(pts[:-1].tolist(), pts[1:].tolist()))
        if etype == "ARC":
            cx, cy = float(ent.dxf.center.x), float(ent.dxf.center.y)
            r = float(ent.dxf.radius)
            a1 = float(ent.dxf.start_angle)
            a2 = float(ent.dxf.end_angle)
            span = (a2 - a1) % 360.0
            if span <= 1e-6:
                span = 360.0
            steps = max(int(span / 7.5), 6)
            angles = np.radians(a1 + np.linspace(0.0, span, steps + 1))
            pts = np.column_stack([cx + r * np.cos(angles), cy + r * np.sin(angles)])
            return list(zip(pts[:-1].tolist(), pts[1:].tolist()))
        if etype == "LWPOLYLINE":
            segs = []
            try:
                for sub in ent.virtual_entities():
                    segs.extend(DXFEditingHelper.entity_to_segments(sub))
                if segs:
                    return segs
            except Exception:
                pass
            pts = [(float(p[0]), float(p[1])) for p in ent.get_points("xy")]
            if ent.closed and len(pts) > 1:
                pts.append(pts[0])
            return list(zip(pts[:-1], pts[1:]))
        try:
            from ezdxf.path import make_path
            path = make_path(ent)
            pts = [(float(p.x), float(p.y)) for p in path.flattening(0.5)]
            return list(zip(pts[:-1], pts[1:]))
        except Exception:
            return []

    @staticmethod
    def entity_keypoints(ent):
        etype = ent.dxftype()
        kpts = []
        if etype == "LINE":
            x1, y1 = float(ent.dxf.start.x), float(ent.dxf.start.y)
            x2, y2 = float(ent.dxf.end.x), float(ent.dxf.end.y)
            mx, my = (x1 + x2) * 0.5, (y1 + y2) * 0.5
            kpts.append(((x1, y1), "END"))
            kpts.append(((x2, y2), "END"))
            kpts.append(((mx, my), "MID"))
        elif etype == "ARC":
            cx, cy = float(ent.dxf.center.x), float(ent.dxf.center.y)
            r = float(ent.dxf.radius)
            a1 = math.radians(float(ent.dxf.start_angle))
            a2 = math.radians(float(ent.dxf.end_angle))
            p1 = (cx + r * math.cos(a1), cy + r * math.sin(a1))
            p2 = (cx + r * math.cos(a2), cy + r * math.sin(a2))
            kpts.append(((cx, cy), "CEN"))
            kpts.append((p1, "END"))
            kpts.append((p2, "END"))
        elif etype == "CIRCLE":
            cx, cy = float(ent.dxf.center.x), float(ent.dxf.center.y)
            r = float(ent.dxf.radius)
            kpts.append(((cx, cy), "CEN"))
            for dx, dy in ((r, 0.0), (-r, 0.0), (0.0, r), (0.0, -r)):
                kpts.append(((cx + dx, cy + dy), "END"))
        elif etype == "LWPOLYLINE":
            try:
                for sub in ent.virtual_entities():
                    kpts.extend(DXFEditingHelper.entity_keypoints(sub))
            except Exception:
                pass
        return kpts

    @staticmethod
    def circle_from_2_points(p1, p2):
        cx, cy = float(p1[0]), float(p1[1])
        r = math.hypot(p2[0] - cx, p2[1] - cy)
        return (cx, cy), r

    @staticmethod
    def circle_from_3_points(p1, p2, p3):
        ax, ay = p1
        bx, by = p2
        cx, cy = p3
        d = 2.0 * (ax * (by - cy) + bx * (cy - ay) + cx * (ay - by))
        if abs(d) < 1e-9:
            return None, None
        a2 = ax * ax + ay * ay
        b2 = bx * bx + by * by
        c2 = cx * cx + cy * cy
        ux = (a2 * (by - cy) + b2 * (cy - ay) + c2 * (ay - by)) / d
        uy = (a2 * (cx - bx) + b2 * (ax - cx) + c2 * (bx - ax)) / d
        return (ux, uy), math.hypot(ax - ux, ay - uy)

    @classmethod
    def arc_from_3_points(cls, p1, p2, p3):
        cen, r = cls.circle_from_3_points(p1, p2, p3)
        if cen is None or r < 1e-6:
            return None, None, None, None
        cx, cy = cen
        a1 = math.degrees(math.atan2(p1[1] - cy, p1[0] - cx)) % 360.0
        a2 = math.degrees(math.atan2(p2[1] - cy, p2[0] - cx)) % 360.0
        a3 = math.degrees(math.atan2(p3[1] - cy, p3[0] - cx)) % 360.0
        ccw_12 = (a2 - a1) % 360.0
        ccw_13 = (a3 - a1) % 360.0
        if ccw_12 <= ccw_13:
            return cen, r, a1, a3
        return cen, r, a3, a1

    # ---------------------------------------------------------------- 鎖點
    @staticmethod
    def build_segment_arrays(segments_by_handle: dict):
        all_p1, all_p2, seg_handles = [], [], []
        for handle, segs in segments_by_handle.items():
            for p1, p2 in segs:
                all_p1.append(p1)
                all_p2.append(p2)
                seg_handles.append(handle)
        p1_arr = np.array(all_p1, dtype=float) if all_p1 else np.empty((0, 2))
        p2_arr = np.array(all_p2, dtype=float) if all_p2 else np.empty((0, 2))
        v_arr = p2_arr - p1_arr
        c2_arr = np.sum(v_arr * v_arr, axis=1) if len(p1_arr) else np.empty(0)
        return p1_arr, p2_arr, v_arr, c2_arr, seg_handles

    @staticmethod
    def point_to_segments_dist(px: float, py: float, segs):
        arr = np.asarray(segs, dtype=float)
        if arr.size == 0:
            return float("inf"), -1
        p1 = arr[:, 0, :]
        v = arr[:, 1, :] - p1
        c2 = np.sum(v * v, axis=1)
        w = np.array([px, py], dtype=float) - p1
        c1 = np.sum(w * v, axis=1)
        t = np.where(c2 > 1e-12, np.clip(c1 / c2, 0.0, 1.0), 0.0)
        proj = p1 + t[:, None] * v
        dists = np.hypot(proj[:, 0] - px, proj[:, 1] - py)
        idx = int(np.argmin(dists))
        return float(dists[idx]), idx

    @staticmethod
    def compute_hover_and_snap(
        px,
        py,
        p1_arr,
        p2_arr,
        v_arr,
        c2_arr,
        seg_handles,
        snap_pts_arr,
        snap_types,
        pick_tol,
        snap_tol,
    ):
        hover_handle = None
        if len(p1_arr) > 0:
            w = np.array([px, py], dtype=float) - p1_arr
            c1 = np.sum(w * v_arr, axis=1)
            t = np.where(c2_arr > 1e-12, np.clip(c1 / c2_arr, 0.0, 1.0), 0.0)
            proj = p1_arr + t[:, None] * v_arr
            dists = np.hypot(proj[:, 0] - px, proj[:, 1] - py)
            min_idx = int(np.argmin(dists))
            if float(dists[min_idx]) < pick_tol:
                hover_handle = seg_handles[min_idx]
        snap_pt = None
        snap_type = None
        if len(snap_pts_arr) > 0:
            sdists = np.hypot(snap_pts_arr[:, 0] - px, snap_pts_arr[:, 1] - py)
            s_idx = int(np.argmin(sdists))
            if float(sdists[s_idx]) < snap_tol:
                snap_pt = (float(snap_pts_arr[s_idx, 0]), float(snap_pts_arr[s_idx, 1]))
                snap_type = snap_types[s_idx]
        eff_pt = snap_pt if snap_pt is not None else (float(px), float(py))
        return hover_handle, snap_pt, snap_type, eff_pt

    # ---------------------------------------------------------------- msp 操作
    @staticmethod
    def add_line(msp, p1, p2, layer):
        if math.hypot(p2[0] - p1[0], p2[1] - p1[1]) < 1e-6:
            return None
        return msp.add_line(p1, p2, dxfattribs={"layer": layer})

    @staticmethod
    def add_circle_2p(msp, p1, p2, layer):
        cen, r = DXFEditingHelper.circle_from_2_points(p1, p2)
        if r < 1e-6:
            return None
        return msp.add_circle(center=cen, radius=r, dxfattribs={"layer": layer})

    @staticmethod
    def add_circle_3p(msp, p1, p2, p3, layer):
        cen, r = DXFEditingHelper.circle_from_3_points(p1, p2, p3)
        if cen is None or r < 1e-6:
            return None
        return msp.add_circle(center=cen, radius=r, dxfattribs={"layer": layer})

    @staticmethod
    def add_arc_3p(msp, p1, p2, p3, layer):
        cen, r, a_start, a_end = DXFEditingHelper.arc_from_3_points(p1, p2, p3)
        if cen is None:
            return None
        return msp.add_arc(
            center=cen, radius=r, start_angle=a_start, end_angle=a_end,
            dxfattribs={"layer": layer},
        )

    @staticmethod
    def find_entity(doc, handle):
        if doc is None or not handle:
            return None
        try:
            return doc.entitydb.get(handle)
        except Exception:
            return None

    @classmethod
    def delete_entity(cls, doc, handle) -> bool:
        ent = cls.find_entity(doc, handle)
        if ent is None:
            return False
        doc.modelspace().delete_entity(ent)
        return True

    @classmethod
    def paint_entity_layer(cls, doc, handle, new_layer) -> bool:
        ent = cls.find_entity(doc, handle)
        if ent is None:
            return False
        ent.dxf.layer = new_layer
        return True
