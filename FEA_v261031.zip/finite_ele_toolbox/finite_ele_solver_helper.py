import math
import re
import time
from dataclasses import dataclass
import numpy as np
from scipy.sparse import csc_matrix
from scipy.sparse.linalg import spsolve
import matplotlib
from matplotlib.collections import PolyCollection

try:
    from .dxf_editting_helper import DXFEditingHelper
except ImportError:
    from dxf_editting_helper import DXFEditingHelper

MATERIALS = {
    "Al-7075-T6": {"E_mpa": 71700.0, "nu": 0.33, "yield_mpa": 503.0},
    "Ti-6Al-4V": {"E_mpa": 113800.0, "nu": 0.342, "yield_mpa": 880.0},
    "SUS304": {"E_mpa": 193000.0, "nu": 0.29, "yield_mpa": 215.0},
    "ABS": {"E_mpa": 2300.0, "nu": 0.35, "yield_mpa": 40.0},
}

GF_TO_N = 0.00980665

VIEW_MODES = [
    "Von Mises 應力",
    "總位移 |dxy|",
    "位移角 disp_theta",
    "X位移 dx",
    "Y位移 dy",
]

VIEW_FIELD = {
    "Von Mises 應力": ("von_mises", "Von Mises (MPa)", "turbo"),
    "總位移 |dxy|": ("u_mag", "|dxy| (mm)", "viridis"),
    "位移角 disp_theta": ("disp_theta_deg", "disp_theta (deg)", "hsv"),
    "X位移 dx": ("u_x", "dx (mm)", "coolwarm"),
    "Y位移 dy": ("u_y", "dy (mm)", "coolwarm"),
}


@dataclass
class SolverHyperParams:
    material: str = "Al-7075-T6"
    E_mpa: float = 71700.0
    nu: float = 0.33
    yield_mpa: float = 503.0
    thickness_mm: float = 10.0
    large_disp: bool = True
    n_steps: int = 5
    max_nr_iter: int = 20
    tol_rel: float = 1e-4
    deform_scale: float = 1.0
    min_det_f: float = 1e-3
    n_gauss: int = 3


class FiniteEleSolverHelper:
    _GP_L = (0.445948490915965, 0.091576213509771)
    _GP_W = (0.223381589678011, 0.109951743655322)
    _EYE2 = np.eye(2)

    @classmethod
    def _quadrature(cls, n_gauss: int = 3):
        """三角形積分點；3 點 (degree-2) 為預設，6 點可作對照。權重已換算到參考面積 0.5。"""
        if int(n_gauss) >= 6:
            a1, a2 = cls._GP_L
            w1, w2 = cls._GP_W
            b1 = 1.0 - 2.0 * a1
            b2 = 1.0 - 2.0 * a2
            pts = []
            for l2, l3 in ((a1, a1), (b1, a1), (a1, b1)):
                pts.append((l2, l3, 0.5 * w1))
            for l2, l3 in ((a2, a2), (b2, a2), (a2, b2)):
                pts.append((l2, l3, 0.5 * w2))
            return pts
        a = 1.0 / 6.0
        b = 2.0 / 3.0
        return [(a, a, 1.0 / 6.0), (b, a, 1.0 / 6.0), (a, b, 1.0 / 6.0)]

    @staticmethod
    def _shape(xi, eta):
        L1 = 1.0 - xi - eta
        L2 = xi
        L3 = eta
        N = np.array([
            L1 * (2.0 * L1 - 1.0),
            L2 * (2.0 * L2 - 1.0),
            L3 * (2.0 * L3 - 1.0),
            4.0 * L1 * L2,
            4.0 * L2 * L3,
            4.0 * L3 * L1,
        ])
        dL = np.array([[-1.0, -1.0], [1.0, 0.0], [0.0, 1.0]])
        dN = np.empty((6, 2))
        dN[0] = (4.0 * L1 - 1.0) * dL[0]
        dN[1] = (4.0 * L2 - 1.0) * dL[1]
        dN[2] = (4.0 * L3 - 1.0) * dL[2]
        dN[3] = 4.0 * (L2 * dL[0] + L1 * dL[1])
        dN[4] = 4.0 * (L3 * dL[1] + L2 * dL[2])
        dN[5] = 4.0 * (L1 * dL[2] + L3 * dL[0])
        return N, dN

    @staticmethod
    def _parse_layer(layer_name: str) -> dict:
        return dict(DXFEditingHelper.parse_bc_layer_name(layer_name))

    @staticmethod
    def _plane_stress_matrix(E: float, nu: float) -> np.ndarray:
        c = E / (1.0 - nu * nu)
        return np.array([
            [c, c * nu, 0.0],
            [c * nu, c, 0.0],
            [0.0, 0.0, c * (1.0 - nu) / 2.0],
        ])

    @classmethod
    def _precompute_reference(cls, nodes, elements, thickness, n_gauss: int = 3):
        """回傳 dNdX: (Nel, Ngp, 6, 2) 與 dV0: (Nel, Ngp)。"""
        gps = cls._quadrature(n_gauss)
        Xe = nodes[elements]
        dNdX_list = []
        dV0_list = []
        for xi, eta, w in gps:
            _N, dN = cls._shape(xi, eta)
            J0 = np.einsum('eai,aj->eij', Xe, dN)
            detJ = J0[:, 0, 0] * J0[:, 1, 1] - J0[:, 0, 1] * J0[:, 1, 0]
            detJ = np.where(np.abs(detJ) < 1e-14, 1e-14, detJ)
            invJ = np.empty_like(J0)
            invJ[:, 0, 0] = J0[:, 1, 1] / detJ
            invJ[:, 0, 1] = -J0[:, 0, 1] / detJ
            invJ[:, 1, 0] = -J0[:, 1, 0] / detJ
            invJ[:, 1, 1] = J0[:, 0, 0] / detJ
            dNdX_list.append(np.einsum('ai,eij->eaj', dN, invJ))
            dV0_list.append(np.abs(detJ) * w * thickness)
        return np.stack(dNdX_list, axis=1), np.stack(dV0_list, axis=1)

    @classmethod
    def _kinematics(cls, u_e, dNdX, D):
        grad_u = np.einsum('eai,egaj->egij', u_e, dNdX)
        F = cls._EYE2 + grad_u
        detF = F[..., 0, 0] * F[..., 1, 1] - F[..., 0, 1] * F[..., 1, 0]
        FtF = np.einsum('egji,egjk->egik', F, F)
        E = np.stack([
            0.5 * (FtF[..., 0, 0] - 1.0),
            0.5 * (FtF[..., 1, 1] - 1.0),
            FtF[..., 0, 1],
        ], axis=2)
        S = np.einsum('egk,jk->egj', E, D)
        return F, detF, S

    @classmethod
    def _bmatrix(cls, F, dNdX):
        Nel = F.shape[0]
        ngp = F.shape[1]
        B = np.empty((Nel, ngp, 3, 12))
        for k in (0, 1):
            B[:, :, 0, k::2] = F[:, :, k, 0][:, :, None] * dNdX[:, :, :, 0]
            B[:, :, 1, k::2] = F[:, :, k, 1][:, :, None] * dNdX[:, :, :, 1]
            B[:, :, 2, k::2] = (
                F[:, :, k, 0][:, :, None] * dNdX[:, :, :, 1]
                + F[:, :, k, 1][:, :, None] * dNdX[:, :, :, 0]
            )
        return B

    @classmethod
    def _assemble_element(cls, u_flat, elements, dNdX, dV0, D):
        """全張量組裝：一次處理所有元素與所有積分點。"""
        u_e = u_flat.reshape(-1, 2)[elements]
        F, detF, S = cls._kinematics(u_e, dNdX, D)
        min_det = float(np.min(detF))
        B = cls._bmatrix(F, dNdX)
        f_int_e = np.einsum('eg,egja,egj->ea', dV0, B, S)
        K_e = np.einsum('eg,egja,jk,egkb->eab', dV0, B, D, B)
        S_mat = np.empty(F.shape)
        S_mat[..., 0, 0] = S[..., 0]
        S_mat[..., 1, 1] = S[..., 1]
        S_mat[..., 0, 1] = S[..., 2]
        S_mat[..., 1, 0] = S[..., 2]
        KG = np.einsum('eg,egai,egij,egbj->eab', dV0, dNdX, S_mat, dNdX)
        K_e[:, 0::2, 0::2] += KG
        K_e[:, 1::2, 1::2] += KG
        return K_e, f_int_e, min_det

    @classmethod
    def _min_det_f(cls, u_flat, elements, dNdX):
        u_e = u_flat.reshape(-1, 2)[elements]
        grad_u = np.einsum('eai,egaj->egij', u_e, dNdX)
        F = cls._EYE2 + grad_u
        detF = F[..., 0, 0] * F[..., 1, 1] - F[..., 0, 1] * F[..., 1, 0]
        return float(np.min(detF))

    @classmethod
    def _nodal_fields(cls, u_flat, nodes, elements, dNdX, dV0, D):
        n_nodes = len(nodes)
        u_e = u_flat.reshape(-1, 2)[elements]
        F, detF, S = cls._kinematics(u_e, dNdX, D)
        detF = np.where(np.abs(detF) < 1e-12, 1e-12, detF)
        S_mat = np.empty(F.shape)
        S_mat[..., 0, 0] = S[..., 0]
        S_mat[..., 1, 1] = S[..., 1]
        S_mat[..., 0, 1] = S[..., 2]
        S_mat[..., 1, 0] = S[..., 2]
        FS = np.einsum('egij,egjk->egik', F, S_mat)
        sig = np.einsum('egij,egkj->egik', FS, F) / detF[..., None, None]
        sig_v = np.stack([sig[..., 0, 0], sig[..., 1, 1], sig[..., 0, 1]], axis=2)
        w = dV0 / 6.0
        acc_sig = np.zeros((n_nodes, 3))
        acc_F = np.zeros((n_nodes, 2, 2))
        acc_w = np.zeros(n_nodes)
        for a in range(6):
            ids = elements[:, a]
            np.add.at(acc_sig, ids, np.einsum('eg,egk->ek', w, sig_v))
            np.add.at(acc_F, ids, np.einsum('eg,egij->eij', w, F))
            np.add.at(acc_w, ids, w.sum(axis=1))
        acc_w = np.where(acc_w < 1e-30, 1e-30, acc_w)
        sig_node = acc_sig / acc_w[:, None]
        F_node = acc_F / acc_w[:, None, None]
        sxx, syy, sxy = sig_node[:, 0], sig_node[:, 1], sig_node[:, 2]
        von_mises = np.sqrt(np.maximum(sxx ** 2 - sxx * syy + syy ** 2 + 3.0 * sxy ** 2, 0.0))
        rot_deg = np.degrees(np.arctan2(F_node[:, 1, 0] - F_node[:, 0, 1], F_node[:, 0, 0] + F_node[:, 1, 1]))
        return von_mises, sig_node, rot_deg

    @staticmethod
    def _evaluate_probes(probes_dict, u, von_mises, sig, rot_deg):
        out = {}
        u2 = u.reshape(-1, 2)
        for pid, info in (probes_dict or {}).items():
            nid = int(info.get("node_id", -1))
            if nid < 0 or nid >= len(u2):
                continue
            dx = float(u2[nid, 0])
            dy = float(u2[nid, 1])
            out[pid] = {
                "probe_id": pid,
                "layer": info.get("layer"),
                "node_id": nid,
                "node_xy": info.get("node_xy"),
                "center_xy": info.get("center_xy"),
                "snap_dist": info.get("snap_dist"),
                "dx": dx,
                "dy": dy,
                "dxy": math.hypot(dx, dy),
                "disp_theta": math.degrees(math.atan2(dy, dx)),
                "stress": float(von_mises[nid]) if nid < len(von_mises) else 0.0,
                "sxx": float(sig[nid, 0]) if nid < len(sig) else 0.0,
                "syy": float(sig[nid, 1]) if nid < len(sig) else 0.0,
                "txy": float(sig[nid, 2]) if nid < len(sig) else 0.0,
                "rot_theta": float(rot_deg[nid]) if nid < len(rot_deg) else 0.0,
            }
        return out

    @classmethod
    def _build_bc(cls, mesh, nodes, hp):
        """BC 一律 1:1 真實物理量：DISP 的 x/y 直接是 mm，FORCE 的 x/y 直接是 gf（轉 N）。"""
        n_nodes = len(nodes)
        n_dof = 2 * n_nodes
        constrained = np.zeros(n_dof, dtype=bool)
        u_target = np.zeros(n_dof)
        f_ext = np.zeros(n_dof)
        layer_groups = {}
        for lay, info in (mesh.get("bc_groups") or {}).items():
            ids = np.asarray(info.get("node_ids", []), dtype=int)
            if len(ids) == 0:
                continue
            parsed = cls._parse_layer(lay)
            btype = parsed["type"]
            layer_groups[str(lay)] = (ids, parsed)
            if btype == "FIXED":
                constrained[2 * ids] = True
                constrained[2 * ids + 1] = True
            elif btype == "DISP":
                constrained[2 * ids] = True
                constrained[2 * ids + 1] = True
                u_target[2 * ids] = parsed["x"]
                u_target[2 * ids + 1] = parsed["y"]
            elif btype == "FORCE":
                edges = np.asarray(info.get("edges_t6", []), dtype=int)
                if edges.size == 0:
                    continue
                n0 = edges[:, 0]
                n1 = edges[:, 1]
                m01 = edges[:, 2]
                L = np.linalg.norm(nodes[n1] - nodes[n0], axis=1)
                L_total = max(float(L.sum()), 1e-12)
                force_n = np.array([parsed["x"], parsed["y"]], dtype=float) * GF_TO_N
                trac = force_n / L_total
                for nd, wt in ((n0, 1.0 / 6.0), (n1, 1.0 / 6.0), (m01, 4.0 / 6.0)):
                    np.add.at(f_ext, 2 * nd, wt * L * trac[0])
                    np.add.at(f_ext, 2 * nd + 1, wt * L * trac[1])
        return n_dof, constrained, u_target, f_ext, layer_groups

    @classmethod
    def solve(cls, mesh: dict, hp: SolverHyperParams = None) -> dict:
        if hp is None:
            hp = SolverHyperParams()
        t0 = time.perf_counter()
        nodes = np.asarray(mesh["nodes"], dtype=float)
        elements = np.asarray(mesh["elements"], dtype=int)
        n_dof, constrained, u_target, f_ext, groups = cls._build_bc(mesh, nodes, hp)
        free = np.where(~constrained)[0]
        E = float(hp.E_mpa)
        nu = float(hp.nu)
        if not (-0.95 < nu < 0.4999):
            nu = 0.3
        D = cls._plane_stress_matrix(E, nu)
        dof_map = (elements[:, :, None] * 2 + np.arange(2)[None, None, :]).reshape(len(elements), 12)
        dNdX, dV0 = cls._precompute_reference(nodes, elements, hp.thickness_mm, hp.n_gauss)
        n_free = len(free)
        free_idx_map = np.full(n_dof, -1, dtype=int)
        free_idx_map[free] = np.arange(n_free, dtype=int)
        rows_full = np.repeat(dof_map, 12, axis=1).ravel()
        cols_full = np.tile(dof_map, (1, 12)).ravel()
        r_free_idx = free_idx_map[rows_full]
        c_free_idx = free_idx_map[cols_full]
        mask_ff = (r_free_idx >= 0) & (c_free_idx >= 0)
        ff_rows = r_free_idx[mask_ff]
        ff_cols = c_free_idx[mask_ff]

        def _assemble_global(u_vec):
            K_e_l, f_int_e_l, min_det_l = cls._assemble_element(u_vec, elements, dNdX, dV0, D)
            f_int_l = np.zeros(n_dof)
            np.add.at(f_int_l, dof_map.ravel(), f_int_e_l.ravel())
            return K_e_l, f_int_l, min_det_l

        def _solve_free(K_e_l, resid_l):
            K_ff = csc_matrix(
                (K_e_l.ravel()[mask_ff], (ff_rows, ff_cols)),
                shape=(n_free, n_free),
            )
            return spsolve(K_ff, -resid_l[free])

        u = np.zeros(n_dof)
        lam = 0.0
        d_lam = 1.0 / max(1, int(hp.n_steps)) if hp.large_disp else 1.0
        d_lam_prev = 1.0
        du_prev = np.zeros(n_dof)
        step_history = []
        warning = None
        n_iter_total = 0
        if hp.large_disp and n_free > 0:
            u_pre = np.zeros(n_dof)
            u_pre[constrained] = u_target[constrained]
            K_e0, f_int0, _md0 = _assemble_global(u_pre)
            du_lin = _solve_free(K_e0, f_int0 - f_ext)
            du_prev = np.zeros(n_dof)
            du_prev[free] = du_lin
            du_prev[constrained] = u_target[constrained]
            d_lam_prev = 1.0
        while lam < 1.0 - 1e-12:
            lam_try = min(1.0, lam + d_lam)
            step_dl = lam_try - lam
            if d_lam_prev > 1e-12:
                u_try = u + (step_dl / d_lam_prev) * du_prev
            else:
                u_try = u.copy()
            u_try[constrained] = lam_try * u_target[constrained]
            converged = False
            it = 0
            for it in range(max(1, int(hp.max_nr_iter))):
                n_iter_total += 1
                K_e, f_int, min_det = _assemble_global(u_try)
                if min_det <= hp.min_det_f and it > 0:
                    break
                resid = f_int - lam_try * f_ext
                ref_scale = max(
                    float(np.linalg.norm(f_int)),
                    float(np.linalg.norm(lam_try * f_ext)),
                    1.0,
                )
                res_norm = float(np.linalg.norm(resid[free])) / ref_scale
                if res_norm < hp.tol_rel:
                    converged = True
                    break
                if n_free == 0:
                    converged = True
                    break
                du = _solve_free(K_e, resid)
                if float(np.linalg.norm(du)) <= 1e-12 * max(float(np.linalg.norm(u_try)), 1.0):
                    converged = True
                    break
                alpha = 1.0
                accepted = False
                while alpha >= 1.0 / 32.0:
                    u_cand = u_try.copy()
                    u_cand[free] += alpha * du
                    if cls._min_det_f(u_cand, elements, dNdX) > 0.02:
                        u_try = u_cand
                        accepted = True
                        break
                    alpha *= 0.5
                if not accepted:
                    break
            if converged:
                du_prev = u_try - u
                d_lam_prev = step_dl
                u = u_try
                lam = lam_try
                von_mises, sig, rot_deg = cls._nodal_fields(
                    u, nodes, elements, dNdX, dV0, D
                )
                step_history.append({
                    "lambda": lam,
                    "probes": cls._evaluate_probes(mesh.get("probes") or {}, u, von_mises, sig, rot_deg),
                })
                if hp.large_disp and it <= 3:
                    d_lam = min(d_lam * 1.4, 0.25)
            else:
                d_lam *= 0.5
                if d_lam < 1e-4:
                    warning = f"已達機構物理大變形極限 (lambda={lam:.3f})"
                    break
        von_mises, sig, rot_deg = cls._nodal_fields(u, nodes, elements, dNdX, dV0, D)
        probes = cls._evaluate_probes(mesh.get("probes") or {}, u, von_mises, sig, rot_deg)
        _K_e, f_int, _min_det = _assemble_global(u)
        reactions = {}
        balance_vec = np.array([float(np.sum(f_ext[0::2])), float(np.sum(f_ext[1::2]))])
        for lay, (ids_raw, parsed) in groups.items():
            if parsed.get("type") not in ("FIXED", "DISP"):
                continue
            ids = np.unique(np.asarray(ids_raw, dtype=int))
            rx = float(np.sum(f_int[2 * ids]) - np.sum(f_ext[2 * ids]))
            ry = float(np.sum(f_int[2 * ids + 1]) - np.sum(f_ext[2 * ids + 1]))
            balance_vec += np.array([rx, ry])
            reactions[str(lay)] = {
                "rx_n": rx,
                "ry_n": ry,
                "r_n": math.hypot(rx, ry),
                "rx_gf": rx / GF_TO_N,
                "ry_gf": ry / GF_TO_N,
                "r_gf": math.hypot(rx, ry) / GF_TO_N,
                "n_nodes": int(len(ids)),
            }
        balance = float(np.linalg.norm(balance_vec))
        u2 = u.reshape(-1, 2)
        depth = {}
        for pid, pinfo in probes.items():
            hist = [
                {
                    "lambda": rec["lambda"],
                    "dx": rec["probes"][pid]["dx"],
                    "dy": rec["probes"][pid]["dy"],
                    "dxy": rec["probes"][pid]["dxy"],
                    "stress": rec["probes"][pid]["stress"],
                    "disp_theta": rec["probes"][pid]["disp_theta"],
                    "rot_theta": rec["probes"][pid]["rot_theta"],
                }
                for rec in step_history
                if pid in rec["probes"]
            ]
            pinfo["history"] = hist
            depth[pid] = pinfo
        vm_max = float(np.max(von_mises)) if len(von_mises) else 0.0
        return {
            "u": u2,
            "u_x": u2[:, 0],
            "u_y": u2[:, 1],
            "u_mag": np.hypot(u2[:, 0], u2[:, 1]),
            "disp_theta_deg": np.degrees(np.arctan2(u2[:, 1], u2[:, 0])),
            "rot_theta_deg": rot_deg,
            "von_mises": von_mises,
            "stress_tensor": sig,
            "probes": depth,
            "reactions": reactions,
            "converged_lambda": float(lam),
            "max_von_mises": vm_max,
            "safety_factor": (float(hp.yield_mpa) / vm_max) if vm_max > 1e-12 else float("inf"),
            "equilibrium_residual_n": balance,
            "n_dof": n_dof,
            "n_free": int(len(free)),
            "n_iter_total": n_iter_total,
            "step_history": step_history,
            "warning": warning,
            "hp": hp,
            "elapsed_ms": (time.perf_counter() - t0) * 1000.0,
        }

    @staticmethod
    def plot_fea_on_ax(result: dict, mesh: dict, ax, mode: str = "Von Mises 應力",
                       show_undeformed: bool = True, deform_scale: float = None):
        if ax is None or result is None:
            return None
        ax.clear()
        ax.set_facecolor("#0a0a0a")
        if ax.figure is not None:
            ax.figure.patch.set_facecolor("#0a0a0a")
        field_key, field_label, cmap = VIEW_FIELD.get(mode, VIEW_FIELD[VIEW_MODES[0]])
        hp = result.get("hp")
        if deform_scale is None:
            deform_scale = float(getattr(hp, "deform_scale", 1.0)) if hp is not None else 1.0
        scale = float(deform_scale)
        nodes0 = np.asarray(mesh["nodes"], dtype=float)
        elements = np.asarray(mesh["elements"], dtype=int)
        nodes = nodes0 + scale * np.asarray(result["u"], dtype=float)
        values = np.asarray(result[field_key], dtype=float)
        n0, n1, n2 = elements[:, 0], elements[:, 1], elements[:, 2]
        m01, m12, m20 = elements[:, 3], elements[:, 4], elements[:, 5]
        sub = np.stack([
            np.stack([n0, m01, m20], axis=1),
            np.stack([m01, n1, m12], axis=1),
            np.stack([m20, m12, n2], axis=1),
            np.stack([m01, m12, m20], axis=1),
        ], axis=1)
        tri = sub.reshape(-1, 3)
        tri_vals = values[tri].mean(axis=1)
        coll = PolyCollection(
            nodes[tri], array=tri_vals, cmap=cmap,
            edgecolors="none", alpha=0.95, zorder=2,
        )
        ax.add_collection(coll)
        prev_cbar = getattr(ax, "_fea_cbar", None)
        if prev_cbar is not None:
            try:
                prev_cbar.remove()
            except Exception:
                pass
            ax._fea_cbar = None
        cbar = ax.figure.colorbar(coll, ax=ax, shrink=0.8, pad=0.015)
        ax._fea_cbar = cbar
        cbar.set_label(field_label, color="#cccccc", fontsize=8)
        cbar.ax.tick_params(colors="#cccccc", labelsize=7)
        if show_undeformed:
            for loop in [mesh.get("outer_loop")] + list(mesh.get("hole_loops") or []):
                if loop is None or len(loop) < 2:
                    continue
                closed = np.vstack([loop, loop[0]])
                ax.plot(closed[:, 0], closed[:, 1], color="#55606a", lw=0.8, ls="--", zorder=3)
        for pid, pinfo in (result.get("probes") or {}).items():
            cx, cy = pinfo.get("center_xy") or (0.0, 0.0)
            nid = int(pinfo.get("node_id", -1))
            if 0 <= nid < len(nodes):
                px, py = float(nodes[nid, 0]), float(nodes[nid, 1])
                ax.plot([px], [py], marker="+", markersize=12, color="#00ff88", mew=2.2, zorder=8)
                ax.annotate(
                    f"{pid}\ndx={pinfo['dx']:+.3f} dy={pinfo['dy']:+.3f}\n|d|={pinfo['dxy']:.3f} mm\n"
                    f"vm={pinfo['stress']:.1f} MPa",
                    xy=(px, py), xytext=(px + 2.5, py + 2.5),
                    color="#00ff88", fontsize=7.5, zorder=9,
                    bbox=dict(boxstyle="round,pad=0.25", facecolor="#101010", edgecolor="#00ff88", alpha=0.85),
                )
        hud = [
            f"T6 TL-SVK FEA | {getattr(hp, 'material', '')} | lambda={result['converged_lambda']:.3f}",
            f"Nodes {len(nodes)} | Elements {len(elements)} | iter {result['n_iter_total']} "
            f"| {result['elapsed_ms']:.0f} ms | Visual: {scale:g}x",
            f"max vm {result['max_von_mises']:.2f} MPa | SF {result['safety_factor']:.2f} | "
            f"eq-res {result['equilibrium_residual_n']:.3e} N",
        ]
        if result.get("warning"):
            hud.append(f"WARNING: {result['warning']}")
        ax.text(
            0.012, 0.985, "\n".join(hud), transform=ax.transAxes,
            color="#ffdd55", fontsize=8, va="top", ha="left", zorder=20,
            bbox=dict(boxstyle="round,pad=0.35", facecolor="#161616", edgecolor="#444444", alpha=0.92),
        )
        outer = mesh.get("outer_loop")
        if outer is not None and len(outer) > 0:
            allpts = np.vstack([nodes[tri].reshape(-1, 2), np.asarray(outer, dtype=float)])
            xmin, ymin = allpts.min(axis=0)
            xmax, ymax = allpts.max(axis=0)
            dx = max(xmax - xmin, 1.0) * 0.06
            dy = max(ymax - ymin, 1.0) * 0.06
            ax.set_xlim(xmin - dx, xmax + dx)
            ax.set_ylim(ymin - dy, ymax + dy)
        ax.set_aspect("equal", adjustable="datalim")
        ax.tick_params(colors="#888888", labelsize=7)
        return ax
