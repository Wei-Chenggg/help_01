import math
import re
from dataclasses import dataclass, field
import numpy as np
import ezdxf
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection, PolyCollection
from matplotlib.path import Path
from scipy.spatial import cKDTree

try:
    from .dxf_editting_helper import DXFEditingHelper
except ImportError:
    from dxf_editting_helper import DXFEditingHelper

@dataclass
class ContourHyperParams:
    snap_tol: float = 1e-4
    angle_tol_rad: float = 1e-4
    min_seg_len: float = 1e-3
    gap_warn_tol: float = 0.15
    arc_chord_tol: float = 0.02

@dataclass
class LineSegment:
    seg_id: int
    handle: str
    entity_type: str
    layer: str
    p1: tuple[float, float]
    p2: tuple[float, float]
    @property
    def length(self) -> float:
        return math.hypot(self.p2[0] - self.p1[0], self.p2[1] - self.p1[1])
    @property
    def midpoint(self) -> tuple[float, float]:
        return ((self.p1[0] + self.p2[0]) * 0.5, (self.p1[1] + self.p2[1]) * 0.5)
    @property
    def direction(self) -> tuple[float, float]:
        L = self.length
        if L <= 1e-12:
            return (0.0, 0.0)
        dx = (self.p2[0] - self.p1[0]) / L
        dy = (self.p2[1] - self.p1[1]) / L
        if dx < -1e-9 or (abs(dx) <= 1e-9 and dy < 0):
            dx, dy = -dx, -dy
        return (dx, dy)

@dataclass
class ContourIssue:
    issue_id: int
    issue_type: str
    severity: str
    layer_a: str
    layer_b: str
    handles: list[str]
    marker_pts: list[tuple[float, float]]
    highlight_seg: tuple[tuple[float, float], tuple[float, float]] | None
    description: str
    focus_xy: tuple[float, float] = (0.0, 0.0)
    island_poly: list[tuple[float, float]] | None = None

@dataclass
class ContourCheckResult:
    dxf_path: str
    raw_line_segments: list[LineSegment] = field(default_factory=list)
    clean_line_segments: list[LineSegment] = field(default_factory=list)
    display_curve_segments: list[tuple[tuple[float, float], tuple[float, float], str]] = field(default_factory=list)
    issues: list[ContourIssue] = field(default_factory=list)
    node_coords: np.ndarray = field(default_factory=lambda: np.empty((0, 2)))
    node_degrees: np.ndarray = field(default_factory=lambda: np.empty(0, dtype=int))
    loops: list[dict] = field(default_factory=list)
    probe_circles: list[dict] = field(default_factory=list)
    @property
    def is_clean(self) -> bool:
        return not any(i.severity == "ERROR" for i in self.issues)
    def summary_dict(self) -> dict[str, int]:
        counts = {
            "DEGENERATE": 0,
            "EXACT_DUPLICATE": 0,
            "CONTAINMENT": 0,
            "PARTIAL_OVERLAP": 0,
            "HEAD_TO_TAIL": 0,
            "OPEN_ENDPOINT": 0,
            "MULTI_JUNCTION": 0,
            "MICRO_GAP": 0,
            "EXTERIOR_ISLAND": 0,
            "NESTED_ISLAND": 0,
            "LOOP_INTERSECT": 0,
        }
        for iss in self.issues:
            counts[iss.issue_type] = counts.get(iss.issue_type, 0) + 1
        return counts

class DXFContourHelper:
    @staticmethod
    def parse_bc_layer(layer_name: str) -> dict:
        info = DXFEditingHelper.parse_bc_layer_name(layer_name)
        out = dict(info)
        out["priority"] = DXFEditingHelper.layer_priority(layer_name)
        if out.get("type") == "FREE":
            out["type"] = "FREE_CONTOUR"
        elif out.get("type") == "CUSTOM":
            out["type"] = "UNKNOWN"
        return out

    @classmethod
    def layer_priority(cls, layer_name: str) -> int:
        return int(DXFEditingHelper.layer_priority(layer_name))

    @staticmethod
    def extract_primitives_from_msp(msp) -> tuple[list[LineSegment], list[tuple], list[tuple], list[tuple], list[tuple]]:
        line_segs: list[LineSegment] = []
        curve_topology_edges: list[tuple[tuple[float, float], tuple[float, float], str, str]] = []
        display_curves: list[tuple[tuple[float, float], tuple[float, float], str]] = []
        arc_polys: list[tuple[np.ndarray, str, str]] = []
        circle_polys: list[tuple[np.ndarray, str, str]] = []
        seg_id = 0
        for ent in msp:
            etype = ent.dxftype()
            handle = ent.dxf.handle
            layer = ent.dxf.layer if ent.dxf.hasattr("layer") else "0"
            if etype == "LINE":
                p1 = (float(ent.dxf.start.x), float(ent.dxf.start.y))
                p2 = (float(ent.dxf.end.x), float(ent.dxf.end.y))
                line_segs.append(LineSegment(seg_id, handle, "LINE", layer, p1, p2))
                seg_id += 1
            elif etype == "LWPOLYLINE":
                try:
                    for sub in ent.virtual_entities():
                        stype = sub.dxftype()
                        if stype == "LINE":
                            p1 = (float(sub.dxf.start.x), float(sub.dxf.start.y))
                            p2 = (float(sub.dxf.end.x), float(sub.dxf.end.y))
                            line_segs.append(LineSegment(seg_id, handle, "LWPOLYLINE", layer, p1, p2))
                            seg_id += 1
                        elif stype == "ARC":
                            p1, p2, sub_segs = DXFContourHelper._sample_arc_entity(sub)
                            curve_topology_edges.append((p1, p2, handle, layer))
                            for s1, s2 in sub_segs:
                                display_curves.append((s1, s2, layer))
                            arc_polys.append((DXFContourHelper._segs_to_pts(sub_segs), handle, layer))
                except Exception:
                    pts = list(ent.get_points(format="xyb"))
                    n = len(pts)
                    if n >= 2:
                        num_edges = n if ent.closed else n - 1
                        for i in range(num_edges):
                            x1, y1, bulge = pts[i]
                            x2, y2, _ = pts[(i + 1) % n]
                            if abs(bulge) <= 1e-7:
                                line_segs.append(LineSegment(seg_id, handle, "LWPOLYLINE", layer, (float(x1), float(y1)), (float(x2), float(y2))))
                                seg_id += 1
                            else:
                                curve_topology_edges.append(((float(x1), float(y1)), (float(x2), float(y2)), handle, layer))
                                arc_polys.append((np.array([[float(x1), float(y1)], [float(x2), float(y2)]]), handle, layer))
            elif etype == "ARC":
                p1, p2, sub_segs = DXFContourHelper._sample_arc_entity(ent)
                curve_topology_edges.append((p1, p2, handle, layer))
                for s1, s2 in sub_segs:
                    display_curves.append((s1, s2, layer))
                arc_polys.append((DXFContourHelper._segs_to_pts(sub_segs), handle, layer))
            elif etype == "CIRCLE":
                cx, cy = float(ent.dxf.center.x), float(ent.dxf.center.y)
                r = float(ent.dxf.radius)
                angles = np.linspace(0.0, 2.0 * math.pi, 49)
                pts = np.column_stack([cx + r * np.cos(angles), cy + r * np.sin(angles)])
                for k in range(len(pts) - 1):
                    display_curves.append(((float(pts[k, 0]), float(pts[k, 1])), (float(pts[k + 1, 0]), float(pts[k + 1, 1])), layer))
                circle_polys.append((pts, handle, layer))
        return line_segs, curve_topology_edges, display_curves, arc_polys, circle_polys

    @staticmethod
    def _segs_to_pts(sub_segs: list[tuple]) -> np.ndarray:
        if not sub_segs:
            return np.empty((0, 2))
        return np.array([sub_segs[0][0]] + [s[1] for s in sub_segs], dtype=float)

    @staticmethod
    def _sample_arc_entity(arc_ent) -> tuple[tuple[float, float], tuple[float, float], list[tuple]]:
        cx, cy = float(arc_ent.dxf.center.x), float(arc_ent.dxf.center.y)
        r = float(arc_ent.dxf.radius)
        a1 = float(arc_ent.dxf.start_angle)
        a2 = float(arc_ent.dxf.end_angle)
        span = (a2 - a1) % 360.0
        if span <= 1e-6:
            span = 360.0
        steps = max(int(span / 7.5), 8)
        angs = np.radians(a1 + np.linspace(0.0, span, steps + 1))
        pts = np.column_stack([cx + r * np.cos(angs), cy + r * np.sin(angs)])
        p_start = (float(pts[0, 0]), float(pts[0, 1]))
        p_end = (float(pts[-1, 0]), float(pts[-1, 1]))
        segs = [((float(pts[k, 0]), float(pts[k, 1])), (float(pts[k + 1, 0]), float(pts[k + 1, 1]))) for k in range(len(pts) - 1)]
        return p_start, p_end, segs

    @staticmethod
    def _point_to_line_dist(pt: tuple[float, float], line_p1: tuple[float, float], u: tuple[float, float]) -> float:
        vx = pt[0] - line_p1[0]
        vy = pt[1] - line_p1[1]
        return abs(vx * u[1] - vy * u[0])

    @classmethod
    def check_dxf(
        cls,
        dxf_source: str | object,
        hp: ContourHyperParams | None = None,
    ) -> ContourCheckResult:
        if hp is None:
            hp = ContourHyperParams()
        if isinstance(dxf_source, str):
            doc = ezdxf.readfile(dxf_source)
            dxf_name = dxf_source
        else:
            doc = dxf_source
            dxf_name = "<in-memory-doc>"
        msp = doc.modelspace()
        raw_lines, curve_edges, disp_curves, arc_polys, circle_polys = cls.extract_primitives_from_msp(msp)
        issues: list[ContourIssue] = []
        valid_lines: list[LineSegment] = []
        issue_seq = 1
        for seg in raw_lines:
            if seg.length <= hp.min_seg_len:
                issues.append(
                    ContourIssue(
                        issue_id=issue_seq,
                        issue_type="DEGENERATE",
                        severity="ERROR",
                        layer_a=seg.layer,
                        layer_b="",
                        handles=[seg.handle],
                        marker_pts=[seg.p1],
                        highlight_seg=None,
                        description=f"退化零長線段 #{seg.handle} (Layer={seg.layer}, Len={seg.length:.2e})",
                        focus_xy=seg.p1,
                    )
                )
                issue_seq += 1
            else:
                valid_lines.append(seg)
        n = len(valid_lines)
        for i in range(n):
            sa = valid_lines[i]
            u = sa.direction
            for j in range(i + 1, n):
                sb = valid_lines[j]
                v = sb.direction
                cross = abs(u[0] * v[1] - u[1] * v[0])
                if cross > hp.angle_tol_rad:
                    continue
                d1 = cls._point_to_line_dist(sb.p1, sa.p1, u)
                d2 = cls._point_to_line_dist(sb.p2, sa.p1, u)
                if max(d1, d2) > hp.snap_tol:
                    continue
                def proj(pt: tuple[float, float]) -> float:
                    return (pt[0] - sa.p1[0]) * u[0] + (pt[1] - sa.p1[1]) * u[1]
                def unproj(t_val: float) -> tuple[float, float]:
                    return (sa.p1[0] + t_val * u[0], sa.p1[1] + t_val * u[1])
                a_min, a_max = sorted([proj(sa.p1), proj(sa.p2)])
                b_min, b_max = sorted([proj(sb.p1), proj(sb.p2)])
                inter_min = max(a_min, b_min)
                inter_max = min(a_max, b_max)
                overlap = inter_max - inter_min
                if overlap < -hp.snap_tol:
                    continue
                ov_p1 = unproj(inter_min)
                ov_p2 = unproj(inter_max)
                ov_mid = ((ov_p1[0] + ov_p2[0]) * 0.5, (ov_p1[1] + ov_p2[1]) * 0.5)
                if abs(overlap) <= hp.snap_tol:
                    issues.append(
                        ContourIssue(
                            issue_id=issue_seq,
                            issue_type="HEAD_TO_TAIL",
                            severity="INFO",
                            layer_a=sa.layer,
                            layer_b=sb.layer,
                            handles=[sa.handle, sb.handle],
                            marker_pts=[ov_p1],
                            highlight_seg=None,
                            description=f"共線端點相接 #{sa.handle}({sa.layer}) & #{sb.handle}({sb.layer}) @ ({ov_p1[0]:.2f},{ov_p1[1]:.2f})",
                            focus_xy=ov_p1,
                        )
                    )
                    issue_seq += 1
                    continue
                same_min = abs(a_min - b_min) <= hp.snap_tol
                same_max = abs(a_max - b_max) <= hp.snap_tol
                if same_min and same_max:
                    itype = "EXACT_DUPLICATE"
                    desc = f"完全重疊 #{sa.handle}({sa.layer}) == #{sb.handle}({sb.layer}), Len={overlap:.2f}"
                elif (a_min - hp.snap_tol <= b_min) and (b_max <= a_max + hp.snap_tol):
                    itype = "CONTAINMENT"
                    desc = f"包含重疊 長#{sa.handle}({sa.layer}) 蓋住 短#{sb.handle}({sb.layer}), Len={overlap:.2f}"
                elif (b_min - hp.snap_tol <= a_min) and (a_max <= b_max + hp.snap_tol):
                    itype = "CONTAINMENT"
                    desc = f"包含重疊 長#{sb.handle}({sb.layer}) 蓋住 短#{sa.handle}({sa.layer}), Len={overlap:.2f}"
                else:
                    itype = "PARTIAL_OVERLAP"
                    desc = f"部分交錯重疊 #{sa.handle}({sa.layer}) & #{sb.handle}({sb.layer}), Len={overlap:.2f}"
                issues.append(
                    ContourIssue(
                        issue_id=issue_seq,
                        issue_type=itype,
                        severity="ERROR",
                        layer_a=sa.layer,
                        layer_b=sb.layer,
                        handles=[sa.handle, sb.handle],
                        marker_pts=[ov_p1, ov_p2],
                        highlight_seg=(ov_p1, ov_p2),
                        description=desc,
                        focus_xy=ov_mid,
                    )
                )
                issue_seq += 1
        clean_lines = cls.split_and_dedup_lines(valid_lines, hp=hp)
        node_coords, node_degrees, topo_issues = cls._check_endpoint_topology(clean_lines, curve_edges, hp, issue_seq)
        issues.extend(topo_issues)
        probe_circles = []
        solid_circles = []
        for pts, handle, layer in circle_polys:
            info = cls.parse_bc_layer(layer)
            if info.get("type") == "PROBE":
                arr = np.asarray(pts, dtype=float)
                if len(arr) >= 3:
                    cx = float(arr[:, 0].mean())
                    cy = float(arr[:, 1].mean())
                    r = float(np.mean(np.hypot(arr[:, 0] - cx, arr[:, 1] - cy)))
                    probe_circles.append({
                        "probe_id": info.get("probe_id", "PROBE#001"),
                        "layer": layer,
                        "handle": handle,
                        "center": (cx, cy),
                        "radius": r,
                    })
            else:
                solid_circles.append((pts, handle, layer))
        loops, island_issues = cls._assemble_and_classify_loops(
            clean_lines, arc_polys + solid_circles, hp, issue_seq + len(topo_issues)
        )
        issues.extend(island_issues)
        return ContourCheckResult(
            dxf_path=dxf_name,
            raw_line_segments=raw_lines,
            clean_line_segments=clean_lines,
            display_curve_segments=disp_curves,
            issues=issues,
            node_coords=node_coords,
            node_degrees=node_degrees,
            loops=loops,
            probe_circles=probe_circles,
        )

    @classmethod
    def split_and_dedup_lines(
        cls,
        segments: list[LineSegment],
        hp: ContourHyperParams | None = None,
    ) -> list[LineSegment]:
        if hp is None:
            hp = ContourHyperParams()
        valid = [s for s in segments if s.length > hp.min_seg_len]
        if not valid:
            return []
        used = [False] * len(valid)
        groups: list[list[LineSegment]] = []
        for i in range(len(valid)):
            if used[i]:
                continue
            sa = valid[i]
            u = sa.direction
            grp = [sa]
            used[i] = True
            for j in range(i + 1, len(valid)):
                if used[j]:
                    continue
                sb = valid[j]
                v = sb.direction
                if abs(u[0] * v[1] - u[1] * v[0]) <= hp.angle_tol_rad:
                    d1 = cls._point_to_line_dist(sb.p1, sa.p1, u)
                    d2 = cls._point_to_line_dist(sb.p2, sa.p1, u)
                    if max(d1, d2) <= hp.snap_tol:
                        grp.append(sb)
                        used[j] = True
            groups.append(grp)
        result: list[LineSegment] = []
        new_id = 0
        for grp in groups:
            if len(grp) == 1:
                s = grp[0]
                result.append(LineSegment(new_id, s.handle, s.entity_type, s.layer, s.p1, s.p2))
                new_id += 1
                continue
            ref = grp[0]
            u = ref.direction
            origin = ref.p1
            def proj(pt: tuple[float, float]) -> float:
                return (pt[0] - origin[0]) * u[0] + (pt[1] - origin[1]) * u[1]
            def unproj(t_val: float) -> tuple[float, float]:
                return (origin[0] + t_val * u[0], origin[1] + t_val * u[1])
            raw_t = []
            intervals = []
            for s in grp:
                t1, t2 = sorted([proj(s.p1), proj(s.p2)])
                raw_t.extend([t1, t2])
                intervals.append((t1, t2, cls.layer_priority(s.layer), s))
            raw_t.sort()
            uniq_t = [raw_t[0]]
            for tv in raw_t[1:]:
                if tv - uniq_t[-1] > hp.snap_tol:
                    uniq_t.append(tv)
                else:
                    uniq_t[-1] = 0.5 * (uniq_t[-1] + tv)
            elem_segs: list[LineSegment] = []
            for k in range(len(uniq_t) - 1):
                ta, tb = uniq_t[k], uniq_t[k + 1]
                if tb - ta <= hp.min_seg_len:
                    continue
                t_mid = 0.5 * (ta + tb)
                covering = [iv for iv in intervals if (iv[0] - hp.snap_tol <= t_mid <= iv[1] + hp.snap_tol)]
                if not covering:
                    continue
                covering.sort(key=lambda x: (x[2], -x[3].seg_id), reverse=True)
                winner = covering[0][3]
                elem_segs.append(
                    LineSegment(
                        new_id,
                        winner.handle,
                        winner.entity_type,
                        winner.layer,
                        unproj(ta),
                        unproj(tb),
                    )
                )
                new_id += 1
            for es in elem_segs:
                if (
                    result
                    and result[-1].layer == es.layer
                    and result[-1].handle == es.handle
                    and math.hypot(result[-1].p2[0] - es.p1[0], result[-1].p2[1] - es.p1[1]) <= hp.snap_tol
                ):
                    prev = result[-1]
                    result[-1] = LineSegment(prev.seg_id, prev.handle, prev.entity_type, prev.layer, prev.p1, es.p2)
                else:
                    result.append(es)
        return result

    @classmethod
    def _check_endpoint_topology(
        cls,
        line_segs: list[LineSegment],
        curve_edges: list[tuple],
        hp: ContourHyperParams,
        start_issue_id: int,
    ) -> tuple[np.ndarray, np.ndarray, list[ContourIssue]]:
        raw_pts = []
        edge_Work = []
        for s in line_segs:
            i1 = len(raw_pts)
            raw_pts.append(s.p1)
            i2 = len(raw_pts)
            raw_pts.append(s.p2)
            edge_Work.append((i1, i2, s.handle, s.layer))
        for p1, p2, h, lyr in curve_edges:
            i1 = len(raw_pts)
            raw_pts.append(p1)
            i2 = len(raw_pts)
            raw_pts.append(p2)
            edge_Work.append((i1, i2, h, lyr))
        if not raw_pts:
            return np.empty((0, 2)), np.empty(0, dtype=int), []
        pts_arr = np.array(raw_pts, dtype=float)
        parent = list(range(len(pts_arr)))

        def _find(a):
            while parent[a] != a:
                parent[a] = parent[parent[a]]
                a = parent[a]
            return a

        if len(pts_arr) > 1:
            pairs = cKDTree(pts_arr).query_pairs(r=hp.snap_tol, output_type="ndarray")
            for a, b in pairs:
                ra, rb = _find(int(a)), _find(int(b))
                if ra != rb:
                    parent[rb] = ra
        root_node: dict[int, int] = {}
        root_coord: dict[int, np.ndarray] = {}
        pt_to_node = np.zeros(len(pts_arr), dtype=int)
        for idx in range(len(pts_arr)):
            r = _find(idx)
            if r not in root_node:
                root_node[r] = len(root_node)
                root_coord[r] = pts_arr[idx]
            pt_to_node[idx] = root_node[r]
        nodes = np.array(
            [root_coord[r] for r in sorted(root_node, key=lambda k: root_node[k])], dtype=float
        )
        degrees = np.zeros(len(nodes), dtype=int)
        node_handles: dict[int, list[str]] = {i: [] for i in range(len(nodes))}
        node_layers: dict[int, list[str]] = {i: [] for i in range(len(nodes))}
        for i1, i2, h, lyr in edge_Work:
            u_id = int(pt_to_node[i1])
            v_id = int(pt_to_node[i2])
            if u_id == v_id:
                continue
            degrees[u_id] += 1
            degrees[v_id] += 1
            node_handles[u_id].append(h)
            node_handles[v_id].append(h)
            node_layers[u_id].append(lyr)
            node_layers[v_id].append(lyr)
        topo_issues: list[ContourIssue] = []
        seq = start_issue_id
        open_node_ids = []
        for nid, deg in enumerate(degrees):
            pt = (float(nodes[nid, 0]), float(nodes[nid, 1]))
            h_list = sorted(set(node_handles[nid]))
            l_list = sorted(set(node_layers[nid]))
            l_a = l_list[0] if l_list else "0"
            l_b = l_list[1] if len(l_list) > 1 else l_a
            if deg == 1:
                open_node_ids.append(nid)
                topo_issues.append(
                    ContourIssue(
                        issue_id=seq,
                        issue_type="OPEN_ENDPOINT",
                        severity="ERROR",
                        layer_a=l_a,
                        layer_b="",
                        handles=h_list,
                        marker_pts=[pt],
                        highlight_seg=None,
                        description=f"懸空未閉合端點 (Degree=1) @ ({pt[0]:.2f}, {pt[1]:.2f}), 圖元={h_list}",
                        focus_xy=pt,
                    )
                )
                seq += 1
            elif deg >= 3:
                topo_issues.append(
                    ContourIssue(
                        issue_id=seq,
                        issue_type="MULTI_JUNCTION",
                        severity="WARNING",
                        layer_a=l_a,
                        layer_b=l_b,
                        handles=h_list,
                        marker_pts=[pt],
                        highlight_seg=None,
                        description=f"多重交會點/T字點 (Degree={deg}) @ ({pt[0]:.2f}, {pt[1]:.2f}), 圖元={h_list}",
                        focus_xy=pt,
                    )
                )
                seq += 1
        for a_idx in range(len(open_node_ids)):
            na = open_node_ids[a_idx]
            pa = nodes[na]
            for b_idx in range(a_idx + 1, len(open_node_ids)):
                nb = open_node_ids[b_idx]
                pb = nodes[nb]
                # 同一條懸空碎線的兩端不算「縫隙」，避免與 OPEN_ENDPOINT 重複告警
                if set(node_handles[na]) & set(node_handles[nb]):
                    continue
                dist = float(math.hypot(pa[0] - pb[0], pa[1] - pb[1]))
                if hp.snap_tol < dist <= hp.gap_warn_tol:
                    p1 = (float(pa[0]), float(pa[1]))
                    p2 = (float(pb[0]), float(pb[1]))
                    mid = ((p1[0] + p2[0]) * 0.5, (p1[1] + p2[1]) * 0.5)
                    topo_issues.append(
                        ContourIssue(
                            issue_id=seq,
                            issue_type="MICRO_GAP",
                            severity="ERROR",
                            layer_a="",
                            layer_b="",
                            handles=sorted(set(node_handles[na] + node_handles[nb])),
                            marker_pts=[p1, p2],
                            highlight_seg=(p1, p2),
                            description=f"微小未接縫隙 Gap={dist:.4f} mm @ ({mid[0]:.2f}, {mid[1]:.2f})",
                            focus_xy=mid,
                        )
                    )
                    seq += 1
        return nodes, degrees, topo_issues

    @classmethod
    def _assemble_and_classify_loops(
        cls,
        clean_lines: list[LineSegment],
        arc_polys: list[tuple],
        hp: ContourHyperParams,
        start_issue_id: int,
    ) -> tuple[list[dict], list[ContourIssue]]:
        """將直線段與圓弧/圓頂點序列串成封閉迴圈，並以包含深度 (Nesting Depth) 判定孤島。"""
        edges = []
        for s in clean_lines:
            edges.append({
                "pts": [(float(s.p1[0]), float(s.p1[1])), (float(s.p2[0]), float(s.p2[1]))],
                "handles": {s.handle},
                "layers": {s.layer},
            })
        for pts, handle, layer in arc_polys:
            arr = np.asarray(pts, dtype=float)
            if len(arr) < 2:
                continue
            edges.append({
                "pts": [(float(p[0]), float(p[1])) for p in arr],
                "handles": {handle},
                "layers": {layer},
            })

        def _dist(a, b):
            return math.hypot(a[0] - b[0], a[1] - b[1])

        closed_polys = []
        open_edges = []
        for e in edges:
            p = e["pts"]
            if len(p) >= 4 and _dist(p[0], p[-1]) <= hp.snap_tol:
                closed_polys.append({"pts": p, "handles": set(e["handles"]), "layers": set(e["layers"])})
            else:
                open_edges.append(e)

        used = [False] * len(open_edges)
        for i in range(len(open_edges)):
            if used[i]:
                continue
            cur = list(open_edges[i]["pts"])
            h_set = set(open_edges[i]["handles"])
            l_set = set(open_edges[i]["layers"])
            used[i] = True
            while True:
                if len(cur) >= 3 and _dist(cur[0], cur[-1]) <= hp.snap_tol:
                    closed_polys.append({"pts": cur, "handles": h_set, "layers": l_set})
                    break
                tail = cur[-1]
                found = -1
                reversed_edge = False
                for j, e in enumerate(open_edges):
                    if used[j]:
                        continue
                    p = e["pts"]
                    if _dist(p[0], tail) <= hp.snap_tol:
                        found = j
                        reversed_edge = False
                        break
                    if _dist(p[-1], tail) <= hp.snap_tol:
                        found = j
                        reversed_edge = True
                        break
                if found < 0:
                    break
                e = open_edges[found]
                used[found] = True
                seg = list(reversed(e["pts"])) if reversed_edge else list(e["pts"])
                cur.extend(seg[1:])
                h_set |= e["handles"]
                l_set |= e["layers"]

        if not closed_polys:
            return [], []

        for poly in closed_polys:
            pts = np.asarray(poly["pts"], dtype=float)
            x, y = pts[:, 0], pts[:, 1]
            poly["area"] = 0.5 * abs(float(np.dot(x, np.roll(y, -1)) - np.dot(y, np.roll(x, -1))))
            poly["path"] = Path(pts, closed=True)
        closed_polys.sort(key=lambda p: p["area"], reverse=True)

        loops = []
        island_issues = []
        seq = start_issue_id
        for i, poly in enumerate(closed_polys):
            pts = np.asarray(poly["pts"], dtype=float)
            if len(pts) >= 2 and _dist(poly["pts"][0], poly["pts"][-1]) <= hp.snap_tol:
                pts = pts[:-1]
            mid_pts = 0.5 * (pts + np.roll(pts, -1, axis=0))
            parents = []
            intersect_pairs = []
            for p in range(i):
                inside_mask = closed_polys[p]["path"].contains_points(mid_pts, radius=1e-5)
                ratio_in = float(np.mean(inside_mask)) if len(inside_mask) else 0.0
                if ratio_in > 0.98:
                    parents.append(p)
                elif 0.02 <= ratio_in <= 0.98:
                    intersect_pairs.append((p, ratio_in))
            depth = len(parents)
            parent_id = parents[-1] if depth > 0 else None
            if i == 0:
                role = "OUTER_BOUNDARY"
            elif depth == 0:
                role = "EXTERIOR_ISLAND"
            elif depth == 1 and parent_id == 0:
                role = "INNER_HOLE"
            else:
                role = "NESTED_ISLAND"
            center = (float(pts[:, 0].mean()), float(pts[:, 1].mean()))
            layers = sorted(poly["layers"])
            handles = sorted(poly["handles"])
            loops.append({
                "index": i,
                "role": role,
                "area": poly["area"],
                "depth": depth,
                "handles": handles,
                "layers": layers,
                "center": center,
                "pts": pts,
            })
            if role in ("EXTERIOR_ISLAND", "NESTED_ISLAND"):
                island_issues.append(
                    ContourIssue(
                        issue_id=seq,
                        issue_type=role,
                        severity="ERROR",
                        layer_a=(layers[0] if layers else ""),
                        layer_b="",
                        handles=handles,
                        marker_pts=[center],
                        highlight_seg=None,
                        description=(
                            f"{'外框外的分離孤島' if role == 'EXTERIOR_ISLAND' else '孔洞中的懸浮孤島'} "
                            f"(Depth={depth}, Area={poly['area']:.2f}) @ ({center[0]:.2f}, {center[1]:.2f}), "
                            f"圖元={handles}"
                        ),
                        focus_xy=center,
                        island_poly=[(float(p[0]), float(p[1])) for p in pts],
                    )
                )
                seq += 1
            for p_idx, ratio_in in intersect_pairs:
                other = loops[p_idx] if p_idx < len(loops) else None
                other_handles = other["handles"] if other else []
                island_issues.append(
                    ContourIssue(
                        issue_id=seq,
                        issue_type="LOOP_INTERSECT",
                        severity="ERROR",
                        layer_a=(layers[0] if layers else ""),
                        layer_b=(other["layers"][0] if other and other["layers"] else ""),
                        handles=sorted(set(handles) | set(other_handles)),
                        marker_pts=[center],
                        highlight_seg=None,
                        description=(
                            f"迴圈交叉刺穿 (與迴圈#{p_idx} 邊中點在內比例 {ratio_in * 100:.1f}%) "
                            f"@ ({center[0]:.2f}, {center[1]:.2f})"
                        ),
                        focus_xy=center,
                        island_poly=[(float(p[0]), float(p[1])) for p in pts],
                    )
                )
                seq += 1
        return loops, island_issues

    @classmethod
    def apply_auto_dedup_to_doc(cls, doc, hp: ContourHyperParams | None = None) -> ContourCheckResult:
        if hp is None:
            hp = ContourHyperParams()
        msp = doc.modelspace()
        polylines = [e for e in msp if e.dxftype() == "LWPOLYLINE"]
        for pl in polylines:
            try:
                pl.explode(msp)
            except Exception:
                pass
        raw_lines, _, _, _, _ = cls.extract_primitives_from_msp(msp)
        clean_lines = cls.split_and_dedup_lines(raw_lines, hp=hp)
        for ent in [e for e in msp if e.dxftype() == "LINE"]:
            msp.delete_entity(ent)
        for s in clean_lines:
            if s.layer not in doc.layers:
                doc.layers.add(name=s.layer)
            msp.add_line(s.p1, s.p2, dxfattribs={"layer": s.layer})
        return cls.check_dxf(doc, hp=hp)

    @classmethod
    def plot_check_result(
        cls,
        result: ContourCheckResult,
        ax=None,
        show_clean_endpoints: bool = True,
        focus_issue_id: int | None = None,
    ):
        created_fig = None
        if ax is None:
            created_fig, ax = plt.subplots(figsize=(10, 6.5))
        ax.clear()
        ax.set_facecolor("#0a0a0a")
        if ax.figure is not None:
            ax.figure.patch.set_facecolor("#0a0a0a")
        bg_segs = [(s.p1, s.p2) for s in result.raw_line_segments]
        for c1, c2, _ in result.display_curve_segments:
            bg_segs.append((c1, c2))
        if bg_segs:
            bg_col = LineCollection(bg_segs, colors="#555555", linewidths=1.2, zorder=2)
            ax.add_collection(bg_col)
        if show_clean_endpoints and len(result.node_coords) > 0:
            ok_mask = result.node_degrees == 2
            if np.any(ok_mask):
                ok_pts = result.node_coords[ok_mask]
                ax.scatter(ok_pts[:, 0], ok_pts[:, 1], c="#22aa55", s=14, alpha=0.75, zorder=4, label="Closed Node (Deg=2)")
        ov_segs = []
        ov_pts = []
        open_pts = []
        junc_pts = []
        gap_pts = []
        island_polys = []
        island_pts = []
        intersect_polys = []
        intersect_pts = []
        for iss in result.issues:
            if iss.issue_type in ("EXACT_DUPLICATE", "CONTAINMENT", "PARTIAL_OVERLAP"):
                if iss.highlight_seg is not None:
                    ov_segs.append(iss.highlight_seg)
                ov_pts.extend(iss.marker_pts)
            elif iss.issue_type == "OPEN_ENDPOINT":
                open_pts.extend(iss.marker_pts)
            elif iss.issue_type == "MULTI_JUNCTION":
                junc_pts.extend(iss.marker_pts)
            elif iss.issue_type in ("DEGENERATE", "MICRO_GAP"):
                gap_pts.extend(iss.marker_pts)
            elif iss.issue_type in ("EXTERIOR_ISLAND", "NESTED_ISLAND"):
                if iss.island_poly:
                    island_polys.append(np.asarray(iss.island_poly, dtype=float))
                island_pts.extend(iss.marker_pts)
            elif iss.issue_type == "LOOP_INTERSECT":
                if iss.island_poly:
                    intersect_polys.append(np.asarray(iss.island_poly, dtype=float))
                intersect_pts.extend(iss.marker_pts)
        if island_polys:
            island_col = PolyCollection(
                island_polys,
                facecolors="#00ffff", edgecolors="#00ffff",
                alpha=0.28, linestyles="dashed", zorder=7,
                label="Island (Floating)",
            )
            ax.add_collection(island_col)
        if island_pts:
            arr = np.array(island_pts, dtype=float)
            ax.scatter(arr[:, 0], arr[:, 1], s=190, facecolors="none", edgecolors="#00ffff", linewidths=2.4, zorder=14, label="Island Center")
            ax.scatter(arr[:, 0], arr[:, 1], s=90, c="#00ffff", marker="x", linewidths=2.0, zorder=14)
        if intersect_polys:
            inter_col = PolyCollection(
                intersect_polys,
                facecolors="none", edgecolors="#ffcc00",
                linestyles="dashed", linewidths=2.2, zorder=9,
                label="Loop Intersect",
            )
            ax.add_collection(inter_col)
        if intersect_pts:
            arr = np.array(intersect_pts, dtype=float)
            ax.scatter(arr[:, 0], arr[:, 1], s=170, facecolors="none", edgecolors="#ffcc00", marker="D", linewidths=2.2, zorder=15, label="Loop Intersect Center")
        for probe in (result.probe_circles or []):
            cx, cy = probe["center"]
            r = float(probe.get("radius", 0.0))
            if r > 0:
                th = np.linspace(0.0, 2.0 * math.pi, 49)
                ax.plot(cx + r * np.cos(th), cy + r * np.sin(th), color="#00ff88", lw=1.8, ls="--", zorder=16)
            ax.plot([cx], [cy], marker="+", markersize=12, color="#00ff88", mew=2.0, zorder=16)
            ax.annotate(
                str(probe.get("probe_id", "PROBE")), xy=(cx, cy), xytext=(cx + 2.0, cy + 2.0),
                color="#00ff88", fontsize=8, zorder=17,
            )
        if ov_segs:
            ov_col = LineCollection(ov_segs, colors="#ff00ff", linewidths=4.8, alpha=0.85, zorder=8, label="Overlap Segment")
            ax.add_collection(ov_col)
        if ov_pts:
            arr = np.array(ov_pts, dtype=float)
            ax.scatter(arr[:, 0], arr[:, 1], s=130, facecolors="none", edgecolors="#ff00ff", linewidths=2.2, zorder=11, label="Overlap Endpoint")
        if open_pts:
            arr = np.array(open_pts, dtype=float)
            ax.scatter(arr[:, 0], arr[:, 1], s=170, facecolors="none", edgecolors="#ff2244", linewidths=2.5, zorder=12, label="Open Endpoint (Deg=1)")
            ax.scatter(arr[:, 0], arr[:, 1], s=50, c="#ff2244", marker="+", linewidths=1.8, zorder=12)
        if junc_pts:
            arr = np.array(junc_pts, dtype=float)
            ax.scatter(arr[:, 0], arr[:, 1], s=150, facecolors="none", edgecolors="#ff9900", marker="o", linewidths=2.2, zorder=10, label="Multi-Junction (Deg>=3)")
        if gap_pts:
            arr = np.array(gap_pts, dtype=float)
            ax.scatter(arr[:, 0], arr[:, 1], s=160, facecolors="none", edgecolors="#ffff00", marker="D", linewidths=2.2, zorder=13, label="Micro-Gap / Degenerate")
        counts = result.summary_dict()
        n_ov = counts["EXACT_DUPLICATE"] + counts["CONTAINMENT"] + counts["PARTIAL_OVERLAP"]
        status_color = "#00ff88" if result.is_clean else "#ff3355"
        hud_text = (
            f"STATUS: {'CLEAN (PASS)' if result.is_clean else 'ISSUES FOUND'}\n"
            f"Raw Lines: {len(result.raw_line_segments)} -> Clean Lines: {len(result.clean_line_segments)}   |   "
            f"Overlaps(Purple): {n_ov}   |   Open Ends(Red): {counts['OPEN_ENDPOINT']}   |   "
            f"Junctions(Orange): {counts['MULTI_JUNCTION']}   |   Gaps(Yellow): {counts['MICRO_GAP'] + counts['DEGENERATE']}   |   "
            f"Islands(Cyan): {counts['EXTERIOR_ISLAND'] + counts['NESTED_ISLAND']}   |   "
            f"Loop X(Yellow): {counts['LOOP_INTERSECT']}"
        )
        ax.text(
            0.015, 0.975, hud_text, transform=ax.transAxes,
            color=status_color, fontsize=9.5, fontweight="bold", va="top", ha="left", zorder=20,
            bbox=dict(boxstyle="round,pad=0.35", facecolor="#161616", edgecolor="#444444", alpha=0.92),
        )
        ax.set_aspect("equal", adjustable="datalim")
        if focus_issue_id is not None:
            target = next((x for x in result.issues if x.issue_id == focus_issue_id), None)
            if target is not None:
                fx, fy = target.focus_xy
                ax.set_xlim(fx - 12.0, fx + 12.0)
                ax.set_ylim(fy - 8.0, fy + 8.0)
                ax.annotate(
                    f"#{target.issue_id} {target.issue_type}",
                    xy=(fx, fy), xytext=(fx + 2.0, fy + 2.0),
                    color="#ffff00", fontsize=9, fontweight="bold",
                    arrowprops=dict(arrowstyle="->", color="#ffff00", lw=1.5),
                    zorder=25,
                )
        elif bg_segs:
            all_xy = np.vstack([np.array(bg_segs).reshape(-1, 2)])
            xmin, ymin = all_xy.min(axis=0)
            xmax, ymax = all_xy.max(axis=0)
            dx = max(xmax - xmin, 10.0) * 0.12
            dy = max(ymax - ymin, 10.0) * 0.12
            ax.set_xlim(xmin - dx, xmax + dx)
            ax.set_ylim(ymin - dy, ymax + dy)
        handles_leg, labels_leg = ax.get_legend_handles_labels()
        if handles_leg:
            ax.legend(loc="lower right", facecolor="#181818", edgecolor="#444444", labelcolor="#dddddd", fontsize=8)
        return created_fig, ax
