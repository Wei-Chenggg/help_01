import os
import re
import math
import time
import ezdxf
import numpy as np
import matplotlib
from matplotlib.collections import LineCollection
from finite_ele_toolbox.dxf_editting_helper import DXFEditingHelper, DEFAULT_BRUSH_STYLES
from finite_ele_toolbox.dxf_contour_helper import DXFContourHelper, ContourHyperParams
from finite_ele_toolbox.finite_ele_mesh_helper import FiniteEleMeshHelper, MeshHyperParams
from finite_ele_toolbox.finite_ele_solver_helper import (
    FiniteEleSolverHelper,
    SolverHyperParams,
    MATERIALS,
    VIEW_MODES,
)

# 設定 Matplotlib 支援繁體中文字型與負號顯示
matplotlib.rcParams["font.sans-serif"] = ["Microsoft JhengHei", "SimHei", "Arial"]
matplotlib.rcParams["axes.unicode_minus"] = False


# ==============================================================================
# 1. 前端 UI 控制元件名稱定義 (供前端 CSV 佈局對接，缺件時自動安全略過)
# ==============================================================================
UI_CTRLS = {
    # 主顯示區：TK_Figure
    "figure":           "fig_dxf",
    "figure_fallback":  "fig_1",

    # 畫筆 (DXF 圖層) 與幾何落筆工具控制
    "combo_brush":      "list_dxf_brush",     # combo: 選擇畫筆圖層
    "btn_next_brush":   "btn_dxf_next_brush", # single button: 換圖層 (Q)
    "combo_tool":       "list_dxf_tool",      # combo: 選擇落筆幾何工具 (可選)
    "btn_next_tool":    "btn_dxf_next_tool",  # single button: 換落筆工具 (W) (可選)
    "btn_del_ent":      "btn_dxf_del_ent",    # single button: 刪除停駐圖元 (E)

    # DISP (mm) / FORCE (gf) 數值設定
    "ety_bc_x":         "ety_dxf_bc_x",       # entry (float): X 分量 (mm 或 gf)
    "ety_bc_y":         "ety_dxf_bc_y",       # entry (float): Y 分量 (mm 或 gf)
    "btn_update_brush": "btn_dxf_upd_brush",  # single button: 套用 X/Y 到當前畫筆

    # 檔案讀寫與視角
    "ety_dxf_in":       "ety_dxf_in_path",    # entry (str): 讀取 DXF 路徑
    "btn_load_dxf":     "btn_dxf_load",       # single button: 載入 DXF
    "ety_dxf_out":      "ety_dxf_out_path",   # entry (str): 儲存 DXF 路徑
    "btn_save_dxf":     "btn_dxf_save",       # single button: 儲存 DXF
    "btn_fit_view":     "btn_dxf_fit",        # single button: 重置視角 (Autoscale)

    # 狀態與日誌回饋
    "lb_status":        "lb_dxf_status",
    "lb_status_fb":     "lb_info",
    "txt_log":          "txt_dxf_log",
    "txt_log_fb":       "txt_log_x1",

    # 輪廓 / 去重檢查頁 (fm_left_bottom page2 + fm_right_bottom page4)
    "figure_check":     "fig_dxf_check",      # figure: 圈圈標記檢查圖
    "btn_check":        "btn_dxf_check",      # single button: 執行輪廓與去重檢查
    "combo_issues":     "list_dxf_issues",    # combo: 問題清單
    "btn_zoom_issue":   "btn_dxf_zoom_issue", # single button: 放大定位
    "btn_auto_dedup":   "btn_dxf_auto_dedup", # single button: 一鍵自動去重/切分
    "page_check":       "bpg_r4",             # page button: 切到「去重檢查」頁

    # 有限元網格生成頁 (fm_left_bottom page3 + fm_right_bottom page5)
    "figure_mesh":      "fig_dxf_mesh",       # figure: T6 網格畫布
    "ety_mesh_hmax":    "ety_mesh_hmax",      # entry (float_2): 最大網格尺寸
    "ety_mesh_hmin":    "ety_mesh_hmin",      # entry (float_2): 最小網格尺寸
    "ety_mesh_grad":    "ety_mesh_grad",      # entry (float_2): 漸變率
    "btn_mesh_auto":    "btn_mesh_auto",      # binary button: 自適應加密開關
    "btn_mesh_mid":     "btn_mesh_mid",       # binary button: 顯示 T6 中點開關
    "btn_mesh_gen":     "btn_mesh_gen",       # single button: 生成 T6 有限元網格
    "lb_mesh_info":     "lb_mesh_info",       # label: 網格統計摘要
    "page_mesh":        "bpg_r5",             # page button: 切到「網格畫布」頁

    # FEA 求解頁 (fm_left_bottom page4 + fm_right_bottom page6)
    "figure_fea":       "fig_dxf_fea",        # figure: FEA 雲圖畫布
    "combo_fea_mat":    "list_fea_mat",       # combo: 材料
    "ety_fea_E":        "ety_fea_E",          # entry: 楊氏模數 MPa
    "ety_fea_nu":       "ety_fea_nu",         # entry: 蒲松比
    "ety_fea_thk":      "ety_fea_thk",        # entry: 厚度 mm
    "ety_fea_scale":    "ety_fea_scale",      # entry: BC 載荷倍率
    "btn_fea_large":    "btn_fea_large",      # binary: 大位移 TL-SVK 開關
    "combo_fea_view":   "list_fea_view",      # combo: 雲圖模式
    "btn_fea_solve":    "btn_fea_solve",      # single: 執行 FEA 求解
    "combo_fea_probes": "list_fea_probes",    # combo: PROBE 清單
    "lb_fea_info":      "lb_fea_info",        # label: FEA 摘要
    "page_fea":         "bpg_r6",             # page button: 切到「FEA畫布」頁
}


# ==============================================================================
# 2. TK_Figure 互動式 DXF 編輯器
# ==============================================================================
class DXFFigureEditor:
    # 支援的左鍵落筆工具與所需點數
    DRAW_TOOLS = ["line", "2p-circle", "3p-circle", "3p-arc", "paint"]
    TOOL_NEED_PTS = {
        "line":      2,
        "2p-circle": 2,
        "3p-circle": 3,
        "3p-arc":    3,
        "paint":     1,
    }

    def __init__(self, machine_helper, dxf_path="./part01.dxf", bg="#0a0a0a"):
        self.helper = machine_helper
        self.ui = machine_helper.ui
        self.bg = bg
        self.dxf_path = dxf_path

        # 畫筆 (DXF 圖層) 與幾何落筆工具狀態
        self.brushes = [dict(b) for b in DEFAULT_BRUSH_STYLES]
        self.brush_idx = 0
        self.bc_serial = {"DISP": 0, "FORCE": 0}
        self.cur_tool = "line"
        self.draw_pts = []       # 落筆已點選的座標序列 [(x, y), ...]
        self.added_history = []  # 記錄新增圖元的 handle 堆疊 (供 Ctrl+Z 退回)

        # ezdxf Document 與幾何快取
        self.doc = None
        self.entities_by_handle = {}
        self.entity_segments = {}
        self.p1_arr = np.empty((0, 2))
        self.p2_arr = np.empty((0, 2))
        self.v_arr = np.empty((0, 2))
        self.c2_arr = np.empty(0)
        self.seg_handles = []

        # 吸附點快取 (ARC/CIRCLE cen+end, LINE end+mid)
        self.snap_pts_arr = np.empty((0, 2))
        self.snap_types = []
        self.enable_snap = True

        # 互動狀態
        self.hovered_handle = None
        self.snapped_pt = None
        self.snapped_type = None
        self.mouse_xy = (0.0, 0.0)
        self.pan_state = {"pressed": False, "x0": None, "y0": None}
        self._last_key_ts = 0.0

        # Matplotlib 繪圖容器與動態圖層物件
        self.tk_fig = self._find_tk_figure()
        self.fig = self.tk_fig.get_fig() if self.tk_fig else None
        self.ax = self.tk_fig.get_ax() if self.tk_fig else None
        self.layer_collections = {}
        self.hover_col = None
        self.preview_line = None
        self.snap_marker = None
        self.pts_marker = None
        self.hud_brush_text = None
        self.hud_info_text = None

        # 輪廓 / 去重檢查頁狀態
        self.hp = ContourHyperParams()
        self.check_result = None
        self.issue_map = {}
        self.tk_fig_check = self._find_check_figure()
        self.ax_check = self.tk_fig_check.get_ax() if self.tk_fig_check else None
        self.check_pan = {"pressed": False, "x0": None, "y0": None}

        # 有限元網格頁狀態
        self.mesh_hp = MeshHyperParams()
        self.mesh_result = None
        self.tk_fig_mesh = self._find_mesh_figure()
        self.ax_mesh = self.tk_fig_mesh.get_ax() if self.tk_fig_mesh else None
        self.mesh_pan = {"pressed": False, "x0": None, "y0": None}

        # FEA 求解頁狀態
        self.fea_hp = SolverHyperParams()
        self.fea_result = None
        self.fea_mode = VIEW_MODES[0]
        self.tk_fig_fea = self._find_fea_figure()
        self.ax_fea = self.tk_fig_fea.get_ax() if self.tk_fig_fea else None
        self.fea_pan = {"pressed": False, "x0": None, "y0": None}
        self.fea_probe_map = {}

        self._init_plot_artists()
        self.load_dxf(self.dxf_path, explode_lwpolyline=True, fit_view=True)
        self._bind_events()
        self._init_mesh_controls()
        self._init_fea_controls()

    # ==================================================================
    # 公開 API 1：畫筆 (DXF 圖層)、DISP/FORCE 數值設定與工具切換
    # ==================================================================
    @property
    def cur_brush(self) -> dict:
        return self.brushes[self.brush_idx]

    @property
    def cur_layer(self) -> str:
        return self.cur_brush["name"]

    @property
    def brush_names(self) -> list[str]:
        return [b["name"] for b in self.brushes]

    @staticmethod
    def format_bc_layer_name(bc_type: str, x: float = 0.0, y: float = 0.0) -> str:
        """將 FIXED / PROBE / DISP (mm) / FORCE (gf) 格式化為標準 DXF 圖層名稱。"""
        return DXFEditingHelper.format_bc_layer_name(bc_type, x, y)

    @staticmethod
    def parse_bc_layer_name(layer_name: str) -> dict:
        """解析 DXF 圖層名稱，回傳結構化邊界條件資訊 (供 FEA / MESH / OPTIMIZER 使用)。"""
        return DXFEditingHelper.parse_bc_layer_name(layer_name)

    def set_bc_brush(self, bc_type: str = None, x: float = None, y: float = None) -> str:
        """依 UI 的 X/Y 產生下一個流水號 BC 畫筆並切換過去。

        - 圖層名稱：DISP#001_X-1Y0.1 / FORCE#002_X-200Y0（x 單位 mm、y 單位 mm；FORCE 為 gf）
        - 若目前畫筆是同類型且「圖面上還沒被任何圖元使用」，直接原地刷掉該槽位（不留空號）
        - 若舊畫筆已經畫了東西，則保留它並新增一支流水號畫筆
        """
        ety_x = self._ctrl("ety_bc_x")
        ety_y = self._ctrl("ety_bc_y")
        if x is None:
            x = ety_x.value() if ety_x is not None else -100.0
        if y is None:
            y = ety_y.value() if ety_y is not None else 10.0

        cur_parsed = self.parse_bc_layer_name(self.cur_layer)
        if bc_type is None:
            bc_type = cur_parsed.get("type") if cur_parsed.get("type") in ("DISP", "FORCE") else "DISP"
        bc_type = str(bc_type).strip().upper()
        seq = self._next_bc_serial(bc_type)
        new_name = DXFEditingHelper.format_bc_layer_name(bc_type, x, y, seq=seq)

        used_layers = {e.dxf.layer for e in self.doc.modelspace()} if self.doc is not None else set()
        if cur_parsed.get("type") == bc_type and self.cur_layer not in used_layers:
            self.brushes[self.brush_idx]["name"] = new_name
        else:
            st = DXFEditingHelper.get_layer_style(new_name)
            self.brushes.append({
                "name": new_name,
                "colors": st["colors"],
                "linewidths": st["linewidths"],
                "linestyles": st["linestyles"],
                "zorder": st["zorder"],
                "dxf_color": st["dxf_color"],
            })
            self.brush_idx = len(self.brushes) - 1
        self._ensure_layer(new_name)

        if ety_x is not None:
            ety_x.value(x)
        if ety_y is not None:
            ety_y.value(y)
        cb = self._ctrl("combo_brush")
        if cb is not None:
            cb.options(self.brush_names)
            cb.set(value=new_name)

        self.rebuild_scene(fit_view=False)
        unit = "mm" if bc_type == "DISP" else "gf"
        self._log(f"新增 {bc_type} 畫筆: [{new_name}] (X={x:g} {unit}, Y={y:g} {unit})")
        return new_name

    def switch_layer(self, target="next") -> str:
        """按下 Q 切換當前畫筆 (DXF 圖層)。"""
        if target == "next" or target is None:
            self.brush_idx = (self.brush_idx + 1) % len(self.brushes)
        elif isinstance(target, int):
            self.brush_idx = target % len(self.brushes)
        elif isinstance(target, str) and target in self.brush_names:
            self.brush_idx = self.brush_names.index(target)

        if self.doc is not None and self.cur_layer not in self.doc.layers:
            self.doc.layers.add(name=self.cur_layer, color=self.cur_brush.get("dxf_color", 7))

        if self.preview_line is not None:
            self.preview_line.set_color(self.cur_brush["colors"])

        # 若切到 DISP 或 FORCE 畫筆，自動將其 X, Y 數值同步顯示到左側輸入框
        parsed = self.parse_bc_layer_name(self.cur_layer)
        if parsed["type"] in ("DISP", "FORCE"):
            ety_x = self._ctrl("ety_bc_x")
            ety_y = self._ctrl("ety_bc_y")
            if ety_x is not None:
                ety_x.value(parsed["x"])
            if ety_y is not None:
                ety_y.value(parsed["y"])

        cb = self._ctrl("combo_brush")
        if cb is not None and cb.value() != self.cur_layer:
            cb.set(value=self.cur_layer)

        self._update_hud()
        self._draw_idle()
        self._log(f"[Q] 切換畫筆圖層 -> {self.cur_layer}")
        return self.cur_layer

    def set_draw_tool(self, tool="next") -> str:
        """按下 W 切換左鍵落筆幾何工具: line / 2p-circle / 3p-circle / 3p-arc / paint。"""
        if tool == "next" or tool is None:
            idx = (self.DRAW_TOOLS.index(self.cur_tool) + 1) % len(self.DRAW_TOOLS)
            self.cur_tool = self.DRAW_TOOLS[idx]
        elif tool in self.DRAW_TOOLS:
            self.cur_tool = tool
        self.cancel_drawing(silent=True)

        cb_tool = self._ctrl("combo_tool")
        if cb_tool is not None and cb_tool.value() != self.cur_tool:
            cb_tool.set(value=self.cur_tool)

        need = self.TOOL_NEED_PTS[self.cur_tool]
        self._update_hud()
        self._draw_idle()
        self._log(f"[W] 切換落筆工具 -> [{self.cur_tool}] (需點選 {need} 點)")
        return self.cur_tool

    def get_bc_summary(self) -> dict:
        """匯出全圖各圖層的邊界條件解析結果與圖元 Handle 清單，供 MESH / FEA 使用。"""
        if self.doc is None:
            return {}
        return DXFEditingHelper.get_bc_summary(self.doc.modelspace())

    # ==================================================================
    # 公開 API 2：程式化與互動式幾何繪製 (Line / 2P-Circle / 3P-Circle / 3P-Arc / Paint)
    # ==================================================================
    @staticmethod
    def _calc_circle_2p(p1, p2):
        """2點圓：p1 為圓心 (cent)，p2 為圓周上一點。"""
        return DXFEditingHelper.circle_from_2_points(p1, p2)

    @staticmethod
    def _calc_circle_3p(p1, p2, p3):
        return DXFEditingHelper.circle_from_3_points(p1, p2, p3)

    @classmethod
    def _calc_arc_3p(cls, p1, p2, p3):
        """由起點 p1、弧上點 p2、終點 p3 計算 (center, radius, start_angle_deg, end_angle_deg)。"""
        return DXFEditingHelper.arc_from_3_points(p1, p2, p3)

    def _ensure_layer(self, layer: str = None) -> str:
        lay = layer or self.cur_layer
        return DXFEditingHelper.ensure_layer(self.doc, lay)

    def _next_probe_layer_name(self) -> str:
        return DXFEditingHelper.next_probe_layer_name(self.doc)

    def _next_bc_serial(self, bc_type: str) -> int:
        btype = str(bc_type).upper()
        self.bc_serial[btype] = self.bc_serial.get(btype, 0) + 1
        return self.bc_serial[btype]

    def _sync_bc_serial(self):
        if self.doc is None:
            return
        for ent in self.doc.modelspace():
            info = self.parse_bc_layer_name(ent.dxf.layer)
            btype = info.get("type")
            if btype in ("DISP", "FORCE") and info.get("seq"):
                self.bc_serial[btype] = max(self.bc_serial.get(btype, 0), int(info["seq"]))

    def _promote_bc_brush(self, parsed: dict) -> str:
        btype = parsed.get("type")
        seq = self._next_bc_serial(btype)
        new_name = DXFEditingHelper.format_bc_layer_name(
            btype, parsed.get("x", 0.0), parsed.get("y", 0.0), seq=seq
        )
        self.brushes[self.brush_idx]["name"] = new_name
        cb = self._ctrl("combo_brush")
        if cb is not None:
            cb.options(self.brush_names)
            cb.set(value=new_name)
        self._log(f"[BC] 畫筆轉為流水號圖層: [{new_name}]")
        return new_name

    def _resolve_draw_layer(self, layer: str = None, for_circle: bool = False) -> str:
        if layer is not None:
            return layer
        lay = self.cur_layer
        parsed = self.parse_bc_layer_name(lay)
        btype = parsed.get("type")
        if for_circle and btype == "PROBE":
            return self._next_probe_layer_name()
        if btype in ("DISP", "FORCE") and parsed.get("seq") is None:
            return self._promote_bc_brush(parsed)
        return lay

    def add_line(self, p1, p2, layer: str = None):
        lay = self._ensure_layer(layer)
        ent = DXFEditingHelper.add_line(self.doc.modelspace(), p1, p2, lay)
        if ent is None:
            return None
        self.added_history.append(ent.dxf.handle)
        self.rebuild_scene(fit_view=False)
        self._log(f"[新增 LINE #{ent.dxf.handle}] Layer={lay} | ({p1[0]:.2f},{p1[1]:.2f})->({p2[0]:.2f},{p2[1]:.2f})")
        return ent

    def add_circle_2p(self, p1, p2, layer: str = None):
        cen, r = self._calc_circle_2p(p1, p2)
        lay = self._ensure_layer(self._resolve_draw_layer(layer, for_circle=True))
        ent = DXFEditingHelper.add_circle_2p(self.doc.modelspace(), p1, p2, lay)
        if ent is None:
            return None
        self.added_history.append(ent.dxf.handle)
        self.rebuild_scene(fit_view=False)
        self._log(f"[新增 2P-CIRCLE(圓心->圓周) #{ent.dxf.handle}] Layer={lay} | Cen=({cen[0]:.2f},{cen[1]:.2f}), R={r:.2f}")
        return ent

    def add_circle_3p(self, p1, p2, p3, layer: str = None):
        cen, r = self._calc_circle_3p(p1, p2, p3)
        if cen is None or r < 1e-6:
            self._log("[警告] 三點共線，無法建立 3P-Circle")
            return None
        lay = self._ensure_layer(self._resolve_draw_layer(layer, for_circle=True))
        ent = DXFEditingHelper.add_circle_3p(self.doc.modelspace(), p1, p2, p3, lay)
        if ent is None:
            return None
        self.added_history.append(ent.dxf.handle)
        self.rebuild_scene(fit_view=False)
        self._log(f"[新增 3P-CIRCLE #{ent.dxf.handle}] Layer={lay} | Cen=({cen[0]:.2f},{cen[1]:.2f}), R={r:.2f}")
        return ent

    def add_arc_3p(self, p1, p2, p3, layer: str = None):
        cen, r, a_start, a_end = self._calc_arc_3p(p1, p2, p3)
        if cen is None:
            self._log("[警告] 三點共線，無法建立 3P-Arc")
            return None
        lay = self._ensure_layer(layer)
        ent = DXFEditingHelper.add_arc_3p(self.doc.modelspace(), p1, p2, p3, lay)
        if ent is None:
            return None
        self.added_history.append(ent.dxf.handle)
        self.rebuild_scene(fit_view=False)
        self._log(
            f"[新增 3P-ARC #{ent.dxf.handle}] Layer={lay} | "
            f"Cen=({cen[0]:.2f},{cen[1]:.2f}), R={r:.2f}, Ang={a_start:.1f}°~{a_end:.1f}°"
        )
        return ent

    def undo_last_added(self) -> bool:
        """按下 Ctrl+Z：退回最後一次添加的圖元。
        若正在連續畫線 (line) 中，刪除最後一段後自動將起點退回該段起點，可繼續接著畫！
        """
        was_chaining_line = (self.cur_tool == "line" and len(self.draw_pts) == 1)

        while self.added_history:
            last_handle = self.added_history.pop()
            ent = self.entities_by_handle.get(last_handle)
            if ent is not None:
                info = self._format_entity_info(ent)
                prev_start = None
                if was_chaining_line and ent.dxftype() == "LINE":
                    prev_start = (float(ent.dxf.start.x), float(ent.dxf.start.y))

                self.doc.modelspace().delete_entity(ent)
                self.rebuild_scene(fit_view=False)

                if prev_start is not None:
                    self.draw_pts = [prev_start]
                    end_pt = self.snapped_pt if self.snapped_pt is not None else self.mouse_xy
                    self._update_rubberband_preview(end_pt)
                    self._update_hud()
                    self._draw_idle()
                elif self.draw_pts:
                    self.cancel_drawing(silent=True)

                self._log(f"[Ctrl+Z] 已退回最後新增圖元 -> {info}")
                return True

        if self.draw_pts:
            self.cancel_drawing()
            return True

        self._log("[Ctrl+Z] 目前沒有可退回的新增圖元")
        return False

    def paint_entity_layer(self, handle: str = None, layer: str = None) -> bool:
        """將停駐圖元 (或指定 handle) 的圖層直接改為當前畫筆圖層 (快捷鍵 F 或 paint 工具)。"""
        h = handle or self.hovered_handle
        if h is None or h not in self.entities_by_handle:
            self._log("[塗層] 請先將滑鼠停駐於目標線段/圓弧上，再按 F 或用 paint 點擊")
            return False
        ent = self.entities_by_handle[h]
        old_lay = ent.dxf.layer
        new_lay = self._ensure_layer(self._resolve_draw_layer(layer, for_circle=(ent.dxftype() == "CIRCLE")))
        if not DXFEditingHelper.paint_entity_layer(self.doc, h, new_lay):
            return False
        self.rebuild_scene(fit_view=False)
        self._log(f"[塗層成功] [{ent.dxftype()} #{h}] 圖層已由 [{old_lay}] 改為 [{new_lay}]")
        return True

    # ==================================================================
    # 公開 API 3：輪廓 / 去重檢查頁 (fig_dxf_check + list_dxf_issues)
    # ==================================================================
    def _find_check_figure(self):
        ctrl = self._ctrl("figure_check")
        if ctrl is not None and getattr(ctrl, "ax", None) is not None:
            return ctrl
        return None

    def run_contour_check(self, focus_issue_id: int = None):
        """掃描當前 DXF，畫圈圈標記到 fig_dxf_check 並切到「去重檢查」頁。"""
        if self.doc is None:
            return None
        if self.tk_fig_check is None:
            self._log("[檢查] 找不到 fig_dxf_check，請確認控件 CSV 的 page4 figure")
            return None
        self.check_result = DXFContourHelper.check_dxf(self.doc, hp=self.hp)
        self._refresh_check_plot(focus_issue_id)
        self._fill_issue_combo()
        self._switch_to_check_page()
        counts = self.check_result.summary_dict()
        n_ov = counts["EXACT_DUPLICATE"] + counts["CONTAINMENT"] + counts["PARTIAL_OVERLAP"]
        self._log(
            f"檢查完成: {'CLEAN (PASS)' if self.check_result.is_clean else 'ISSUES FOUND'} | "
            f"直線 {len(self.check_result.raw_line_segments)} -> 去重後 {len(self.check_result.clean_line_segments)}"
        )
        self._log_detail(
            f"重疊(紫)={n_ov} 懸空(紅)={counts['OPEN_ENDPOINT']} 分岔(橘)={counts['MULTI_JUNCTION']} "
            f"微縫/退化(黃)={counts['MICRO_GAP'] + counts['DEGENERATE']} "
            f"端點相接(INFO)={counts['HEAD_TO_TAIL']} 問題總數={len(self.check_result.issues)}"
        )
        for iss in self.check_result.issues:
            self._log_detail(f"  [#{iss.issue_id:02d}] [{iss.severity}] [{iss.issue_type}] {iss.description}")
        return self.check_result

    def zoom_to_selected_issue(self):
        """依 list_dxf_issues 目前選項，把檢查畫布放大到該問題位置。"""
        if self.check_result is None:
            self._log("[放大定位] 請先執行輪廓與去重檢查")
            return
        cb = self._ctrl("combo_issues")
        label = cb.value() if cb is not None else ""
        iid = self.issue_map.get(label)
        if iid is None:
            self._log("[放大定位] 請先在問題清單中選擇一項")
            return
        self._refresh_check_plot(iid)
        self._switch_to_check_page()
        self._log(f"[放大定位] 已聚焦問題 #{iid}")

    def auto_dedup_contours(self):
        """對當前 doc 原地執行切分/去重，並同步主編輯畫布與檢查畫布。"""
        if self.doc is None:
            return
        self.check_result = DXFContourHelper.apply_auto_dedup_to_doc(self.doc, hp=self.hp)
        self.rebuild_scene(fit_view=False)
        self._refresh_check_plot()
        self._fill_issue_combo()
        self._switch_to_check_page()
        counts = self.check_result.summary_dict()
        self._log(
            f"[一鍵去重] 完成，直線 {len(self.check_result.raw_line_segments)} -> "
            f"{len(self.check_result.clean_line_segments)}"
        )
        self._log_detail(f"[一鍵去重] 剩餘問題: {counts}")

    def _refresh_check_plot(self, focus_issue_id: int = None):
        if self.tk_fig_check is None:
            return
        if self.ax_check is None:
            self.ax_check = self.tk_fig_check.get_ax()
        if self.ax_check is None or self.check_result is None:
            return
        DXFContourHelper.plot_check_result(
            self.check_result, ax=self.ax_check, focus_issue_id=focus_issue_id
        )
        self.tk_fig_check.draw()

    def _fill_issue_combo(self):
        cb = self._ctrl("combo_issues")
        if cb is None or self.check_result is None:
            return
        self.issue_map = {}
        labels = []
        for iss in self.check_result.issues:
            label = f"#{iss.issue_id:02d} {iss.issue_type} [{iss.severity}] {iss.layer_a}"
            self.issue_map[label] = iss.issue_id
            labels.append(label)
        cb.options(labels)

    def _switch_to_check_page(self):
        pb = self._ctrl("page_check")
        if pb is not None:
            pb.activate()

    def _log_detail(self, msg: str):
        log = self._ctrl("txt_log") or self._ctrl("txt_log_fb")
        if log is not None:
            log.write_async(f"[DXFEditor] {msg}")

    # ==================================================================
    # 公開 API 4：T6 有限元網格生成頁 (fig_dxf_mesh + lb_mesh_info)
    # ==================================================================
    def _find_mesh_figure(self):
        ctrl = self._ctrl("figure_mesh")
        if ctrl is not None and getattr(ctrl, "ax", None) is not None:
            return ctrl
        return None

    def _init_mesh_controls(self):
        for key, val in (
            ("ety_mesh_hmax", self.mesh_hp.h_max),
            ("ety_mesh_hmin", self.mesh_hp.h_min),
            ("ety_mesh_grad", self.mesh_hp.gradation),
        ):
            ctrl = self._ctrl(key)
            if ctrl is not None:
                ctrl.value(val)
        auto = self._ctrl("btn_mesh_auto")
        if auto is not None:
            auto.on()
        mid = self._ctrl("btn_mesh_mid")
        if mid is not None:
            mid.on()

    def _read_mesh_num(self, key, default):
        ctrl = self._ctrl(key)
        try:
            val = ctrl.value() if ctrl is not None else default
            return float(val)
        except (TypeError, ValueError):
            return float(default)

    def run_mesh_generation(self):
        """從當前 self.doc 生成 T6 自適應網格，繪製於 fig_dxf_mesh 並切到「網格畫布」頁。"""
        if self.doc is None:
            return None
        if self.tk_fig_mesh is None:
            self._log("[網格] 找不到 fig_dxf_mesh，請確認控件 CSV 的 page5 figure")
            return None
        self.mesh_hp.h_max = self._read_mesh_num("ety_mesh_hmax", self.mesh_hp.h_max)
        self.mesh_hp.h_min = self._read_mesh_num("ety_mesh_hmin", self.mesh_hp.h_min)
        self.mesh_hp.gradation = self._read_mesh_num("ety_mesh_grad", self.mesh_hp.gradation)
        if self.mesh_hp.h_min > self.mesh_hp.h_max:
            self.mesh_hp.h_min = self.mesh_hp.h_max
        auto = self._ctrl("btn_mesh_auto")
        if auto is not None:
            self.mesh_hp.auto_density = bool(auto.is_on())
        try:
            self.mesh_result = FiniteEleMeshHelper.build_t6_mesh_from_dxf(self.doc, hp=self.mesh_hp)
        except Exception as exc:
            self._log(f"[網格錯誤] {exc}")
            return None
        for lay, ginfo in (self.mesh_result.get("bc_groups") or {}).items():
            ginfo.update(self.parse_bc_layer_name(lay))
        self._refresh_mesh_plot()
        self._switch_to_mesh_page()
        n_nodes = len(self.mesh_result["nodes"])
        n_elem = len(self.mesh_result["elements"])
        size_txt = ""
        areas = self.mesh_result.get("areas")
        if areas is not None and len(areas):
            char_len = np.sqrt(2.0 * np.asarray(areas, dtype=float))
            size_txt = f" | {char_len.min():.2f}~{char_len.max():.2f} mm"
        info = f"T6: {n_elem} 元素 / {n_nodes} 節點{size_txt} | {self.mesh_result['elapsed_ms']:.0f} ms"
        lb = self._ctrl("lb_mesh_info")
        if lb is not None:
            lb.text(info)
        self._log(f"[網格] {info}")
        bc_lines = ", ".join(
            f"{k}:{len(v.get('node_ids', []))}" for k, v in (self.mesh_result.get("bc_groups") or {}).items()
        )
        if bc_lines:
            self._log_detail(f"[網格] BC 節點數 {bc_lines}")
        return self.mesh_result

    def _refresh_mesh_plot(self):
        if self.tk_fig_mesh is None or self.mesh_result is None:
            return
        if self.ax_mesh is None:
            self.ax_mesh = self.tk_fig_mesh.get_ax()
        if self.ax_mesh is None:
            return
        mid = self._ctrl("btn_mesh_mid")
        show_mid = bool(mid.is_on()) if mid is not None else True
        FiniteEleMeshHelper.plot_t6_mesh_on_ax(self.mesh_result, ax=self.ax_mesh, show_mid_nodes=show_mid)
        self.tk_fig_mesh.draw()

    def _switch_to_mesh_page(self):
        pb = self._ctrl("page_mesh")
        if pb is not None:
            pb.activate()

    # ==================================================================
    # 公開 API 5：T6 大位移 FEA 求解頁 (fig_dxf_fea + PROBE 查詢)
    # ==================================================================
    def _find_fea_figure(self):
        ctrl = self._ctrl("figure_fea")
        if ctrl is not None and getattr(ctrl, "ax", None) is not None:
            return ctrl
        return None

    def _init_fea_controls(self):
        cb_mat = self._ctrl("combo_fea_mat")
        if cb_mat is not None:
            cb_mat.options(list(MATERIALS.keys()))
            cb_mat.set(value=self.fea_hp.material)
            cb_mat.on_change = lambda name, val: self._apply_material(val)
        cb_view = self._ctrl("combo_fea_view")
        if cb_view is not None:
            cb_view.options(list(VIEW_MODES))
            cb_view.set(value=self.fea_mode)
            cb_view.on_change = lambda name, val: self._set_fea_view(val)
        cb_probe = self._ctrl("combo_fea_probes")
        if cb_probe is not None:
            cb_probe.on_change = lambda name, val: self._show_fea_probe(val)
        for key, val in (
            ("ety_fea_E", self.fea_hp.E_mpa),
            ("ety_fea_nu", self.fea_hp.nu),
            ("ety_fea_thk", self.fea_hp.thickness_mm),
            ("ety_fea_scale", self.fea_hp.deform_scale),
        ):
            ctrl = self._ctrl(key)
            if ctrl is not None:
                ctrl.value(val)
        large = self._ctrl("btn_fea_large")
        if large is not None:
            large.on()

    def _apply_material(self, name):
        info = MATERIALS.get(str(name))
        if not info:
            return
        self.fea_hp.material = str(name)
        self.fea_hp.E_mpa = float(info["E_mpa"])
        self.fea_hp.nu = float(info["nu"])
        self.fea_hp.yield_mpa = float(info["yield_mpa"])
        for key, val in (("ety_fea_E", self.fea_hp.E_mpa), ("ety_fea_nu", self.fea_hp.nu)):
            ctrl = self._ctrl(key)
            if ctrl is not None:
                ctrl.value(val)
        self._log(f"[FEA] 材料 -> {name} (E={self.fea_hp.E_mpa:g} MPa, nu={self.fea_hp.nu:g}, Sy={self.fea_hp.yield_mpa:g} MPa)")

    def _set_fea_view(self, mode):
        if mode not in VIEW_MODES:
            return
        self.fea_mode = str(mode)
        self._refresh_fea_plot()

    def _show_fea_probe(self, label):
        pid = self.fea_probe_map.get(str(label))
        if pid is None or not self.fea_result:
            return
        info = (self.fea_result.get("probes") or {}).get(pid)
        if info is None:
            return
        txt = (
            f"{pid} -> Node #{info['node_id']} | dx={info['dx']:+.4f} dy={info['dy']:+.4f} "
            f"|d|={info['dxy']:.4f} mm | vm={info['stress']:.2f} MPa | "
            f"θd={info['disp_theta']:+.2f}° θr={info['rot_theta']:+.2f}°"
        )
        lb = self._ctrl("lb_fea_info")
        if lb is not None:
            lb.text(txt)
        self._log_detail(f"[FEA] {txt}")

    def run_fea_solve(self):
        if self.mesh_result is None:
            self._log("[FEA] 請先在「網格劃分」頁生成 T6 網格")
            return None
        if self.tk_fig_fea is None:
            self._log("[FEA] 找不到 fig_dxf_fea，請確認控件 CSV 的 page6 figure")
            return None
        self.fea_hp.E_mpa = self._read_mesh_num("ety_fea_E", self.fea_hp.E_mpa)
        self.fea_hp.nu = self._read_mesh_num("ety_fea_nu", self.fea_hp.nu)
        self.fea_hp.thickness_mm = self._read_mesh_num("ety_fea_thk", self.fea_hp.thickness_mm)
        self.fea_hp.deform_scale = self._read_mesh_num("ety_fea_scale", self.fea_hp.deform_scale)
        cb_mat = self._ctrl("combo_fea_mat")
        if cb_mat is not None and cb_mat.value():
            self.fea_hp.material = cb_mat.value()
        large = self._ctrl("btn_fea_large")
        if large is not None:
            self.fea_hp.large_disp = bool(large.is_on())
        try:
            self.fea_result = FiniteEleSolverHelper.solve(self.mesh_result, hp=self.fea_hp)
        except Exception as exc:
            self._log(f"[FEA 錯誤] {exc}")
            return None
        self._refresh_fea_plot()
        self._fill_fea_probes()
        self._switch_to_fea_page()
        res = self.fea_result
        txt = (
            f"vm_max={res['max_von_mises']:.2f} MPa | SF={res['safety_factor']:.2f} | "
            f"λ={res['converged_lambda']:.3f} | {res['elapsed_ms']:.0f} ms"
        )
        lb = self._ctrl("lb_fea_info")
        if lb is not None:
            lb.text(txt)
        self._log(f"[FEA] {txt}")
        if res.get("warning"):
            self._log(f"[FEA 警告] {res['warning']}")
        for btype, rinfo in (res.get("reactions") or {}).items():
            self._log_detail(
                f"[FEA] {btype} 反力 Rx={rinfo['rx_n']:+.3f} N Ry={rinfo['ry_n']:+.3f} N "
                f"(|R|={rinfo['r_gf']:.2f} gf, n={rinfo['n_nodes']})"
            )
        for pid, pinfo in (res.get("probes") or {}).items():
            self._log_detail(
                f"[FEA] {pid} -> Node #{pinfo['node_id']} dx={pinfo['dx']:+.4f} dy={pinfo['dy']:+.4f} "
                f"|d|={pinfo['dxy']:.4f} mm vm={pinfo['stress']:.2f} MPa "
                f"θd={pinfo['disp_theta']:+.2f}° θr={pinfo['rot_theta']:+.2f}°"
            )
        return res

    def _refresh_fea_plot(self):
        if self.tk_fig_fea is None or self.fea_result is None or self.mesh_result is None:
            return
        if self.ax_fea is None:
            self.ax_fea = self.tk_fig_fea.get_ax()
        if self.ax_fea is None:
            return
        scale = self._read_mesh_num("ety_fea_scale", self.fea_hp.deform_scale)
        self.fea_hp.deform_scale = scale
        FiniteEleSolverHelper.plot_fea_on_ax(
            self.fea_result, self.mesh_result, ax=self.ax_fea, mode=self.fea_mode, deform_scale=scale
        )
        self.tk_fig_fea.draw()

    def _fill_fea_probes(self):
        cb = self._ctrl("combo_fea_probes")
        if cb is None or self.fea_result is None:
            return
        self.fea_probe_map = {}
        labels = []
        for pid, info in (self.fea_result.get("probes") or {}).items():
            label = f"{pid} | d={info['dxy']:.3f}mm vm={info['stress']:.1f}MPa"
            self.fea_probe_map[label] = pid
            labels.append(label)
        cb.options(labels)

    def _switch_to_fea_page(self):
        pb = self._ctrl("page_fea")
        if pb is not None:
            pb.activate()

    # ==================================================================
    # 步驟 A：DXF 圖元離散器 & 吸附關鍵點提取器
    # ==================================================================
    def _entity_to_segments(self, ent):
        return DXFEditingHelper.entity_to_segments(ent)

    def _entity_keypoints(self, ent) -> list[tuple[tuple[float, float], str]]:
        return DXFEditingHelper.entity_keypoints(ent)

    @staticmethod
    def _format_entity_info(ent) -> str:
        etype = ent.dxftype()
        layer = ent.dxf.layer
        handle = ent.dxf.handle
        if etype == "LINE":
            x1, y1 = float(ent.dxf.start.x), float(ent.dxf.start.y)
            x2, y2 = float(ent.dxf.end.x), float(ent.dxf.end.y)
            length = math.hypot(x2 - x1, y2 - y1)
            return f"[LINE #{handle}] Layer={layer} | Len={length:.2f} | ({x1:.1f},{y1:.1f})->({x2:.1f},{y2:.1f})"
        if etype == "ARC":
            cx, cy = float(ent.dxf.center.x), float(ent.dxf.center.y)
            r = float(ent.dxf.radius)
            a1, a2 = float(ent.dxf.start_angle), float(ent.dxf.end_angle)
            return f"[ARC #{handle}] Layer={layer} | Cen=({cx:.1f},{cy:.1f}) R={r:.2f} | Ang={a1:.0f}°~{a2:.0f}°"
        if etype == "CIRCLE":
            cx, cy = float(ent.dxf.center.x), float(ent.dxf.center.y)
            r = float(ent.dxf.radius)
            return f"[CIRCLE #{handle}] Layer={layer} | Cen=({cx:.1f},{cy:.1f}) R={r:.2f}"
        return f"[{etype} #{handle}] Layer={layer}"

    # ==================================================================
    # 步驟 B & C：載入 DXF 與批次建立/更新 LineCollection
    # ==================================================================
    def load_dxf(self, filepath: str = None, explode_lwpolyline: bool = True, fit_view: bool = True):
        if filepath is None:
            ety = self._ctrl("ety_dxf_in")
            filepath = ety.value().strip() if ety is not None and ety.value() else self.dxf_path
        self.dxf_path = filepath

        if os.path.isfile(filepath):
            self.doc = DXFEditingHelper.load_doc(filepath)
            msg = f"已載入 DXF: {filepath}"
        else:
            self.doc = ezdxf.new(dxfversion="R2010")
            self.doc.units = ezdxf.units.MM
            msg = f"找不到 {filepath}，已建立空白 DXF 畫布"

        msp = self.doc.modelspace()
        if explode_lwpolyline:
            DXFEditingHelper.explode_all_lwpolylines(msp)

        # 將 DXF 檔案中既有的 BC 圖層自動納入試算畫筆清單
        for ent in msp:
            lay = ent.dxf.layer
            if lay not in self.brush_names:
                st = DXFEditingHelper.get_layer_style(lay)
                self.brushes.append({
                    "name": lay,
                    "colors": st["colors"],
                    "linewidths": st["linewidths"],
                    "linestyles": st["linestyles"],
                    "zorder": st["zorder"],
                    "dxf_color": st["dxf_color"],
                })

        for b in self.brushes:
            if b["name"] not in self.doc.layers:
                self.doc.layers.add(name=b["name"], color=b.get("dxf_color", 7))
        self._sync_bc_serial()

        cb = self._ctrl("combo_brush")
        if cb is not None:
            cb.options(self.brush_names)
            cb.set(value=self.cur_layer)

        # 換圖後舊的檢查結果已失效，清空清單避免殘留 handle
        self.check_result = None
        self.issue_map = {}
        cb_issue = self._ctrl("combo_issues")
        if cb_issue is not None:
            cb_issue.options([])

        self.added_history.clear()
        self.rebuild_scene(fit_view=fit_view)
        self._log(msg)

    def save_dxf(self, filepath: str = None):
        if self.doc is None:
            return
        if filepath is None:
            ety = self._ctrl("ety_dxf_out")
            filepath = ety.value().strip() if ety is not None and ety.value() else self.dxf_path

        self.doc.saveas(filepath)
        self._log(f"已儲存 DXF 至: {filepath}")

    def _init_plot_artists(self):
        if self.ax is None or self.fig is None:
            return
        self.ax.clear()
        self.ax.set_facecolor(self.bg)
        self.fig.patch.set_facecolor(self.bg)
        self.ax.set_aspect("equal", adjustable="datalim")
        self.ax.tick_params(colors="#888888", labelsize=8)
        for spine in self.ax.spines.values():
            spine.set_color("#333333")

        self.hover_col = LineCollection([], colors="#00ffff", linewidths=2.8, zorder=10)
        self.ax.add_collection(self.hover_col)

        (self.preview_line,) = self.ax.plot(
            [], [], linestyle="--", linewidth=1.8, color=self.cur_brush["colors"], zorder=12
        )
        (self.pts_marker,) = self.ax.plot(
            [], [], marker="o", markersize=6, color="#00ff88", linestyle="none", zorder=13
        )
        (self.snap_marker,) = self.ax.plot(
            [], [], marker="s", markersize=8, markerfacecolor="none",
            markeredgecolor="#ffff00", markeredgewidth=2.0, linestyle="none", zorder=15
        )

        self.hud_brush_text = self.ax.text(
            0.015, 0.975, "", transform=self.ax.transAxes,
            color=self.cur_brush["colors"], fontsize=9.5, fontweight="bold",
            va="top", ha="left", zorder=20,
            bbox=dict(boxstyle="round,pad=0.35", facecolor="#181818", edgecolor="#444444", alpha=0.9),
        )
        self.hud_info_text = self.ax.text(
            0.015, 0.025, "", transform=self.ax.transAxes,
            color="#00ffff", fontsize=9.0,
            va="bottom", ha="left", zorder=20,
            bbox=dict(boxstyle="round,pad=0.35", facecolor="#181818", edgecolor="#333333", alpha=0.9),
        )

    def rebuild_scene(self, fit_view: bool = False):
        if self.ax is None or self.doc is None:
            return

        prev_xlim = self.ax.get_xlim()
        prev_ylim = self.ax.get_ylim()

        for col in self.layer_collections.values():
            try:
                col.remove()
            except Exception:
                pass
        self.layer_collections.clear()

        msp = self.doc.modelspace()
        layer_segs = {}
        self.entities_by_handle.clear()
        self.entity_segments.clear()
        all_p1, all_p2, self.seg_handles = [], [], []
        snap_pts, self.snap_types = [], []

        for ent in msp:
            segs = self._entity_to_segments(ent)
            if not segs:
                continue
            layer = ent.dxf.layer
            handle = ent.dxf.handle
            layer_segs.setdefault(layer, []).extend(segs)
            self.entities_by_handle[handle] = ent
            self.entity_segments[handle] = segs

            for p1, p2 in segs:
                all_p1.append(p1)
                all_p2.append(p2)
                self.seg_handles.append(handle)

            for pt, ktype in self._entity_keypoints(ent):
                snap_pts.append(pt)
                self.snap_types.append(ktype)

        style_lookup = {b["name"]: b for b in self.brushes}
        for layer, segs in layer_segs.items():
            st = style_lookup.get(layer) or DXFEditingHelper.get_layer_style(layer)

            col = LineCollection(
                segs,
                colors=st["colors"],
                linewidths=st["linewidths"],
                linestyles=st["linestyles"],
                zorder=st["zorder"],
            )
            self.ax.add_collection(col)
            self.layer_collections[layer] = col

        self.p1_arr = np.array(all_p1, dtype=float) if all_p1 else np.empty((0, 2))
        self.p2_arr = np.array(all_p2, dtype=float) if all_p2 else np.empty((0, 2))
        self.v_arr = self.p2_arr - self.p1_arr
        self.c2_arr = np.sum(self.v_arr * self.v_arr, axis=1) if len(self.p1_arr) else np.empty(0)
        self.snap_pts_arr = np.array(snap_pts, dtype=float) if snap_pts else np.empty((0, 2))

        if fit_view:
            self._fit_data_limits()
        else:
            self.ax.set_xlim(prev_xlim)
            self.ax.set_ylim(prev_ylim)

        self.hovered_handle = None
        if self.hover_col is not None:
            self.hover_col.set_segments([])
        self._update_hud()
        self._draw_idle()

    def _fit_data_limits(self):
        if len(self.p1_arr) == 0:
            self.ax.set_xlim(-80, 80)
            self.ax.set_ylim(-50, 50)
            return
        all_pts = np.vstack([self.p1_arr, self.p2_arr])
        xmin, ymin = np.min(all_pts, axis=0)
        xmax, ymax = np.max(all_pts, axis=0)
        dx = max(xmax - xmin, 10.0) * 0.12
        dy = max(ymax - ymin, 10.0) * 0.12
        self.ax.set_xlim(xmin - dx, xmax + dx)
        self.ax.set_ylim(ymin - dy, ymax + dy)

    # ==================================================================
    # 步驟 D：互動核心 (Hover、Snap、多點落筆預覽與完筆、刪除、塗層)
    # ==================================================================
    def _compute_hover_and_snap(self, px: float, py: float):
        xlim = self.ax.get_xlim()
        view_w = abs(xlim[1] - xlim[0])
        pick_tol = view_w * 0.015
        snap_tol = view_w * 0.018
        hover, snap_pt, snap_type, _eff = DXFEditingHelper.compute_hover_and_snap(
            px,
            py,
            self.p1_arr,
            self.p2_arr,
            self.v_arr,
            self.c2_arr,
            self.seg_handles,
            self.snap_pts_arr if self.enable_snap else np.empty((0, 2)),
            self.snap_types,
            pick_tol,
            snap_tol,
        )
        self.hovered_handle = hover
        self.snapped_pt = snap_pt
        self.snapped_type = snap_type

        if self.hovered_handle is not None:
            self.hover_col.set_segments(self.entity_segments[self.hovered_handle])
        else:
            self.hover_col.set_segments([])

        if self.snapped_pt is not None:
            self.snap_marker.set_data([self.snapped_pt[0]], [self.snapped_pt[1]])
        else:
            self.snap_marker.set_data([], [])

    def _update_rubberband_preview(self, cursor_pt):
        """根據目前落筆工具 (line / 2p-circle / 3p-circle / 3p-arc) 更新動態預覽線。"""
        if not self.draw_pts:
            self.preview_line.set_data([], [])
            self.pts_marker.set_data([], [])
            return

        xs = [p[0] for p in self.draw_pts]
        ys = [p[1] for p in self.draw_pts]
        self.pts_marker.set_data(xs, ys)
        self.preview_line.set_color(self.cur_brush["colors"])

        t = self.cur_tool
        n = len(self.draw_pts)

        if t == "line" and n == 1:
            p1 = self.draw_pts[0]
            self.preview_line.set_data([p1[0], cursor_pt[0]], [p1[1], cursor_pt[1]])

        elif t == "2p-circle" and n == 1:
            cen, r = self._calc_circle_2p(self.draw_pts[0], cursor_pt)
            if r > 1e-6:
                ang = np.linspace(0.0, 2.0 * math.pi, 65)
                self.preview_line.set_data(cen[0] + r * np.cos(ang), cen[1] + r * np.sin(ang))
            else:
                self.preview_line.set_data([], [])

        elif t == "3p-circle":
            if n == 1:
                p1 = self.draw_pts[0]
                self.preview_line.set_data([p1[0], cursor_pt[0]], [p1[1], cursor_pt[1]])
            elif n == 2:
                cen, r = self._calc_circle_3p(self.draw_pts[0], self.draw_pts[1], cursor_pt)
                if cen is not None and r > 1e-6:
                    ang = np.linspace(0.0, 2.0 * math.pi, 65)
                    self.preview_line.set_data(cen[0] + r * np.cos(ang), cen[1] + r * np.sin(ang))
                else:
                    p1, p2 = self.draw_pts
                    self.preview_line.set_data([p1[0], p2[0], cursor_pt[0]], [p1[1], p2[1], cursor_pt[1]])

        elif t == "3p-arc":
            if n == 1:
                p1 = self.draw_pts[0]
                self.preview_line.set_data([p1[0], cursor_pt[0]], [p1[1], cursor_pt[1]])
            elif n == 2:
                cen, r, a1, a2 = self._calc_arc_3p(self.draw_pts[0], self.draw_pts[1], cursor_pt)
                if cen is not None and r > 1e-6:
                    span = (a2 - a1) % 360.0
                    if span <= 1e-6:
                        span = 360.0
                    ang = np.radians(a1 + np.linspace(0.0, span, 49))
                    self.preview_line.set_data(cen[0] + r * np.cos(ang), cen[1] + r * np.sin(ang))
                else:
                    p1, p2 = self.draw_pts
                    self.preview_line.set_data([p1[0], p2[0], cursor_pt[0]], [p1[1], p2[1], cursor_pt[1]])

    def on_left_click_draw(self, px: float, py: float):
        """左鍵落筆：支援 line, 2p-circle, 3p-circle, 3p-arc 與 paint 油漆桶刷圖層模式。"""
        if self.cur_tool == "paint":
            self.paint_entity_layer()
            return

        target_pt = self.snapped_pt if self.snapped_pt is not None else (float(px), float(py))
        if self.draw_pts and math.hypot(target_pt[0] - self.draw_pts[-1][0], target_pt[1] - self.draw_pts[-1][1]) < 1e-6:
            return

        self.draw_pts.append(target_pt)
        need = self.TOOL_NEED_PTS[self.cur_tool]

        if len(self.draw_pts) < need:
            self._update_rubberband_preview(target_pt)
            self._update_hud()
            self._draw_idle()
            self._log(
                f"[{self.cur_tool} 落筆 {len(self.draw_pts)}/{need}] "
                f"點位=({target_pt[0]:.2f}, {target_pt[1]:.2f}) (Esc 取消)"
            )
            return

        # 點數已滿，正式建立 DXF 圖元
        pts = list(self.draw_pts)

        if self.cur_tool == "line":
            self.add_line(pts[0], pts[1])
            # 連續畫線模式：將本段終點 pts[1] 直接設為下一段起點，直到按 Esc 才斷開
            self.draw_pts = [pts[1]]
            self._update_rubberband_preview(pts[1])
            self._update_hud()
            self._draw_idle()
            return

        self.cancel_drawing(silent=True)
        if self.cur_tool == "2p-circle":
            self.add_circle_2p(pts[0], pts[1])
        elif self.cur_tool == "3p-circle":
            self.add_circle_3p(pts[0], pts[1], pts[2])
        elif self.cur_tool == "3p-arc":
            self.add_arc_3p(pts[0], pts[1], pts[2])

    def delete_hovered_entity(self):
        """按下 E：刪除目前滑鼠停駐高亮的 DXF 圖元。"""
        if self.hovered_handle is None:
            self._log("[E] 未停駐於任何圖元上，請將滑鼠移至線段/圓弧呈現亮青色後再按 E")
            return
        ent = self.entities_by_handle.get(self.hovered_handle)
        if ent is None:
            return
        info = self._format_entity_info(ent)
        if not DXFEditingHelper.delete_entity(self.doc, self.hovered_handle):
            return
        self.hovered_handle = None
        self.rebuild_scene(fit_view=False)
        self._log(f"[E] 已刪除圖元 -> {info}")

    def cancel_drawing(self, silent=False):
        self.draw_pts = []
        if self.pts_marker is not None:
            self.pts_marker.set_data([], [])
        if self.preview_line is not None:
            self.preview_line.set_data([], [])
        if not silent:
            self._update_hud()
            self._draw_idle()
            self._log("[Esc] 已取消當前未完成的落筆點")

    # ==================================================================
    # HUD 更新與事件綁定
    # ==================================================================
    def _update_hud(self):
        if self.hud_brush_text is None or self.hud_info_text is None:
            return

        need = self.TOOL_NEED_PTS[self.cur_tool]
        cur_n = len(self.draw_pts)
        parsed = self.parse_bc_layer_name(self.cur_layer)
        if parsed["type"] in ("DISP", "FORCE"):
            bc_desc = (
                f"({parsed.get('bc_id', parsed['type'])}: X={parsed['x']:g} {parsed['unit']}, "
                f"Y={parsed['y']:g} {parsed['unit']})"
            )
        elif parsed["type"] == "FIXED":
            bc_desc = "(固定邊界 ux=uy=0)"
        elif parsed["type"] == "PROBE":
            bc_desc = "(探針/觀測邊界 Probe)"
        else:
            bc_desc = "(自由輪廓邊)"

        brush_msg = (
            f"Brush Layer [Q] : {self.cur_layer} {bc_desc}   |   "
            f"Tool [W] : {self.cur_tool} ({cur_n}/{need} pts)\n"
            f"Hotkeys: [Q] 換圖層  [W] 換工具(線/圓心圓/3P圓/3P弧/刷層)  "
            f"[F] 停駐刷圖層  [E] 刪除停駐  [Ctrl+Z] 退回新增  [左鍵] 落筆"
        )
        self.hud_brush_text.set_text(brush_msg)
        self.hud_brush_text.set_color(self.cur_brush["colors"])

        if self.hovered_handle is not None and self.hovered_handle in self.entities_by_handle:
            hover_str = self._format_entity_info(self.entities_by_handle[self.hovered_handle])
        else:
            hover_str = "Hover: None"

        if self.snapped_pt is not None:
            snap_str = f"SNAP [{self.snapped_type}]: ({self.snapped_pt[0]:.2f}, {self.snapped_pt[1]:.2f})"
        else:
            snap_str = f"XY: ({self.mouse_xy[0]:.2f}, {self.mouse_xy[1]:.2f})"

        self.hud_info_text.set_text(f"{hover_str}   |   {snap_str}")

    def _on_mpl_press(self, event):
        if event.inaxes != self.ax or event.xdata is None or event.ydata is None:
            return
        if self.tk_fig and self.tk_fig.widget:
            self.tk_fig.widget.focus_set()

        if event.button in (2, 3):
            self.pan_state["pressed"] = True
            self.pan_state["x0"] = event.xdata
            self.pan_state["y0"] = event.ydata
            return

        if event.button == 1:
            self.on_left_click_draw(event.xdata, event.ydata)

    def _on_mpl_release(self, event):
        self.pan_state["pressed"] = False

    def _on_mpl_motion(self, event):
        if event.inaxes != self.ax or event.xdata is None or event.ydata is None:
            return
        # 當滑鼠在畫布上移動且焦點不在 Entry 時，自動歸還焦點給畫布以確保 Q/W/E/F 熱鍵隨時可用
        if self.ui and self.ui.root and self.tk_fig and self.tk_fig.widget:
            focused = self.ui.root.focus_get()
            if focused is not None and focused.winfo_class() not in ("Entry", "Text"):
                self.tk_fig.widget.focus_set()

        px, py = float(event.xdata), float(event.ydata)
        self.mouse_xy = (px, py)

        if self.pan_state["pressed"] and self.pan_state["x0"] is not None:
            dx = px - self.pan_state["x0"]
            dy = py - self.pan_state["y0"]
            xlim = self.ax.get_xlim()
            ylim = self.ax.get_ylim()
            self.ax.set_xlim(xlim[0] - dx, xlim[1] - dx)
            self.ax.set_ylim(ylim[0] - dy, ylim[1] - dy)
            self._draw_idle()
            return

        self._compute_hover_and_snap(px, py)

        if self.draw_pts:
            end_pt = self.snapped_pt if self.snapped_pt is not None else (px, py)
            self._update_rubberband_preview(end_pt)

        self._update_hud()
        self._draw_idle()

    def _on_mpl_scroll(self, event):
        if event.inaxes != self.ax or event.xdata is None or event.ydata is None:
            return
        scale = 0.82 if event.button == "up" else 1.22
        xlim = self.ax.get_xlim()
        ylim = self.ax.get_ylim()
        self.ax.set_xlim([
            event.xdata - (event.xdata - xlim[0]) * scale,
            event.xdata + (xlim[1] - event.xdata) * scale,
        ])
        self.ax.set_ylim([
            event.ydata - (event.ydata - ylim[0]) * scale,
            event.ydata + (ylim[1] - event.ydata) * scale,
        ])
        self._draw_idle()

    # ------------------------------------------------------------------
    # 檢查畫布 (fig_dxf_check) 的滾輪縮放與右/中鍵平移
    # ------------------------------------------------------------------
    def _on_generic_scroll(self, event, ax, tk_fig):
        if ax is None or event.inaxes != ax or event.xdata is None or event.ydata is None:
            return
        scale = 0.82 if event.button == "up" else 1.22
        xlim = ax.get_xlim()
        ylim = ax.get_ylim()
        ax.set_xlim([
            event.xdata - (event.xdata - xlim[0]) * scale,
            event.xdata + (xlim[1] - event.xdata) * scale,
        ])
        ax.set_ylim([
            event.ydata - (event.ydata - ylim[0]) * scale,
            event.ydata + (ylim[1] - event.ydata) * scale,
        ])
        if tk_fig is not None:
            tk_fig.draw()

    def _bind_canvas_pan_zoom(self, tk_fig, ax, pan_state):
        if tk_fig is None or getattr(tk_fig, "canvas", None) is None:
            return
        c = tk_fig.canvas
        c.mpl_connect("scroll_event", lambda e: self._on_generic_scroll(e, ax, tk_fig))
        c.mpl_connect("button_press_event", lambda e: self._on_pan_press(e, ax, pan_state))
        c.mpl_connect("button_release_event", lambda e: self._on_pan_release(e, pan_state))
        c.mpl_connect("motion_notify_event", lambda e: self._on_pan_motion(e, ax, pan_state, tk_fig))

    @staticmethod
    def _on_pan_press(event, ax, pan_state):
        if ax is None or event.inaxes != ax:
            return
        if event.xdata is None or event.ydata is None:
            return
        if event.button in (2, 3):
            pan_state["pressed"] = True
            pan_state["x0"] = event.xdata
            pan_state["y0"] = event.ydata

    @staticmethod
    def _on_pan_release(event, pan_state):
        pan_state["pressed"] = False

    def _on_pan_motion(self, event, ax, pan_state, tk_fig):
        if ax is None or event.inaxes != ax:
            return
        if event.xdata is None or event.ydata is None:
            return
        if not (pan_state["pressed"] and pan_state["x0"] is not None):
            return
        px, py = float(event.xdata), float(event.ydata)
        dx = px - pan_state["x0"]
        dy = py - pan_state["y0"]
        xlim = ax.get_xlim()
        ylim = ax.get_ylim()
        ax.set_xlim(xlim[0] - dx, xlim[1] - dx)
        ax.set_ylim(ylim[0] - dy, ylim[1] - dy)
        if tk_fig is not None:
            tk_fig.draw()

    def handle_hotkey(self, key: str):
        """統一處理快捷鍵: Q (換圖層)、W (換幾何工具)、E (刪除停駐圖元)、F (刷圖層)、Esc (取消落筆)。"""
        now = time.perf_counter()
        if now - self._last_key_ts < 0.08:
            return
        self._last_key_ts = now

        if self.ui and self.ui.root:
            focused = self.ui.root.focus_get()
            if focused is not None and focused.winfo_class() in ("Entry", "Text") and key.lower() not in ("escape", "esc"):
                return

        k = key.lower()
        if k in ("ctrl+z", "control+z"):
            self.undo_last_added()
        elif k == "q":
            self.switch_layer("next")
        elif k == "w":
            self.set_draw_tool("next")
        elif k == "e":
            self.delete_hovered_entity()
        elif k == "f":
            self.paint_entity_layer()
        elif k in ("escape", "esc"):
            self.cancel_drawing()

    def _bind_events(self):
        if self.tk_fig is not None and self.tk_fig.canvas is not None:
            c = self.tk_fig.canvas
            c.mpl_connect("button_press_event", self._on_mpl_press)
            c.mpl_connect("button_release_event", self._on_mpl_release)
            c.mpl_connect("motion_notify_event", self._on_mpl_motion)
            c.mpl_connect("scroll_event", self._on_mpl_scroll)
            c.mpl_connect("key_press_event", lambda e: self.handle_hotkey(e.key or ""))

        self._bind_canvas_pan_zoom(self.tk_fig_check, self.ax_check, self.check_pan)

        self._bind_canvas_pan_zoom(self.tk_fig_mesh, self.ax_mesh, self.mesh_pan)

        self._bind_canvas_pan_zoom(self.tk_fig_fea, self.ax_fea, self.fea_pan)

        if self.ui and self.ui.root:
            for k in ("q", "Q", "w", "W", "e", "E", "f", "F", "Escape"):
                self.ui.root.bind(f"<KeyPress-{k}>", lambda e, key=k: self.handle_hotkey(key), add="+")
            self.ui.root.bind("<Control-z>", lambda e: self.handle_hotkey("ctrl+z"), add="+")
            self.ui.root.bind("<Control-Z>", lambda e: self.handle_hotkey("ctrl+z"), add="+")

        cb_brush = self._ctrl("combo_brush")
        if cb_brush is not None:
            cb_brush.options(self.brush_names)
            cb_brush.set(value=self.cur_layer)
            cb_brush.on_change = lambda name, val: self.switch_layer(val)

        cb_tool = self._ctrl("combo_tool")
        if cb_tool is not None:
            cb_tool.options(self.DRAW_TOOLS)
            cb_tool.set(value=self.cur_tool)
            cb_tool.on_change = lambda name, val: self.set_draw_tool(val)

        # 當在 BC_X 或 BC_Y 輸入框按下 Enter 提交時，自動更新當前 DISP/FORCE 畫筆
        for ety_key in ("ety_bc_x", "ety_bc_y"):
            ety = self._ctrl(ety_key)
            if ety is not None and ety.widget is not None:
                ety.widget.bind("<Return>", lambda e: self.set_bc_brush(), add="+")

        btn_map = {
            "btn_next_brush":   lambda b: self.switch_layer("next"),
            "btn_next_tool":    lambda b: self.set_draw_tool("next"),
            "btn_del_ent":      lambda b: self.delete_hovered_entity(),
            "btn_update_brush": lambda b: self.set_bc_brush(),
            "btn_load_dxf":     lambda b: self.load_dxf(fit_view=True),
            "btn_save_dxf":     lambda b: self.save_dxf(),
            "btn_fit_view":     lambda b: (self._fit_data_limits(), self._draw_idle()),
            "btn_check":        lambda b: self.run_contour_check(),
            "btn_zoom_issue":   lambda b: self.zoom_to_selected_issue(),
            "btn_auto_dedup":   lambda b: self.auto_dedup_contours(),
            "btn_mesh_gen":     lambda b: self.run_mesh_generation(),
            "btn_mesh_mid":     lambda b: self._refresh_mesh_plot(),
            "btn_fea_solve":    lambda b: self.run_fea_solve(),
        }
        for key, fn in btn_map.items():
            btn = self._ctrl(key)
            if btn is not None:
                btn.on_click = fn

    # ==================================================================
    # 工具函式
    # ==================================================================
    def _find_tk_figure(self):
        for k in ("figure", "figure_fallback"):
            ctrl = self._ctrl(k)
            if ctrl is not None:
                return ctrl
        for ctrl in self.ui.ctrls.values():
            if getattr(ctrl, "type", "").lower() == "figure":
                return ctrl
        return None

    def _ctrl(self, key):
        name = UI_CTRLS.get(key)
        return self.ui.ctrls.get(name) if (self.ui and name) else None

    def _draw_idle(self):
        if self.tk_fig is not None:
            self.tk_fig.draw()

    def _log(self, msg: str):
        lb = self._ctrl("lb_status") or self._ctrl("lb_status_fb")
        if lb is not None:
            lb.text(msg)
        log = self._ctrl("txt_log") or self._ctrl("txt_log_fb")
        if log is not None:
            log.write_async(f"[DXFEditor] {msg}")


# ==============================================================================
# 3. 腳本入口：掛載至 helper.dxf_editor
# ==============================================================================
if "helper" in globals():
    if not hasattr(helper, "dxf_editor") or helper.dxf_editor is None:
        helper.dxf_editor = DXFFigureEditor(helper, dxf_path="./part01.dxf")
    else:
        helper.dxf_editor.load_dxf("./part01.dxf", fit_view=True)
