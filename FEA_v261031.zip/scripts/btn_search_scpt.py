

e = helper

files = get_files(e.path["script"], types=["py"])
e.ui.ctrls["list_scpt_files"].options([f[2] for f in files])











