

e = helper

name = e.ui.ctrls["list_scpt_files"].value()
if name : e.exec_scpt(name)


