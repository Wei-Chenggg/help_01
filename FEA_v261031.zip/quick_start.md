# quick_start — 專案快速導覽

## main.py — 主框架
單一 `Machine` 類作為整個應用的總管，`__main__` 只有兩行：`Machine()` → `run_main_loop()`。

### 成員
- `self.path`：路徑字典（`config`、`script`）。
- `self.ui`：`TK_Helper` 主視窗。
- `self.kb`：`Keyboard_Helper` 鍵盤滑鼠。
- `self.threads` / `self.tmr`：背景執行緒與各迴圈的間隔計時。
- `self.scpt_running`：防重入鎖，同時只允許一支腳本執行。
- `self.hotkeys`：按鍵 → 腳本名對照表。

### 初始化
1. `_init_tk`：建立 `TK_Helper`，讀 `config/ui_frames_layout_config.csv` 與 `config/ui_ctrls_layout_config.csv` 建出整個 UI。
2. `_init_hotkeys`：讀 `config/hotkey_table.csv`，把每列的腳本名對應到多個按鍵。

### 主迴圈
`run_main_loop()` 依序執行：
1. `kb.run_main_loop()` — 啟動鍵盤 / 滑鼠監聽執行緒。
2. 用 `_start_loop` 開兩個背景輪詢（daemon thread + 間隔計時）：
   - `lpf_check_tk`（100ms）：消化 UI 按鈕事件，逐個呼叫 `_exec_scpt`。
   - `lpf_check_kb`（50ms）：消化鍵盤事件，每輪只吃 1 鍵後 `break`。
3. `ui.run()` — 進入 Tk mainloop（阻塞）。

### 腳本執行
- `_exec_scpt(name)`：`name` 先經 `self.hotkeys.get(name, name)` 重映射 → 確認 `scripts/{py_name}.py` 存在 → 檢查 `scpt_running` 鎖 → 以 daemon thread 執行。
- `exec_scpt(name)`：讀 `scripts/{name}.py`，在 `globals()` 副本的 namespace 中 `exec`，並注入 `helper = self`；腳本內可用 `helper.ui.ctrls["..."]`、`helper.kb` 等操作主機。

### 命名習慣
- 輪詢函式以 `lpf_` 開頭。
- 裝置短名：`ui` / `kb`。

## scripts/ — 業務腳本
- 存放可被按鈕 / 熱鍵觸發的獨立 `.py`。
- 觸發對應：
  - 鍵盤：按鍵 → `hotkeys` 重映射 → 腳本名。
  - UI 按鈕：按鈕 `name` 直接當腳本名（`scripts/{name}.py`）。
- 腳本在執行緒中執行，`helper` 指向主機；同一時間只跑一支（`scpt_running` 鎖）。
- 目前目錄為空，需後續補上實際腳本。

### 命名方式

**UI 觸發類**
- `btn_XXXXX.py`：按下 UI 按鈕後要做的事。
- `list_XXX.py`：combo 選中後要做的事（可能是更新參數之類）。

**後端觸發類**
- `hpr_task_XXX.py`：任務或雜項（如滑鼠到哪裡點一下），這種特殊用途幾乎不可能跨任務通用。
- `hpr_init_XXX.py`：程式碼初始化定義類，例如想加入一個新 class 到 main.py，但該 class 有自己的初始化定義，單模組收整一個，再打包回 main.py 呼叫 `exec_scpt` 進行單一窗口初始化。
- `hpr_basic_XXX.py`：基礎函數或基礎共用工具，可能被 UI 觸發類與後端觸發類共用的 py。

## config/ — 設定

### ui_frames_layout_config.csv
欄位：`name, parent, parent_page, align, w, h, pages, title, grids, bg_color, linewidth`
- 每列一個 frame 容器；`parent=root` 是頂層入口。
- `align` + `w` / `h` 決定同層兄弟 frame 的相對排列（place）。
- `grids` 是給內部控件用的格線（`RxC`）。

目前版面樹：
```
fm_main (root)
├── fm_u   (h=0.08, 1x6)   頂列：bpg_l1 ~ l4 四個分頁鈕
└── fm_d   (h=0.92)        主區（被 L1~L4 切成 4 頁）
    ├─ 頁1: fm_a1 (6x6)  Load tm + combo
    │      fm_a2 (6x6)  Save Name + 輸入框 + p1/p2/p3 + Save
    └─ 頁2: fm_b1 (1x20) 工具列（test / Mode / Color / Width / Grip / Clear / Snap / Mark）
           fm_b2 (1x1)   cav_1 畫布
    （頁3、頁4 目前空白）
```

### ui_ctrls_layout_config.csv
欄位：`name, parent, page, type, mode, row, col, row_spn, col_spn, text, bg_color, fg_color, fontsize, linewidth, tgr_bg_color, tgr_fg_color`
- `type` 決定控件：`button` / `entry` / `combo` / `page` / `canvas` / `figure` / `label`。
- `row` / `col` + `row_spn` / `col_spn` 在父 frame 的 `grids` 內定位（grid）。
- `mode` 依型別不同：entry 的 `str/int/float`、button 的 `binary/single`、page 的 `目標frame#頁id`、figure 的尺寸 `寬x高`。

### 控件 name 前綴
| 前綴 | type | 控件 | 說明 |
|---|---|---|---|
| `bpg_` | page | 分頁鈕 | 切換目標 frame 的頁 |
| `btn_` | button | 按鈕 | 按下觸發 `scripts/btn_XXXXX.py` |
| `list_` | combo | 下拉選單 | 選中觸發 `scripts/list_XXX.py` |
| `ety_` | entry | 輸入框 | 參數輸入 |
| `lb_` | label | 標籤 | 顯示文字 |
| `cav_` | canvas | 畫布 | 顯示影像 |
| `fig_` | figure | 圖表 | matplotlib 圖 |

- 框架容器（frame）的 `name` 用 `fm_` 前綴。
- UI 觸發類連動：控件 `name` 就是 script 名（`btn_save` → `scripts/btn_save.py`；`list_1` → `scripts/list_1.py`）。

### hotkey_table.csv
欄位：`py_name, key1, key2, ...`
- 每列一個腳本名，後續欄位是觸發它的按鍵。
- 目前：`debug01` ← q / alt+w；`debug02` ← alt+1。

### 版面配置慣例

**經典 layout（標準控件組合）**
- 檔案選擇（files selection）：`combo_files`（下拉列出檔名供選擇）+ `btn_file_search`（按下後搜尋路徑下檔案）放同一列，`col_spn` 為 `5:1`（檔名可能很長，需 5 倍於按鈕）。
- 參數輸入（entry）：左側放 dummy label 說明要輸入什麼（如 `text="參數1 : "`），`col_spn` 為 `1:5`（entry 內容可能很長，需 5 倍於 label）。

**frame 美學**
- 善用 frame-in-frame：例如先切上下，每個 frame 內再切左右，切出合適的視覺比例。
- 先判斷任務是否需要大的 canvas / figure：
  - 需要大 canvas / figure：主區先切左右（約 2:8），左右兩半各自有放 page 的 frame，內部再切上下；放 page ctrls 的 frame 通常很矮但寬度吃滿 parent，grids 用 `1x10` 或 `1x6`。
  - 不需要大 canvas / figure：先切上下較合適；上方顯示基本訊息（目前時間、滑鼠位置、`info_label`，後端 log 用 `label.text` 打印）。這類通常是 kb / match_helper 的任務定位，協助日常鍵盤滑鼠自動化，UI 通常偏小（如 `300x500`）。

**ctrls grids 美學**
- frame 內放多個 ctrls 時，習慣 `col=6`、`row` 依比例而定；若 ctrl 的 parent frame 高度吃滿，就給很多 row（如 10、20 row），讓字體剛好吃滿 btn / label 邊框最舒適。
- 避免「btn 框很大但字體只佔 <50%」的大房小用；基本情況一律 `fontsize=9`，除非特別指定。

**page button 規則**
- page button 不能放在它自己要切換的 frame 內（會被隱藏導致 bug）。
- page button 的 frame 採上下排列，page button 習慣放在上方。

## toolbox/ — 工具模組

### files_helper.py — 檔案 / 資料夾操作
純函式集合，無 class。
- CSV：`load_csv` / `save_csv` / `append_csv`（自動補 `.csv`、自動偵測編碼）。
- pickle：`load_pkl` / `save_pkl`。
- 單檔：`copy_file` / `move_file` / `delete_file`。
- 資料夾：`add_folder`。
- 批次：`get_files` / `copy_files` / `move_files`（依副檔名 + accept / reject 篩選）。
- 其他：`get_timestamp`（`YYYYMMDD-HHMMSS`）。

### image_helper.py — 影像核心（Imgtool）
`Imgtool` 類，內部統一 BGR / uint8。
- 載入輸出：`load` / `save`（支援中文路徑）、`get`、`cvt_cv2_img`（dtype / 通道收斂）。
- 幾何：`pad_by_pixel` / `pad_by_ratio`（補白擴張）。
- 處理：`smooth`（高斯模糊）、`binary`（二值化）、`canny`（邊緣偵測）。
- 繪圖：`circle` / `line` / `rect` / `poly`。
- 文字：`text` / `auto_text`（支援中文、四角自動堆疊）。

### keyboard_helper.py — 鍵盤 / 滑鼠
`Keyboard_Helper` 類（pynput）。
- 模擬：`click`（點擊 / 組合鍵 / 滾輪）、`typing`（打字）、`move`（可指定耗時、esc 中斷）、`pos`。
- 監聽：`run_main_loop` 啟動鍵盤 / 滑鼠 listener 執行緒，事件寫入 buffer。
- 讀取：`interact(clear)` 取出事件佇列。
- 內建按鍵名對照（`KEY_TABLE` / `VK_TABLE` / 修飾鍵組合）。

### tkinter_helper.py — GUI 控件套件
以 CSV 驅動整個 Tkinter 視窗。
- 控件類：`TK_Entry`（輸入框）、`TK_Combo`（唯讀下拉）、`TK_Button`（切換 / 單發）、`TK_Label`、`TK_PageBtn`（分頁鈕）、`TK_Canvas`（畫布）、`TK_Figure`（matplotlib）、`TK_Frame`（容器）。
- `TK_Helper` 主入口：`load_frames_config` + `load_ctrl_config` 建 UI，`run()` 進 mainloop，`interact()` 回傳按鈕事件。
- `TK_Canvas`：滾輪縮放 / 拖移平移 / 座標轉換，`set_async` 跨執行緒刷新。
- `TK_Figure`：`plot/scatter/bar/hist`，代理 Axes 自動重繪。

### painter_helper.py — 影像標註（Image_Painter）
在底圖上疊加幾何標註，不改動底圖。
- `mark`：餵點，點數夠自動成形（`3p-circle` / `2p-circle` / `tshape` / `line` / `rect` / `cen-rect`）。
- `mode`：切換形狀；`pick` / `dist`：查詢靠近的圖形。
- `snap`：磁吸到熱點關鍵點；`key_points`：取圖形關鍵點。
- `plot`：合成底圖 + 標註 + 動態預覽，回傳顯示用圖。
- `layer` / `style`：多圖層與樣式設定。

### match_vision_helper.py — 模板比對
`Match_Vision_Helper` 類，做「在螢幕上找畫面位置」。
- `get_screen_image`：截全螢幕 / 指定區塊（BGR uint8）。
- `build`：框選區塊存成模板，並記錄目標點偏移。
- `find`：`cv2.matchTemplate` 找模板，回傳目標點座標，比對分數存 `last_score`。
- `load` / `save`：模板集 pkl 存取。
