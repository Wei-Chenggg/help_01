import sys
import os
import time
import threading
import random
module_path = "./toolbox"
sys.path.append(module_path)
from files_helper import *
from image_helper import *
from keyboard_helper import Keyboard_Helper
# from match_vision_helper import Match_Vision_Helper
from tkinter_helper import TK_Helper
# from agents_helper import *

class Machine():
    ###    --------------------      初始化     --------------------------
    def __init__(self, window_size="1600x800", window_dxy=(20, 60), title='TK UI'):
        self.path = {"config": "./config", "script":"./scripts", }
        self.threads = {}
        self.tmr = {}
        self.scpt_running = None
        self.ui = None
        self.kb = Keyboard_Helper()
        self._init_tk(size=window_size, loc=window_dxy, title=title)
        self._init_hotkeys()
    def _init_after_ui_run(self,):
        self._exec_scpt("btn_search_scpt")
        self.ui.root.after(300, lambda: self._exec_scpt("hpr_dxf_editor_plt"))
        # self.ui.ctrls["bpg_main2"].activate()
    def _init_hotkeys(self, ):
        folder = self.path["config"]
        fpath = f"{folder}/hotkey_table.csv"
        self.hotkeys = {}
        if not os.path.isfile(fpath) : return
        for row in load_csv(fpath)[1:]:
            if not row : continue
            py_name = row[0].strip()
            for key in row[1:]:
                key = key.strip().lower()
                if key : self.hotkeys[key] = py_name
    ###    --------------------      tk     --------------------------
    def _init_tk(self, size="1800x900", loc=(20, 60), title='Helper'):
        self.ui = TK_Helper(size=size, loc=loc, title=title)
        self.ui.set_config(topmost=False, resizable=(True, True), bg='white')
        self.ui.load_frames_config(os.path.join(self.path["config"], 'ui_frames_layout_config.csv'))
        self.ui.load_ctrl_config(os.path.join(self.path["config"], 'ui_ctrls_layout_config.csv'))
    def lpf_check_tk(self, ):
        for key in self.ui.interact(True): 
            self._exec_scpt(key)
    def lpf_check_kb(self, ):
        for key in self.kb.interact(True): 
            self._exec_scpt(key)    
            break
    def exec_scpt(self, name):
        folder = self.path["script"]
        fpath = f"{folder}/{name}.py"
        if not self._is_scpt_exist(fpath) : return
        with open(fpath, "r", encoding="utf-8-sig") as f:
            scpt = f.read()
        ns = dict(globals())
        ns["helper"] = self
        exec(compile(scpt, fpath, "exec"), ns)
    def _exec_scpt(self, name):
        folder = self.path["script"]
        py_name = self.hotkeys.get(name, name)
        fpath = f"{folder}/{py_name}.py"
        if not self._is_scpt_exist(fpath) : return
        if self.scpt_running : return
        self.scpt_running = py_name
        def _run():
            try:
                self.exec_scpt(py_name)
            finally:
                self.scpt_running = None
        thd1 = threading.Thread(target=_run, args=())
        thd1.daemon = True
        thd1.start()
    def _is_scpt_exist(self, fpath):
        return os.path.isfile(fpath)
    ###    --------------------      基本 loop     --------------------------
    def _start_loop(self, name, func, dt):
        self.tmr[name] = time.time()
        def _run():
            while True:
                if time.time() - self.tmr[name] < dt:
                    time.sleep(0.01)
                    continue
                self.tmr[name] = time.time()
                func()
        thd1 = threading.Thread(target=_run, args=())
        thd1.daemon = True
        self.threads[name] = thd1
        self.threads[name].start()
    def run_main_loop(self, ):
        self.kb.run_main_loop()
        self._start_loop('tk', self.lpf_check_tk, dt=0.1)
        self._start_loop('kb', self.lpf_check_kb, dt=0.05)
        self.ui.root.after(500, self._init_after_ui_run)
        self.ui.run()
if __name__ == "__main__":
    d = Machine()
    d.run_main_loop()
