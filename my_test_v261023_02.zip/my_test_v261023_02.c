#include "driverlib.h"
#include "device.h"
#include "board.h"
#include <string.h>
#include <stdlib.h>
#include <math.h>

// ============================================================================
// 硬體基底位址與腳位定義
// ============================================================================
#define COMM_SCI_BASE       SCIA_BASE       // 板載 XDS110 UART (GPIO28=RX, GPIO29=TX)

// DOUT 允許控制的腳位
#define DOUT_PIN_1          58U             // GPIO58 (J6-Pin 55)
#define DOUT_PIN_2          59U             // GPIO59 (J6-Pin 54)

// PWM 模組 (A -> ePWM1A / GPIO0, B -> ePWM2A / GPIO2)
#define PWM_A_BASE          EPWM1_BASE
#define PWM_B_BASE          EPWM2_BASE
#define PWM_TBCLK_HZ        50000000UL      // 100MHz SYSCLK / 2 = 50MHz

// DAC 模組 (A -> DACA / A0 壓電主驅動, B -> DACB / A1 預留)
#define DAC_A_BASE          DACA_BASE
#define DAC_B_BASE          DACB_BASE

// 接收緩衝區大小
#define CMD_BUF_SIZE        64U

// 控制迴路取樣頻率: 1000 Hz (每 1 ms 執行一次)
#define CTRL_ISR_FREQ_HZ    1000UL
#define CTRL_PERIOD_US      1000UL

// 黑盒子最大儲存筆數 (600 筆 * 5 words = 3000 words，配置於 RAMGS0)
#define LOG_MAX_SAMPLES     600U

// ============================================================================
// 壓電夾爪控制狀態機與超參數結構定義
// ============================================================================
typedef enum
{
    STATE_IDLE    = 0,  // 閒置待機 (維持當前 DAC 電壓)
    STATE_SEARCH  = 1,  // 定速接近探觸中 (actDir=-1 時 DAC 遞減靠攏)
    STATE_HOLD    = 2,  // 閉迴路 PID 恆力保持中
    STATE_RELEASE = 3,  // 平滑斜坡鬆開撐開中 (actDir=-1 時 DAC 遞增至 maxDac)
    STATE_FAULT   = 4,  // 空夾超行程保護 (DAC 已降到底仍未觸發 TOUCH_TH)
    STATE_REST    = 5   // 平滑卸壓回 0V 斷電休息狀態
} GripperState_t;

typedef struct
{
    int16_t  targetForce;     // [ID 0] 目標夾持保持力 (ADC 格數, 預設 200)
    int16_t  touchThreshold;  // [ID 1] 初接觸切換門檻力 (ADC 格數, 預設 20)
    uint16_t searchStepX10;   // [ID 2] 探觸接近速度 (0.1 格 DAC / ms, 預設 80 -> 8.0 格/ms)
    uint16_t releaseStepX10;  // [ID 3] 鬆開撐開速度 (0.1 格 DAC / ms, 預設 150 -> 15.0 格/ms)
    uint16_t maxPidStepX10;   // [ID 4] PID 單步最大修正限速 (0.1 格 DAC / ms, 預設 50 -> 5.0 格/ms)
    int32_t  kpX1000;         // [ID 5] 比例增益 Kp * 1000 (預設 200 -> Kp = 0.200)
    int32_t  kiX1000;         // [ID 6] 積分增益 Ki * 1000 (預設 30  -> Ki = 0.030)
    int32_t  kdX1000;         // [ID 7] 微分增益 Kd * 1000 (預設 0   -> Kd = 0.000)
    int16_t  forceDir;        // [ID 8] 夾持力感測極性 (+1 或 -1, 預設 +1)
    int16_t  forceZero;       // [ID 9] ADC0 空載零點偏置值 (0~4095, 預設 0)
    int16_t  deadband;        // [ID 10] 力量誤差死區 (ADC 格數, 預設 2)
    uint16_t maxDac;          // [ID 11] DAC 最大撐開上限 (0~4095, 預設 4095)
    uint16_t logDiv;          // [ID 12] 黑盒子取樣分頻 (1~50 ms, 預設 2)
    int16_t  actDir;          // [ID 13] 致動器方向 (-1: DAC減少=夾緊/增加=撐開; +1: DAC增加=夾緊)
} GripperParams_t;

typedef struct
{
    volatile GripperState_t state;
    volatile uint16_t       rawAdc[4];     // ADC0(力), ADC1(位移), ADC2(B2), ADC3(C2)
    volatile float          filtAdcForce;  // ADC0 低通濾波值
    volatile int16_t        measForce;     // 正規化後的有效夾持力 F_meas
    volatile int16_t        posZero;       // ADC1 零點記錄
    volatile float          dacAccum;      // 浮點數 DAC 累加器 (0.0 ~ 4095.0)
    volatile uint16_t       currentDac;    // 目前實際輸出至 DACA 的整數值
    float                   errPrev1;      // e[k-1]
    float                   errPrev2;      // e[k-2]
    bool                    filterInit;    // 濾波器初始化旗標
    volatile bool           isCalibrated;  // 是否已完成零點校正旗標
} GripperRuntime_t;

// 黑盒子單點紀錄結構 (共 5 個 16-bit words = 10 Bytes)
typedef struct
{
    uint16_t packedStateDac; // 高 4 bits: State (0~5), 低 12 bits: DAC (0~4095)
    uint16_t adc[4];         // ADC0, ADC1, ADC2, ADC3 原始值
} LogEntry_t;

// 全域控制參數與執行期狀態
static GripperParams_t gParams = {
    .targetForce    = 200,
    .touchThreshold = 20,
    .searchStepX10  = 80U,
    .releaseStepX10 = 150U,
    .maxPidStepX10  = 50U,
    .kpX1000        = 200L,
    .kiX1000        = 30L,
    .kdX1000        = 0L,
    .forceDir       = 1,
    .forceZero      = 0,
    .deadband       = 2,
    .maxDac         = 4095U,
    .logDiv         = 2U,
    .actDir         = -1      // 預設 -1: DAC 增加時鬆開(撐開)，DAC 減少時夾緊
};

static GripperRuntime_t gRt = {
    .state        = STATE_IDLE,
    .rawAdc       = {0U, 0U, 0U, 0U},
    .filtAdcForce = 0.0f,
    .measForce    = 0,
    .posZero      = 0,
    .dacAccum     = 0.0f,
    .currentDac   = 0U,
    .errPrev1     = 0.0f,
    .errPrev2     = 0.0f,
    .filterInit   = false,
    .isCalibrated = false
};

// 將黑盒子陣列配置於寬敞的 RAMGS0 (8192 words)，避免撐爆預設 .ebss (2048 words)
#pragma DATA_SECTION(gLogBuf, "ramgs0")
static LogEntry_t        gLogBuf[LOG_MAX_SAMPLES];
static volatile uint16_t gLogCount   = 0U;
static volatile uint16_t gLogTickCnt = 0U;
static volatile bool     gLogActive  = false;

// ============================================================================
// 快速通訊與字串轉換輔助函式
// ============================================================================
static inline void SCI_sendStr(const char *str)
{
    SCI_writeCharArray(COMM_SCI_BASE, (const uint16_t *)str, strlen(str));
}

static inline void SCI_sendAck(void)
{
    SCI_writeCharArray(COMM_SCI_BASE, (const uint16_t *)"R\n", 2U);
}

static inline void SCI_sendErr(void)
{
    SCI_writeCharArray(COMM_SCI_BASE, (const uint16_t *)"E\n", 2U);
}

static uint16_t u16ToStr(uint16_t val, char *buf)
{
    char temp[6];
    uint16_t i = 0U, j = 0U;

    if (val == 0U)
    {
        buf[0] = '0';
        return 1U;
    }
    while (val > 0U)
    {
        temp[i++] = (char)('0' + (val % 10U));
        val /= 10U;
    }
    while (i > 0U)
    {
        buf[j++] = temp[--i];
    }
    return j;
}

static uint16_t i32ToStr(int32_t val, char *buf)
{
    uint16_t pos = 0U;
    uint32_t uval;

    if (val < 0L)
    {
        buf[pos++] = '-';
        uval = (uint32_t)(-val);
    }
    else
    {
        uval = (uint32_t)val;
    }

    pos += u16ToStr((uint16_t)uval, &buf[pos]);
    return pos;
}

// ============================================================================
// 啟動黑盒子重新錄製 (僅於新一輪 PICK 或手動 LOG,START 時呼叫)
// ============================================================================
static inline void startLogger(void)
{
    gLogCount   = 0U;
    gLogTickCnt = 0U;
    gLogActive  = true;
}

// ============================================================================
// ADC 四通道同步擷取函式 (A2, A3, B2, C2)
// ============================================================================
static void readGripperADC(uint16_t *adc0, uint16_t *adc1, uint16_t *adc2, uint16_t *adc3)
{
    // 同時觸發三個 ADC 模組
    ADC_forceSOC(ADCA_BASE, ADC_SOC_NUMBER0 | ADC_SOC_NUMBER1);
    ADC_forceSOC(ADCB_BASE, ADC_SOC_NUMBER0);
    ADC_forceSOC(ADCC_BASE, ADC_SOC_NUMBER0);

    // 等待 ADCA SOC1 結束 (作為四通道轉換完成同步點)
    while (!ADC_getInterruptStatus(ADCA_BASE, ADC_INT_NUMBER1)) {}
    ADC_clearInterruptStatus(ADCA_BASE, ADC_INT_NUMBER1);

    *adc0 = ADC_readResult(ADCARESULT_BASE, ADC_SOC_NUMBER0); // A2 (夾持力 SGS)
    *adc1 = ADC_readResult(ADCARESULT_BASE, ADC_SOC_NUMBER1); // A3 (位移 SGS)
    *adc2 = ADC_readResult(ADCBRESULT_BASE, ADC_SOC_NUMBER0); // B2 (第 3 路)
    *adc3 = ADC_readResult(ADCCRESULT_BASE, ADC_SOC_NUMBER0); // C2 (第 4 路)
}

// ============================================================================
// 1 kHz (每 1 ms) 即時閉迴路控制中斷服務常式 (CPU Timer 0 ISR)
// ============================================================================
__interrupt void cpuTimer0ISR(void)
{
    uint16_t adc0, adc1, adc2, adc3;

    // 1. 擷取 4 路 ADC
    readGripperADC(&adc0, &adc1, &adc2, &adc3);
    gRt.rawAdc[0] = adc0;
    gRt.rawAdc[1] = adc1;
    gRt.rawAdc[2] = adc2;
    gRt.rawAdc[3] = adc3;

    // 2. 濾波與正規化 (針對 ADC0 夾持力)
    if (!gRt.filterInit)
    {
        gRt.filtAdcForce = (float)adc0;
        gRt.filterInit   = true;
    }
    else
    {
        gRt.filtAdcForce = (0.75f * gRt.filtAdcForce) + (0.25f * (float)adc0);
    }

    int16_t filtInt = (int16_t)(gRt.filtAdcForce + 0.5f);
    gRt.measForce   = (filtInt - gParams.forceZero) * gParams.forceDir;

    // 3. 狀態機與閉迴路控制 (支援 actDir = -1: 減壓夾緊、加壓撐開)
    switch (gRt.state)
    {
        case STATE_IDLE:
            break;

        case STATE_SEARCH:
        {
            if (gRt.measForce >= gParams.touchThreshold)
            {
                float initErr = (float)(gParams.targetForce - gRt.measForce);
                gRt.errPrev1  = initErr;
                gRt.errPrev2  = initErr;
                gRt.state     = STATE_HOLD;
            }
            else
            {
                // 往夾緊方向推進: 當 actDir = -1 時，dacAccum 遞減 (從高壓往 0V 合攏)
                float step = (float)gParams.searchStepX10 * 0.1f * (float)gParams.actDir;
                gRt.dacAccum += step;

                if (gParams.actDir < 0)
                {
                    // 減壓夾緊模式: 若降到 0V 仍未碰到部品 -> 空夾保護 FAULT
                    if (gRt.dacAccum <= 0.0f)
                    {
                        gRt.dacAccum = 0.0f;
                        gRt.state    = STATE_FAULT;
                    }
                }
                else
                {
                    // 加壓夾緊模式: 若升到 maxDac 仍未碰到部品 -> 空夾保護 FAULT
                    if (gRt.dacAccum >= (float)gParams.maxDac)
                    {
                        gRt.dacAccum = (float)gParams.maxDac;
                        gRt.state    = STATE_FAULT;
                    }
                }
            }
            break;
        }

        case STATE_HOLD:
        {
            int16_t errInt = gParams.targetForce - gRt.measForce;
            float err      = (float)errInt;
            float deltaU   = 0.0f;

            if (abs(errInt) > gParams.deadband)
            {
                float kp = (float)gParams.kpX1000 * 0.001f;
                float ki = (float)gParams.kiX1000 * 0.001f;
                float kd = (float)gParams.kdX1000 * 0.001f;

                deltaU = (kp * (err - gRt.errPrev1))
                       + (ki * err)
                       + (kd * (err - (2.0f * gRt.errPrev1) + gRt.errPrev2));

                float maxStep = (float)gParams.maxPidStepX10 * 0.1f;
                if (deltaU > maxStep)       deltaU = maxStep;
                else if (deltaU < -maxStep) deltaU = -maxStep;
            }

            gRt.errPrev2  = gRt.errPrev1;
            gRt.errPrev1  = err;

            // 乘上 actDir: 當 actDir = -1 且 err > 0 (不夠緊) 時，自動減小 DAC 電壓以夾更緊！
            gRt.dacAccum += (deltaU * (float)gParams.actDir);

            if (gRt.dacAccum > (float)gParams.maxDac) gRt.dacAccum = (float)gParams.maxDac;
            if (gRt.dacAccum < 0.0f)                  gRt.dacAccum = 0.0f;
            break;
        }

        case STATE_RELEASE:
        {
            // 往鬆開(撐開)方向移動: 當 actDir = -1 時，DAC 往 maxDac 遞增撐開！
            float relStep = (float)gParams.releaseStepX10 * 0.1f * (float)(-gParams.actDir);
            gRt.dacAccum += relStep;

            if (gParams.actDir < 0)
            {
                // 減壓夾緊/加壓撐開模式: 升壓到 maxDac 即完成撐開，回到 IDLE 待命
                if (gRt.dacAccum >= (float)gParams.maxDac)
                {
                    gRt.dacAccum = (float)gParams.maxDac;
                    gRt.state    = STATE_IDLE;
                }
            }
            else
            {
                if (gRt.dacAccum <= 0.0f)
                {
                    gRt.dacAccum = 0.0f;
                    gRt.state    = STATE_IDLE;
                }
            }
            break;
        }

        case STATE_REST:
        {
            // 不論 actDir 為何，平滑將 DAC 洩放回 0V 斷電休息
            float restStep = (float)gParams.releaseStepX10 * 0.1f;
            gRt.dacAccum -= restStep;
            if (gRt.dacAccum <= 0.0f)
            {
                gRt.dacAccum = 0.0f;
                gRt.state    = STATE_IDLE;
            }
            break;
        }

        case STATE_FAULT:
        default:
            break;
    }

    // 4. 寫入硬體 DACA
    uint16_t dacOut = (uint16_t)(gRt.dacAccum + 0.5f);
    if (dacOut > 4095U) dacOut = 4095U;
    gRt.currentDac = dacOut;
    DAC_setShadowValue(DAC_A_BASE, dacOut);

    // 5. 黑盒子歷史紀錄 (當 gLogActive 為 true 時自動取樣)
    if (gLogActive)
    {
        gLogTickCnt++;
        if (gLogTickCnt >= gParams.logDiv)
        {
            gLogTickCnt = 0U;
            if (gLogCount < LOG_MAX_SAMPLES)
            {
                uint16_t idx = gLogCount;
                gLogBuf[idx].packedStateDac = (((uint16_t)gRt.state & 0x000FU) << 12U)
                                            | (dacOut & 0x0FFFU);
                gLogBuf[idx].adc[0] = gRt.rawAdc[0];
                gLogBuf[idx].adc[1] = gRt.rawAdc[1];
                gLogBuf[idx].adc[2] = gRt.rawAdc[2];
                gLogBuf[idx].adc[3] = gRt.rawAdc[3];
                gLogCount = idx + 1U;
            }
            else
            {
                gLogActive = false; // 錄滿 600 筆自動停止
            }
        }
    }

    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP1);
}

// ============================================================================
// 功能模組控制函式
// ============================================================================

// 空載歸零校正 ("ZERO") - 維持當前待機電壓下直接取樣歸零，不強制拉回 0V
static bool handleZeroCalibration(void)
{
    uint16_t i, fVal, pVal, bVal, cVal;
    uint32_t sumForce = 0UL, sumPos = 0UL;

    // 僅允許在 STATE_IDLE 靜止待機下歸零 (不論此時是在 0V 還是已撐開在 maxDac)
    if (gRt.state != STATE_IDLE)
    {
        return false;
    }

    // 暫停 1kHz 控制中斷，避免與主迴圈同時呼叫 readGripperADC() 造成死機
    Interrupt_disable(INT_TIMER0);

    for (i = 0U; i < 16U; i++)
    {
        DEVICE_DELAY_US(500);
        readGripperADC(&fVal, &pVal, &bVal, &cVal);
        sumForce += fVal;
        sumPos   += pVal;
    }

    gParams.forceZero = (int16_t)(sumForce >> 4U);
    gRt.posZero       = (int16_t)(sumPos >> 4U);
    gRt.filtAdcForce  = (float)gParams.forceZero;
    gRt.measForce     = 0;
    gRt.filterInit    = true;
    gRt.isCalibrated  = true;

    // 恢復 1kHz 控制中斷
    Interrupt_enable(INT_TIMER0);
    return true;
}

// 回報系統即時狀態 ("STATUS" -> "<State>,<DAC>,<Force>,<ADC0>,<ADC1>,<ADC2>,<ADC3>\n")
static void handleStatus(void)
{
    char outBuf[64];
    uint16_t pos = 0U;

    pos += u16ToStr((uint16_t)gRt.state, &outBuf[pos]);
    outBuf[pos++] = ',';
    pos += u16ToStr(gRt.currentDac, &outBuf[pos]);
    outBuf[pos++] = ',';
    pos += i32ToStr((int32_t)gRt.measForce, &outBuf[pos]);
    outBuf[pos++] = ',';
    pos += u16ToStr(gRt.rawAdc[0], &outBuf[pos]);
    outBuf[pos++] = ',';
    pos += u16ToStr(gRt.rawAdc[1], &outBuf[pos]);
    outBuf[pos++] = ',';
    pos += u16ToStr(gRt.rawAdc[2], &outBuf[pos]);
    outBuf[pos++] = ',';
    pos += u16ToStr(gRt.rawAdc[3], &outBuf[pos]);
    outBuf[pos++] = '\n';

    SCI_writeCharArray(COMM_SCI_BASE, (const uint16_t *)outBuf, pos);
}

// 批次下載黑盒子紀錄 ("LOG,<start>,<count>," -> 吐出資料後送 "END\n")
static void dumpLogRecords(uint16_t startIdx, uint16_t reqCount)
{
    char lineBuf[64];
    uint16_t i, pos;

    // 下載前先停止黑盒子錄製，確保讀取期間陣列內容不會被 ISR 改寫
    gLogActive = false;
    uint16_t total = gLogCount;

    if (startIdx >= total)
    {
        SCI_sendStr("END\n");
        return;
    }

    uint16_t endIdx = startIdx + reqCount;
    if (endIdx > total) endIdx = total;

    for (i = startIdx; i < endIdx; i++)
    {
        uint16_t packed = gLogBuf[i].packedStateDac;
        uint16_t state  = (packed >> 12U) & 0x000FU;
        uint16_t dac    = packed & 0x0FFFU;

        pos = 0U;
        pos += u16ToStr(i, &lineBuf[pos]);
        lineBuf[pos++] = ',';
        pos += u16ToStr(state, &lineBuf[pos]);
        lineBuf[pos++] = ',';
        pos += u16ToStr(dac, &lineBuf[pos]);
        lineBuf[pos++] = ',';
        pos += u16ToStr(gLogBuf[i].adc[0], &lineBuf[pos]);
        lineBuf[pos++] = ',';
        pos += u16ToStr(gLogBuf[i].adc[1], &lineBuf[pos]);
        lineBuf[pos++] = ',';
        pos += u16ToStr(gLogBuf[i].adc[2], &lineBuf[pos]);
        lineBuf[pos++] = ',';
        pos += u16ToStr(gLogBuf[i].adc[3], &lineBuf[pos]);
        lineBuf[pos++] = '\n';

        SCI_writeCharArray(COMM_SCI_BASE, (const uint16_t *)lineBuf, pos);
    }
    SCI_sendStr("END\n");
}

// [FUNC "A"] DOUT
static bool handleDOUT(const char *idxStr, const char *val1Str)
{
    if (*idxStr == '\0' || *val1Str == '\0') return false;
    uint32_t pin = (uint32_t)atoi(idxStr);
    int16_t state = atoi(val1Str);
    if ((pin != DOUT_PIN_1 && pin != DOUT_PIN_2) || (state != 0 && state != 1)) return false;
    GPIO_writePin(pin, (uint32_t)state);
    return true;
}

// [FUNC "B"] PWM
static bool handlePWM(const char *idxStr, const char *val1Str, const char *val2Str)
{
    if (*idxStr == '\0' || *val1Str == '\0' || *val2Str == '\0') return false;
    uint32_t base;
    if (idxStr[0] == 'A' && idxStr[1] == '\0')      base = PWM_A_BASE;
    else if (idxStr[0] == 'B' && idxStr[1] == '\0') base = PWM_B_BASE;
    else return false;
    int16_t duty = atoi(val1Str);
    int32_t freq = atol(val2Str);
    if (duty < 0 || duty > 100 || freq < 1000L || freq > 10000L) return false;
    uint16_t tbprd = (uint16_t)((PWM_TBCLK_HZ / (uint32_t)freq) - 1UL);
    EPWM_setTimeBasePeriod(base, tbprd);
    if (duty == 0) EPWM_setActionQualifierContSWForceAction(base, EPWM_AQ_OUTPUT_A, EPWM_AQ_SW_OUTPUT_LOW);
    else if (duty == 100) EPWM_setActionQualifierContSWForceAction(base, EPWM_AQ_OUTPUT_A, EPWM_AQ_SW_OUTPUT_HIGH);
    else {
        EPWM_setActionQualifierContSWForceAction(base, EPWM_AQ_OUTPUT_A, EPWM_AQ_SW_DISABLED);
        uint16_t cmpa = (uint16_t)(((uint32_t)(tbprd + 1U) * (uint32_t)duty) / 100UL);
        EPWM_setCounterCompareValue(base, EPWM_COUNTER_COMPARE_A, cmpa);
    }
    return true;
}

// [FUNC "C"] 手動 DAC (加入中斷保護，確保狀態與累加器原子更新)
static bool handleDAC(const char *idxStr, const char *val1Str)
{
    if (*idxStr == '\0' || *val1Str == '\0') return false;
    int16_t dacVal = atoi(val1Str);
    if (dacVal < 0 || dacVal > 4095) return false;
    if (idxStr[0] == 'A' && idxStr[1] == '\0') {
        Interrupt_disable(INT_TIMER0);
        gRt.state      = STATE_IDLE;
        gRt.dacAccum   = (float)dacVal;
        gRt.currentDac = (uint16_t)dacVal;
        DAC_setShadowValue(DAC_A_BASE, (uint16_t)dacVal);
        Interrupt_enable(INT_TIMER0);
        return true;
    } else if (idxStr[0] == 'B' && idxStr[1] == '\0') {
        DAC_setShadowValue(DAC_B_BASE, (uint16_t)dacVal);
        return true;
    }
    return false;
}

// [FUNC "D"] 讀取單次 ADC
static void handleADC(const char *idxStr)
{
    char outBuf[32];
    uint16_t pos = 0U;
    if (*idxStr != '\0') { SCI_sendErr(); return; }
    pos += u16ToStr(gRt.rawAdc[0], &outBuf[pos]); outBuf[pos++] = ',';
    pos += u16ToStr(gRt.rawAdc[1], &outBuf[pos]); outBuf[pos++] = ',';
    pos += u16ToStr(gRt.rawAdc[2], &outBuf[pos]); outBuf[pos++] = ',';
    pos += u16ToStr(gRt.rawAdc[3], &outBuf[pos]); outBuf[pos++] = '\n';
    SCI_writeCharArray(COMM_SCI_BASE, (const uint16_t *)outBuf, pos);
}

// [FUNC "E"] 超參數設定
static bool handleParamSet(const char *idxStr, const char *val1Str)
{
    if (*idxStr == '\0' || *val1Str == '\0') return false;
    int16_t paramId = atoi(idxStr);
    int32_t val     = atol(val1Str);

    switch (paramId)
    {
        case 0:  if (val < 1L || val > 4095L) return false; gParams.targetForce = (int16_t)val; break;
        case 1:  if (val < 1L || val > 4095L) return false; gParams.touchThreshold = (int16_t)val; break;
        case 2:  if (val < 1L || val > 2000L) return false; gParams.searchStepX10 = (uint16_t)val; break;
        case 3:  if (val < 1L || val > 2000L) return false; gParams.releaseStepX10 = (uint16_t)val; break;
        case 4:  if (val < 1L || val > 2000L) return false; gParams.maxPidStepX10 = (uint16_t)val; break;
        case 5:  if (val < 0L || val > 50000L) return false; gParams.kpX1000 = val; break;
        case 6:  if (val < 0L || val > 50000L) return false; gParams.kiX1000 = val; break;
        case 7:  if (val < 0L || val > 50000L) return false; gParams.kdX1000 = val; break;
        case 8:  if (val != 1L && val != -1L) return false; gParams.forceDir = (int16_t)val; break;
        case 9:
            if (val < 0L || val > 4095L) return false;
            gParams.forceZero = (int16_t)val;
            gRt.isCalibrated  = true; // 手動指定零點亦視為已校正
            break;
        case 10: if (val < 0L || val > 100L) return false; gParams.deadband = (int16_t)val; break;
        case 11: if (val < 0L || val > 4095L) return false; gParams.maxDac = (uint16_t)val; break;
        case 12: if (val < 1L || val > 50L) return false; gParams.logDiv = (uint16_t)val; break;
        case 13: if (val != 1L && val != -1L) return false; gParams.actDir = (int16_t)val; break;
        default: return false;
    }
    return true;
}

// ============================================================================
// 指令解析器
// ============================================================================
static void processCommand(char *cmd)
{
    if (strcmp(cmd, "DEV") == 0) { SCI_sendStr("Device_v261023\n"); return; }
    if (strcmp(cmd, "STATUS") == 0) { handleStatus(); return; }

    // [ZERO] 僅允許在 STATE_IDLE 待機時歸零
    if (strcmp(cmd, "ZERO") == 0)
    {
        if (handleZeroCalibration()) SCI_sendAck();
        else SCI_sendErr();
        return;
    }

    // [STOP] 緊急原地凍結指令 (立刻停在當前 DAC 電壓並切回 IDLE，不洗掉 LOG)
    if (strcmp(cmd, "STOP") == 0)
    {
        gRt.state = STATE_IDLE;
        SCI_sendAck();
        return;
    }

    // [REST] 平滑將 DAC 降回 0V 斷電休息
    if (strcmp(cmd, "REST") == 0)
    {
        gRt.state = STATE_REST;
        SCI_sendAck();
        return;
    }

    // [PICK] 開始夾取 (必須已完成歸零，且只允許從 IDLE 或 HOLD 執行)
    if (strncmp(cmd, "PICK", 4) == 0)
    {
        // 防呆1: 未完成零點校正前拒絕盲夾
        if (!gRt.isCalibrated)
        {
            SCI_sendErr();
            return;
        }
        // 防呆2: 只允許從 IDLE (新一輪夾取) 或 HOLD (夾持中動態微調目標力) 進入
        if (gRt.state != STATE_IDLE && gRt.state != STATE_HOLD)
        {
            SCI_sendErr();
            return;
        }
        // 防呆3: 反向動作夾爪，必須先撐開 (currentDac > 0) 才能往內夾
        if (gParams.actDir < 0 && gRt.currentDac == 0U && gRt.state == STATE_IDLE)
        {
            SCI_sendErr(); 
            return;
        }

        if (cmd[4] == '\0')
        {
            if (gRt.state == STATE_IDLE)
            {
                startLogger(); // 從待機開始新一輪夾取時，才清空並啟動黑盒子
                gRt.state = STATE_SEARCH;
            }
            SCI_sendAck();
            return;
        }
        else if (cmd[4] == ',')
        {
            int16_t newTarget = atoi(&cmd[5]);
            if (newTarget > 0 && newTarget <= 4095)
            {
                gParams.targetForce = newTarget;
                if (gRt.state == STATE_IDLE)
                {
                    startLogger(); // 從待機開始新一輪夾取時，才清空並啟動黑盒子
                    gRt.state = STATE_SEARCH;
                }
                SCI_sendAck();
            }
            else
            {
                SCI_sendErr();
            }
            return;
        }
        SCI_sendErr();
        return;
    }

    // [RELEASE] 任何狀態下皆可緊急中止並平滑退回 0 (不呼叫 startLogger，完整保留 PICK 紀錄)
    if (strcmp(cmd, "RELEASE") == 0)
    {
        gRt.state = STATE_RELEASE;
        SCI_sendAck();
        return;
    }

    // 處理 LOG 相關指令
    if (strncmp(cmd, "LOG", 3) == 0)
    {
        if (cmd[3] == '\0') // "LOG" 直接下載全部
        {
            dumpLogRecords(0U, LOG_MAX_SAMPLES);
            return;
        }
        else if (cmd[3] == ',')
        {
            char *subCmd = &cmd[4];
            if (strncmp(subCmd, "INFO", 4) == 0)
            {
                char outBuf[32];
                uint16_t pos = 0U;
                pos += u16ToStr(gLogActive ? 1U : 0U, &outBuf[pos]); outBuf[pos++] = ',';
                pos += u16ToStr(gLogCount, &outBuf[pos]); outBuf[pos++] = ',';
                pos += u16ToStr(gParams.logDiv, &outBuf[pos]); outBuf[pos++] = '\n';
                SCI_writeCharArray(COMM_SCI_BASE, (const uint16_t *)outBuf, pos);
                return;
            }
            else if (strncmp(subCmd, "START", 5) == 0)
            {
                startLogger();
                SCI_sendAck();
                return;
            }
            else if (strncmp(subCmd, "STOP", 4) == 0)
            {
                gLogActive = false;
                SCI_sendAck();
                return;
            }
            else
            {
                // 處理 "LOG,<start>,<count>,"
                char *p1 = subCmd;
                char *p2 = strchr(p1, ',');
                if (p2 != NULL)
                {
                    *p2 = '\0';
                    char *p3 = strchr(p2 + 1, ',');
                    if (p3 != NULL) *p3 = '\0';

                    uint16_t start = (uint16_t)atoi(p1);
                    uint16_t count = (uint16_t)atoi(p2 + 1);
                    dumpLogRecords(start, count);
                    return;
                }
            }
        }
        SCI_sendErr();
        return;
    }

    // 處理 A, B, C, D, E 指令
    char *fields[4] = { "", "", "", "" };
    uint16_t fieldIdx = 0U;
    fields[0] = cmd;
    char *p = cmd;

    while (*p != '\0' && fieldIdx < 3U)
    {
        if (*p == ',') { *p = '\0'; fields[++fieldIdx] = p + 1; }
        p++;
    }

    if (fields[0][0] == '\0' || fields[0][1] != '\0') { SCI_sendErr(); return; }

    bool ok = false;
    switch (fields[0][0])
    {
        case 'A': ok = handleDOUT(fields[1], fields[2]); if(ok) SCI_sendAck(); else SCI_sendErr(); break;
        case 'B': ok = handlePWM(fields[1], fields[2], fields[3]); if(ok) SCI_sendAck(); else SCI_sendErr(); break;
        case 'C': ok = handleDAC(fields[1], fields[2]); if(ok) SCI_sendAck(); else SCI_sendErr(); break;
        case 'D': handleADC(fields[1]); break;
        case 'E': ok = handleParamSet(fields[1], fields[2]); if(ok) SCI_sendAck(); else SCI_sendErr(); break;
        default: SCI_sendErr(); break;
    }
}

// ============================================================================
// 外設底層初始化
// ============================================================================
static void initPeripheralsManual(void)
{
    uint16_t i;

    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_SCIA);
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_EPWM1);
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_EPWM2);
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_ADCA);
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_ADCB);
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_ADCC);
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_DACA);
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_DACB);
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_CPUTIMER0);

    GPIO_setAnalogMode(231U, GPIO_ANALOG_ENABLED); // A0
    GPIO_setAnalogMode(232U, GPIO_ANALOG_ENABLED); // A1
    GPIO_setAnalogMode(224U, GPIO_ANALOG_ENABLED); // A2 (ADC0)
    GPIO_setAnalogMode(242U, GPIO_ANALOG_ENABLED); // A3 (ADC1)
    GPIO_setAnalogMode(226U, GPIO_ANALOG_ENABLED); // B2 (ADC2)
    GPIO_setAnalogMode(244U, GPIO_ANALOG_ENABLED); // C2 (ADC3)

    ADC_setVREF(ADCA_BASE, ADC_REFERENCE_INTERNAL, ADC_REFERENCE_3_3V);
    ADC_setVREF(ADCB_BASE, ADC_REFERENCE_INTERNAL, ADC_REFERENCE_3_3V);
    ADC_setVREF(ADCC_BASE, ADC_REFERENCE_INTERNAL, ADC_REFERENCE_3_3V);

    uint32_t dacBases[2] = { DAC_A_BASE, DAC_B_BASE };
    for (i = 0U; i < 2U; i++) {
        DAC_setReferenceVoltage(dacBases[i], DAC_REF_ADC_VREFHI);
        DAC_setGainMode(dacBases[i], DAC_GAIN_TWO);
        DAC_setLoadMode(dacBases[i], DAC_LOAD_SYSCLK);
        DAC_setShadowValue(dacBases[i], 0U);
        DAC_enableOutput(dacBases[i]);
    }

    uint32_t adcBases[3] = { ADCA_BASE, ADCB_BASE, ADCC_BASE };
    for (i = 0U; i < 3U; i++) {
        ADC_setPrescaler(adcBases[i], ADC_CLK_DIV_2_0);
        ADC_setInterruptPulseMode(adcBases[i], ADC_PULSE_END_OF_CONV);
        ADC_enableConverter(adcBases[i]);
    }
    DEVICE_DELAY_US(1000);

    // 配置 4 個 SOC (A2, A3, B2, C2)
    ADC_setupSOC(ADCA_BASE, ADC_SOC_NUMBER0, ADC_TRIGGER_SW_ONLY, ADC_CH_ADCIN2, 15U); // A2
    ADC_setupSOC(ADCA_BASE, ADC_SOC_NUMBER1, ADC_TRIGGER_SW_ONLY, ADC_CH_ADCIN3, 15U); // A3
    ADC_setupSOC(ADCB_BASE, ADC_SOC_NUMBER0, ADC_TRIGGER_SW_ONLY, ADC_CH_ADCIN2, 15U); // B2
    ADC_setupSOC(ADCC_BASE, ADC_SOC_NUMBER0, ADC_TRIGGER_SW_ONLY, ADC_CH_ADCIN2, 15U); // C2

    ADC_setInterruptSource(ADCA_BASE, ADC_INT_NUMBER1, ADC_SOC_NUMBER1);
    ADC_enableInterrupt(ADCA_BASE, ADC_INT_NUMBER1);
    ADC_clearInterruptStatus(ADCA_BASE, ADC_INT_NUMBER1);

    GPIO_setPinConfig(GPIO_58_GPIO58);
    GPIO_setPadConfig(DOUT_PIN_1, GPIO_PIN_TYPE_STD);
    GPIO_writePin(DOUT_PIN_1, 0U);
    GPIO_setDirectionMode(DOUT_PIN_1, GPIO_DIR_MODE_OUT);

    GPIO_setPinConfig(GPIO_59_GPIO59);
    GPIO_setPadConfig(DOUT_PIN_2, GPIO_PIN_TYPE_STD);
    GPIO_writePin(DOUT_PIN_2, 0U);
    GPIO_setDirectionMode(DOUT_PIN_2, GPIO_DIR_MODE_OUT);

    GPIO_setPinConfig(GPIO_0_EPWM1_A);
    GPIO_setPadConfig(0U, GPIO_PIN_TYPE_STD);
    GPIO_setPinConfig(GPIO_2_EPWM2_A);
    GPIO_setPadConfig(2U, GPIO_PIN_TYPE_STD);

    SysCtl_disablePeripheral(SYSCTL_PERIPH_CLK_TBCLKSYNC);
    uint32_t pwmBases[2] = { PWM_A_BASE, PWM_B_BASE };
    for (i = 0U; i < 2U; i++) {
        EPWM_setClockPrescaler(pwmBases[i], EPWM_CLOCK_DIVIDER_2, EPWM_HSCLOCK_DIVIDER_1);
        EPWM_setTimeBasePeriod(pwmBases[i], 49999U);
        EPWM_setTimeBaseCounter(pwmBases[i], 0U);
        EPWM_setTimeBaseCounterMode(pwmBases[i], EPWM_COUNTER_MODE_UP);
        EPWM_setCounterCompareValue(pwmBases[i], EPWM_COUNTER_COMPARE_A, 0U);
        EPWM_setPeriodLoadMode(pwmBases[i], EPWM_PERIOD_SHADOW_LOAD);
        EPWM_setCounterCompareShadowLoadMode(pwmBases[i], EPWM_COUNTER_COMPARE_A, EPWM_COMP_LOAD_ON_CNTR_ZERO);
        EPWM_setActionQualifierAction(pwmBases[i], EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_HIGH, EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);
        EPWM_setActionQualifierAction(pwmBases[i], EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_LOW, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);
        EPWM_setActionQualifierContSWForceShadowMode(pwmBases[i], EPWM_AQ_SW_IMMEDIATE_LOAD);
        EPWM_setActionQualifierContSWForceAction(pwmBases[i], EPWM_AQ_OUTPUT_A, EPWM_AQ_SW_OUTPUT_LOW);
    }
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_TBCLKSYNC);

    GPIO_setPinConfig(GPIO_28_SCIA_RX);
    GPIO_setPadConfig(28U, GPIO_PIN_TYPE_STD | GPIO_PIN_TYPE_PULLUP);
    GPIO_setQualificationMode(28U, GPIO_QUAL_ASYNC);
    GPIO_setPinConfig(GPIO_29_SCIA_TX);
    GPIO_setPadConfig(29U, GPIO_PIN_TYPE_STD | GPIO_PIN_TYPE_PULLUP);
    GPIO_setQualificationMode(29U, GPIO_QUAL_ASYNC);

    SCI_performSoftwareReset(COMM_SCI_BASE);
    SCI_setConfig(COMM_SCI_BASE, DEVICE_LSPCLK_FREQ, 115200UL,
                  (SCI_CONFIG_WLEN_8 | SCI_CONFIG_STOP_ONE | SCI_CONFIG_PAR_NONE));
    SCI_enableModule(COMM_SCI_BASE);
    SCI_enableFIFO(COMM_SCI_BASE);
    SCI_resetChannels(COMM_SCI_BASE);
    SCI_resetRxFIFO(COMM_SCI_BASE);
    SCI_resetTxFIFO(COMM_SCI_BASE);
}

// ============================================================================
// 主程式
// ============================================================================
void main(void)
{
    char cmdBuffer[CMD_BUF_SIZE];
    uint16_t cmdIndex = 0U;

    Device_init();
    Device_initGPIO();
    Interrupt_initModule();
    Interrupt_initVectorTable();

    Board_init();
    initPeripheralsManual();

    // 開機時先自動執行一次初始空載歸零校正
    (void)handleZeroCalibration();

    // 設定並啟動 1 kHz 控制迴路定時器 (CPU Timer 0)
    Interrupt_register(INT_TIMER0, &cpuTimer0ISR);
    CPUTimer_setPeriod(CPUTIMER0_BASE, (uint32_t)(DEVICE_SYSCLK_FREQ / CTRL_ISR_FREQ_HZ) - 1UL);
    CPUTimer_setPreScaler(CPUTIMER0_BASE, 0U);
    CPUTimer_stopTimer(CPUTIMER0_BASE);
    CPUTimer_reloadTimerCounter(CPUTIMER0_BASE);
    CPUTimer_setEmulationMode(CPUTIMER0_BASE, CPUTIMER_EMULATIONMODE_RUNFREE);
    CPUTimer_enableInterrupt(CPUTIMER0_BASE);
    Interrupt_enable(INT_TIMER0);
    CPUTimer_startTimer(CPUTIMER0_BASE);

    EINT;
    ERTM;

    while (1)
    {
        if ((SCI_getRxStatus(COMM_SCI_BASE) & SCI_RXSTATUS_ERROR) != 0U)
        {
            SCI_performSoftwareReset(COMM_SCI_BASE);
            cmdIndex = 0U;
        }

        while (SCI_getRxFIFOStatus(COMM_SCI_BASE) != SCI_FIFO_RX0)
        {
            char c = (char)SCI_readCharNonBlocking(COMM_SCI_BASE);
            if (c == '\n' || c == '\r')
            {
                if (cmdIndex > 0U)
                {
                    cmdBuffer[cmdIndex] = '\0';
                    processCommand(cmdBuffer);
                    cmdIndex = 0U;
                }
            }
            else
            {
                if (cmdIndex < (CMD_BUF_SIZE - 1U)) cmdBuffer[cmdIndex++] = c;
                else { cmdIndex = 0U; SCI_sendErr(); }
            }
        }
    }
}