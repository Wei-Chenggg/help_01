import csv
import time
from typing import Optional
import serial

# 若需畫圖請確保已安裝 matplotlib: pip install pyserial matplotlib
try:
    import matplotlib.pyplot as plt
    HAS_MATPLOTLIB = True
except ImportError:
    HAS_MATPLOTLIB = False


class C2000Gripper:
    """
    對應 my_test_v261023_02.c (支援 actDir=-1 加壓撐開/減壓夾緊) 的完整 Python 控制類別
    支援所有底層硬體指令 (A/B/C/D)、超參數設定 (E,0~13)、
    夾爪控制 (PICK / RELEASE / STOP / REST / ZERO / STATUS)
    以及黑盒子歷史數據擷取與繪圖 (LOG / LOG,INFO / LOG,START / LOG,STOP)
    """

    # --- 超參數 ID 定義 (對應 C 程式 handleParamSet 的 case 0 ~ 13) ---
    PARAM_TARGET_FORCE = 0   # 目標夾持保持力 (1 ~ 4095)
    PARAM_TOUCH_TH     = 1   # 初接觸切換門檻力 (1 ~ 4095)
    PARAM_SEARCH_STEP  = 2   # 探觸接近速度 (1 ~ 2000, 單位: 0.1 格 DAC / ms)
    PARAM_RELEASE_STEP = 3   # 鬆開撐開速度 (1 ~ 2000, 單位: 0.1 格 DAC / ms)
    PARAM_MAX_PID_STEP = 4   # PID 單步最大修正限速 (1 ~ 2000, 單位: 0.1 格 DAC / ms)
    PARAM_KP_X1000     = 5   # 比例增益 Kp * 1000
    PARAM_KI_X1000     = 6   # 積分增益 Ki * 1000
    PARAM_KD_X1000     = 7   # 微分增益 Kd * 1000
    PARAM_FORCE_DIR    = 8   # 夾持力感測極性 (+1 或 -1)
    PARAM_FORCE_ZERO   = 9   # ADC0 空載零點偏置值 (0 ~ 4095)
    PARAM_DEADBAND     = 10  # 力量誤差死區 (0 ~ 100)
    PARAM_MAX_DAC      = 11  # DAC 最大撐開上限 (0 ~ 4095)
    PARAM_LOG_DIV      = 12  # 黑盒子取樣分頻 (1 ~ 50 ms)
    PARAM_ACT_DIR      = 13  # 致動器方向 (-1: DAC減少=夾緊/增加=撐開; +1: DAC增加=夾緊)

    # --- 狀態機名稱對照表 (對應 GripperState_t 0 ~ 5) ---
    STATE_MAP = {
        0: "STATE_IDLE (0:待機)",
        1: "STATE_SEARCH (1:探觸接近中)",
        2: "STATE_HOLD (2:PID恆力保持)",
        3: "STATE_RELEASE (3:平滑撐開中)",
        4: "STATE_FAULT (4:空夾保護)",
        5: "STATE_REST (5:平滑降回0V休息)",
    }

    def __init__(self, port: str = "COM5", baudrate: int = 115200, timeout: float = 2.0):
        self.ser = serial.Serial(port=port, baudrate=baudrate, timeout=timeout)
        self.clear_buffers()
        time.sleep(0.3)  # 確保板子剛連線時能完整接收第一筆指令

    def clear_buffers(self) -> None:
        """清空串口收發緩衝區"""
        self.ser.reset_input_buffer()
        self.ser.reset_output_buffer()

    def close(self) -> None:
        """關閉串口連線"""
        if self.ser and self.ser.is_open:
            self.ser.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    # ========================================================================
    # 1. 底層收發核心函式
    # ========================================================================
    def send_raw(self, cmd: str) -> str:
        """發送單行指令並讀取單行回應"""
        payload = f"{cmd.strip()}\n".encode("ascii")
        self.ser.write(payload)
        self.ser.flush()
        resp = self.ser.readline().decode("ascii", errors="replace").strip()
        return resp

    def _expect_ack(self, cmd: str) -> bool:
        """發送指令並確認 C2000 是否回傳 'R'"""
        resp = self.send_raw(cmd)
        if resp != "R":
            print(f"[警告] 指令 {cmd!r} 被拒絕或回傳異常: {resp!r}")
            return False
        return True

    # ========================================================================
    # 2. 系統與基礎外設控制指令 (DEV, A, B, C, D)
    # ========================================================================
    def get_device_version(self) -> str:
        """[DEV] 查詢裝置版本 (預期回傳 'Device_v261023')"""
        return self.send_raw("DEV")

    def set_dout(self, gpio_pin: int, state: int | bool) -> bool:
        """
        [FUNC A] 控制數位輸出 DOUT
        :param gpio_pin: 58 或 59
        :param state: 1 (High/True) 或 0 (Low/False)
        """
        val = 1 if state else 0
        return self._expect_ack(f"A,{gpio_pin},{val},")

    def set_pwm(self, channel: str, duty: int, freq_hz: int) -> bool:
        """
        [FUNC B] 設定 PWM 輸出
        :param channel: 'A' (GPIO0/ePWM1A) 或 'B' (GPIO2/ePWM2A)
        :param duty: 責任週期整數 0 ~ 100 (%)
        :param freq_hz: 頻率整數 1000 ~ 10000 (Hz)
        """
        ch = channel.upper().strip()
        return self._expect_ack(f"B,{ch},{int(duty)},{int(freq_hz)}")

    def set_dac_manual(self, channel: str, dac_val: int) -> bool:
        """
        [FUNC C] 手動設定 DAC 輸出 (設定 A 通道時 C2000 會自動切回 STATE_IDLE)
        :param channel: 'A' (DACA/A0) 或 'B' (DACB/A1)
        :param dac_val: 0 ~ 4095 (對應 0 ~ 3.3V / 放大後 0 ~ 120V)
        """
        ch = channel.upper().strip()
        return self._expect_ack(f"C,{ch},{int(dac_val)},")

    def read_adc_raw(self) -> list[int]:
        """
        [FUNC D] 單次讀取 4 個 ADC 通道原始值
        :return: [ADC0, ADC1, ADC2, ADC3] (範圍 0 ~ 4095)
        """
        resp = self.send_raw("D,,,")
        if resp == "E" or not resp:
            raise RuntimeError(f"ADC 讀取失敗，回傳: {resp!r}")
        return [int(x) for x in resp.split(",")]

    # ========================================================================
    # 3. 壓電夾爪閉迴路動作與狀態指令 (ZERO, PICK, RELEASE, STOP, REST, STATUS)
    # ========================================================================
    def zero_calibrate(self) -> bool:
        """
        [ZERO] 在當前待機狀態 (STATE_IDLE) 下直接取樣 16 次平均作為空載零點
        注意：建議先執行 release() 並 wait_until_idle() 讓夾爪完全撐開後，再呼叫此函式！
        """
        return self._expect_ack("ZERO")

    def pick(self, target_force: Optional[int] = None) -> bool:
        """
        [PICK] 開始夾取動作 (actDir=-1 時從高壓往 0V 降壓合攏，並自動觸發黑盒子錄製)
        :param target_force: 若有指定 (1~4095)，會一併更新目標夾持力；若為 None 則使用當前設定值
        """
        if target_force is not None:
            return self._expect_ack(f"PICK,{int(target_force)}")
        return self._expect_ack("PICK")

    def release(self) -> bool:
        """
        [RELEASE] 平滑鬆開/撐開夾爪 (actDir=-1 時平滑升壓至 maxDac 撐開兩爪，不洗掉 LOG)
        """
        return self._expect_ack("RELEASE")

    def stop_freeze(self) -> bool:
        """
        [STOP] 緊急原地凍結在當前 DAC 電壓並切換回 STATE_IDLE (不洗掉 LOG)
        """
        return self._expect_ack("STOP")

    def rest(self) -> bool:
        """
        [REST] 平滑將 DAC 降壓回 0V 斷電休息 (實驗結束或長時間待機時使用，避免長期高壓)
        """
        return self._expect_ack("REST")

    def get_status(self) -> dict:
        """
        [STATUS] 查詢即時控制狀態
        C2000 回傳格式: <State>,<DAC>,<Force>,<ADC0>,<ADC1>,<ADC2>,<ADC3>
        """
        resp = self.send_raw("STATUS")
        parts = resp.split(",")
        if len(parts) != 7:
            raise RuntimeError(f"STATUS 回傳格式異常: {resp!r}")

        state_code = int(parts[0])
        return {
            "state":      state_code,
            "state_name": self.STATE_MAP.get(state_code, f"UNKNOWN({state_code})"),
            "dac":        int(parts[1]),
            "force":      int(parts[2]),  # 已扣零點並乘極性的有效夾持力
            "adc0":       int(parts[3]),  # 夾持力 SGS 原始值
            "adc1":       int(parts[4]),  # 位移 SGS 原始值
            "adc2":       int(parts[5]),  # 第 3 路 ADC 原始值
            "adc3":       int(parts[6]),  # 第 4 路 ADC 原始值
        }

    def wait_until_idle(self, timeout_s: float = 3.0, poll_interval_s: float = 0.05) -> bool:
        """
        等待夾爪完成 RELEASE (撐開到位) 或 REST (回到 0V) 並進入 STATE_IDLE (0)
        同時額外等待 0.15 秒確保硬體 5kΩ*5uF RC 完全充放電穩定
        """
        t0 = time.time()
        while (time.time() - t0) < timeout_s:
            st = self.get_status()
            if st["state"] == 0:  # STATE_IDLE
                time.sleep(0.15)  # 額外等待 150ms (> 5*tau_RC) 讓壓電電壓徹底穩定
                return True
            time.sleep(poll_interval_s)
        print("[警告] 等待進入 STATE_IDLE 逾時！")
        return False

    # ========================================================================
    # 4. 超參數設定指令 (FUNC E, ID 0 ~ 13)
    # ========================================================================
    def set_param_raw(self, param_id: int, val: int) -> bool:
        """[FUNC E] 直接以參數編號 (0~13) 設定整數超參數"""
        return self._expect_ack(f"E,{int(param_id)},{int(val)},")

    def configure_force_params(
        self,
        target_force: Optional[int] = None,
        touch_threshold: Optional[int] = None,
        force_dir: Optional[int] = None,
        force_zero: Optional[int] = None,
        deadband: Optional[int] = None,
        max_dac: Optional[int] = None,
        act_dir: Optional[int] = None,
    ) -> bool:
        """設定力量與方向相關超參數 (只傳入想修改的項目即可)"""
        ok = True
        if target_force is not None:
            ok &= self.set_param_raw(self.PARAM_TARGET_FORCE, target_force)
        if touch_threshold is not None:
            ok &= self.set_param_raw(self.PARAM_TOUCH_TH, touch_threshold)
        if force_dir is not None:
            ok &= self.set_param_raw(self.PARAM_FORCE_DIR, force_dir)
        if force_zero is not None:
            ok &= self.set_param_raw(self.PARAM_FORCE_ZERO, force_zero)
        if deadband is not None:
            ok &= self.set_param_raw(self.PARAM_DEADBAND, deadband)
        if max_dac is not None:
            ok &= self.set_param_raw(self.PARAM_MAX_DAC, max_dac)
        if act_dir is not None:
            ok &= self.set_param_raw(self.PARAM_ACT_DIR, act_dir)
        return ok

    def configure_speed_steps(
        self,
        search_step_dac_per_ms: Optional[float] = None,
        release_step_dac_per_ms: Optional[float] = None,
        max_pid_step_dac_per_ms: Optional[float] = None,
    ) -> bool:
        """
        以直覺的「每毫秒幾格 DAC (格/ms)」設定斜率參數 (內部自動乘以 10 轉為整數)
        例如傳入 search_step_dac_per_ms=8.0 -> 自動下達 E,2,80,
        """
        ok = True
        if search_step_dac_per_ms is not None:
            ok &= self.set_param_raw(self.PARAM_SEARCH_STEP, round(search_step_dac_per_ms * 10))
        if release_step_dac_per_ms is not None:
            ok &= self.set_param_raw(self.PARAM_RELEASE_STEP, round(release_step_dac_per_ms * 10))
        if max_pid_step_dac_per_ms is not None:
            ok &= self.set_param_raw(self.PARAM_MAX_PID_STEP, round(max_pid_step_dac_per_ms * 10))
        return ok

    def configure_pid(
        self,
        kp: Optional[float] = None,
        ki: Optional[float] = None,
        kd: Optional[float] = None,
    ) -> bool:
        """
        以直覺的小數設定 PID 增益 (內部自動乘以 1000 轉為整數)
        例如傳入 kp=0.25, ki=0.01, kd=0.0 -> 自動下達 E,5,250 / E,6,10 / E,7,0
        """
        ok = True
        if kp is not None:
            ok &= self.set_param_raw(self.PARAM_KP_X1000, round(kp * 1000))
        if ki is not None:
            ok &= self.set_param_raw(self.PARAM_KI_X1000, round(ki * 1000))
        if kd is not None:
            ok &= self.set_param_raw(self.PARAM_KD_X1000, round(kd * 1000))
        return ok

    def set_log_divider(self, log_div_ms: int) -> bool:
        """[E,12] 設定黑盒子每幾毫秒錄 1 筆 (範圍 1 ~ 50 ms，預設 2ms)"""
        return self.set_param_raw(self.PARAM_LOG_DIV, log_div_ms)

    # ========================================================================
    # 5. 黑盒子歷史紀錄指令 (LOG,INFO / LOG,START / LOG,STOP / LOG)
    # ========================================================================
    def get_log_info(self) -> dict:
        """
        [LOG,INFO] 查詢黑盒子目前狀態
        回傳: {'active': bool, 'count': 已錄筆數, 'log_div_ms': 取樣間隔毫秒}
        """
        resp = self.send_raw("LOG,INFO")
        parts = resp.split(",")
        if len(parts) != 3:
            raise RuntimeError(f"LOG,INFO 回傳異常: {resp!r}")
        return {
            "active":     bool(int(parts[0])),
            "count":      int(parts[1]),
            "log_div_ms": int(parts[2]),
        }

    def start_log(self) -> bool:
        """[LOG,START] 手動觸發黑盒子重新開始錄製"""
        return self._expect_ack("LOG,START")

    def stop_log(self) -> bool:
        """[LOG,STOP] 手動停止黑盒子錄製"""
        return self._expect_ack("LOG,STOP")

    def fetch_log(self, start_idx: Optional[int] = None, count: Optional[int] = None) -> list[dict]:
        """
        [LOG] 下載 C2000 黑盒子歷史紀錄並自動換算時間軸 (time_ms)
        :param start_idx: 起始索引 (若為 None 則下載全部)
        :param count: 下載筆數 (若為 None 則下載全部)
        :return: list of dict, 每筆包含 time_ms, idx, state, dac, adc0, adc1, adc2, adc3
        """
        info = self.get_log_info()
        log_div_ms = info["log_div_ms"]
        if info["count"] == 0:
            print("[提示] 目前黑盒子內尚無歷史紀錄 (count=0)")
            return []

        if start_idx is None or count is None:
            cmd = "LOG\n"
        else:
            cmd = f"LOG,{int(start_idx)},{int(count)},\n"

        self.ser.write(cmd.encode("ascii"))
        self.ser.flush()

        records = []
        while True:
            line = self.ser.readline().decode("ascii", errors="replace").strip()
            if not line:
                print("[警告] 讀取 LOG 逾時 (未收到 END)")
                break
            if line == "END":
                break
            if line == "E":
                raise RuntimeError("C2000 回傳 LOG 指令錯誤 (E)")

            parts = line.split(",")
            if len(parts) == 7:
                idx = int(parts[0])
                records.append({
                    "time_ms": idx * log_div_ms,
                    "idx":     idx,
                    "state":   int(parts[1]),
                    "dac":     int(parts[2]),
                    "adc0":    int(parts[3]),
                    "adc1":    int(parts[4]),
                    "adc2":    int(parts[5]),
                    "adc3":    int(parts[6]),
                })
        return records

    # ========================================================================
    # 6. CSV 匯出與六通道對齊波形繪圖工具
    # ========================================================================
    @staticmethod
    def save_log_to_csv(records: list[dict], filepath: str = "gripper_history.csv") -> None:
        """將黑盒子歷史紀錄儲存為 CSV 檔案"""
        if not records:
            print("[提示] 無歷史紀錄可供儲存")
            return
        with open(filepath, mode="w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(records[0].keys()))
            writer.writeheader()
            writer.writerows(records)
        print(f"[完成] 已將 {len(records)} 筆紀錄匯出至 {filepath}")

    @staticmethod
    def plot_log(records: list[dict], title: str = "Piezo Gripper History Curves") -> None:
        """繪製 State + DAC + ADC0~ADC3 共 6 條時間對齊曲線"""
        if not HAS_MATPLOTLIB:
            print("[提示] 尚未安裝 matplotlib，請執行: pip install matplotlib")
            return
        if not records:
            print("[提示] 紀錄為空，無法繪圖")
            return

        t     = [r["time_ms"] for r in records]
        state = [r["state"]   for r in records]
        dac   = [r["dac"]     for r in records]
        adc0  = [r["adc0"]    for r in records]
        adc1  = [r["adc1"]    for r in records]
        adc2  = [r["adc2"]    for r in records]
        adc3  = [r["adc3"]    for r in records]

        fig, axes = plt.subplots(3, 1, figsize=(11, 8), sharex=True)

        # 子圖 1: 當下狀態碼 (0~5)
        axes[0].step(t, state, where="post", color="purple", linewidth=2.0, label="State Code")
        axes[0].set_ylabel("State")
        axes[0].set_yticks([0, 1, 2, 3, 4, 5])
        axes[0].set_yticklabels(["0:IDLE", "1:SEARCH", "2:HOLD", "3:RELEASE", "4:FAULT", "5:REST"])
        axes[0].grid(True, linestyle="--", alpha=0.6)
        axes[0].legend(loc="upper right")
        axes[0].set_title(title)

        # 子圖 2: DAC 當下輸出數值 (0~4095)
        axes[1].plot(t, dac, color="tab:red", linewidth=1.8, label="DAC Output (0~4095)")
        axes[1].set_ylabel("DAC (Counts)")
        axes[1].grid(True, linestyle="--", alpha=0.6)
        axes[1].legend(loc="upper right")

        # 子圖 3: 四路應變規 ADC0 ~ ADC3
        axes[2].plot(t, adc0, label="ADC0 (Force SGS)", linewidth=2.0, color="tab:blue")
        axes[2].plot(t, adc1, label="ADC1 (Pos SGS)",   linewidth=1.5, color="tab:orange")
        axes[2].plot(t, adc2, label="ADC2 (B2)",        linewidth=1.2, color="tab:green", alpha=0.8)
        axes[2].plot(t, adc3, label="ADC3 (C2)",        linewidth=1.2, color="tab:brown", alpha=0.8)
        axes[2].set_xlabel("Time (ms)")
        axes[2].set_ylabel("ADC (0~4095)")
        axes[2].grid(True, linestyle="--", alpha=0.6)
        axes[2].legend(loc="upper right")

        plt.tight_layout()
        plt.show()


# ============================================================================
# 實機執行與示範流程 (專為「DAC增加=撐開、DAC減少=夾緊」機構設計)
# ============================================================================
def run_demo_workflow(port: str = "COM5"):
    """
    完整標準流程：
    1. 設定超參數 (act_dir = -1)
    2. 先執行 RELEASE 將夾爪平滑升壓撐開至 MAX_DAC (4095)
    3. 等待撐開穩定後，執行 ZERO 空載歸零
    4. 執行 PICK 開始降壓合攏夾取 (黑盒子自動錄製 600 點)
    5. 執行 RELEASE 升壓撐開鬆手 (保留剛才 PICK 的黑盒子紀錄)
    6. 下載黑盒子歷史曲線並畫圖
    7. 測試完畢，執行 REST 平滑降壓回 0V 斷電休息
    """
    with C2000Gripper(port=port, baudrate=115200) as dev:
        # 1. 檢查版本
        ver = dev.get_device_version()
        print(f"1. 連線成功，C2000 版本: {ver}")

        # 2. 設定超參數 (act_dir=-1 代表 DAC 增加時撐開、減少時夾緊)
        dev.configure_force_params(
            target_force=200,      # 目標夾持力 200 格
            touch_threshold=20,    # 初接觸門檻 20 格
            force_dir=1,           # 若夾緊時 ADC0 原始讀值減小，請改為 -1
            deadband=2,            # 誤差死區 +-2 格
            max_dac=4095,          # 最大撐開 DAC 上限
            act_dir=-1,            # -1: DAC 減少 = 夾緊 (PICK), DAC 增加 = 撐開 (RELEASE)
        )
        dev.configure_speed_steps(
            search_step_dac_per_ms=8.0,   # 空行程合攏速度 8.0 格/ms
            release_step_dac_per_ms=15.0, # 撐開速度 15.0 格/ms
            max_pid_step_dac_per_ms=5.0,  # PID 單步最大修正 5.0 格/ms
        )
        dev.configure_pid(kp=0.250, ki=0.010, kd=0.000)
        dev.set_log_divider(log_div_ms=2) # 每 2ms 記錄一筆 (600 筆 = 1.2 秒)
        print("2. 超參數設定完成！")

        # 3. 先將夾爪撐開 (RELEASE: 0 -> 4095) 並等待到位穩定
        print("3. 執行 RELEASE 先將夾爪升壓撐開...")
        dev.release()
        dev.wait_until_idle(timeout_s=2.0)
        print("   夾爪已撐開到位，目前狀態:", dev.get_status())

        # 4. 在撐開且空載狀態下執行一鍵歸零 (ZERO)
        dev.zero_calibrate()
        print("4. 撐開狀態空載歸零完成，目前狀態:", dev.get_status())

        # 5. 下達 PICK 開始降壓合攏夾取 (黑盒子自動從 0ms 開始錄製 1.2 秒)
        print("\n5. 下達 PICK 指令，開始降壓夾取並錄製波形...")
        dev.pick()

        for _ in range(7):
            time.sleep(0.2)
            st = dev.get_status()
            print(
                f"   [{st['state_name']}] DAC={st['dac']:4d} | "
                f"Force={st['force']:4d} | ADC={st['adc0']},{st['adc1']},{st['adc2']},{st['adc3']}"
            )

        # 6. 先下達 RELEASE 撐開鬆開部品 (不會洗掉剛剛 PICK 錄好的黑盒子數據！)
        print("\n6. 下達 RELEASE 撐開鬆手...")
        dev.release()
        dev.wait_until_idle(timeout_s=2.0)

        # 7. 下載剛剛 PICK 過程的 600 筆歷史曲線並畫圖
        log_info = dev.get_log_info()
        print(f"\n7. 黑盒子狀態: {log_info}，開始下載歷史數據...")
        records = dev.fetch_log()
        dev.save_log_to_csv(records, "pick_history.csv")
        dev.plot_log(records, title="PICK Action History (State, DAC, ADC0~ADC3)")

        # 8. 實驗結束，下達 REST 將壓電陶瓷平滑洩放回 0V 休息
        print("\n8. 實驗結束，下達 REST 平滑降回 0V 斷電休息...")
        dev.rest()
        dev.wait_until_idle(timeout_s=2.0)
        print("   最終休息狀態:", dev.get_status())


if __name__ == "__main__":
    SERIAL_PORT = "COM5"
    run_demo_workflow(SERIAL_PORT)