# predict.py
import os
import json
import time
import numpy as np
import matplotlib
import matplotlib.pyplot as plt

matplotlib.rcParams["font.family"] = "sans-serif"
matplotlib.rcParams["font.sans-serif"] = [
    "Microsoft JhengHei",
    "PingFang TC",
    "Noto Sans CJK TC",
    "DejaVu Sans",
]
matplotlib.rcParams["axes.unicode_minus"] = False

from vision_localizer import Contour_WLSQ


def compute_gt_errors(rel_pose, meta_item, symmetry_deg=360.0):
    if rel_pose is None or meta_item is None:
        return None, None
    dx_pred, dy_pred, dth_pred = rel_pose
    dth_gt = float(meta_item["gt_rel_dtheta_deg"])

    sym = float(symmetry_deg) if symmetry_deg else 360.0
    k = float(np.rint((dth_pred - dth_gt) / sym))
    dth_eff = dth_gt + k * sym
    err_theta = float(abs(dth_pred - dth_eff))

    if "obj_dx" in meta_item and "_img0_dx" in meta_item:
        rad = np.deg2rad(dth_eff)
        c, s = np.cos(rad), np.sin(rad)
        img0_dx = float(meta_item["_img0_dx"])
        img0_dy = float(meta_item["_img0_dy"])
        dx_gt = float(meta_item["obj_dx"] - (c * img0_dx - s * img0_dy))
        dy_gt = float(meta_item["obj_dy"] - (s * img0_dx + c * img0_dy))
    else:
        dx_gt = float(meta_item["gt_rel_dx"])
        dy_gt = float(meta_item["gt_rel_dy"])

    err_xy = float(np.hypot(dx_pred - dx_gt, dy_pred - dy_gt))
    return err_xy, err_theta


def save_result_figure(
    save_path, img1, loc, ds_name, stem, ext, x_cam, y_cam, theta_cam_deg, ct_ms,
    meta_item=None, err_xy=None, err_theta=None,
):
    cx, cy = loc._cache["cx"], loc._cache["cy"]
    H_img, W_img = loc._cache["H_img"], loc._cache["W_img"]
    edge_x1, edge_y1 = loc.get_transformed_edges()
    p1_pred, p2_pred = loc.pred_p1, loc.pred_p2
    is_ok = loc.is_ok()
    status_str = "OK" if is_ok else "NG"

    fig, (ax_raw, ax_ovl) = plt.subplots(1, 2, figsize=(15.0, 7.2))

    ax_raw.imshow(img1, cmap="gray", vmin=0, vmax=255)
    ax_raw.axhline(cy, color="cyan", ls="--", lw=0.8, alpha=0.5)
    ax_raw.axvline(cx, color="cyan", ls="--", lw=0.8, alpha=0.5)
    ax_raw.plot(cx, cy, "c+", ms=9)
    desc_str = f" — {meta_item['desc']}" if meta_item and "desc" in meta_item else ""
    ax_raw.set_title(f"[{ds_name}] 原始待測圖: {stem}.{ext}{desc_str}", fontsize=10.5, fontweight="bold")
    ax_raw.set_xlim(0, W_img)
    ax_raw.set_ylim(H_img, 0)

    ax_ovl.imshow(img1, cmap="gray", vmin=0, vmax=255)
    ax_ovl.axhline(cy, color="cyan", ls="--", lw=0.8, alpha=0.5, label="攝影機中心 (0,0)")
    ax_ovl.axvline(cx, color="cyan", ls="--", lw=0.8, alpha=0.5)
    ax_ovl.plot(cx, cy, "c+", ms=9)
    ax_ovl.scatter(edge_x1, edge_y1, s=1.5, c="lime", alpha=0.85, label="Template Edge 疊圖")

    if p1_pred is not None and p2_pred is not None:
        ax_ovl.annotate(
            "",
            xy=(p2_pred[0], p2_pred[1]),
            xytext=(p1_pred[0], p1_pred[1]),
            arrowprops=dict(arrowstyle="->", color="yellow", lw=2.5, mutation_scale=18),
        )
        ax_ovl.plot(p1_pred[0], p1_pred[1], "ro", ms=8, label=f"P1' 中心 ({x_cam:+.1f}, {y_cam:+.1f})")
        ax_ovl.plot(p2_pred[0], p2_pred[1], "yo", ms=6, label=f"P2' 轉角 ({theta_cam_deg:+.2f}°)")

    info_lines = [
        f"■ 最終姿態：X = {x_cam:+.2f} px, Y = {y_cam:+.2f} px, Θ = {theta_cam_deg:+.2f}°"
    ]
    if err_xy is not None and err_theta is not None:
        precision_tag = " (極高精度)" if err_xy < 0.1 else ""
        info_lines.append(f"■ 真實誤差：e_xy = {err_xy:.3f} px{precision_tag} | e_θ = {err_theta:.4f}°")
    else:
        info_lines.append("■ 真實誤差：無 GT 資料可對比")
    info_lines.extend([
        f"■ 擬合狀態：RMSE = {loc.rmse:.3f} px | 覆蓋率 {loc.coverage * 100:.1f}% | 耗時 {ct_ms:.2f} ms",
        f"■ 演算法狀態：{status_str} (迭代 {loc.iterations} 次達標)",
    ])

    ax_ovl.text(
        0.02,
        0.98,
        "\n".join(info_lines),
        transform=ax_ovl.transAxes,
        fontsize=9.5,
        va="top",
        ha="left",
        color="#0f172a",
        linespacing=1.6,
        bbox=dict(
            boxstyle="round,pad=0.5",
            facecolor="#f8fafc" if is_ok else "#fef2f2",
            edgecolor="#16a34a" if is_ok else "#dc2626",
            lw=1.5,
            alpha=0.92,
        ),
    )

    err_title = f" | 誤差: {err_xy:.3f} px ({err_theta:.4f}°)" if err_xy is not None else ""
    ax_ovl.set_title(
        f"[{status_str}] 定位結果{err_title}",
        fontsize=11.5,
        fontweight="bold",
        color="darkgreen" if is_ok else "crimson",
    )
    ax_ovl.legend(loc="lower right", fontsize=8.5)
    ax_ovl.set_xlim(0, W_img)
    ax_ovl.set_ylim(H_img, 0)

    plt.tight_layout()
    fig.savefig(save_path, dpi=130)
    plt.close(fig)


if __name__ == "__main__":
    SIM_ROOT = os.path.join(".", "sim_data")
    RESULT_ROOT = os.path.join(".", "test_result")

    DATASET_ORDER = [
        "rect_2circles",
        "rounded_circle_slot",
        "wavy_cam_flange",
        "cross_mounting_plate",
        "eccentric_gear_arm",
        "bull_horn",
    ]
    if not os.path.isdir(SIM_ROOT):
        raise FileNotFoundError(f"找不到 {SIM_ROOT} 目錄！請先執行 gen_simu_imgs.py。")

    # =========================================================================
    # ✅ 方案 B：只跑 DATASET_ORDER 指定、且存在 img0.png 的 dataset
    #    （原本自動補上 sim_data/ 底下其他資料夾的迴圈已移除）
    # =========================================================================
    datasets = [d for d in DATASET_ORDER if os.path.isfile(os.path.join(SIM_ROOT, d, "img0.png"))]

    # 提示：若你在 DATASET_ORDER 里写了但找不到 img0.png，明确告知，避免静默跳过
    missing = [d for d in DATASET_ORDER if d not in datasets]
    if missing:
        print(f"[警告] 以下 DATASET_ORDER 項目找不到 img0.png，已忽略：{missing}")

    if not datasets:
        raise FileNotFoundError(
            f"DATASET_ORDER 中的 dataset 在 {SIM_ROOT} 下都找不到 img0.png！"
            f"請確認資料夾存在，或執行 gen_simu_imgs.py 生成模擬圖。"
        )

    print("=" * 95)
    print(f"【啟動】本次將執行 {len(datasets)} 個 Dataset：{datasets}")
    print("=" * 95)

    # =========================================================================
    # 階段一：依序標註全部 Dataset 的 img0.png
    # =========================================================================
    print("=" * 95)
    print(f"【階段 1/2】依序標註全部 {len(datasets)} 個 Dataset 的基準影像 (img0.png)")
    print("  - 點選 [P1: 物件中心] 與 [P2: 轉角方向] 後按 [Enter / 空白鍵] 確認")
    print("  - 若該 Dataset 已有 golden_model.pkl，可直接按 [s 鍵] 沿用舊模型")
    print("=" * 95)

    for idx_ds, ds_name in enumerate(datasets, start=1):
        data_dir = os.path.join(SIM_ROOT, ds_name)
        img0_path = os.path.join(data_dir, "img0.png")
        pkl_path = os.path.join(data_dir, "golden_model.pkl")
        has_pkl = os.path.isfile(pkl_path)

        loc = Contour_WLSQ()
        loc.set_orginal_img(img0_path)

        ds_title = f"[{idx_ds}/{len(datasets)}] {ds_name}"
        p1, p2 = loc.interactive_mark_img0(
            ds_title=ds_title, has_existing_pkl=has_pkl, ds_factor=3
        )

        if p1 is None or p2 is None:
            if has_pkl:
                print(f"  -> {ds_title}: 沿用既有模型 {pkl_path}")
            else:
                print(f"  -> {ds_title}: 未完成標註且無既有模型，此 Dataset 將於階段 2 跳過")
        else:
            loc.save(pkl_path)
            ox, oy = loc._cache["gold_center_offset"]
            th0 = loc._cache["gold_angle_deg"]
            print(
                f"  -> {ds_title}: 標註完成並儲存 {pkl_path} | "
                f"P1=({p1[0]:.1f},{p1[1]:.1f}), P2=({p2[0]:.1f},{p2[1]:.1f}), "
                f"Θ0={th0:+.2f}°, 中心偏移=({ox:+.2f},{oy:+.2f})"
            )

    # =========================================================================
    # 階段二：批次跑完所有 Dataset 的所有 img1_*.png，存圖並打印跑分
    # =========================================================================
    print("\n" + "=" * 95)
    print(f"【階段 2/2】全自動批次推論所有測試影像，結果圖存至 {RESULT_ROOT}/<dataset_name>/")
    print("=" * 95)

    summary_rows = []

    for idx_ds, ds_name in enumerate(datasets, start=1):
        data_dir = os.path.join(SIM_ROOT, ds_name)
        pkl_path = os.path.join(data_dir, "golden_model.pkl")
        meta_path = os.path.join(data_dir, "gt_meta.json")
        out_dir = os.path.join(RESULT_ROOT, ds_name)

        img1_files = sorted(
            [fn for fn in os.listdir(data_dir) if fn.startswith("img1_") and fn.lower().endswith(".png")]
        )
        if not img1_files:
            print(f"[{ds_name}] 找不到任何 img1_*.png，跳過。")
            continue
        if not os.path.isfile(pkl_path):
            print(f"[{ds_name}] 找不到 {pkl_path}，跳過此 Dataset。")
            continue

        os.makedirs(out_dir, exist_ok=True)

        meta_map = {}
        symmetry_deg = 360.0
        ds_desc = ""
        if os.path.isfile(meta_path):
            with open(meta_path, "r", encoding="utf-8") as f:
                meta_json = json.load(f)
            symmetry_deg = float(meta_json.get("symmetry_deg", 360.0))
            ds_desc = meta_json.get("desc", "")
            img0_p = meta_json.get("img0_pose", {})
            for item in meta_json.get("test_images", []):
                item["_img0_dx"] = img0_p.get("dx", 0.0)
                item["_img0_dy"] = img0_p.get("dy", 0.0)
                meta_map[item["file"]] = item

        loc = Contour_WLSQ().load(pkl_path)

        print(f"\n>> Dataset [{idx_ds}/{len(datasets)}]: {ds_name} ({ds_desc}) — 共 {len(img1_files)} 張測試圖")
        print("-" * 118)
        print(
            f"{'檔案名稱':<13} | {'狀態':<6} | {'預測相機姿態 (X, Y, Θ)':<26} | "
            f"{'誤差 (e_xy, e_θ)':<20} | {'Cov(%)':<7} | {'RMSE(px)':<9} | {'CT(ms)':<7} | {'場景說明'}"
        )
        print("-" * 118)

        ok_cnt = 0
        cts, covs, rmses, err_xys, err_ths = [], [], [], [], []

        for fn in img1_files:
            fpath = os.path.join(data_dir, fn)
            stem, ext = os.path.splitext(fn)
            ext = ext.lstrip(".")
            img1 = Contour_WLSQ._load_gray_array(fpath)

            t0 = time.perf_counter()
            x_cam, y_cam, theta_cam_deg = loc.predict(img1)
            ct_ms = (time.perf_counter() - t0) * 1000.0

            is_ok = loc.is_ok()
            status_str = "OK" if is_ok else "NG"
            if is_ok:
                ok_cnt += 1

            meta_item = meta_map.get(fn, None)
            err_xy, err_th = compute_gt_errors(loc.rel_pose, meta_item, symmetry_deg=symmetry_deg)

            cts.append(ct_ms)
            covs.append(loc.coverage * 100.0)
            rmses.append(loc.rmse)
            if err_xy is not None:
                err_xys.append(err_xy)
                err_ths.append(err_th)

            save_result_figure(
                os.path.join(out_dir, fn), img1, loc, ds_name, stem, ext,
                x_cam, y_cam, theta_cam_deg, ct_ms,
                meta_item=meta_item, err_xy=err_xy, err_theta=err_th,
            )

            pose_str = f"({x_cam:+7.2f}, {y_cam:+7.2f}, {theta_cam_deg:+6.2f}°)"
            err_str = f"{err_xy:6.2f}px, {err_th:6.3f}°" if err_xy is not None else "  N/A"
            desc_str = meta_item["desc"] if meta_item and "desc" in meta_item else ""
            print(
                f"{fn:<13} | [{status_str:<2}] | {pose_str:<26} | "
                f"{err_str:<20} | {loc.coverage * 100:5.1f}%  | {loc.rmse:7.3f}  | {ct_ms:5.2f}ms | {desc_str}"
            )

        summary_rows.append({
            "dataset": ds_name,
            "total": len(img1_files),
            "ok": ok_cnt,
            "mean_err_xy": float(np.mean(err_xys)) if err_xys else float("nan"),
            "max_err_xy": float(np.max(err_xys)) if err_xys else float("nan"),
            "mean_err_th": float(np.mean(err_ths)) if err_ths else float("nan"),
            "max_err_th": float(np.max(err_ths)) if err_ths else float("nan"),
            "mean_cov": float(np.mean(covs)),
            "mean_rmse": float(np.mean(rmses)),
            "mean_ct": float(np.mean(cts)),
            "max_ct": float(np.max(cts)),
        })

    # =========================================================================
    # 總結跑分成績單
    # =========================================================================
    print("\n" + "=" * 118)
    print(f"【全體 Dataset 定位跑分總結報告】結果圖已儲存至 {RESULT_ROOT}/<dataset_name>/")
    print("=" * 118)
    print(
        f"{'Dataset 名稱':<22} | {'成功率':<9} | {'平均 e_xy':<11} | {'最大 e_xy':<11} | "
        f"{'平均 e_θ':<11} | {'最大 e_θ':<11} | {'平均 Cov':<10} | {'平均 RMSE':<10} | {'平均 CT':<10}"
    )
    print("-" * 118)
    for r in summary_rows:
        print(
            f"{r['dataset']:<22} | {r['ok']:2d}/{r['total']:2d}     | "
            f"{r['mean_err_xy']:7.3f} px | {r['max_err_xy']:7.3f} px | "
            f"{r['mean_err_th']:7.4f}°  | {r['max_err_th']:7.4f}°  | "
            f"{r['mean_cov']:6.1f}%   | {r['mean_rmse']:7.3f} px | {r['mean_ct']:7.2f} ms"
        )
    print("=" * 118)

#

