# vision_localizer.py
import os
import pickle
import warnings
import cv2
import numpy as np
from scipy.ndimage import (
    gaussian_filter,
    gaussian_filter1d,
    distance_transform_edt,
)


class Contour_WLSQ:
    """
    萬用任意曲線輪廓定位器（無 ROI、不對號入座、免 ICP 迭代）：
    1. 前處理 Step 1: 1D 梯度方向直方圖 (含 sqrt 抗遮擋壓縮) FFT 互相關 -> 求候選旋轉角 θ
    2. 前處理 Step 2: 轉正後 1D X/Y 正負梯度邊際投影 FFT 互相關 -> 求粗平移 (dx, dy)
    3. 候選角寬帶預拉入與反極性懲罰評分 -> 鎖定全局唯一正確姿態
    4. 後處理 Step 3: 窄帶法線場加權最小平方法 (Tukey WLSQ) -> 次像素精修並剔除灰塵與遮擋
    5. 支援 Golden Template 雙點標記 (p1=物件中心, p2=物件轉角方向) 與 .pkl 模板輕量存取 (save/load)
    """

    def __init__(
        self,
        canny_low=50,
        canny_high=150,
        blur_level=1.0,
        angle_bins=720,
        top_k_angles=6,
        proj_len=512,
        proj_sigma=1.5,
        band_tau=2.5,
        polarity_th=0.7,
        max_iter=3,
        tol=1e-4,
        eta=1e-6,
    ):
        self.canny_low = canny_low
        self.canny_high = canny_high
        self.blur_level = float(max(blur_level, 0.0))
        self.angle_bins = int(angle_bins)
        self.top_k_angles = int(max(top_k_angles, 1))
        self.proj_len = int(proj_len)
        self.proj_sigma = float(proj_sigma)
        self.band_tau = float(band_tau)
        self.polarity_th = float(polarity_th)
        self.max_iter = int(max(max_iter, 1))
        self.tol = float(tol)
        self.eta = float(eta)

        self._ref_img = None
        self._cache = None
        self.history = []
        self.coarse_pose = None
        self.rel_pose = None
        self.pred_p1 = None
        self.pred_p2 = None
        self.exit_reason = None
        self.stopped_early = False
        self.iterations = 0
        self.valid_inliers = 0
        self.coverage = 0.0
        self.rmse = 999.0

    @staticmethod
    def _load_gray_u8(img_or_path):
        """支援傳入影像檔案路徑 (含中文路徑) 或 2D/3D ndarray，統一轉為 2D uint8 灰階陣列 (零冗餘浮點配置)。"""
        if isinstance(img_or_path, (str, os.PathLike)):
            with open(img_or_path, "rb") as f:
                buf = np.frombuffer(f.read(), dtype=np.uint8)
            arr = cv2.imdecode(buf, cv2.IMREAD_GRAYSCALE)
            if arr is None:
                raise FileNotFoundError(f"無法讀取影像檔案: {img_or_path}")
            return arr
        arr = np.asarray(img_or_path)
        if arr.ndim == 3:
            if arr.dtype != np.uint8:
                arr = np.clip(np.rint(arr), 0, 255).astype(np.uint8)
            return cv2.cvtColor(arr, cv2.COLOR_BGR2GRAY)
        if arr.dtype == np.uint8:
            return np.ascontiguousarray(arr)
        return np.clip(np.rint(arr), 0.0, 255.0).astype(np.uint8)

    @staticmethod
    def _load_gray_array(img_or_path):
        """相容輔助方法：回傳 2D uint8 灰階陣列。"""
        return Contour_WLSQ._load_gray_u8(img_or_path)

    def _extract_subpixel_edges(self, img, return_mask=False):
        """
        提取 Canny 邊緣點，並利用梯度方向三點拋物線內插取得次像素邊緣座標與單位梯度向量。
        全程於 uint8 全圖執行 Canny、findNonZero 與 GaussianBlur，僅對稀疏邊緣點轉 float64 計算梯度。
        """
        img_u8 = self._load_gray_u8(img)
        H_img, W_img = img_u8.shape
        edges_u8 = cv2.Canny(img_u8, self.canny_low, self.canny_high)

        edges_u8[:2, :] = 0
        edges_u8[-2:, :] = 0
        edges_u8[:, :2] = 0
        edges_u8[:, -2:] = 0

        pts = cv2.findNonZero(edges_u8)
        if pts is None:
            empty = np.empty(0, dtype=np.float64)
            mask = (edges_u8 > 0) if return_mask else edges_u8
            return mask, empty, empty, empty, empty, empty

        pts = pts.reshape(-1, 2)
        xs = pts[:, 0]
        ys = pts[:, 1]

        if self.blur_level > 0.0:
            img_work = cv2.GaussianBlur(
                img_u8, (0, 0), sigmaX=self.blur_level, sigmaY=self.blur_level, borderType=cv2.BORDER_REPLICATE
            )
        else:
            img_work = img_u8

        gx = 0.5 * (img_work[ys, xs + 1].astype(np.float64) - img_work[ys, xs - 1].astype(np.float64))
        gy = 0.5 * (img_work[ys + 1, xs].astype(np.float64) - img_work[ys - 1, xs].astype(np.float64))
        mag = np.maximum(np.hypot(gx, gy), self.eta)
        ux = gx / mag
        uy = gy / mag

        xm = np.clip(np.rint(xs - ux).astype(np.int32), 1, W_img - 2)
        ym = np.clip(np.rint(ys - uy).astype(np.int32), 1, H_img - 2)
        xp = np.clip(np.rint(xs + ux).astype(np.int32), 1, W_img - 2)
        yp = np.clip(np.rint(ys + uy).astype(np.int32), 1, H_img - 2)

        gm = np.hypot(
            0.5 * (img_work[ym, xm + 1].astype(np.float64) - img_work[ym, xm - 1].astype(np.float64)),
            0.5 * (img_work[ym + 1, xm].astype(np.float64) - img_work[ym - 1, xm].astype(np.float64)),
        )
        g0 = mag
        gp = np.hypot(
            0.5 * (img_work[yp, xp + 1].astype(np.float64) - img_work[yp, xp - 1].astype(np.float64)),
            0.5 * (img_work[yp + 1, xp].astype(np.float64) - img_work[yp - 1, xp].astype(np.float64)),
        )
        denom = gm - 2.0 * g0 + gp
        dt = np.where(
            (np.abs(denom) > self.eta) & (g0 >= gm) & (g0 >= gp),
            0.5 * (gm - gp) / np.where(np.abs(denom) > self.eta, denom, 1.0),
            0.0,
        )
        dt = np.clip(dt, -0.6, 0.6)

        cx = (W_img - 1) / 2.0
        cy = (H_img - 1) / 2.0
        px = (xs.astype(np.float64) + dt * ux) - cx
        py = (ys.astype(np.float64) + dt * uy) - cy
        mask = (edges_u8 > 0) if return_mask else edges_u8
        return mask, px, py, ux, uy, mag

    def _build_1d_orient_hist(self, ux, uy, weights):
        """
        建立長度為 angle_bins 的 1D 梯度方向角直方圖：
        使用 sqrt 非線性壓縮抑制大塊直線型遮擋物造成的異常單一角度尖刺。
        """
        B = self.angle_bins
        ang_deg = np.mod(np.rad2deg(np.arctan2(uy, ux)), 360.0)
        bins = np.mod(np.rint(ang_deg * (B / 360.0)).astype(np.int32), B)
        hist = np.bincount(bins, weights=weights, minlength=B).astype(np.float64)
        hist = np.sqrt(np.maximum(hist, 0.0))
        hist = gaussian_filter1d(hist, sigma=2.5, mode="wrap")
        hist -= np.mean(hist)
        norm = float(np.linalg.norm(hist))
        if norm > self.eta:
            hist /= norm
        return hist

    def _build_1d_xy_proj(self, x_arr, y_arr, ux_arr, uy_arr, do_smooth=False, scale_ratio=1.0):
        """
        建立轉正後的 1D X 與 Y 正負梯度投影剖面 (長度 proj_len)。
        只在離線 img0 執行高斯平滑，線上 img1 直接使用 bincount 以大幅節省 CT。
        """
        M = self.proj_len
        half_M = M / 2.0
        ix = np.clip(np.rint(x_arr + half_M).astype(np.int32), 0, M - 1)
        iy = np.clip(np.rint(y_arr + half_M).astype(np.int32), 0, M - 1)

        wx_pos = np.maximum(ux_arr, 0.0)
        wx_neg = np.maximum(-ux_arr, 0.0)
        wy_pos = np.maximum(uy_arr, 0.0)
        wy_neg = np.maximum(-uy_arr, 0.0)
        w_abs_y = np.abs(uy_arr)
        w_abs_x = np.abs(ux_arr)

        px_pos = np.bincount(ix, weights=wx_pos, minlength=M).astype(np.float64)
        px_neg = np.bincount(ix, weights=wx_neg, minlength=M).astype(np.float64)
        px_abs = np.bincount(ix, weights=w_abs_y, minlength=M).astype(np.float64)

        py_pos = np.bincount(iy, weights=wy_pos, minlength=M).astype(np.float64)
        py_neg = np.bincount(iy, weights=wy_neg, minlength=M).astype(np.float64)
        py_abs = np.bincount(iy, weights=w_abs_x, minlength=M).astype(np.float64)

        if do_smooth and self.proj_sigma > 0.0:
            s = self.proj_sigma * np.sqrt(2.0) * float(scale_ratio)
            px_pos = gaussian_filter1d(px_pos, s)
            px_neg = gaussian_filter1d(px_neg, s)
            px_abs = gaussian_filter1d(px_abs, s)
            py_pos = gaussian_filter1d(py_pos, s)
            py_neg = gaussian_filter1d(py_neg, s)
            py_abs = gaussian_filter1d(py_abs, s)

        return (px_pos, px_neg, px_abs), (py_pos, py_neg, py_abs)

    @staticmethod
    def _parabolic_peak_1d(corr, wrap=True):
        """在 1D 互相關陣列找最大值並做三點拋物線次像素內插。"""
        N = corr.size
        k = int(np.argmax(corr))
        val = float(corr[k])
        if wrap:
            ym = float(corr[(k - 1) % N])
            yp = float(corr[(k + 1) % N])
        else:
            if k <= 0 or k >= N - 1:
                return float(k), val
            ym = float(corr[k - 1])
            yp = float(corr[k + 1])
        denom = ym - 2.0 * val + yp
        dk = 0.5 * (ym - yp) / denom if abs(denom) > 1e-12 else 0.0
        dk = float(np.clip(dk, -0.5, 0.5))
        return float(k) + dk, val

    def set_orginal_img(self, img0, p1=None, p2=None):
        """
        離線建立 Golden Template (Teach)
        Args:
            img0: 參考影像 (支援傳入檔案路徑 str 或 2D/3D ndarray)
            p1: (x1, y1) 點 1 像素座標 -> 表達「物件中心」 (若為 None 則預設為畫面中心)
            p2: (x2, y2) 點 2 像素座標 -> 表達「物件轉角方向」 (由 p1->p2 定義物件角度，若為 None 則預設為 0°)
        """
        img0 = self._load_gray_array(img0)
        H_img, W_img = img0.shape
        cx = (W_img - 1) / 2.0
        cy = (H_img - 1) / 2.0

        edges0, px0, py0, u0x, u0y, mag0 = self._extract_subpixel_edges(img0, return_mask=True)
        if px0.size < 5:
            raise ValueError(
                "[Contour_WLSQ] 參考影像 img0 提取到的 Canny 邊緣點過少！"
            )

        # --- 自動依影像對角線與零件尺寸進行尺度自適應 (Auto-Adaptation) ---
        diag = float(np.hypot(W_img, H_img))
        auto_proj_len = int(2 ** np.ceil(np.log2(max(512.0, diag * 1.5))))
        eff_proj_len = max(self.proj_len, auto_proj_len)
        self.proj_len = eff_proj_len

        # 計算零件外圍特徵半徑 r_obj (以 75 px 為基準比例 1.0)
        r_obj = float(np.percentile(np.hypot(px0, py0), 90))
        scale_ratio = float(max(1.0, r_obj / 75.0))

        hist_theta0 = self._build_1d_orient_hist(u0x, u0y, mag0)
        fft_theta0_conj = np.conj(np.fft.rfft(hist_theta0))

        (px0_pos, px0_neg, px0_abs), (py0_pos, py0_neg, py0_abs) = (
            self._build_1d_xy_proj(px0, py0, u0x, u0y, do_smooth=True, scale_ratio=scale_ratio)
        )
        fft_x0_conj = (
            np.conj(np.fft.rfft(px0_pos)),
            np.conj(np.fft.rfft(px0_neg)),
            np.conj(np.fft.rfft(px0_abs)),
        )
        fft_y0_conj = (
            np.conj(np.fft.rfft(py0_pos)),
            np.conj(np.fft.rfft(py0_neg)),
            np.conj(np.fft.rfft(py0_abs)),
        )

        ys0, xs0 = np.nonzero(edges0)
        idx_map = np.zeros((H_img, W_img), dtype=np.int32)
        idx_map[ys0, xs0] = np.arange(px0.size, dtype=np.int32)

        dist_map, (near_y, near_x) = distance_transform_edt(
            ~edges0, return_indices=True
        )
        nearest_edge_idx = idx_map[near_y, near_x]

        dist_map = dist_map.astype(np.float32)
        px0_map = px0.astype(np.float32)[nearest_edge_idx]
        py0_map = py0.astype(np.float32)[nearest_edge_idx]
        nx_map = u0x.astype(np.float32)[nearest_edge_idx]
        ny_map = u0y.astype(np.float32)[nearest_edge_idx]

        self._ref_img = img0
        self._cache = {
            "H_img": H_img,
            "W_img": W_img,
            "cx": cx,
            "cy": cy,
            "xs0": xs0.astype(np.int32),
            "ys0": ys0.astype(np.int32),
            "px0": px0,
            "py0": py0,
            "u0x": u0x,
            "u0y": u0y,
            "fft_theta0_conj": fft_theta0_conj,
            "fft_x0_conj": fft_x0_conj,
            "fft_y0_conj": fft_y0_conj,
            "dist_map": dist_map,
            "px0_map": px0_map,
            "py0_map": py0_map,
            "nx_map": nx_map,
            "ny_map": ny_map,
            "num_ref_pts": int(px0.size),
            "scale_ratio": scale_ratio,
            "mark_p1": None,
            "mark_p2": None,
            "gold_center_offset": np.array([0.0, 0.0], dtype=np.float64),
            "gold_angle_deg": 0.0,
        }

        if p1 is not None and p2 is not None:
            self.set_golden_points(p1, p2)

    def set_golden_points(self, p1, p2):
        """
        設定或更新 Golden Template 上的 2 個標記點 (像素座標):
            p1 = (x1, y1): 點 1 表達「物件中心」
            p2 = (x2, y2): 點 2 表達「物件轉角方向」 (由 p1 -> p2 向量定義)
        """
        if self._cache is None:
            raise ValueError(
                "[Contour_WLSQ] 請先呼叫 set_orginal_img(img0) 再設定標記點。"
            )
        p1_arr = np.asarray(p1, dtype=np.float64).reshape(2)
        p2_arr = np.asarray(p2, dtype=np.float64).reshape(2)
        vec = p2_arr - p1_arr
        if float(np.hypot(vec[0], vec[1])) < self.eta:
            raise ValueError("[Contour_WLSQ] 標記點 p1 與 p2 不可重合！")

        cx = self._cache["cx"]
        cy = self._cache["cy"]
        # 點 1 相對於攝影機畫面中心 (cx, cy) 的偏移向量
        gold_center_offset = np.array([p1_arr[0] - cx, p1_arr[1] - cy], dtype=np.float64)
        # p1 -> p2 相對於攝影機畫面右方 (+X 軸 = 0°) 的基準角度
        gold_angle_deg = float(np.rad2deg(np.arctan2(vec[1], vec[0])))

        self._cache["mark_p1"] = p1_arr
        self._cache["mark_p2"] = p2_arr
        self._cache["gold_center_offset"] = gold_center_offset
        self._cache["gold_angle_deg"] = gold_angle_deg

    def get_golden_edges(self):
        """回傳 Golden Template (img0) 上的次像素邊緣點像素座標 (edge_x0, edge_y0)。"""
        if self._cache is None:
            raise ValueError("[Contour_WLSQ] 尚未載入模板！")
        cx, cy = self._cache["cx"], self._cache["cy"]
        return self._cache["px0"] + cx, self._cache["py0"] + cy

    def get_transformed_edges(self):
        """
        回傳剛預測完的 img1 上，對齊後的 Golden Template 邊緣點像素座標 (edge_x1, edge_y1)，
        可直接疊加繪製在 img1 上檢視對位效果。
        """
        if self._cache is None or self.rel_pose is None:
            raise ValueError("[Contour_WLSQ] 請先執行 predict(img1)！")
        dx, dy, dtheta_deg = self.rel_pose
        rad = np.deg2rad(dtheta_deg)
        c, s = np.cos(rad), np.sin(rad)
        px0 = self._cache["px0"]
        py0 = self._cache["py0"]
        cx, cy = self._cache["cx"], self._cache["cy"]
        edge_x1 = c * px0 - s * py0 + dx + cx
        edge_y1 = s * px0 + c * py0 + dy + cy
        return edge_x1, edge_y1

    def save(self, pkl_path, save_ref_img=False, compact=True):
        """
        將訓練好的 Golden Template 與標記點資訊存成 .pkl 檔案。
        上機時可直接呼叫 load(pkl_path)，免除重拍 img0。
        - compact=True (預設): 存檔時不寫入 5 張大型 2D 密集查找表 (dist_map 等)，
          改於 load() 時由 1D 邊緣點瞬間重建，大幅縮小 .pkl 檔案。
        """
        if self._cache is None:
            raise ValueError(
                "[Contour_WLSQ] 尚未建立 Golden Template，無法儲存 .pkl！"
            )
        folder = os.path.dirname(os.path.abspath(pkl_path))
        if folder and not os.path.exists(folder):
            os.makedirs(folder, exist_ok=True)

        heavy_keys = {"dist_map", "px0_map", "py0_map", "nx_map", "ny_map"}
        if compact and "xs0" in self._cache and "ys0" in self._cache:
            cache_to_save = {
                k: v for k, v in self._cache.items() if k not in heavy_keys
            }
        else:
            cache_to_save = self._cache

        payload = {
            "params": {
                "canny_low": self.canny_low,
                "canny_high": self.canny_high,
                "blur_level": self.blur_level,
                "angle_bins": self.angle_bins,
                "top_k_angles": self.top_k_angles,
                "proj_len": self.proj_len,
                "proj_sigma": self.proj_sigma,
                "band_tau": self.band_tau,
                "polarity_th": self.polarity_th,
                "max_iter": self.max_iter,
                "tol": self.tol,
                "eta": self.eta,
            },
            "cache": cache_to_save,
            "ref_img": self._ref_img if save_ref_img else None,
        }
        with open(pkl_path, "wb") as f:
            pickle.dump(payload, f, protocol=pickle.HIGHEST_PROTOCOL)

    def load(self, pkl_path):
        """
        從 .pkl 檔案載入 Golden Template 與標記點設定，若為 compact 輕量格式則自動重建 2D 查找表。
        """
        with open(pkl_path, "rb") as f:
            payload = pickle.load(f)

        params = payload.get("params", {})
        for k, v in params.items():
            if hasattr(self, k):
                setattr(self, k, v)

        c = payload["cache"]
        if "dist_map" not in c:
            H_img, W_img = c["H_img"], c["W_img"]
            xs0, ys0 = c["xs0"], c["ys0"]
            px0, py0 = c["px0"], c["py0"]
            u0x, u0y = c["u0x"], c["u0y"]

            edges0 = np.zeros((H_img, W_img), dtype=bool)
            edges0[ys0, xs0] = True
            idx_map = np.zeros((H_img, W_img), dtype=np.int32)
            idx_map[ys0, xs0] = np.arange(px0.size, dtype=np.int32)

            dist_map, (near_y, near_x) = distance_transform_edt(
                ~edges0, return_indices=True
            )
            nearest_edge_idx = idx_map[near_y, near_x]
            c["dist_map"] = dist_map.astype(np.float32)
            c["px0_map"] = px0.astype(np.float32)[nearest_edge_idx]
            c["py0_map"] = py0.astype(np.float32)[nearest_edge_idx]
            c["nx_map"] = u0x.astype(np.float32)[nearest_edge_idx]
            c["ny_map"] = u0y.astype(np.float32)[nearest_edge_idx]

        self._cache = c
        self._ref_img = payload.get("ref_img", None)
        return self

    def _wlsq_step(self, qx, qy, u1x, u1y, dx, dy, dtheta, tau, pol_th):
        """執行單步法線場加權最小平方 (WLSQ) 更新。"""
        c_data = self._cache
        H_img, W_img = c_data["H_img"], c_data["W_img"]
        cx, cy = c_data["cx"], c_data["cy"]
        px0_map, py0_map = c_data["px0_map"], c_data["py0_map"]
        nx_map, ny_map = c_data["nx_map"], c_data["ny_map"]

        c, s = np.cos(dtheta), np.sin(dtheta)
        gx = qx - dx
        gy = qy - dy
        px = c * gx + s * gy
        py = -s * gx + c * gy

        ux_rot = c * u1x + s * u1y
        uy_rot = -s * u1x + c * u1y

        ix = np.clip(np.rint(px + cx).astype(np.int32), 0, W_img - 1)
        iy = np.clip(np.rint(py + cy).astype(np.int32), 0, H_img - 1)

        px0_star = px0_map[iy, ix]
        py0_star = py0_map[iy, ix]
        nx = nx_map[iy, ix]
        ny = ny_map[iy, ix]

        err = (px - px0_star) * nx + (py - py0_star) * ny
        abs_err = np.abs(err)
        pol_dot = ux_rot * nx + uy_rot * ny

        in_band = (abs_err < tau) & (pol_dot >= pol_th)
        valid_cnt = int(np.sum(in_band))
        if valid_cnt < 6:
            return dx, dy, dtheta, 0.0, 0.0, 0.0, 0, 999.0, 999.0

        w = np.where(in_band, (1.0 - (abs_err / tau) ** 2) ** 2 * pol_dot, 0.0)

        Jx = -nx * c + ny * s
        Jy = -nx * s - ny * c
        Jt = nx * py - ny * px

        wJx = w * Jx
        wJy = w * Jy
        wJt = w * Jt

        H = np.array(
            [
                [np.dot(wJx, Jx), np.dot(wJx, Jy), np.dot(wJx, Jt)],
                [np.dot(wJy, Jx), np.dot(wJy, Jy), np.dot(wJy, Jt)],
                [np.dot(wJt, Jx), np.dot(wJt, Jy), np.dot(wJt, Jt)],
            ],
            dtype=np.float64,
        )
        b_vec = -np.array(
            [np.dot(wJx, err), np.dot(wJy, err), np.dot(wJt, err)],
            dtype=np.float64,
        )

        if abs(float(np.linalg.det(H))) <= self.eta:
            np.fill_diagonal(H, np.maximum(np.diag(H), self.eta))

        ddx, ddy, ddth = [float(v) for v in np.linalg.solve(H, b_vec)]
        sse = float(np.dot(w, err * err))
        rmse = float(np.sqrt(sse / max(float(np.sum(w)), self.eta)))
        return dx + ddx, dy + ddy, dtheta + ddth, ddx, ddy, ddth, valid_cnt, sse, rmse

    def _estimate_coarse_pose(self, qx, qy, u1x, u1y, mag1):
        """
        前處理：1D 角度互相關 + 1D X/Y 邊緣投影互相關 + 1步寬帶預拉入與反極性懲罰評分。
        """
        c_data = self._cache
        B = self.angle_bins
        M = self.proj_len
        scale_ratio = float(c_data.get("scale_ratio", 1.0))
        wide_tau = 7.0 * scale_ratio
        score_dist_tau = 3.0 * scale_ratio

        hist_theta1 = self._build_1d_orient_hist(u1x, u1y, mag1)
        corr_theta = np.fft.irfft(
            np.fft.rfft(hist_theta1) * c_data["fft_theta0_conj"], n=B
        )

        min_sep_bins = max(1, int(round(12.0 * B / 360.0)))
        work_corr = corr_theta.copy()
        cand_angles_deg = []
        cand_corr_vals = []
        for _ in range(self.top_k_angles):
            k_peak, peak_val = self._parabolic_peak_1d(work_corr, wrap=True)
            ang = ((k_peak * (360.0 / B)) + 180.0) % 360.0 - 180.0
            cand_angles_deg.append(float(ang))
            cand_corr_vals.append(float(peak_val))
            k_int = int(round(k_peak)) % B
            for offset in range(-min_sep_bins, min_sep_bins + 1):
                work_corr[(k_int + offset) % B] = -1e9

        fx0_pos, fx0_neg, fx0_abs = c_data["fft_x0_conj"]
        fy0_pos, fy0_neg, fy0_abs = c_data["fft_y0_conj"]
        H_img, W_img = c_data["H_img"], c_data["W_img"]
        cx, cy = c_data["cx"], c_data["cy"]
        nx_map, ny_map = c_data["nx_map"], c_data["ny_map"]
        dist_map = c_data["dist_map"]

        best_score = -1e18
        best_pose = (0.0, 0.0, 0.0)
        best_idx = 0
        best_corr_x = None
        best_corr_y = None
        best_dx_tilde = 0.0
        best_dy_tilde = 0.0
        cand_records = []

        # 高解析度影像邊緣點數過多 (>3500) 時，粗定位投影與寬帶拉入採用等距抽樣以降低 CT
        max_coarse_pts = 3500
        if qx.size > max_coarse_pts:
            step_c = int(np.ceil(qx.size / float(max_coarse_pts)))
            qx_c, qy_c = qx[::step_c], qy[::step_c]
            u1x_c, u1y_c = u1x[::step_c], u1y[::step_c]
        else:
            qx_c, qy_c, u1x_c, u1y_c = qx, qy, u1x, u1y

        for c_idx, ang_deg in enumerate(cand_angles_deg):
            th = np.deg2rad(ang_deg)
            c, s = np.cos(th), np.sin(th)
            qx_rot = c * qx_c + s * qy_c
            qy_rot = -s * qx_c + c * qy_c
            ux_rot = c * u1x_c + s * u1y_c
            uy_rot = -s * u1x_c + c * u1y_c

            (px1_pos, px1_neg, px1_abs), (py1_pos, py1_neg, py1_abs) = (
                self._build_1d_xy_proj(qx_rot, qy_rot, ux_rot, uy_rot, do_smooth=False)
            )

            corr_x = np.fft.irfft(
                np.fft.rfft(px1_pos) * fx0_pos
                + np.fft.rfft(px1_neg) * fx0_neg
                + 0.4 * np.fft.rfft(px1_abs) * fx0_abs,
                n=M,
            )
            corr_y = np.fft.irfft(
                np.fft.rfft(py1_pos) * fy0_pos
                + np.fft.rfft(py1_neg) * fy0_neg
                + 0.4 * np.fft.rfft(py1_abs) * fy0_abs,
                n=M,
            )

            kx, _ = self._parabolic_peak_1d(corr_x, wrap=True)
            ky, _ = self._parabolic_peak_1d(corr_y, wrap=True)
            dx_tilde = (kx + M / 2.0) % M - M / 2.0
            dy_tilde = (ky + M / 2.0) % M - M / 2.0

            dx_cand = float(c * dx_tilde - s * dy_tilde)
            dy_cand = float(s * dx_tilde + c * dy_tilde)

            # 寬帶 (tau=wide_tau) WLSQ 預拉入，修正遮擋造成的 5°~8° 粗角度偏移
            dx_r, dy_r, th_r, *_ = self._wlsq_step(
                qx_c, qy_c, u1x_c, u1y_c, dx_cand, dy_cand, th, tau=wide_tau, pol_th=0.35
            )
            if scale_ratio > 1.5:
                dx_r, dy_r, th_r, *_ = self._wlsq_step(
                    qx_c, qy_c, u1x_c, u1y_c, dx_r, dy_r, th_r, tau=score_dist_tau, pol_th=0.5
                )

            # 計算對齊分數 (含反極性邊緣扣分，防止圓孔貼在遮擋塊反相邊界騙分)
            cr, sr = np.cos(th_r), np.sin(th_r)
            px_test = cr * (qx_c - dx_r) + sr * (qy_c - dy_r)
            py_test = -sr * (qx_c - dx_r) + cr * (qy_c - dy_r)
            ux_test = cr * u1x_c + sr * u1y_c
            uy_test = -sr * u1x_c + cr * u1y_c

            ix = np.clip(np.rint(px_test + cx).astype(np.int32), 0, W_img - 1)
            iy = np.clip(np.rint(py_test + cy).astype(np.int32), 0, H_img - 1)
            d_val = dist_map[iy, ix]
            pol = ux_test * nx_map[iy, ix] + uy_test * ny_map[iy, ix]

            prox = np.maximum(0.0, 1.0 - d_val / score_dist_tau)
            pos_score = float(np.sum(np.where(pol >= 0.5, prox * pol, 0.0)))
            neg_penalty = float(np.sum(np.where(pol < -0.2, prox * (0.8 * pol), 0.0)))
            total_score = pos_score + neg_penalty

            th_r_deg = float(((np.rad2deg(th_r) + 180.0) % 360.0) - 180.0)
            cand_records.append(
                {
                    "rank": c_idx + 1,
                    "init_ang_deg": float(ang_deg),
                    "pulled_ang_deg": th_r_deg,
                    "dx_cand": dx_cand,
                    "dy_cand": dy_cand,
                    "dx_r": float(dx_r),
                    "dy_r": float(dy_r),
                    "corr_val": cand_corr_vals[c_idx],
                    "pos_score": pos_score,
                    "neg_penalty": neg_penalty,
                    "total_score": total_score,
                }
            )

            if total_score > best_score:
                best_score = total_score
                best_pose = (dx_r, dy_r, float(np.rad2deg(th_r)))
                best_idx = c_idx
                best_corr_x = corr_x
                best_corr_y = corr_y
                best_dx_tilde = float(dx_tilde)
                best_dy_tilde = float(dy_tilde)

        self._last_coarse_debug = {
            "hist_theta1": hist_theta1,
            "corr_theta": corr_theta,
            "cand_records": cand_records,
            "best_idx": best_idx,
            "best_corr_x": best_corr_x,
            "best_corr_y": best_corr_y,
            "best_dx_tilde": best_dx_tilde,
            "best_dy_tilde": best_dy_tilde,
            "wide_tau": wide_tau,
            "score_dist_tau": score_dist_tau,
        }
        return best_pose

    def predict(self, img1, init_dx=None, init_dy=None, init_dtheta_deg=None):
        """
        預測目標影像 img1 (支援傳入檔案路徑 str 或 2D/3D ndarray) 的姿態：
        - 若未設定標記點 (p1, p2)，回傳相對於 img0 的 (dx, dy, dtheta_deg)。
        - 若已設定標記點 (p1=物件中心, p2=物件轉角)，則自動將標記點剛體映射至 img1，
          回傳「物件中心相對於攝影機畫面中心 (0,0) 的座標 (x_cam, y_cam)」與
          「物件相對於攝影機畫面右方 +X 軸 (0°) 的絕對角度 theta_cam_deg」。
        """
        if self._cache is None:
            raise ValueError(
                "[Contour_WLSQ] 尚未設定或載入模板，請先呼叫 set_orginal_img() 或 load()。"
            )
        _, qx, qy, u1x, u1y, mag1 = self._extract_subpixel_edges(img1)
        if qx.size < 5:
            self.rel_pose = None
            self.pred_p1 = None
            self.pred_p2 = None
            self.valid_inliers = 0
            self.coverage = 0.0
            self.rmse = 999.0
            self.exit_reason = "too_few_edges"
            warnings.warn(
                "[Contour_WLSQ] 目標影像提取到的邊緣點過少，退回 (0, 0, 0)。",
                RuntimeWarning,
            )
            return 0.0, 0.0, 0.0

        if init_dx is None or init_dy is None or init_dtheta_deg is None:
            dx, dy, dtheta_deg = self._estimate_coarse_pose(qx, qy, u1x, u1y, mag1)
        else:
            dx = float(init_dx)
            dy = float(init_dy)
            dtheta_deg = float(init_dtheta_deg)

        self.coarse_pose = (dx, dy, dtheta_deg)
        dtheta = float(np.deg2rad(dtheta_deg))

        self.history = []
        self.exit_reason = None
        self.stopped_early = False
        self.iterations = 0

        scale_ratio = float(self._cache.get("scale_ratio", 1.0))

        max_fine_pts = 8000
        if qx.size > max_fine_pts:
            step_f = int(np.ceil(qx.size / float(max_fine_pts)))
            qx_f, qy_f = qx[::step_f], qy[::step_f]
            u1x_f, u1y_f = u1x[::step_f], u1y[::step_f]
        else:
            step_f = 1
            qx_f, qy_f, u1x_f, u1y_f = qx, qy, u1x, u1y

        for i in range(self.max_iter):
            self.iterations = i + 1
            if i == 0:
                tau = self.band_tau * max(1.0, min(2.5, 0.5 * scale_ratio))
            elif i == 1:
                tau = self.band_tau
            else:
                tau = max(1.5, self.band_tau * 0.7)
            dx, dy, dtheta, ddx, ddy, ddth, valid_cnt, sse, rmse = self._wlsq_step(
                qx_f, qy_f, u1x_f, u1y_f, dx, dy, dtheta, tau=tau, pol_th=self.polarity_th
            )
            if valid_cnt < 6:
                self.exit_reason = "insufficient_inliers"
                break

            self.history.append(
                {
                    "iter": i + 1,
                    "delta_dx": ddx,
                    "delta_dy": ddy,
                    "delta_dtheta_deg": float(np.rad2deg(ddth)),
                    "dx": dx,
                    "dy": dy,
                    "dtheta_deg": float(np.rad2deg(dtheta)),
                    "inliers": valid_cnt,
                    "sse": sse,
                    "rmse": rmse,
                }
            )

            if np.hypot(ddx, ddy) < self.tol and abs(ddth) < self.tol:
                self.stopped_early = True
                self.exit_reason = "tolerance"
                break
        else:
            self.exit_reason = "max_iter"

        dtheta_rel_deg = float(np.rad2deg(dtheta))
        self.rel_pose = (dx, dy, dtheta_rel_deg)

        if self.history:
            self.valid_inliers = int(self.history[-1]["inliers"]) * step_f
            self.rmse = float(self.history[-1]["rmse"])
            self.coverage = float(
                self.valid_inliers / max(1, self._cache["num_ref_pts"])
            )
        else:
            self.valid_inliers = 0
            self.rmse = 999.0
            self.coverage = 0.0

        # 將 Golden Template 上的標記點 (p1=中心, p2=轉角) 剛體轉換到 img1 的攝影機中心座標系
        c_rot, s_rot = np.cos(dtheta), np.sin(dtheta)
        ox, oy = self._cache.get("gold_center_offset", (0.0, 0.0))
        gold_ang = self._cache.get("gold_angle_deg", 0.0)

        x_cam = float(c_rot * ox - s_rot * oy + dx)
        y_cam = float(s_rot * ox + c_rot * oy + dy)
        theta_cam_deg = float((gold_ang + dtheta_rel_deg + 180.0) % 360.0 - 180.0)

        # 若有標記 p1, p2，同步計算它們在 img1 上的像素座標 (pred_p1, pred_p2) 供視覺化使用
        mark_p1 = self._cache.get("mark_p1", None)
        mark_p2 = self._cache.get("mark_p2", None)
        if mark_p1 is not None and mark_p2 is not None:
            cx, cy = self._cache["cx"], self._cache["cy"]
            self.pred_p1 = np.array([x_cam + cx, y_cam + cy], dtype=np.float64)
            v2x, v2y = mark_p2[0] - cx, mark_p2[1] - cy
            p2x_cam = c_rot * v2x - s_rot * v2y + dx
            p2y_cam = s_rot * v2x + c_rot * v2y + dy
            self.pred_p2 = np.array([p2x_cam + cx, p2y_cam + cy], dtype=np.float64)
        else:
            self.pred_p1 = None
            self.pred_p2 = None

        return x_cam, y_cam, theta_cam_deg

    def is_ok(self, min_coverage=0.35, max_rmse=0.8):
        """
        機台防呆判定：檢查剛才的 predict() 定位結果是否健康可靠 (OK / NG)。
        - min_coverage: 最低有效內點輪廓覆蓋率 (0.0~1.0，預設 0.35，可攔截空拍、欠料或大面積嚴重遮擋)
        - max_rmse    : 最高允許窄帶法線殘差 (px，預設 0.8，可攔截放錯機種或嚴重變形)
        """
        return (
            self.rel_pose is not None
            and self.coverage >= float(min_coverage)
            and self.rmse <= float(max_rmse)
        )

    @staticmethod
    def _setup_mpl_font():
        """設定 Matplotlib 中文字型與負號顯示 (延遲載入)。"""
        import matplotlib

        matplotlib.rcParams["font.family"] = "sans-serif"
        matplotlib.rcParams["font.sans-serif"] = [
            "Microsoft JhengHei",
            "PingFang TC",
            "Noto Sans CJK TC",
            "DejaVu Sans",
        ]
        matplotlib.rcParams["axes.unicode_minus"] = False

    def interactive_mark_img0(
        self, img0=None, ds_title="", has_existing_pkl=False, ds_factor=None
    ):
        """
        開啟互動式同心圓靶心視窗，於基準影像 img0 上標定 2 個基準點：
          - P1 (x1, y1): 物件中心
          - P2 (x2, y2): 物件轉角方向 (由 P1 -> P2 向量定義基準角)
        確認完成後自動呼叫 self.set_golden_points(p1, p2) 並回傳 (p1, p2)；
        若按 s 鍵跳過或未按確認即關閉視窗，回傳 (None, None)。
        """
        import matplotlib.pyplot as plt
        from matplotlib.patches import Circle

        self._setup_mpl_font()

        if img0 is not None and self._cache is None:
            self.set_orginal_img(img0)
        if self._cache is None or self._ref_img is None:
            raise ValueError(
                "[Contour_WLSQ] 請先呼叫 set_orginal_img(img0) 或於參數傳入 img0！"
            )

        ref_img = self._ref_img
        edge_xy0 = self.get_golden_edges()
        H_orig, W_orig = ref_img.shape[:2]

        if ds_factor is None:
            ds_factor = max(1, int(round(max(H_orig, W_orig) / 900.0)))
        else:
            ds_factor = max(1, int(ds_factor))

        img0_ds = ref_img[::ds_factor, ::ds_factor] if ds_factor > 1 else ref_img
        H, W = img0_ds.shape[:2]

        scale_x = (W_orig - 1) / (W - 1) if W > 1 else 1.0
        scale_y = (H_orig - 1) / (H - 1) if H > 1 else 1.0
        cx, cy = (W - 1) / 2.0, (H - 1) / 2.0

        scale_ui = max(1.0, min(H, W) / 400.0)
        base_radii = [r * scale_ui for r in (4, 8, 12, 16, 20, 26, 34, 45)]
        state = {
            "r_scale": 1.0,
            "press_xy": None,
            "confirmed": False,
            "skip_use_existing": False,
            "last_mouse": (cx, cy),
            "show_edges": True,
        }
        clicked_pts = []

        fig, ax = plt.subplots(figsize=(9.0, 8.5))
        ax.imshow(img0_ds, cmap="gray", vmin=0, vmax=255, interpolation="nearest")

        ax.axhline(cy, color="cyan", ls="--", lw=0.8, alpha=0.45, label="攝影機中心 (0, 0)")
        ax.axvline(cx, color="cyan", ls="--", lw=0.8, alpha=0.45)
        ax.plot(cx, cy, "c+", ms=10, mew=1.2)

        edge_scatter = None
        if edge_xy0 is not None:
            edge_x_ds = edge_xy0[0] / scale_x
            edge_y_ds = edge_xy0[1] / scale_y
            if len(edge_x_ds) > 5000:
                edge_x_ds = edge_x_ds[::2]
                edge_y_ds = edge_y_ds[::2]
            edge_scatter = ax.scatter(
                edge_x_ds,
                edge_y_ds,
                s=1.2 * (ds_factor**1.5),
                c="deepskyblue",
                alpha=0.55,
                label="Template 邊緣 (按 e 開關)",
            )

        (cursor_h,) = ax.plot([0, W], [cy, cy], color="lime", lw=0.8, ls="-", alpha=0.75)
        (cursor_v,) = ax.plot([cx, cx], [0, H], color="lime", lw=0.8, ls="-", alpha=0.75)
        (cursor_center_dot,) = ax.plot([cx], [cy], "g+", ms=8, mew=1.2, alpha=0.9)

        cursor_circles = []
        for idx_r, r in enumerate(base_radii):
            circ = Circle(
                (cx, cy),
                radius=r,
                fill=False,
                edgecolor="lime" if idx_r % 2 == 0 else "yellow",
                lw=0.85,
                ls="-" if idx_r % 2 == 0 else ":",
                alpha=0.75,
            )
            ax.add_patch(circ)
            cursor_circles.append(circ)

        (preview_line,) = ax.plot([], [], color="yellow", lw=1.4, ls="--", alpha=0.85)
        (p1_marker,) = ax.plot([], [], "ro", ms=8, mew=1.5, fillstyle="none", label="P1 (物件中心)")
        (p1_dot,) = ax.plot([], [], "r+", ms=10, mew=1.5)
        (p2_marker,) = ax.plot([], [], "yo", ms=7, mew=1.5, fillstyle="none", label="P2 (轉角方向)")
        arrow_patch = {"ann": None}

        ax.set_xlim(0, W)
        ax.set_ylim(H, 0)
        ax.legend(loc="upper right", fontsize=8.5)

        skip_hint = " | 按 [s 鍵] 沿用既有 .pkl" if has_existing_pkl else ""
        prefix = f"{ds_title} — " if ds_title else ""

        def update_title(mouse_x=None, mouse_y=None):
            coord_str = ""
            if mouse_x is not None and mouse_y is not None:
                orig_x = mouse_x * scale_x
                orig_y = mouse_y * scale_y
                coord_str = f"游標=({orig_x:.1f}, {orig_y:.1f})"

            if len(clicked_pts) == 0:
                msg = (
                    f"{prefix}【Step 1】請左鍵點擊 [點1: 物件中心]  {coord_str}\n"
                    f"(滾輪:縮放 | [/]鍵:調同心圓 | e鍵:邊緣 | r鍵:重置{skip_hint})"
                )
                col = "crimson"
            elif len(clicked_pts) == 1:
                p1 = clicked_pts[0]
                ang_str = ""
                if mouse_x is not None and mouse_y is not None:
                    ang = np.rad2deg(
                        np.arctan2((mouse_y - p1[1]) * scale_y, (mouse_x - p1[0]) * scale_x)
                    )
                    ang_str = f" | 預覽角度={ang:+.2f}°"
                msg = (
                    f"{prefix}【Step 2】請左鍵點擊 [點2: 物件轉角方向]  {coord_str}{ang_str}\n"
                    f"(右鍵/Backspace: 退回重選 P1 | 滾輪: 放大縮小{skip_hint})"
                )
                col = "darkgreen"
            else:
                p1, p2 = clicked_pts[0], clicked_pts[1]
                ang = np.rad2deg(
                    np.arctan2((p2[1] - p1[1]) * scale_y, (p2[0] - p1[0]) * scale_x)
                )
                msg = (
                    f"{prefix}【已標記 2 點】P1=({p1[0]*scale_x:.1f}, {p1[1]*scale_y:.1f}), "
                    f"P2=({p2[0]*scale_x:.1f}, {p2[1]*scale_y:.1f}), 基準角={ang:+.2f}°\n"
                    f">>> 請按 [Enter / 空白鍵] 確認完成，或按 [右鍵 / Backspace] 重選 <<<"
                )
                col = "navy"
            ax.set_title(msg, fontsize=10.0, fontweight="bold", color=col)

        def redraw_markers():
            if arrow_patch["ann"] is not None:
                arrow_patch["ann"].remove()
                arrow_patch["ann"] = None

            if len(clicked_pts) == 0:
                p1_marker.set_data([], [])
                p1_dot.set_data([], [])
                p2_marker.set_data([], [])
                preview_line.set_data([], [])
            elif len(clicked_pts) == 1:
                p1 = clicked_pts[0]
                p1_marker.set_data([p1[0]], [p1[1]])
                p1_dot.set_data([p1[0]], [p1[1]])
                p2_marker.set_data([], [])
                mx, my = state["last_mouse"]
                preview_line.set_data([p1[0], mx], [p1[1], my])
            else:
                p1, p2 = clicked_pts[0], clicked_pts[1]
                p1_marker.set_data([p1[0]], [p1[1]])
                p1_dot.set_data([p1[0]], [p1[1]])
                p2_marker.set_data([p2[0]], [p2[1]])
                preview_line.set_data([], [])
                arrow_patch["ann"] = ax.annotate(
                    "",
                    xy=p2,
                    xytext=p1,
                    arrowprops=dict(arrowstyle="->", color="lime", lw=2.2, mutation_scale=18),
                )
            update_title(*state["last_mouse"])
            fig.canvas.draw_idle()

        def on_move(event):
            if event.inaxes != ax or event.xdata is None or event.ydata is None:
                return
            x, y = float(event.xdata), float(event.ydata)
            state["last_mouse"] = (x, y)
            cursor_h.set_data([0, W], [y, y])
            cursor_v.set_data([x, x], [0, H])
            cursor_center_dot.set_data([x], [y])
            for circ, r0 in zip(cursor_circles, base_radii):
                circ.center = (x, y)
                circ.set_radius(r0 * state["r_scale"])
            if len(clicked_pts) == 1:
                p1 = clicked_pts[0]
                preview_line.set_data([p1[0], x], [p1[1], y])
            update_title(x, y)
            fig.canvas.draw_idle()

        def on_scroll(event):
            if event.inaxes != ax or event.xdata is None or event.ydata is None:
                return
            scale_factor = 0.8 if event.button == "up" else 1.25
            cur_xlim = ax.get_xlim()
            cur_ylim = ax.get_ylim()
            xdata, ydata = float(event.xdata), float(event.ydata)
            new_w = (cur_xlim[1] - cur_xlim[0]) * scale_factor
            new_h = (cur_ylim[0] - cur_ylim[1]) * scale_factor
            if new_w >= W * 1.2 or abs(new_h) >= H * 1.2:
                ax.set_xlim(0, W)
                ax.set_ylim(H, 0)
            else:
                rel_x = (xdata - cur_xlim[0]) / (cur_xlim[1] - cur_xlim[0])
                rel_y = (ydata - cur_ylim[1]) / (cur_ylim[0] - cur_ylim[1])
                xmin = xdata - rel_x * new_w
                xmax = xmin + new_w
                ymin = ydata - rel_y * new_h
                ymax = ymin + new_h
                ax.set_xlim(xmin, xmax)
                ax.set_ylim(ymax, ymin)
            fig.canvas.draw_idle()

        def on_press(event):
            if event.inaxes != ax or event.xdata is None or event.ydata is None:
                return
            tb = getattr(fig.canvas, "toolbar", None)
            if tb is not None and getattr(tb, "mode", "") != "":
                return
            if event.button == 1:
                state["press_xy"] = (event.x, event.y, float(event.xdata), float(event.ydata))
            elif event.button == 3:
                if clicked_pts:
                    clicked_pts.pop()
                    redraw_markers()

        def on_release(event):
            if event.button != 1 or state["press_xy"] is None:
                return
            tb = getattr(fig.canvas, "toolbar", None)
            if tb is not None and getattr(tb, "mode", "") != "":
                state["press_xy"] = None
                return
            px_scr, py_scr, x_data, y_data = state["press_xy"]
            state["press_xy"] = None
            if event.inaxes != ax or event.x is None or event.y is None:
                return
            if np.hypot(event.x - px_scr, event.y - py_scr) > 3.0:
                return
            if len(clicked_pts) < 2:
                clicked_pts.append((x_data, y_data))
                redraw_markers()

        def on_key(event):
            if event.key in ("enter", " ") and len(clicked_pts) == 2:
                state["confirmed"] = True
                plt.close(fig)
            elif event.key in ("s", "S") and has_existing_pkl:
                state["skip_use_existing"] = True
                plt.close(fig)
            elif event.key in ("backspace", "delete"):
                if clicked_pts:
                    clicked_pts.pop()
                    redraw_markers()
            elif event.key == "]":
                state["r_scale"] *= 1.15
                for circ, r0 in zip(cursor_circles, base_radii):
                    circ.set_radius(r0 * state["r_scale"])
                fig.canvas.draw_idle()
            elif event.key == "[":
                state["r_scale"] = max(0.2, state["r_scale"] / 1.15)
                for circ, r0 in zip(cursor_circles, base_radii):
                    circ.set_radius(r0 * state["r_scale"])
                fig.canvas.draw_idle()
            elif event.key == "r":
                ax.set_xlim(0, W)
                ax.set_ylim(H, 0)
                fig.canvas.draw_idle()
            elif event.key == "e" and edge_scatter is not None:
                state["show_edges"] = not state["show_edges"]
                edge_scatter.set_visible(state["show_edges"])
                fig.canvas.draw_idle()

        update_title(cx, cy)
        plt.tight_layout()

        cids = [
            fig.canvas.mpl_connect("motion_notify_event", on_move),
            fig.canvas.mpl_connect("scroll_event", on_scroll),
            fig.canvas.mpl_connect("button_press_event", on_press),
            fig.canvas.mpl_connect("button_release_event", on_release),
            fig.canvas.mpl_connect("key_press_event", on_key),
        ]
        plt.show()
        for cid in cids:
            fig.canvas.mpl_disconnect(cid)

        if state["skip_use_existing"] or not state["confirmed"]:
            return None, None

        p1_ds, p2_ds = clicked_pts[0], clicked_pts[1]
        p1_orig = (p1_ds[0] * scale_x, p1_ds[1] * scale_y)
        p2_orig = (p2_ds[0] * scale_x, p2_ds[1] * scale_y)
        self.set_golden_points(p1_orig, p2_orig)
        return p1_orig, p2_orig

    def plot_diagnostics(self, img1, title_prefix=""):
        """
        彈出 2×3 六宮格「全流程 X 光超參數診斷面板」：
          [左上] ① Canny 次像素邊緣 & 梯度法線小箭頭 (檢視 canny_low/high, blur_level)
          [中上] ② Step 1: 1D 梯度方向角互相關頻譜與前 K 名候選峰值 (檢視 angle_bins, top_k_angles)
          [右上] ③ Step 3: 候選角寬帶預拉入 PK 計分板 — 同向加分 vs 反極性扣分 (檢視遮擋干擾)
          [左下] ④ Step 2: 勝出角轉正後 1D X/Y 投影互相關峰值曲線 (檢視 proj_sigma, proj_len)
          [中下] ⑤ Step 4: 窄帶 WLSQ 點雲「紅綠燈」分類圖 — [●]內點 / [×]距離剔除 / [▲]極性剔除 (檢視 band_tau, polarity_th)
          [右下] ⑥ 迭代收斂軌跡 (Coarse -> Iter 1..K) 與超參數調校建議儀表板 (檢視 max_iter, tol, Coverage)
        """
        import matplotlib.pyplot as plt

        self._setup_mpl_font()

        img1_gray = self._load_gray_array(img1)
        x_cam, y_cam, theta_cam_deg = self.predict(img1_gray)
        if self.rel_pose is None:
            print(f"[plot_diagnostics] {title_prefix} 提取到的邊緣點過少，無法產生診斷面板。")
            return
        _, qx, qy, u1x, u1y, mag1 = self._extract_subpixel_edges(img1_gray)

        c_data = self._cache
        H_img, W_img = c_data["H_img"], c_data["W_img"]
        cx, cy = c_data["cx"], c_data["cy"]
        px0, py0 = c_data["px0"], c_data["py0"]
        dbg = getattr(self, "_last_coarse_debug", None)

        fig, axes = plt.subplots(2, 3, figsize=(18.5, 10.5))
        ax1, ax2, ax3 = axes[0]
        ax4, ax5, ax6 = axes[1]

        # =================================================================
        # [宮格 1 - 左上] Canny 次像素邊緣 + 梯度法線小箭頭
        # =================================================================
        ax1.imshow(img1_gray, cmap="gray", vmin=0, vmax=255)
        if qx.size > 0:
            ex1 = qx + cx
            ey1 = qy + cy
            sc1 = ax1.scatter(
                ex1, ey1, c=mag1, cmap="plasma", s=3.0, alpha=0.85, label=f"邊緣點 (N={qx.size})"
            )
            plt.colorbar(sc1, ax=ax1, fraction=0.046, pad=0.03, label="梯度強度 mag")
            step_q = max(1, qx.size // 45)
            ax1.quiver(
                ex1[::step_q],
                ey1[::step_q],
                u1x[::step_q],
                u1y[::step_q],
                color="cyan",
                angles="xy",
                scale_units="xy",
                scale=0.12,
                width=0.004,
                label="梯度法線 (指向亮區)",
            )
        ax1.set_xlim(0, W_img)
        ax1.set_ylim(H_img, 0)
        ax1.legend(loc="lower right", fontsize=8)
        ax1.set_title(
            f"① 邊緣與法線小箭頭 (N={qx.size})\n"
            f"[參數: canny=({self.canny_low},{self.canny_high}), blur={self.blur_level}]",
            fontsize=10.5,
            fontweight="bold",
        )

        # =================================================================
        # [宮格 2 - 中上] Step 1: 1D 角度投票箱互相關頻譜
        # =================================================================
        if dbg is not None:
            B = self.angle_bins
            corr_th = dbg["corr_theta"]
            angles_grid = ((np.arange(B) * (360.0 / B)) + 180.0) % 360.0 - 180.0
            sort_idx = np.argsort(angles_grid)
            ax2.plot(
                angles_grid[sort_idx],
                corr_th[sort_idx],
                color="royalblue",
                lw=1.5,
                label="1D 方向互相關 corr_θ",
            )
            ax2.axhline(0.0, color="gray", ls=":", lw=0.8)

            best_idx = dbg["best_idx"]
            for rec in dbg["cand_records"]:
                r_idx = rec["rank"] - 1
                ang0 = rec["init_ang_deg"]
                cval = rec["corr_val"]
                is_win = r_idx == best_idx
                ax2.plot(
                    ang0,
                    cval,
                    "o",
                    color="limegreen" if is_win else "crimson",
                    ms=8 if is_win else 6,
                )
                ax2.annotate(
                    f"#{rec['rank']} ({ang0:+.1f}°)",
                    xy=(ang0, cval),
                    xytext=(0, 8 if is_win else -14),
                    textcoords="offset points",
                    ha="center",
                    fontsize=8.5,
                    fontweight="bold" if is_win else "normal",
                    color="darkgreen" if is_win else "darkred",
                )
            win_ang = dbg["cand_records"][best_idx]["init_ang_deg"]
            ax2.axvline(win_ang, color="limegreen", ls="--", lw=1.2, label=f"勝出初值角 ({win_ang:+.1f}°)")
            ax2.set_xlim(-180, 180)
            ax2.set_xlabel("旋轉角度 dtheta (deg)")
            ax2.set_ylabel("正規化互相關係數")
            ax2.grid(True, ls=":", alpha=0.5)
            ax2.legend(loc="upper right", fontsize=8)
        ax2.set_title(
            f"② Step 1: 角度投票箱互相關頻譜\n"
            f"[參數: angle_bins={self.angle_bins}, top_k_angles={self.top_k_angles}]",
            fontsize=10.5,
            fontweight="bold",
        )

        # =================================================================
        # [宮格 3 - 右上] Step 3: 候選角寬帶預拉入 PK 計分板
        # =================================================================
        if dbg is not None:
            recs = dbg["cand_records"]
            best_idx = dbg["best_idx"]
            y_pos = np.arange(len(recs))
            pos_scores = [r["pos_score"] for r in recs]
            neg_pens = [r["neg_penalty"] for r in recs]
            tot_scores = [r["total_score"] for r in recs]
            labels = [
                f"#{r['rank']}: {r['init_ang_deg']:+.1f}°->{r['pulled_ang_deg']:+.1f}°"
                + (" ★勝出" if (r["rank"] - 1) == best_idx else "")
                for r in recs
            ]

            ax3.barh(y_pos, pos_scores, color="mediumseagreen", alpha=0.75, label="同向邊緣加分 (+)")
            ax3.barh(y_pos, neg_pens, color="indianred", alpha=0.75, label="反極性邊緣扣分 (-)")
            for yp, tot, r in zip(y_pos, tot_scores, recs):
                is_win = (r["rank"] - 1) == best_idx
                ax3.plot(tot, yp, "D", color="gold" if is_win else "navy", ms=7)
                ax3.text(
                    max(pos_scores) * 0.02,
                    yp,
                    f" 總分={tot:.1f}",
                    va="center",
                    fontsize=8.5,
                    fontweight="bold" if is_win else "normal",
                    color="darkgreen" if is_win else "black",
                )
            ax3.set_yticks(y_pos)
            ax3.set_yticklabels(labels, fontsize=8.5)
            ax3.invert_yaxis()
            ax3.axvline(0.0, color="black", lw=0.8)
            ax3.set_xlabel("對齊評分 (Score)")
            ax3.grid(True, axis="x", ls=":", alpha=0.5)
            ax3.legend(loc="lower right", fontsize=8)
        ax3.set_title(
            f"③ Step 3: 候選角寬帶預拉入 PK 計分板\n"
            f"[寬帶磁場 wide_tau={dbg['wide_tau']:.1f}px, 評分帶={dbg['score_dist_tau']:.1f}px]",
            fontsize=10.5,
            fontweight="bold",
        )

        # =================================================================
        # [宮格 4 - 左下] Step 2: 勝出角轉正後 X / Y 投影互相關峰值
        # =================================================================
        if dbg is not None and dbg["best_corr_x"] is not None:
            M = self.proj_len
            shifts = ((np.arange(M) + M / 2.0) % M) - M / 2.0
            s_idx = np.argsort(shifts)
            shifts_sorted = shifts[s_idx]
            cx_sorted = dbg["best_corr_x"][s_idx]
            cy_sorted = dbg["best_corr_y"][s_idx]

            ax4.plot(shifts_sorted, cx_sorted, color="dodgerblue", lw=1.5, label="X 軸投影互相關 corr_x")
            ax4.plot(shifts_sorted, cy_sorted, color="darkorange", lw=1.5, label="Y 軸投影互相關 corr_y")
            ax4.axvline(
                dbg["best_dx_tilde"],
                color="dodgerblue",
                ls="--",
                lw=1.2,
                label=f"峰值 dx_tilde={dbg['best_dx_tilde']:+.1f} px",
            )
            ax4.axvline(
                dbg["best_dy_tilde"],
                color="darkorange",
                ls="--",
                lw=1.2,
                label=f"峰值 dy_tilde={dbg['best_dy_tilde']:+.1f} px",
            )
            lim_view = max(W_img, H_img) * 0.65
            ax4.set_xlim(-lim_view, lim_view)
            ax4.set_xlabel("轉正座標系下之平移偏移量 (px)")
            ax4.set_ylabel("投影互相關強度")
            ax4.grid(True, ls=":", alpha=0.5)
            ax4.legend(loc="upper right", fontsize=8)
        ax4.set_title(
            f"④ Step 2: 1D X/Y 影子投影互相關峰值\n"
            f"[參數: proj_len={self.proj_len} (自動), proj_sigma={self.proj_sigma}]",
            fontsize=10.5,
            fontweight="bold",
        )

        # =================================================================
        # [宮格 5 - 中下] Step 4: 窄帶 WLSQ 點雲「紅綠燈」分類診斷圖
        # =================================================================
        dx_f, dy_f, dth_f_deg = self.rel_pose
        dth_f = np.deg2rad(dth_f_deg)
        cf, sf = np.cos(dth_f), np.sin(dth_f)
        px_pull = cf * (qx - dx_f) + sf * (qy - dy_f)
        py_pull = -sf * (qx - dx_f) + cf * (qy - dy_f)
        ux_pull = cf * u1x + sf * u1y
        uy_pull = -sf * u1x + cf * u1y

        ix_p = np.clip(np.rint(px_pull + cx).astype(np.int32), 0, W_img - 1)
        iy_p = np.clip(np.rint(py_pull + cy).astype(np.int32), 0, H_img - 1)
        px0_s = c_data["px0_map"][iy_p, ix_p]
        py0_s = c_data["py0_map"][iy_p, ix_p]
        nx_s = c_data["nx_map"][iy_p, ix_p]
        ny_s = c_data["ny_map"][iy_p, ix_p]

        err_f = (px_pull - px0_s) * nx_s + (py_pull - py0_s) * ny_s
        abs_err_f = np.abs(err_f)
        pol_f = ux_pull * nx_s + uy_pull * ny_s

        tau_final = self.band_tau if self.max_iter <= 2 else max(1.5, self.band_tau * 0.7)
        mask_inlier = (abs_err_f < tau_final) & (pol_f >= self.polarity_th)
        mask_pol_rej = (abs_err_f < tau_final) & (~mask_inlier)
        mask_dist_rej = abs_err_f >= tau_final

        n_in = int(np.sum(mask_inlier))
        n_pol = int(np.sum(mask_pol_rej))
        n_dist = int(np.sum(mask_dist_rej))
        cov_pct = 100.0 * n_in / max(1, c_data["num_ref_pts"])

        ax5.imshow(np.minimum(c_data["dist_map"], 15.0), cmap="Greys", alpha=0.35)
        ax5.scatter(px0 + cx, py0 + cy, s=1.0, c="royalblue", alpha=0.45, label="標準圖 img0 輪廓")

        if n_dist > 0:
            ax5.scatter(
                px_pull[mask_dist_rej] + cx,
                py_pull[mask_dist_rej] + cy,
                s=14,
                c="red",
                marker="x",
                alpha=0.85,
                label=f"[×] 距離剔除 |e|>={tau_final:.2f}px ({n_dist}點: 灰塵/遮擋)",
            )
        if n_pol > 0:
            ax5.scatter(
                px_pull[mask_pol_rej] + cx,
                py_pull[mask_pol_rej] + cy,
                s=16,
                c="darkviolet",
                marker="^",
                alpha=0.85,
                label=f"[▲] 極性剔除 pol<{self.polarity_th} ({n_pol}點: 反相邊緣)",
            )
        if n_in > 0:
            ax5.scatter(
                px_pull[mask_inlier] + cx,
                py_pull[mask_inlier] + cy,
                s=6,
                c="limegreen",
                marker="o",
                alpha=0.9,
                label=f"[●] 有效內點 Inliers ({n_in}點, 覆蓋率={cov_pct:.1f}%)",
            )

        ax5.set_xlim(0, W_img)
        ax5.set_ylim(H_img, 0)
        ax5.legend(loc="lower right", fontsize=7.8)
        ax5.set_title(
            f"⑤ Step 4: 窄帶 WLSQ 點雲「紅綠燈」分類圖\n"
            f"[參數: band_tau={self.band_tau}->{tau_final:.2f}px, polarity_th={self.polarity_th}]",
            fontsize=10.5,
            fontweight="bold",
        )

        # =================================================================
        # [宮格 6 - 右下] 迭代收斂軌跡與自動調參建議
        # =================================================================
        if self.history:
            iters = [h["iter"] for h in self.history]
            step_xy = [np.hypot(h["delta_dx"], h["delta_dy"]) for h in self.history]
            rmses = [h["rmse"] for h in self.history]

            ax6_r = ax6.twinx()
            (l1,) = ax6.plot(iters, step_xy, "o-", color="royalblue", lw=2.0, ms=7, label="修正步長 ||Δdxy|| (px)")
            ax6.axhline(self.tol, color="royalblue", ls="--", lw=0.9, alpha=0.6, label=f"收斂門檻 tol={self.tol}")
            (l2,) = ax6_r.plot(iters, rmses, "s--", color="seagreen", lw=2.0, ms=7, label="窄帶殘差 RMSE (px)")

            ax6.set_xticks(iters)
            ax6.set_xticklabels([f"Iter {k}" for k in iters])
            ax6.set_ylabel("修正步長 ||Δdxy|| (px)", color="royalblue")
            ax6_r.set_ylabel("加權殘差 RMSE (px)", color="seagreen")
            ax6.grid(True, ls=":", alpha=0.5)
            ax6.legend(handles=[l1, l2], loc="upper right", fontsize=8)

        rmse_final = self.history[-1]["rmse"] if self.history else 999.0
        tips = []
        if qx.size < 0.4 * c_data["num_ref_pts"]:
            tips.append("注意：邊緣點偏少，建議調低 canny_low / canny_high")
        if cov_pct < 35.0:
            tips.append("注意：內點覆蓋率 < 35%，若零件有形變可調大 band_tau 至 3.5，或檢查是否嚴重遮擋")
        if rmse_final > 0.6:
            tips.append("注意：RMSE 偏高，若邊緣有毛邊/灰塵混入綠點，建議調小 band_tau 至 1.8")
        if not tips:
            tips.append("【正常】內點覆蓋充足、極性一致且殘差極低，無需調整超參數")

        cx_p, cy_p, th_c = self.coarse_pose
        diag_text = (
            f"【收斂狀態】 exit_reason = '{self.exit_reason}' (共跑 {self.iterations} 步)\n"
            f"  • 粗定位初值 (Coarse) : dx={cx_p:+.2f}px, dy={cy_p:+.2f}px, dθ={th_c:+.2f}°\n"
            f"  • 精修後相對 (Final)  : dx={dx_f:+.2f}px, dy={dy_f:+.2f}px, dθ={dth_f_deg:+.2f}°\n"
            f"  • 攝影機座標 (Camera) : X={x_cam:+.2f}px, Y={y_cam:+.2f}px, Θ={theta_cam_deg:+.2f}°\n"
            f"  • 輪廓覆蓋率 Coverage : {cov_pct:.1f}% ({n_in}/{c_data['num_ref_pts']} pts) | 最終 RMSE = {rmse_final:.4f} px\n"
            f"【超參數調校建議】\n  " + "\n  ".join(tips)
        )
        ax6.text(
            0.02,
            0.03,
            diag_text,
            transform=ax6.transAxes,
            fontsize=8.5,
            va="bottom",
            ha="left",
            bbox=dict(boxstyle="round,pad=0.5", facecolor="#f8fafc", edgecolor="#94a3b8", alpha=0.92),
        )
        ax6.set_title(
            f"⑥ WLSQ 收斂軌跡與健康度診斷\n"
            f"[參數: max_iter={self.max_iter}, tol={self.tol}]",
            fontsize=10.5,
            fontweight="bold",
        )

        fig.suptitle(
            f"【Contour_WLSQ 全流程 X 光診斷面板】 {title_prefix}  "
            f"(Camera Pose: X={x_cam:+.2f}, Y={y_cam:+.2f}, Θ={theta_cam_deg:+.2f}°)",
            fontsize=13,
            fontweight="bold",
        )
        plt.tight_layout(rect=[0, 0, 1, 0.95])
        plt.show()