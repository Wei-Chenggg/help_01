# 專案助理指南
## 檔案讀寫限制
1. 只能讀取專案沙盒內資料
2. 不能擴大搜索沙盒外資料, 專案之外的內容會汙染對話方向
3. 讀取檔案使用相對路徑
4. 不要自己執行代碼, 只要把使用者指定要修改的部分改好, 使用者會去確認
5. 你的定位主要是幫忙修改代碼, 你不需要設計/抓問題, 主要是幫忙打字修改好檔案文字

## Python 代碼編輯

1. 盡量沿用現有命名方式。
2. 盡量避免新增註解。
3. 盡可能減少空白行，通常只在 class 前保留一行。
4. 盡量只修改使用者指定的 class 或 def。
5. 不要自己執行代碼, 只要把使用者指定要修改的部分改好, 使用者會去確認

## 修改前備份
1. 任何修改之前, 都需要建立一份備分, 把py,csv,md file 都放到備分資料夾
2. 統一收放在 "./backup" 資料夾, 資料夾內包含每一次的備分, 一個版本備分需要一個資料夾
3. 每次備分資料夾名稱範例 "./backup/backup-YYYYMMDDXXX", 裡面會包含我說的那些檔案
4. png, jpg, pkl, pdf等等不應該放入備分, 因為檔案太大會膨脹佔用空間
5. 嚴禁在備分之前修改檔案

## 備份指令

```powershell
Set-Location -LiteralPath 'C:\folder\to\project'
$root = (Get-Location).Path
$dest = Join-Path $root 'backup\backup-20260927001'
Get-ChildItem -Recurse -File -LiteralPath $root |
  Where-Object { $_.Extension -in '.py','.csv','.md' -and $_.FullName -notmatch '\\backup\\' } |
  ForEach-Object {
    $t = Join-Path $dest $_.FullName.Substring($root.Length+1)
    New-Item -ItemType Directory -Path (Split-Path -Parent $t) -Force | Out-Null
    Copy-Item -LiteralPath $_.FullName -Destination $t -Force
  }
```

- 資料夾：`./backup/backup-YYYYMMDDXXX`（同日第二版遞增：`...002`）
- 保留 `config/`、`toolbox/` 相對結構
- 只備份 `.py` `.csv` `.md`；png/jpg/pkl/pdf 略過

## 聽懂指令
1. 人類老闆說"看一下"or"先討論"or"不動手"or"上手", 代表不要修改文件, 只是提出想法, 說出你的意見, 或是熟悉某些內容
2. 人類老闆說"改一下"or"把...改好", 代表你可以根據之前的資訊去把事項完成, 真的把討論結果改到文件內
3. 人類老闆說"先確認我的需求"or"說說想法", 代表他不想打字, 要你猜, 所以你要多問, 但不是問不經過大腦的問題, 所以每個問題都要有預設答案至少兩個讓老闆選