# gen_simu_imgs.py
import os
import json
import cv2
import numpy as np
from dataclasses import dataclass, replace
from scipy.ndimage import gaussian_filter
from scipy.special import expit


def clear_folder(folder):
    if not os.path.isdir(folder):
        return
    for fn in os.listdir(folder):
        full = os.path.join(folder, fn)
        if os.path.isfile(full):
            os.remove(full)


def save_png(path, img):
    arr = np.clip(np.rint(img), 0, 255).astype(np.uint8)
    ok, buf = cv2.imencode(".png", arr)
    if not ok:
        raise IOError(f"Failed to encode image: {path}")
    with open(path, "wb") as f:
        f.write(buf.tobytes())


def add_dust_and_occlusion(img, rng, sigma=0.0, num_dust=0, occlude=False):
    out = img.copy().astype(np.float64)
    H, W = out.shape
    scale_f = max(1.0, min(H, W) / 400.0)
    yy, xx = np.ogrid[:H, :W]

    if occlude:
        ys_fg, xs_fg = np.nonzero(out > 128)
        if xs_fg.size > 0:
            idx = int(rng.integers(0, xs_fg.size))
            ox, oy = int(xs_fg[idx]), int(ys_fg[idx])
            hw = int(rng.integers(int(22 * scale_f), int(35 * scale_f) + 1))
            hh = int(rng.integers(int(22 * scale_f), int(35 * scale_f) + 1))
            y0, y1 = max(0, oy - hh), min(H, oy + hh)
            x0, x1 = max(0, ox - hw), min(W, ox + hw)
            out[y0:y1, x0:x1] = 0.0

    margin = int(40 * scale_f)
    for _ in range(num_dust):
        cx_d = float(rng.uniform(margin, max(margin + 1, W - margin)))
        cy_d = float(rng.uniform(margin, max(margin + 1, H - margin)))
        r_d = float(rng.uniform(2.5 * scale_f, 6.5 * scale_f))
        val_d = 0.0 if rng.random() < 0.5 else 255.0
        mask_d = (xx - cx_d) ** 2 + (yy - cy_d) ** 2 <= r_d**2
        out[mask_d] = val_d

    if sigma > 0.0:
        out += rng.normal(0.0, sigma, out.shape)

    return np.clip(out, 0.0, 255.0)


def apply_lighting_change(img, offset=0.0, gain=1.0, grad_x=0.0, grad_y=0.0):
    H, W = img.shape
    out = img.astype(np.float64) * float(gain) + float(offset)
    if abs(grad_x) > 1e-6:
        gx = np.linspace(-0.5 * grad_x, 0.5 * grad_x, W, dtype=np.float64)
        out += gx[None, :]
    if abs(grad_y) > 1e-6:
        gy = np.linspace(-0.5 * grad_y, 0.5 * grad_y, H, dtype=np.float64)
        out += gy[:, None]
    return np.clip(np.rint(out), 0, 255).astype(np.uint8)


@dataclass
class Config:
    width: int = 2500
    height: int = 2000
    geom_scale: float = 5.0
    dx: float = 0.0
    dy: float = 0.0
    angle_deg0: float = 0.0
    angle_deg1: float = 0.0
    edge_tau: float = 1.5
    blur_size: int = 7
    blur_sigma: float = 1.5


class Chart_Renderer:
    def __init__(self, equ=None, equ_kwargs=None, edge_mode="sigmoid"):
        self.equ = equ
        self.equ_kwargs = equ_kwargs or {}
        self.edge_mode = edge_mode

    def set_equ(self, func, **kwargs):
        self.equ = func
        self.equ_kwargs = kwargs
        return self

    def render(self, cfg: Config, target=False) -> np.ndarray:
        if self.equ is None:
            raise ValueError("equ not set")
        W, H = cfg.width, cfg.height
        x = np.arange(W, dtype=np.float64) - (W - 1) / 2.0
        y = np.arange(H, dtype=np.float64) - (H - 1) / 2.0
        xx, yy = np.meshgrid(x, y)

        ox = cfg.dx if target else 0.0
        oy = cfg.dy if target else 0.0
        angle_deg = cfg.angle_deg1 if target else cfg.angle_deg0
        theta = np.deg2rad(angle_deg)
        c, s = np.cos(theta), np.sin(theta)
        gx = xx - ox
        gy = yy - oy
        lx = c * gx + s * gy
        ly = -s * gx + c * gy

        s_geom = float(max(cfg.geom_scale, 1e-6))
        sdf = self.equ(lx / s_geom, ly / s_geom, **self.equ_kwargs) * s_geom
        canvas = self._to_gray(sdf, cfg.edge_tau)
        canvas = np.clip(np.rint(canvas), 0, 255).astype(np.uint8).astype(np.float64)
        if cfg.blur_sigma > 0:
            canvas = gaussian_filter(
                canvas,
                sigma=cfg.blur_sigma,
                truncate=cfg.blur_size / 2.0 / cfg.blur_sigma,
            )
        return canvas

    def _to_gray(self, sdf, tau):
        mode = self.edge_mode
        if mode == "hard" or tau <= 0:
            return np.where(sdf <= 0, 255.0, 0.0)
        if mode == "linear":
            return 255.0 * np.clip(-sdf / tau + 0.5, 0.0, 1.0)
        if mode == "sigmoid":
            return 255.0 * expit(-sdf / tau)
        raise ValueError(f"unknown edge_mode: {mode}")


# =====================================================================
# 基礎與 5 種複合工業部品 SDF 定義
# =====================================================================
def equ_circle(xx, yy, r):
    return np.sqrt(xx**2 + yy**2) - r


def equ_rect(xx, yy, w, h):
    dx = np.abs(xx) - w / 2.0
    dy = np.abs(yy) - h / 2.0
    outside = np.sqrt(np.maximum(dx, 0.0) ** 2 + np.maximum(dy, 0.0) ** 2)
    inside = np.minimum(np.maximum(dx, dy), 0.0)
    return outside + inside


def equ_rounded_rect(xx, yy, w, h, r_corner=16.0):
    return equ_rect(xx, yy, w - 2.0 * r_corner, h - 2.0 * r_corner) - r_corner


def equ_slot(xx, yy, half_len, r, angle_deg=0.0):
    th = np.deg2rad(angle_deg)
    c, s = np.cos(th), np.sin(th)
    ux = c * xx + s * yy
    uy = -s * xx + c * yy
    qx = np.maximum(np.abs(ux) - half_len, 0.0)
    qy = np.abs(uy)
    return np.sqrt(qx**2 + qy**2) - r


def equ_rect_2circles(xx, yy, w=160.0, h=110.0, c1=(-45.0, -25.0), c2=(45.0, 25.0), r_hole=16.0):
    d_rect = equ_rect(xx, yy, w, h)
    d_c1 = equ_circle(xx - c1[0], yy - c1[1], r_hole)
    d_c2 = equ_circle(xx - c2[0], yy - c2[1], r_hole)
    d_holes = np.minimum(d_c1, d_c2)
    return np.maximum(d_rect, -d_holes)


def equ_rounded_circle_slot(
    xx, yy, w=164.0, h=112.0, r_corner=18.0,
    c1=(-46.0, -24.0), r_c1=16.0,
    c2=(40.0, 22.0), slot_half_len=14.0, r_slot=12.0, slot_deg=-20.0,
    notch_xy=(-82.0, 12.0), r_notch=12.0,
):
    d_body = equ_rounded_rect(xx, yy, w, h, r_corner=r_corner)
    d_c1 = equ_circle(xx - c1[0], yy - c1[1], r_c1)
    d_s2 = equ_slot(xx - c2[0], yy - c2[1], half_len=slot_half_len, r=r_slot, angle_deg=slot_deg)
    d_notch = equ_circle(xx - notch_xy[0], yy - notch_xy[1], r_notch)
    d_cutouts = np.minimum(d_c1, np.minimum(d_s2, d_notch))
    return np.maximum(d_body, -d_cutouts)


def equ_wavy_cam_flange(
    xx, yy, r0=76.0, coeffs=((3, 11.0, 0.0), (2, 7.0, 0.8), (5, 4.0, -0.5)),
    c1=(-28.0, -18.0), r_c1=17.0,
    c2=(32.0, 20.0), slot_half_len=13.0, r_slot=11.0, slot_deg=35.0,
):
    theta = np.arctan2(yy, xx)
    r_theta = np.full_like(theta, r0, dtype=np.float64)
    for n, amp, phase in coeffs:
        r_theta += amp * np.cos(n * theta + phase)
    d_outer = np.sqrt(xx**2 + yy**2) - r_theta
    d_c1 = equ_circle(xx - c1[0], yy - c1[1], r_c1)
    d_s2 = equ_slot(xx - c2[0], yy - c2[1], half_len=slot_half_len, r=r_slot, angle_deg=slot_deg)
    d_holes = np.minimum(d_c1, d_s2)
    return np.maximum(d_outer, -d_holes)


def equ_cross_mounting_plate(
    xx, yy, w1=172.0, h1=78.0, w2=86.0, h2=156.0, r_corner=12.0, r_center=22.0,
    hole1=(-58.0, 0.0, 11.0), hole2=(0.0, -52.0, 11.0), hole3=(0.0, 52.0, 11.0),
    slot_pos=(56.0, 6.0), slot_half_len=10.0, r_slot=9.0, slot_deg=25.0,
    notch_xy=(-43.0, -39.0), r_notch=9.0,
):
    d_arm1 = equ_rounded_rect(xx, yy, w1, h1, r_corner=r_corner)
    d_arm2 = equ_rounded_rect(xx, yy, w2, h2, r_corner=r_corner)
    d_body = np.minimum(d_arm1, d_arm2)
    d_c0 = equ_circle(xx, yy, r_center)
    d_h1 = equ_circle(xx - hole1[0], yy - hole1[1], hole1[2])
    d_h2 = equ_circle(xx - hole2[0], yy - hole2[1], hole2[2])
    d_h3 = equ_circle(xx - hole3[0], yy - hole3[1], hole3[2])
    d_sl = equ_slot(xx - slot_pos[0], yy - slot_pos[1], half_len=slot_half_len, r=r_slot, angle_deg=slot_deg)
    d_nt = equ_circle(xx - notch_xy[0], yy - notch_xy[1], r_notch)
    d_cut = np.minimum(d_c0, np.minimum(d_h1, np.minimum(d_h2, np.minimum(d_h3, np.minimum(d_sl, d_nt)))))
    return np.maximum(d_body, -d_cut)


def equ_eccentric_gear_arm(
    xx, yy, c_big=(-38.0, 0.0), r_big=52.0, c_small=(52.0, 0.0), r_small=32.0,
    r_bore_big=22.0, r_bore_small=13.0, keyway_xy=(-16.0, 0.0), r_key=7.5,
    slot_xy=(10.0, 8.0), slot_half_len=14.0, r_slot=8.0, slot_deg=-12.0,
):
    d_b1 = equ_circle(xx - c_big[0], yy - c_big[1], r_big)
    d_b2 = equ_circle(xx - c_small[0], yy - c_small[1], r_small)
    d_bar = equ_rounded_rect(xx - 6.0, yy, w=96.0, h=54.0, r_corner=14.0)
    d_outer = np.minimum(d_b1, np.minimum(d_b2, d_bar))
    d_hole1 = equ_circle(xx - c_big[0], yy - c_big[1], r_bore_big)
    d_key = equ_circle(xx - keyway_xy[0], yy - keyway_xy[1], r_key)
    d_hole2 = equ_circle(xx - c_small[0], yy - c_small[1], r_bore_small)
    d_sl = equ_slot(xx - slot_xy[0], yy - slot_xy[1], half_len=slot_half_len, r=r_slot, angle_deg=slot_deg)
    d_cut = np.minimum(d_hole1, np.minimum(d_key, np.minimum(d_hole2, d_sl)))
    return np.maximum(d_outer, -d_cut)


def _smax(a, b, k=4.0):
    return 0.5 * (a + b + np.sqrt((a - b) ** 2 + k**2))


def _eval_bull_horn_raw(xx, yy):
    # 1. 非線性空間彎鉤變換：牛角向上延伸時往內鉤回，並帶不對稱 S 型擺幅
    x_norm = xx / 80.0
    y_norm = yy / 80.0
    inward_curl = 0.30 * (np.maximum(0.0, -y_norm + 0.15) ** 1.6)
    xw = xx * (1.0 + inward_curl) + 9.0 * np.sin(1.9 * y_norm + 0.3) - 3.5
    yw = yy + 11.0 * x_norm + 7.5 * np.cos(2.3 * x_norm - 0.4)

    # 2. 牛角外肚與外側波浪角節 (3, 4, 7 階非對稱諧波，徹底打破正圓)
    ux_o = 0.84 * xw
    uy_o = yw + 4.0
    th_o = np.arctan2(uy_o, ux_o)
    r_outer = (
        79.0
        + 10.5 * np.cos(3.0 * th_o - 0.35)
        + 6.5 * np.sin(4.0 * th_o + 0.75)
        + 4.0 * np.cos(7.0 * th_o - 1.10)
    )
    d_outer = np.hypot(ux_o, uy_o) - r_outer

    # 3. 上方偏心內凹鞍部場：挖出深 U 型牛角內彎，形成左右高聳不對稱雙尖角
    ux_s = 1.06 * (xw + 5.5)
    uy_s = yw + 54.0
    th_s = np.arctan2(uy_s, ux_s)
    r_saddle = (
        61.5
        + 8.0 * np.sin(2.0 * th_s + 0.45)
        + 5.0 * np.cos(3.0 * th_s - 0.85)
        + 2.8 * np.sin(5.0 * th_s + 0.20)
    )
    d_saddle = np.hypot(ux_s, uy_s) - r_saddle
    d_body = _smax(d_outer, -d_saddle, k=4.5)

    # 4. 內部鏤空 1：左翼柳葉彎月尖槽 (兩個偏心波浪橢圓弧相減，兩端收尖無圓弧)
    xl1 = (xx + 34.0) * 0.88 + (yy - 16.0) * 0.48
    yl1 = -(xx + 34.0) * 0.48 + (yy - 16.0) * 0.88
    th_l1 = np.arctan2(yl1, xl1)
    d_l1_a = np.hypot(xl1 * 0.72, yl1 * 1.35) - (19.5 + 2.5 * np.cos(3.0 * th_l1))
    d_l1_b = np.hypot((xl1 - 7.5) * 0.75, (yl1 + 11.5) * 1.25) - (18.5 + 2.0 * np.sin(2.0 * th_l1))
    d_cut_left = _smax(d_l1_a, -d_l1_b, k=2.2)

    # 5. 內部鏤空 2：右腹 S 型漸縮火焰流線槽 (彎曲軸線 + 漸縮尖尾 + 波浪邊緣，無完整圓)
    xr = (xx - 27.0) * 0.82 - (yy - 15.0) * 0.57
    yr = (xx - 27.0) * 0.57 + (yy - 15.0) * 0.82
    t_flame = np.clip((xr + 24.0) / 48.0, 0.0, 1.0)
    y_flame_spine = 5.5 * np.sin(np.pi * t_flame - 0.4) + 2.0 * np.cos(2.0 * np.pi * t_flame)
    w_flame = 11.5 * (np.sin(np.pi * t_flame) ** 0.75) * (1.0 - 0.35 * t_flame) + 1.2 * np.sin(4.0 * np.pi * t_flame)
    d_flame_a = np.abs(yr - y_flame_spine) - np.maximum(w_flame, 0.0)
    d_flame_b = np.abs(xr) - 24.0
    d_cut_right = (
        np.hypot(np.maximum(d_flame_a, 0.0), np.maximum(d_flame_b, 0.0))
        + np.minimum(np.maximum(d_flame_a, d_flame_b), 0.0)
        - 1.5
    )

    d_cutouts = np.minimum(d_cut_left, d_cut_right)
    return _smax(d_body, -d_cutouts, k=2.0)


def equ_bull_horn(xx, yy):
    eps = 0.25
    f0 = _eval_bull_horn_raw(xx, yy)
    fx = (_eval_bull_horn_raw(xx + eps, yy) - _eval_bull_horn_raw(xx - eps, yy)) / (2.0 * eps)
    fy = (_eval_bull_horn_raw(xx, yy + eps) - _eval_bull_horn_raw(xx, yy - eps)) / (2.0 * eps)
    grad_norm = np.maximum(np.hypot(fx, fy), 0.15)
    return f0 / grad_norm


renderer = Chart_Renderer(edge_mode="sigmoid")

DEFAULT_CFG = Config(width=2500, height=2000, geom_scale=5.0, edge_tau=1.5, blur_sigma=1.5)

DATASETS = {
    "rect_2circles": dict(
        id=0, name="rect_2circles", desc="雙圓孔長方板 (180°對稱)",
        symmetry_deg=180.0, equ=equ_rect_2circles, kwargs=dict(), cfg=replace(DEFAULT_CFG),
    ),
    "rounded_circle_slot": dict(
        id=1, name="rounded_circle_slot", desc="圓角長方板+圓孔+斜腰孔+缺口",
        symmetry_deg=360.0, equ=equ_rounded_circle_slot, kwargs=dict(), cfg=replace(DEFAULT_CFG),
    ),
    "wavy_cam_flange": dict(
        id=2, name="wavy_cam_flange", desc="非對稱三葉波浪凸輪法蘭盤",
        symmetry_deg=360.0, equ=equ_wavy_cam_flange, kwargs=dict(), cfg=replace(DEFAULT_CFG),
    ),
    "cross_mounting_plate": dict(
        id=3, name="cross_mounting_plate", desc="十字型多孔精密固定座",
        symmetry_deg=360.0, equ=equ_cross_mounting_plate, kwargs=dict(), cfg=replace(DEFAULT_CFG),
    ),
    "eccentric_gear_arm": dict(
        id=4, name="eccentric_gear_arm", desc="偏心連桿搖臂 (雙圓轂+鍵槽+腰孔)",
        symmetry_deg=360.0, equ=equ_eccentric_gear_arm, kwargs=dict(), cfg=replace(DEFAULT_CFG),
    ),
    "bull_horn": dict(
        id=5, name="bull_horn", desc="浮誇牛角任意曲線輪廓 (全自由曲線無圓孔)",
        symmetry_deg=360.0, equ=equ_bull_horn, kwargs=dict(), cfg=replace(DEFAULT_CFG),
    ),
}

# 待測影像 (img1_XXXX.png) 規格:
# (基準dx, 基準dy, angle_deg, 遮擋, 灰塵數, 高斯雜訊sigma, offset亮度, gain倍率, grad_x偏光, 說明標籤)
IMG1_SPECS = [
    (  0.0,   0.0,    0.0, False,  0,  0.0,   0.0, 1.00,   0.0, "標準燈光 (無干擾歸零驗證)"),
    ( 35.0, -25.0,   25.0, False,  0,  2.0, +30.0, 1.00,   0.0, "整體亮度 +30 (輕微過曝)"),
    (-50.0,  40.0,  -42.0, True,   8,  2.0, +30.0, 1.00,   0.0, "整體亮度 +30 + 遮擋+灰塵"),
    ( 65.0,  50.0,   85.0, False, 10,  2.0, +65.0, 1.00,   0.0, "整體亮度 +65 (中度過曝) + 灰塵"),
    (-68.0, -48.0, -115.0, True,  10,  2.0, -45.0, 1.00,   0.0, "整體亮度 -45 (欠曝變暗) + 遮擋"),
    ( 20.0,  72.0,  145.0, False, 12,  2.0, -80.0, 1.00,   0.0, "整體亮度 -80 (重度欠曝) + 灰塵"),
    (-75.0,  15.0, -168.0, True,  10,  2.0,   0.0, 0.55,   0.0, "光源衰減 0.55x + 遮擋"),
    ( 70.0, -55.0,  175.0, False,  8,  2.0, +25.0, 1.25,   0.0, "強光增益 1.25x + 偏移+25"),
    (-30.0, -70.0,  -75.0, True,  12,  2.0, +30.0, 1.00, +50.0, "亮度+30 + 單側偏光(±25) + 遮擋"),
    ( 52.0,  62.0,  -15.0, True,  10, 12.0, -20.0, 0.85, -40.0, "高強度高斯雜訊(σ=12) + 偏光 + 遮擋"),
]


if __name__ == "__main__":
    IMG_WIDTH = 2500
    IMG_HEIGHT = 2000
    GEOM_SCALE = 5.0
    SIM_ROOT = os.path.join(".", "sim_data")

    # 想只產生特定 dataset 就改此清單，預設一次產生全部 5 組
    TARGET_DATASETS = list(DATASETS.keys())

    IMG0_DX = -15.0 * GEOM_SCALE
    IMG0_DY = 12.0 * GEOM_SCALE
    IMG0_ANGLE_DEG = 18.0

    print("=" * 95)
    print(f"開始批次產生所有模擬資料集 (共 {len(TARGET_DATASETS)} 組，解析度 {IMG_WIDTH}x{IMG_HEIGHT})")
    print("=" * 95)

    for ds_idx, ds_name in enumerate(TARGET_DATASETS, start=1):
        spec = DATASETS[ds_name]
        out_dir = os.path.join(SIM_ROOT, ds_name)
        os.makedirs(out_dir, exist_ok=True)
        clear_folder(out_dir)

        cfg_base = replace(spec["cfg"], width=IMG_WIDTH, height=IMG_HEIGHT, geom_scale=GEOM_SCALE)
        renderer.set_equ(spec["equ"], **spec["kwargs"])

        print(f"\n[{ds_idx}/{len(TARGET_DATASETS)}] 產生 '{ds_name}' ({spec['desc']}) -> {out_dir}")

        # 1. 產生並儲存 img0.png (Golden Template)
        cfg0 = replace(cfg_base, dx=IMG0_DX, dy=IMG0_DY, angle_deg1=IMG0_ANGLE_DEG)
        img0 = renderer.render(cfg0, target=True)
        save_png(os.path.join(out_dir, "img0.png"), img0)
        print(f"  [基準圖] img0.png (dx={IMG0_DX:+.1f}, dy={IMG0_DY:+.1f}, θ={IMG0_ANGLE_DEG:+.1f}°)")

        # 2. 產生 img1_0000.png ~ img1_0009.png 並記錄真實相對變換供跑分核對
        rng = np.random.default_rng(2026)
        meta_items = []
        for i, (dx_b, dy_b, ang, occ, n_dust, sigma, offset, gain, grad_x, desc) in enumerate(IMG1_SPECS):
            dx = float(dx_b) * GEOM_SCALE
            dy = float(dy_b) * GEOM_SCALE
            cfg1 = replace(cfg_base, dx=dx, dy=dy, angle_deg1=float(ang))
            img1 = renderer.render(cfg1, target=True)
            if occ or n_dust > 0 or sigma > 0.0:
                img1 = add_dust_and_occlusion(img1, rng, sigma=sigma, num_dust=n_dust, occlude=occ)
            img1 = apply_lighting_change(img1, offset=offset, gain=gain, grad_x=grad_x)

            fn = f"img1_{i:04d}.png"
            save_png(os.path.join(out_dir, fn), img1)

            dth_gt_deg = float(ang) - IMG0_ANGLE_DEG
            dth_gt_rad = np.deg2rad(dth_gt_deg)
            c, s = np.cos(dth_gt_rad), np.sin(dth_gt_rad)
            dx_gt = float(dx - (c * IMG0_DX - s * IMG0_DY))
            dy_gt = float(dy - (s * IMG0_DX + c * IMG0_DY))

            meta_items.append({
                "file": fn,
                "desc": desc,
                "obj_dx": dx,
                "obj_dy": dy,
                "obj_angle_deg": float(ang),
                "gt_rel_dx": dx_gt,
                "gt_rel_dy": dy_gt,
                "gt_rel_dtheta_deg": dth_gt_deg,
                "sigma": sigma,
                "offset": offset,
                "gain": gain,
                "grad_x": grad_x,
                "occlude": occ,
                "num_dust": n_dust,
            })
            print(
                f"  [測試圖] {fn} | 姿態=({dx:+7.1f}, {dy:+7.1f}, {ang:+6.1f}°) "
                f"| σ={sigma:4.1f}, 燈光=({offset:+5.1f}, {gain:.2f}x, grad={grad_x:+5.1f}) | {desc}"
            )

        with open(os.path.join(out_dir, "gt_meta.json"), "w", encoding="utf-8") as f:
            json.dump(
                {
                    "dataset": ds_name,
                    "desc": spec["desc"],
                    "symmetry_deg": spec["symmetry_deg"],
                    "img0_pose": {"dx": IMG0_DX, "dy": IMG0_DY, "angle_deg": IMG0_ANGLE_DEG},
                    "test_images": meta_items,
                },
                f,
                ensure_ascii=False,
                indent=2,
            )

    print("\n" + "=" * 95)
    print("全部 Dataset 模擬影像與 gt_meta.json 已產生完畢，下一步請執行 predict.py。")
    print("=" * 95)
