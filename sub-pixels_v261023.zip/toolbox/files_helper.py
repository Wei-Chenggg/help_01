import csv
import pickle
import os
import shutil
import chardet
import time
import yaml
import ast
import re
import sys
import subprocess


def _fspath(p):
    # 將 PathLike / bytes 統一轉為 str，避免後續字串操作失敗
    if isinstance(p, bytes):
        return os.fsdecode(p)
    return os.fspath(p)
def _detect_encoding(fpath):
    # 使用 chardet 自動偵測檔案編碼，失敗時退回 utf-8
    with open(fpath, "rb") as f:
        raw = f.read()
    result = chardet.detect(raw)
    return result.get("encoding") or "utf-8"
def _check_exist_folder(fpath):
    # 檢查 fpath 的父資料夾是否存在，不存在則建立（可用於檔案或資料夾路徑）
    parent = os.path.dirname(os.path.abspath(fpath))
    if parent:
        os.makedirs(parent, exist_ok=True)
    return parent
def _ensure_ext(fpath, ext):
    # 若 fpath 結尾不是指定副檔名（不分大小寫），自動補上
    fpath = _fspath(fpath)
    if fpath.lower().endswith(ext.lower()):
        return fpath
    return fpath + ext
def _resolve_ext(fpath, ext):
    # 讀取用：優先使用原路徑，若不存在則嘗試補上副檔名
    fpath = _fspath(fpath)
    if os.path.exists(fpath):
        return fpath
    return _ensure_ext(fpath, ext)
def load_csv(fpath="./try.csv", encoding=None):
    # 讀取 CSV 檔案並回傳資料列表（自動補 .csv；encoding 為 None 時自動偵測）
    fpath = _resolve_ext(fpath, ".csv")
    if encoding is None:
        encoding = _detect_encoding(fpath)
    with open(fpath, "r", encoding=encoding, newline="") as f:
        return list(csv.reader(f))
def save_csv(fpath="./try.csv", data=None, encoding="utf-8-sig"):
    # 將資料寫入 CSV 檔案（自動補 .csv；參數順序顛倒會互換；父資料夾不存在會建立）
    if not isinstance(fpath, (str, bytes, os.PathLike)):
        fpath, data = data, fpath
    if data is None:
        data = []
    fpath = _ensure_ext(fpath, ".csv")
    _check_exist_folder(fpath)
    with open(fpath, "w", encoding=encoding, newline="") as f:
        csv.writer(f).writerows(data)
def append_csv(fpath="./try.csv", data=None, encoding="utf-8-sig"):
    # 將資料追加到 CSV 檔尾（檔案不存在則建立；自動補 .csv；父資料夾不存在會建立）
    if not isinstance(fpath, (str, bytes, os.PathLike)):
        fpath, data = data, fpath
    if data is None:
        data = []
    fpath = _ensure_ext(fpath, ".csv")
    _check_exist_folder(fpath)
    with open(fpath, "a", encoding=encoding, newline="") as f:
        csv.writer(f).writerows(data)
def load_pkl(fpath="./try.pkl"):
    # 讀取 pickle 檔案並回傳物件（自動補 .pkl）
    fpath = _resolve_ext(fpath, ".pkl")
    with open(fpath, "rb") as f:
        return pickle.load(f)
def save_pkl(fpath="./try.pkl", data=None):
    # 將物件以 pickle 格式寫入檔案（自動補 .pkl；參數順序顛倒會互換；父資料夾不存在會建立）
    if not isinstance(fpath, (str, bytes, os.PathLike)):
        fpath, data = data, fpath
    fpath = _ensure_ext(fpath, ".pkl")
    _check_exist_folder(fpath)
    with open(fpath, "wb") as f:
        pickle.dump(data, f)
def delete_file(fpath, ext=None, missing_ok=True):
    # 刪除檔案；ext 有給時自動補副檔名；missing_ok=True 則檔案不存在時不報錯
    if ext:
        fpath = _resolve_ext(fpath, ext)
    else:
        fpath = _fspath(fpath)
    try:
        os.remove(fpath)
        return True
    except FileNotFoundError:
        if missing_ok:
            return False
        raise
    except (IsADirectoryError, PermissionError):
        if os.path.isdir(fpath):
            raise IsADirectoryError(f"{fpath} 是資料夾，請改用 delete_folder")
        raise
def add_folder(fpath="./folder1"):
    # 建立資料夾（含多層），若已存在則不報錯
    if fpath:
        os.makedirs(fpath, exist_ok=True)
def _resolve_dst(src, dst):
    # 判斷 dst 是否為「資料夾意圖」，若是則建立資料夾並回傳 dst/原檔名
    # 判定為資料夾：結尾是路徑分隔符、已是現有資料夾、或整段路徑沒有副檔名
    dst = _fspath(dst)
    is_dir_intent = (
        dst.endswith(("/", "\\"))
        or os.path.isdir(dst)
        or not os.path.splitext(dst)[1]
    )
    if is_dir_intent:
        os.makedirs(dst, exist_ok=True)
        return os.path.join(dst, os.path.basename(_fspath(src)))
    return dst
def copy_file(src="./data.csv", dst=""):
    # 複製檔案（dst 為資料夾時會複製到該資料夾內，資料夾不存在會建立；dst 為空時不動作）
    if dst:
        dst = _resolve_dst(src, dst)
        _check_exist_folder(dst)
        shutil.copy2(src, dst)
def move_file(src="./data.csv", dst=""):
    # 移動檔案（dst 為資料夾時會移入該資料夾內，資料夾不存在會建立；dst 為空時不動作）
    if dst:
        dst = _resolve_dst(src, dst)
        _check_exist_folder(dst)
        shutil.move(src, dst)
def get_files(fpath="./folder1", types=["csv", "png", "txt"], accept=None, reject=None):
    # 取得資料夾內符合條件的檔案清單，回傳 [(index, path, name, sub_name), ...]
    # name 為主檔名（不含副檔名），sub_name 為副檔名（不含點）
    # types=None 或 [] 表示不限制副檔名；accept/reject 為檔名子字串篩選
    fpath = _fspath(fpath)
    file_info = []
    if not os.path.isdir(fpath):
        return file_info
    types_lower = [t.lower().lstrip(".") for t in types] if types else []
    for fn in sorted(os.listdir(fpath)):
        full = os.path.join(fpath, fn)
        if not os.path.isfile(full):
            continue
        if accept and accept not in fn:
            continue
        if reject and reject in fn:
            continue
        stem, ext = os.path.splitext(fn)
        sub_name = ext.lstrip(".")
        if types_lower and sub_name.lower() not in types_lower:
            continue
        file_info.append((len(file_info), full, stem, sub_name))
    return file_info
def copy_files(src, dst, types=["csv"], accept=None, reject=None):
    # 批次複製 src 資料夾內符合條件的檔案到 dst 資料夾（dst 不存在會建立）
    # 回傳複製成功的檔案清單 [(index, path, name, sub_name), ...]
    dst = _fspath(dst)
    os.makedirs(dst, exist_ok=True)
    files = get_files(src, types=types, accept=accept, reject=reject)
    copied = []
    for idx, path, name, sub_name in files:
        copy_file(path, os.path.join(dst, os.path.basename(path)))
        copied.append((len(copied), path, name, sub_name))
    return copied
def move_files(src, dst, types=["csv"], accept=None, reject=None):
    # 批次移動 src 資料夾內符合條件的檔案到 dst 資料夾（dst 不存在會建立）
    # 回傳移動成功的檔案清單 [(index, path, name, sub_name), ...]
    dst = _fspath(dst)
    os.makedirs(dst, exist_ok=True)
    files = get_files(src, types=types, accept=accept, reject=reject)
    moved = []
    for idx, path, name, sub_name in files:
        move_file(path, os.path.join(dst, os.path.basename(path)))
        moved.append((len(moved), path, name, sub_name))
    return moved
def get_timestamp():
    # 回傳當前時間字串（格式：YYYYMMDD-HHMMSS）
    return time.strftime('%Y%m%d-%H%M%S', time.localtime())
def replace_words(words, old, new):
    """
    words: 原始文字
    old: 要搜尋的舊文字
    new: 要替換的新文字
    return: 替換後的文字
    """
    if not isinstance(words, str):
        raise TypeError("words 必須是字串")
    if not old:
        return words
    return words.replace(old, new)
def load_md(fpath="./try.md", encoding="utf-8"):
    # 讀取 md（或任何純文字）檔，回傳字串
    # 自動補 .md；fpath 為資料夾時，讀取其中的 try.md
    fpath = _fspath(fpath)
    if fpath.endswith(("/", "\\")) or os.path.isdir(fpath):
        fpath = os.path.join(fpath, "try.md")
    fpath = _resolve_ext(fpath, ".md")
    with open(fpath, "r", encoding=encoding) as f:
        return f.read()
def save_md(fpath="./try.md", words=None, encoding="utf-8"):
    # 寫入 md（或任何純文字）檔
    # 自動補 .md；參數順序顛倒會互換；父資料夾不存在會建立
    # fpath 為資料夾時，寫入其中的 try.md
    if not isinstance(fpath, (str, bytes, os.PathLike)):
        fpath, words = words, fpath
    if words is None:
        words = ""
    fpath = _fspath(fpath)
    if fpath.endswith(("/", "\\")) or os.path.isdir(fpath):
        os.makedirs(fpath, exist_ok=True)
        fpath = os.path.join(fpath, "try.md")
    fpath = _ensure_ext(fpath, ".md")
    _check_exist_folder(fpath)
    with open(fpath, "w", encoding=encoding) as f:
        f.write(words)
    return fpath
def load_py(fpath="./try.py", encoding="utf-8"):
    # 讀取 py（或任何純文字）檔，回傳字串
    # 自動補 .py；fpath 為資料夾時，讀取其中的 try.py
    fpath = _fspath(fpath)
    if fpath.endswith(("/", "\\")) or os.path.isdir(fpath):
        fpath = os.path.join(fpath, "try.py")
    fpath = _resolve_ext(fpath, ".py")
    with open(fpath, "r", encoding=encoding) as f:
        return f.read()
def save_py(fpath="./try.py", words=None, encoding="utf-8"):
    # 寫入 py（或任何純文字）檔
    # 自動補 .py；參數順序顛倒會互換；父資料夾不存在會建立
    # fpath 為資料夾時，寫入其中的 try.py
    if not isinstance(fpath, (str, bytes, os.PathLike)):
        fpath, words = words, fpath
    if words is None:
        words = ""
    fpath = _fspath(fpath)
    if fpath.endswith(("/", "\\")) or os.path.isdir(fpath):
        os.makedirs(fpath, exist_ok=True)
        fpath = os.path.join(fpath, "try.py")
    fpath = _ensure_ext(fpath, ".py")
    _check_exist_folder(fpath)
    with open(fpath, "w", encoding=encoding) as f:
        f.write(words)
    return fpath
def load_ym(fpath="./try.yaml", encoding="utf-8"):
    # 讀取 yaml（或任何純文字）檔，回傳解析後的資料（dict / list / 純量）
    # 自動補 .yaml；fpath 為資料夾時，讀取其中的 try.yaml
    fpath = _fspath(fpath)
    if fpath.endswith(("/", "\\")) or os.path.isdir(fpath):
        fpath = os.path.join(fpath, "try.yaml")
    fpath = _resolve_ext(fpath, ".yaml")
    with open(fpath, "r", encoding=encoding) as f:
        return yaml.safe_load(f)
def save_ym(fpath="./try.yaml", data=None, encoding="utf-8"):
    # 寫入 yaml（或任何純文字）檔
    # 自動補 .yaml；參數順序顛倒會互換；父資料夾不存在會建立
    # fpath 為資料夾時，寫入其中的 try.yaml
    if not isinstance(fpath, (str, bytes, os.PathLike)):
        fpath, data = data, fpath
    if data is None:
        data = {}
    fpath = _fspath(fpath)
    if fpath.endswith(("/", "\\")) or os.path.isdir(fpath):
        os.makedirs(fpath, exist_ok=True)
        fpath = os.path.join(fpath, "try.yaml")
    fpath = _ensure_ext(fpath, ".yaml")
    _check_exist_folder(fpath)
    with open(fpath, "w", encoding=encoding) as f:
        yaml.safe_dump(data, f, allow_unicode=True, sort_keys=False, default_flow_style=False, indent=2)
    return fpath


def run_py_self_relative(py_path, args=None, timeout=30, encoding="utf-8"):
    """
    執行指定的 .py 檔案，強制子程序的 cwd = 「該 py 所在目錄」。

    效果：
      - 該 py 內若用 "./xxx" 相對路徑，會自動指向「它自己隔壁」的檔案
      - 呼叫端 cwd 是什麼都不影響子程序
      - 這是「保險」，不是「解法」：
        真正的解法是目標 py 內部自己用 __file__ 定位（見下方 self_dir）

    參數：
      py_path : .py 檔案路徑（相對或絕對皆可）
      args    : 傳給 py 的命令列參數 list（可選）
      timeout : 秒
      encoding: 子程序輸出的解碼

    回傳：
      (returncode, stdout, stderr)
      - returncode == 0  表示成功
      - returncode == -1 表示超時或呼叫失敗

    範例：
      rc, out, err = run_py_self_relative("./workspace/work.py")
      if rc == 0:
          print(out)
    """
    py_path = os.path.abspath(py_path)
    if not os.path.isfile(py_path):
        return -1, "", f"找不到檔案: {py_path}"

    py_dir = os.path.dirname(py_path)
    cmd = [sys.executable, "-u", py_path] + list(args or [])

    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONUTF8"] = "1"

    try:
        cp = subprocess.run(
            cmd,
            cwd=py_dir,                 # ★ 關鍵：cwd = 該 py 所在目錄
            env=env,
            capture_output=True,
            text=True,
            encoding=encoding,
            errors="replace",
            timeout=timeout,
        )
        return cp.returncode, cp.stdout or "", cp.stderr or ""

    except subprocess.TimeoutExpired as e:
        def _s(x):
            if x is None:
                return ""
            return x if isinstance(x, str) else x.decode(encoding, "replace")
        return -1, _s(e.stdout), _s(e.stderr) + f"\n[TimeoutExpired {timeout}s]"

    except Exception as e:
        return -1, "", f"[{type(e).__name__}] {e}"

