import os
import time
import numpy as np
from scipy.special import expit
from scipy.ndimage import shift as ndshift, map_coordinates
import matplotlib
matplotlib.rcParams["font.family"] = "sans-serif"
matplotlib.rcParams["font.sans-serif"] = ["Microsoft JhengHei", "PingFang TC", "Noto Sans CJK TC", "DejaVu Sans"]
matplotlib.rcParams["axes.unicode_minus"] = False
from toolbox.image_helper import *
from toolbox.files_helper import *
from toolbox.poly_fitting_helper import Poly_Fitting

class Global_LK:
    """全域次像素平移：I1(x + dx, y + dy) ≈ I0(x)

        margin：避開邊界的像素寬度
        interp_order：1 = 雙線性, 3 = 雙三次
    """

    def __init__(self, margin=4, interp_order=3):
        self.margin = margin
        self.interp_order = interp_order

    def predict(self, img0, img1, max_iter=3, tol=1e-4, init_dx=0.0, init_dy=0.0):
        img0 = np.asarray(img0, dtype=np.float64)
        img1 = np.asarray(img1, dtype=np.float64)
        H_img, W_img = img0.shape
        m = self.margin

        Iy_full, Ix_full = np.gradient(img0)
        I0_roi = img0[m:H_img - m, m:W_img - m]
        Ix = Ix_full[m:H_img - m, m:W_img - m]
        Iy = Iy_full[m:H_img - m, m:W_img - m]

        H = np.array([[np.sum(Ix * Ix), np.sum(Ix * Iy)],
                      [np.sum(Ix * Iy), np.sum(Iy * Iy)]], dtype=np.float64)
        if np.linalg.det(H) < 1e-12:
            return float(init_dx), float(init_dy)

        H_inv = np.linalg.inv(H)
        Wx = H_inv[0, 0] * Ix + H_inv[0, 1] * Iy
        Wy = H_inv[1, 0] * Ix + H_inv[1, 1] * Iy
        grid_y, grid_x = np.mgrid[m:H_img - m, m:W_img - m].astype(np.float64)

        dx, dy = float(init_dx), float(init_dy)
        for _ in range(max_iter):
            I1_warped = map_coordinates(img1, [grid_y + dy, grid_x + dx],
                                        order=self.interp_order, mode="nearest")
            err = I0_roi - I1_warped

            delta_dx = np.sum(Wx * err)
            delta_dy = np.sum(Wy * err)

            dx += delta_dx
            dy += delta_dy
            if np.hypot(delta_dx, delta_dy) < tol:
                break

        return dx, dy


if __name__ == "__main__":
    CHART_DIRS = ["charts/chart12_spike_gauss/400x400",
                  "charts/chart7_flower/400x400"]
    lk = Global_LK(margin=4, interp_order=3)
    lk.predict(np.zeros((64, 64)), np.zeros((64, 64)))

    for chart_dir in CHART_DIRS:
        print(f"\n{chart_dir}")
        errors = []
        costs = []
        for _, fpath, name, _ in get_files(chart_dir, types=["pkl"]):
            data = load_pkl(fpath)
            true_dx, true_dy = data["dxy"]

            t0 = time.perf_counter()
            dx, dy = lk.predict(data["img0"], data["img1"])
            cost_ms = (time.perf_counter() - t0) * 1000.0

            errors.append((dx - true_dx, dy - true_dy))
            costs.append(cost_ms)
            print(f"  {name}  true=({true_dx:+.4f},{true_dy:+.4f})  "
                  f"pred=({dx:+.6f},{dy:+.6f})  "
                  f"err=({dx - true_dx:+.6f},{dy - true_dy:+.6f})  "
                  f"cost={cost_ms:8.3f} ms")

        err = np.abs(np.array(errors))
        print(f"  mean|err| = ({err[:, 0].mean():.6f}, {err[:, 1].mean():.6f})  "
              f"max|err| = ({err[:, 0].max():.6f}, {err[:, 1].max():.6f})")
        print(f"  cost  n={len(costs)}  mean={np.mean(costs):.3f} ms  "
              f"min={np.min(costs):.3f} ms  max={np.max(costs):.3f} ms  "
              f"total={np.sum(costs):.3f} ms")
