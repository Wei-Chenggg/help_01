import os
import numpy as np
from dataclasses import dataclass, replace
from scipy.ndimage import gaussian_filter
from scipy.special import expit
import matplotlib
matplotlib.rcParams["font.family"] = "sans-serif"
matplotlib.rcParams["font.sans-serif"] = ["Microsoft JhengHei", "PingFang TC", "Noto Sans CJK TC", "DejaVu Sans"]
matplotlib.rcParams["axes.unicode_minus"] = False
from toolbox.image_helper import *
from toolbox.files_helper import *


def clear_folder(folder):
    if not os.path.isdir(folder):
        return
    for fn in os.listdir(folder):
        full = os.path.join(folder, fn)
        if os.path.isfile(full):
            os.remove(full)
    print(f"cleared: {folder}")


@dataclass
class Config:
    width: int = 400
    height: int = 400
    dx: float = 0.0
    dy: float = 0.0
    angle_deg0: float = 0.0
    angle_deg1: float = 0.0
    edge_tau: float = 3
    blur_size: int = 7
    blur_sigma: float = 2.0

class Chart_Renderer:
    def __init__(self, equ=None, equ_kwargs=None, edge_mode="sigmoid"):
        self.equ = equ
        self.equ_kwargs = equ_kwargs or {}
        self.edge_mode = edge_mode
    def set_equ(self, func, **kwargs):
        self.equ = func
        self.equ_kwargs = kwargs
        return self
    def render(self, cfg: Config, target=False) -> np.ndarray:
        if self.equ is None:
            raise ValueError("equ not set")
        W, H = cfg.width, cfg.height
        x = np.arange(W, dtype=np.float64) - (W - 1) / 2.0
        y = np.arange(H, dtype=np.float64) - (H - 1) / 2.0
        xx, yy = np.meshgrid(x, y)
        ox = cfg.dx if target else 0.0
        oy = cfg.dy if target else 0.0
        angle_deg = cfg.angle_deg1 if target else cfg.angle_deg0
        theta = np.deg2rad(angle_deg)
        c, s  = np.cos(theta), np.sin(theta)
        gx = xx - ox
        gy = yy - oy
        lx =  c * gx + s * gy
        ly = -s * gx + c * gy
        sdf = self.equ(lx, ly, **self.equ_kwargs)
        canvas = self._to_gray(sdf, cfg.edge_tau)
        canvas = np.clip(np.rint(canvas), 0, 255).astype(np.uint8).astype(np.float64)
        if cfg.blur_sigma > 0:
            canvas = gaussian_filter(
                canvas, sigma=cfg.blur_sigma,
                truncate=cfg.blur_size / 2.0 / cfg.blur_sigma,
            )
        return canvas
    def _to_gray(self, sdf, tau):
        mode = self.edge_mode
        if mode == "hard" or tau <= 0:
            return np.where(sdf <= 0, 255.0, 0.0)
        if mode == "linear":
            return 255.0 * np.clip(-sdf / tau + 0.5, 0.0, 1.0)
        if mode == "sigmoid":
            return 255.0 * expit(-sdf / tau)
        raise ValueError(f"unknown edge_mode: {mode}")

def equ_circle(xx, yy, r):
    return np.sqrt(xx**2 + yy**2) - r
def equ_rect(xx, yy, w, h):
    dx = np.abs(xx) - w / 2.0
    dy = np.abs(yy) - h / 2.0
    outside = np.sqrt(np.maximum(dx, 0.0)**2 + np.maximum(dy, 0.0)**2)
    inside  = np.minimum(np.maximum(dx, dy), 0.0)
    return outside + inside
def equ_ring(xx, yy, r_outer, r_inner):
    d = np.sqrt(xx**2 + yy**2)
    return np.maximum(d - r_outer, r_inner - d)
def equ_ellipse(xx, yy, a, b):
    k0 = np.sqrt((xx/a)**2 + (yy/b)**2)
    k1 = np.sqrt((xx/a**2)**2 + (yy/b**2)**2) + 1e-12
    return k0 * (k0 - 1.0) / k1
def equ_flower(xx, yy, r0=140.0, k=5, amp=18.0, phase=0.0):
    theta = np.arctan2(yy, xx)
    r_theta = np.maximum(r0 + amp * np.cos(k * theta + phase), 1.0)
    return np.sqrt(xx**2 + yy**2) - r_theta
def equ_wavy(xx, yy, r0=140.0, harmonics=((6, 15.0), (3, 8.0))):
    theta = np.arctan2(yy, xx)
    r_theta = np.full_like(theta, r0, dtype=np.float64)
    for n, a in harmonics:
        r_theta += a * np.cos(n * theta)
    r_theta = np.maximum(r_theta, 1.0)
    return np.sqrt(xx**2 + yy**2) - r_theta
def equ_sin_cos_series(xx, yy, r0=140.0,
                       coeffs=((3, 12.0, 0.0),
                               (5, 8.0, np.pi / 4),
                               (7, 5.0, np.pi / 2))):
    theta = np.arctan2(yy, xx)
    r_theta = np.full_like(theta, r0, dtype=np.float64)
    for n, a, b in coeffs:
        r_theta += a * np.cos(n * theta) + b * np.sin(n * theta)
    r_theta = np.maximum(r_theta, 1.0)
    return np.sqrt(xx**2 + yy**2) - r_theta
def _ang_diff(theta, direction_deg):
    d0 = theta - np.deg2rad(direction_deg)
    return np.arctan2(np.sin(d0), np.cos(d0))
def equ_spike_gauss(xx, yy, r0=140.0, amp=45.0,
                    width_deg=10.0, direction_deg=90.0):
    theta = np.arctan2(yy, xx)
    d = _ang_diff(theta, direction_deg)
    r_theta = r0 + amp * np.exp(-(d / np.deg2rad(width_deg)) ** 2)
    return np.sqrt(xx**2 + yy**2) - np.maximum(r_theta, 1.0)
def equ_spike_sharp(xx, yy, r0=140.0, amp=45.0,
                    width_deg=8.0, direction_deg=90.0, power=1.0):
    theta = np.arctan2(yy, xx)
    d = _ang_diff(theta, direction_deg)
    t = np.clip(1.0 - np.abs(d) / np.deg2rad(width_deg), 0.0, 1.0) ** power
    r_theta = r0 + amp * t
    return np.sqrt(xx**2 + yy**2) - np.maximum(r_theta, 1.0)
def equ_gradient_curves(xx, yy, slope=0.05, amp=50.0, freq=0.04, thickness=6.0):
    bg_sdf = -xx * slope
    c1 = np.abs(yy - amp * np.sin(freq * xx)) - thickness
    c2 = np.abs(yy - amp * np.cos(freq * xx * 0.8) + 30.0) - thickness * 0.8
    c3 = np.abs(yy + 0.0) - thickness * 0.6
    return np.minimum(bg_sdf, np.minimum(c1, np.minimum(c2, c3)))


renderer = Chart_Renderer(edge_mode="sigmoid")
CHARTS = {
    0: dict(equ=equ_circle, kwargs=dict(r=160.0),
            cfg=Config(400, 400)),
    1: dict(equ=equ_rect,   kwargs=dict(w=240.0, h=200.0),
            cfg=Config(400, 400)),
    2: dict(equ=equ_ring,   kwargs=dict(r_outer=160.0, r_inner=100.0),
            cfg=Config(400, 400)),
    3: dict(equ=equ_flower,
            kwargs=dict(r0=140.0, k=2, amp=6.0),
            cfg=Config(400, 400, angle_deg0=0.0, angle_deg1=1.0)),
    4: dict(equ=equ_wavy,
            kwargs=dict(r0=140.0, harmonics=((6, 15.0), (3, 8.0))),
            cfg=Config(400, 400, angle_deg0=0.0, angle_deg1=1.0)),
    5: dict(equ=equ_sin_cos_series,
            kwargs=dict(r0=140.0,
                        coeffs=((3, 12.0, 0.0),
                                (5, 8.0,  np.pi / 4),
                                (7, 5.0,  np.pi / 2))),
            cfg=Config(400, 400)),
    6: dict(equ=equ_rect,  kwargs=dict(w=240.0, h=120.0),
            cfg=Config(400, 400, dx=0.0, dy=0.0,
                       angle_deg0=0.0, angle_deg1=30.0)),
    7: dict(equ=equ_flower, kwargs=dict(r0=140.0, k=5, amp=18.0),
            cfg=Config(400, 400, angle_deg0=15.0, angle_deg1=17.0)),
    8: dict(equ=equ_rect,  kwargs=dict(w=240.0, h=120.0),
            cfg=Config(400, 400, angle_deg0=30.0, angle_deg1=0.0)),
    9:  dict(equ=equ_circle, kwargs=dict(r=160.0),
             cfg=Config(400, 400, edge_tau=0.3)),
    10: dict(equ=equ_circle, kwargs=dict(r=160.0),
             cfg=Config(400, 400, edge_tau=1.0)),
    11: dict(equ=equ_circle, kwargs=dict(r=160.0),
             cfg=Config(400, 400, edge_tau=2.0)),
    12: dict(equ=equ_spike_gauss,
             kwargs=dict(r0=140.0, amp=7.0,
                         width_deg=2.0, direction_deg=90.0),
             cfg=Config(400, 400, angle_deg0=0.0, angle_deg1=5.0)),
    13: dict(equ=equ_spike_sharp,
             kwargs=dict(r0=140.0, amp=45.0,
                         width_deg=8.0, direction_deg=90.0, power=1.0),
             cfg=Config(400, 400)),
    14: dict(equ=equ_spike_sharp,
             kwargs=dict(r0=140.0, amp=60.0,
                         width_deg=5.0, direction_deg=0.0, power=1.5),
             cfg=Config(400, 400,
                        angle_deg0=0.0, angle_deg1=10.0)),
    15: dict(equ=equ_gradient_curves,
             kwargs=dict(slope=0.05, amp=50.0, freq=0.04, thickness=6.0),
             cfg=Config(400, 400)),
}

if __name__ == "__main__":
    _dx_all = np.array([
        0.00123456,
        0.01234567,
        0.12345678,
        1.23456789,
    ])
    DXY = [(float(dx), float(-dx * 0)) for dx in _dx_all]
    for chart_id, spec in CHARTS.items():
        renderer.set_equ(spec["equ"], **spec["kwargs"])
        shape_name = spec.get("name") or spec["equ"].__name__.replace("equ_", "", 1)
        out_dir = (
            f"./charts/chart{chart_id}_{shape_name}"
            f"/{spec['cfg'].width}x{spec['cfg'].height}"
        )
        os.makedirs(out_dir, exist_ok=True)
        clear_folder(out_dir)
        img0 = renderer.render(spec["cfg"], target=False)
        imgs1 = []
        dxys = []
        for i, (dx, dy) in enumerate(DXY):
            img1 = renderer.render(
                replace(spec["cfg"], dx=dx, dy=dy), target=True
            )
            imgs1.append(img1)
            dxys.append((dx, dy))
            Imgtool(img1.astype(np.uint8)).save(
                f"{out_dir}/sample_{i:04d}_img1.png"
            )
        save_pkl(
            f"{out_dir}/dataset.pkl",
            {
                "img0": img0,
                "img1_list": np.stack(imgs1, axis=0),
                "dxy_list": np.array(dxys, dtype=np.float64),
                "angle_deg0": spec["cfg"].angle_deg0,
                "angle_deg1": spec["cfg"].angle_deg1,
                "edge_tau": spec["cfg"].edge_tau,
                "shape_name": shape_name,
            },
        )
        Imgtool(img0.astype(np.uint8)).save(f"{out_dir}/img0.png")
        print(
            f"[chart{chart_id}:{shape_name}] {len(DXY)} samples → {out_dir}/dataset.pkl\n"
            f"    img0:  {img0.shape}\n"
            f"    img1_list: {len(imgs1)} × {img0.shape}  "
            f"dxy: {[f'({dx:+.4f},{dy:+.4f})' for dx, dy in dxys]}\n"
            f"    θ0={spec['cfg'].angle_deg0:.1f}°  "
            f"θ1={spec['cfg'].angle_deg1:.1f}°  "
            f"τ={spec['cfg'].edge_tau:.2f}"
        )