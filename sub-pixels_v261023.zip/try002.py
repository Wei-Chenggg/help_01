import os
import time
import warnings
import matplotlib
import numpy as np
from scipy.ndimage import map_coordinates, shift as ndshift
from scipy.special import expit
matplotlib.rcParams["font.family"] = "sans-serif"
matplotlib.rcParams["font.sans-serif"] = [
    "Microsoft JhengHei",
    "PingFang TC",
    "Noto Sans CJK TC",
    "DejaVu Sans",
]
matplotlib.rcParams["axes.unicode_minus"] = False
from toolbox.image_helper import *
from toolbox.files_helper import *
from toolbox.poly_fitting_helper import Poly_Fitting
class Global_LK:
    def __init__(
        self,
        margin=4,
        interp_order=3,
        energy_ratio=0.99,
        eta=1e-6,
        max_iter=5,
        tol=1e-4,
    ):
        self.margin = margin
        self.interp_order = interp_order
        self.energy_ratio = float(np.clip(energy_ratio, 0.1, 1.0))
        self.eta = eta
        self.max_iter = max_iter
        self.tol = tol
        self._ref_img = None
        self._cache = None
        self.history = []
        self.exit_reason = None
        self.stopped_early = False
        self.iterations = 0
    def set_orginal_img(self, img0):
        img0 = np.asarray(img0, dtype=np.float64)
        H_img, W_img = img0.shape
        m = self.margin
        cx = (W_img - 1) / 2.0
        cy = (H_img - 1) / 2.0
        Iy_full, Ix_full = np.gradient(img0)
        energy_full = Ix_full * Ix_full + Iy_full * Iy_full
        energy_roi = energy_full[m : H_img - m, m : W_img - m]
        total_energy = float(np.sum(energy_roi))
        valid_mask = np.zeros((H_img, W_img), dtype=bool)
        if total_energy <= self.eta:
            warnings.warn(
                f"[Global_LK] 參考影像總梯度能量過低 (total_energy={total_energy:.2e})，退回使用整個內部 ROI。",
                RuntimeWarning,
            )
            valid_mask[m : H_img - m, m : W_img - m] = True
        else:
            flat_e = energy_roi.ravel()
            sort_idx = np.argsort(flat_e)
            cum_e = np.cumsum(flat_e[sort_idx])
            discard_target = (1.0 - self.energy_ratio) * total_energy
            cutoff_idx = int(np.searchsorted(cum_e, discard_target, side="right"))
            cutoff_idx = min(cutoff_idx, flat_e.size - 1)
            energy_thresh = max(float(flat_e[sort_idx[cutoff_idx]]), 1e-12)
            valid_mask[m : H_img - m, m : W_img - m] = energy_roi >= energy_thresh
        y_idx, x_idx = np.nonzero(valid_mask)
        px = x_idx.astype(np.float64) - cx
        py = y_idx.astype(np.float64) - cy
        I0_pts = img0[valid_mask]
        Ix = Ix_full[valid_mask]
        Iy = Iy_full[valid_mask]
        Itheta = -py * Ix + px * Iy
        H00 = float(np.sum(Ix * Ix))
        H01 = float(np.sum(Ix * Iy))
        H02 = float(np.sum(Ix * Itheta))
        H11 = float(np.sum(Iy * Iy))
        H12 = float(np.sum(Iy * Itheta))
        H22 = float(np.sum(Itheta * Itheta))
        if H00 < self.eta or H11 < self.eta:
            warnings.warn(
                f"[Global_LK] 平移梯度能量過低 (H00={H00:.2e}, H11={H11:.2e})，已套用 max(val, eta) 防護。",
                RuntimeWarning,
            )
            H00 = max(H00, self.eta)
            H11 = max(H11, self.eta)
        rot_ref_scale = (H00 + H11) * (float(np.mean(px * px + py * py)) + 1.0)
        if H22 < max(self.eta, 1e-7 * rot_ref_scale):
            warnings.warn(
                f"[Global_LK] 旋轉切向梯度能量極低 (H22={H22:.2e}，可能為純圓對稱圖形)，已套用防護。",
                RuntimeWarning,
            )
            H22 = max(H22, self.eta, 1e-3 * rot_ref_scale)
            H02 = 0.0
            H12 = 0.0
        H = np.array(
            [[H00, H01, H02], [H01, H11, H12], [H02, H12, H22]],
            dtype=np.float64,
        )
        det_H = float(np.linalg.det(H))
        if abs(det_H) < self.eta:
            warnings.warn(
                f"[Global_LK] Hessian 行列式過小 (det={det_H:.2e})，對角線已套用 eta 防護。",
                RuntimeWarning,
            )
            np.fill_diagonal(H, np.maximum(np.diag(H), self.eta))
        H_inv = np.linalg.inv(H)
        Wx = H_inv[0, 0] * Ix + H_inv[0, 1] * Iy + H_inv[0, 2] * Itheta
        Wy = H_inv[1, 0] * Ix + H_inv[1, 1] * Iy + H_inv[1, 2] * Itheta
        Wtheta = H_inv[2, 0] * Ix + H_inv[2, 1] * Iy + H_inv[2, 2] * Itheta
        self._ref_img = img0
        self._cache = {
            "cx": cx,
            "cy": cy,
            "px": px,
            "py": py,
            "I0_pts": I0_pts,
            "Wx": Wx,
            "Wy": Wy,
            "Wtheta": Wtheta,
            "H": H,
            "H_inv": H_inv,
            "num_pts": int(px.size),
        }
    def predict(self, img1, init_dx=0.0, init_dy=0.0, init_dtheta_deg=0.0):
        if self._cache is None:
            raise ValueError(
                "[Global_LK] 尚未設定參考影像，請先呼叫 set_orginal_img(img0)。"
            )
        img1 = np.asarray(img1, dtype=np.float64)
        c_data = self._cache
        cx, cy = c_data["cx"], c_data["cy"]
        px, py = c_data["px"], c_data["py"]
        I0_pts = c_data["I0_pts"]
        Wx, Wy, Wtheta = c_data["Wx"], c_data["Wy"], c_data["Wtheta"]
        num_pts = c_data["num_pts"]
        self.history = []
        self.exit_reason = None
        self.stopped_early = False
        self.iterations = 0
        dx = float(init_dx)
        dy = float(init_dy)
        dtheta = float(np.deg2rad(init_dtheta_deg))
        for i in range(self.max_iter):
            self.iterations = i + 1
            c, s = np.cos(dtheta), np.sin(dtheta)
            sample_x = (c * px - s * py + dx) + cx
            sample_y = (s * px + c * py + dy) + cy
            I1_warped = map_coordinates(
                img1, [sample_y, sample_x], order=self.interp_order, mode="nearest"
            )
            err = I0_pts - I1_warped
            sse = float(np.dot(err, err))
            rmse = float(np.sqrt(sse / max(num_pts, 1)))
            delta_dx = float(np.dot(Wx, err))
            delta_dy = float(np.dot(Wy, err))
            delta_dtheta = float(np.dot(Wtheta, err))
            dx += delta_dx
            dy += delta_dy
            dtheta += delta_dtheta
            self.history.append({
                "iter": i + 1,
                "delta_dx": delta_dx,
                "delta_dy": delta_dy,
                "delta_dtheta_deg": float(np.rad2deg(delta_dtheta)),
                "dx": dx,
                "dy": dy,
                "dtheta_deg": float(np.rad2deg(dtheta)),
                "sse": sse,
                "rmse": rmse,
            })
            if np.hypot(delta_dx, delta_dy) < self.tol and abs(delta_dtheta) < self.tol:
                self.stopped_early = True
                self.exit_reason = "tolerance"
                break
        else:
            self.exit_reason = "max_iter"
        return dx, dy, float(np.rad2deg(dtheta))
if __name__ == "__main__":
    CHART_DIRS = [
        "charts/chart12_spike_gauss/400x400",
        "charts/chart7_flower/400x400",
    ]
    runs = [
        (
            "iter5 ",
            Global_LK(margin=4, interp_order=3, energy_ratio=0.99, max_iter=5, tol=1e-4),
            {},
        ),
        (
            "iter20",
            Global_LK(margin=4, interp_order=3, energy_ratio=0.99, max_iter=20, tol=1e-4),
            {},
        ),
    ]
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        for _, lk, _ in runs:
            lk.set_orginal_img(np.zeros((64, 64)))
            lk.predict(np.zeros((64, 64)))
    for chart_dir in CHART_DIRS:
        print(f"\n{chart_dir}")
        stat = {tag: {"err": [], "cost": [], "dth": []} for tag, _, _ in runs}
        for _, fpath, name, _ in get_files(chart_dir, types=["pkl"]):
            data = load_pkl(fpath)
            img0      = data["img0"]
            img1_list = data["img1_list"]
            dxy_list  = data["dxy_list"]
            true_dth  = data["angle_deg1"] - data["angle_deg0"]
            n_samples = len(img1_list)
            print(f"  {name}  N={n_samples}  θtrue={true_dth:+.1f}°")
            for tag, lk, kw in runs:
                lk.set_orginal_img(img0)
                for i, (img1, true_dxy) in enumerate(zip(img1_list, dxy_list)):
                    true_dx, true_dy = true_dxy
                    t0 = time.perf_counter()
                    out = lk.predict(img1, **kw)
                    cost = (time.perf_counter() - t0) * 1000.0
                    dx, dy, dth = out
                    stat[tag]["err"].append((dx - true_dx, dy - true_dy))
                    stat[tag]["cost"].append(cost)
                    stat[tag]["dth"].append(dth - true_dth)
                    print(
                        f"    {tag}  [{i + 1}/{n_samples}]  "
                        f"true=({true_dx:+.4f},{true_dy:+.4f})  "
                        f"pred=({dx:+.6f},{dy:+.6f})  θ={dth:+9.4f}°  "
                        f"err=({dx - true_dx:+.6f},{dy - true_dy:+.6f})  "
                        f"cost={cost:8.3f} ms  "
                        f"[iters={lk.iterations}, exit={lk.exit_reason}, early={lk.stopped_early}]"
                    )
        for tag, _, _ in runs:
            err = np.abs(np.array(stat[tag]["err"]))
            dth = np.abs(np.array(stat[tag]["dth"]))
            cost = np.array(stat[tag]["cost"])
            th_txt = f"{np.nanmean(dth):8.4f}°" if not np.all(np.isnan(dth)) else "       -"
            print(
                f"  {tag}  mean|err|=({err[:, 0].mean():.6f},{err[:, 1].mean():.6f})  "
                f"max|err|=({err[:, 0].max():.6f},{err[:, 1].max():.6f})  "
                f"mean|θerr|={th_txt}  "
                f"cost mean={cost.mean():7.3f} ms  total={cost.sum():8.3f} ms"
            )