import os
import time
import warnings
import matplotlib
import numpy as np
from scipy.ndimage import map_coordinates, shift as ndshift, spline_filter
from scipy.special import expit
matplotlib.rcParams["font.family"] = "sans-serif"
matplotlib.rcParams["font.sans-serif"] = [
    "Microsoft JhengHei",
    "PingFang TC",
    "Noto Sans CJK TC",
    "DejaVu Sans",
]
matplotlib.rcParams["axes.unicode_minus"] = False
from toolbox.image_helper import *
from toolbox.files_helper import *
from toolbox.poly_fitting_helper import Poly_Fitting


import os
import time
import warnings
import matplotlib
import numpy as np
from scipy.ndimage import map_coordinates, shift as ndshift, spline_filter, gaussian_filter
from scipy.special import expit
matplotlib.rcParams["font.family"] = "sans-serif"
matplotlib.rcParams["font.sans-serif"] = [
    "Microsoft JhengHei",
    "PingFang TC",
    "Noto Sans CJK TC",
    "DejaVu Sans",
]
matplotlib.rcParams["axes.unicode_minus"] = False
from toolbox.image_helper import *
from toolbox.files_helper import *
from toolbox.poly_fitting_helper import Poly_Fitting


class Global_LK:
    def __init__(
        self,
        margin=4,
        interp_order=3,
        energy_ratio=0.99,
        p=0.0,
        eta=1e-6,
        max_iter=5,
        tol=1e-4,
        blur_level=0.0,
    ):
        self.margin = margin
        self.interp_order = interp_order
        self.energy_ratio = float(np.clip(energy_ratio, 0.1, 1.0))
        self.p = float(np.clip(p, 0.0, 0.95))
        self.eta = eta
        self.max_iter = max_iter
        self.tol = tol
        self.blur_level = float(max(blur_level, 0.0))  # 0 = 不模糊
        self._ref_img = None
        self._cache = None
        self.history = []
        self.exit_reason = None
        self.stopped_early = False
        self.iterations = 0

    def _maybe_blur(self, img):
        """若 blur_level > 0，對影像套用高斯模糊；否則原樣返回。"""
        if self.blur_level > 0.0:
            return gaussian_filter(img, sigma=self.blur_level, mode="nearest")
        return img

    def set_orginal_img(self, img0):
        img0 = np.asarray(img0, dtype=np.float64)
        img0 = self._maybe_blur(img0)  # 先平滑再計算梯度/能量
        H_img, W_img = img0.shape
        m = self.margin
        cx = (W_img - 1) / 2.0
        cy = (H_img - 1) / 2.0
        Iy_full, Ix_full = np.gradient(img0)
        energy_full = Ix_full * Ix_full + Iy_full * Iy_full
        energy_roi = energy_full[m : H_img - m, m : W_img - m]
        total_energy = float(np.sum(energy_roi))
        valid_mask = np.zeros((H_img, W_img), dtype=bool)
        if total_energy <= self.eta:
            warnings.warn(
                f"[Global_LK] 參考影像總梯度能量過低 (total_energy={total_energy:.2e})，退回使用整個內部 ROI。",
                RuntimeWarning,
            )
            valid_mask[m : H_img - m, m : W_img - m] = True
        else:
            flat_e = energy_roi.ravel()
            sort_idx = np.argsort(flat_e)
            cum_e = np.cumsum(flat_e[sort_idx])
            discard_target = (1.0 - self.energy_ratio) * total_energy
            cutoff_idx = int(np.searchsorted(cum_e, discard_target, side="right"))
            cutoff_idx = min(cutoff_idx, flat_e.size - 1)
            energy_thresh = max(float(flat_e[sort_idx[cutoff_idx]]), 1e-12)
            valid_mask[m : H_img - m, m : W_img - m] = energy_roi >= energy_thresh
        y_idx, x_idx = np.nonzero(valid_mask)
        px = x_idx.astype(np.float64) - cx
        py = y_idx.astype(np.float64) - cy
        I0_pts = img0[valid_mask]
        Ix = Ix_full[valid_mask]
        Iy = Iy_full[valid_mask]
        Itheta = -py * Ix + px * Iy
        H00 = float(np.sum(Ix * Ix))
        H01 = float(np.sum(Ix * Iy))
        H02 = float(np.sum(Ix * Itheta))
        H11 = float(np.sum(Iy * Iy))
        H12 = float(np.sum(Iy * Itheta))
        H22 = float(np.sum(Itheta * Itheta))
        if H00 < self.eta or H11 < self.eta:
            warnings.warn(
                f"[Global_LK] 平移梯度能量過低 (H00={H00:.2e}, H11={H11:.2e})，已套用 max(val, eta) 防護。",
                RuntimeWarning,
            )
            H00 = max(H00, self.eta)
            H11 = max(H11, self.eta)
        rot_ref_scale = (H00 + H11) * (float(np.mean(px * px + py * py)) + 1.0)
        if H22 < max(self.eta, 1e-7 * rot_ref_scale):
            warnings.warn(
                f"[Global_LK] 旋轉切向梯度能量極低 (H22={H22:.2e}，可能為純圓對稱圖形)，已套用防護。",
                RuntimeWarning,
            )
            H22 = max(H22, self.eta, 1e-3 * rot_ref_scale)
            H02 = 0.0
            H12 = 0.0
        H = np.array(
            [[H00, H01, H02], [H01, H11, H12], [H02, H12, H22]],
            dtype=np.float64,
        )
        det_H = float(np.linalg.det(H))
        if abs(det_H) < self.eta:
            warnings.warn(
                f"[Global_LK] Hessian 行列式過小 (det={det_H:.2e})，對角線已套用 eta 防護。",
                RuntimeWarning,
            )
            np.fill_diagonal(H, np.maximum(np.diag(H), self.eta))
        H_inv = np.linalg.inv(H)
        Wx = H_inv[0, 0] * Ix + H_inv[0, 1] * Iy + H_inv[0, 2] * Itheta
        Wy = H_inv[1, 0] * Ix + H_inv[1, 1] * Iy + H_inv[1, 2] * Itheta
        Wtheta = H_inv[2, 0] * Ix + H_inv[2, 1] * Iy + H_inv[2, 2] * Itheta
        self._ref_img = img0
        self._cache = {
            "cx": cx,
            "cy": cy,
            "px": px,
            "py": py,
            "I0_pts": I0_pts,
            "Ix": Ix,
            "Iy": Iy,
            "Itheta": Itheta,
            "Wx": Wx,
            "Wy": Wy,
            "Wtheta": Wtheta,
            "H": H,
            "H_inv": H_inv,
            "num_pts": int(px.size),
        }

    def predict(self, img1, init_dx=0.0, init_dy=0.0, init_dtheta_deg=0.0):
        if self._cache is None:
            raise ValueError(
                "[Global_LK] 尚未設定參考影像，請先呼叫 set_orginal_img(img0)。"
            )
        img1 = np.asarray(img1, dtype=np.float64)
        img1 = self._maybe_blur(img1)  # 先平滑再取樣
        c_data = self._cache
        cx, cy = c_data["cx"], c_data["cy"]
        px, py = c_data["px"], c_data["py"]
        I0_pts = c_data["I0_pts"]
        Ix, Iy, Itheta = c_data["Ix"], c_data["Iy"], c_data["Itheta"]
        Wx, Wy, Wtheta = c_data["Wx"], c_data["Wy"], c_data["Wtheta"]
        H = c_data["H"]
        num_pts = c_data["num_pts"]
        k_drop = int(np.round(self.p * num_pts)) if self.p > 0.0 else 0
        keep_k = max(num_pts - k_drop, 3)
        self.history = []
        self.exit_reason = None
        self.stopped_early = False
        self.iterations = 0
        dx = float(init_dx)
        dy = float(init_dy)
        dtheta = float(np.deg2rad(init_dtheta_deg))
        for i in range(self.max_iter):
            self.iterations = i + 1
            c, s = np.cos(dtheta), np.sin(dtheta)
            sample_x = (c * px - s * py + dx) + cx
            sample_y = (s * px + c * py + dy) + cy
            I1_warped = map_coordinates(
                img1, [sample_y, sample_x], order=self.interp_order, mode="nearest"
            )
            err = I0_pts - I1_warped
            if k_drop > 0 and num_pts > 3:
                abs_err = np.abs(err)
                thresh = float(np.partition(abs_err, keep_k - 1)[keep_k - 1])
                drop_mask = abs_err > thresh
                err = np.where(drop_mask, 0.0, err)
                jx_d = Ix[drop_mask]
                jy_d = Iy[drop_mask]
                jt_d = Itheta[drop_mask]
                H_drop = np.array(
                    [
                        [np.dot(jx_d, jx_d), np.dot(jx_d, jy_d), np.dot(jx_d, jt_d)],
                        [np.dot(jy_d, jx_d), np.dot(jy_d, jy_d), np.dot(jy_d, jt_d)],
                        [np.dot(jt_d, jx_d), np.dot(jt_d, jy_d), np.dot(jt_d, jt_d)],
                    ],
                    dtype=np.float64,
                )
                H_keep = H - H_drop
                b_vec = np.array(
                    [np.dot(Ix, err), np.dot(Iy, err), np.dot(Itheta, err)],
                    dtype=np.float64,
                )
                if abs(float(np.linalg.det(H_keep))) > self.eta:
                    delta_dx, delta_dy, delta_dtheta = [
                        float(v) for v in np.linalg.solve(H_keep, b_vec)
                    ]
                else:
                    delta_dx = float(np.dot(Wx, err))
                    delta_dy = float(np.dot(Wy, err))
                    delta_dtheta = float(np.dot(Wtheta, err))
                valid_cnt = max(num_pts - int(np.sum(drop_mask)), 1)
            else:
                delta_dx = float(np.dot(Wx, err))
                delta_dy = float(np.dot(Wy, err))
                delta_dtheta = float(np.dot(Wtheta, err))
                valid_cnt = max(num_pts, 1)
            sse = float(np.dot(err, err))
            rmse = float(np.sqrt(sse / valid_cnt))
            dx += delta_dx
            dy += delta_dy
            dtheta += delta_dtheta
            self.history.append({
                "iter": i + 1,
                "delta_dx": delta_dx,
                "delta_dy": delta_dy,
                "delta_dtheta_deg": float(np.rad2deg(delta_dtheta)),
                "dx": dx,
                "dy": dy,
                "dtheta_deg": float(np.rad2deg(dtheta)),
                "sse": sse,
                "rmse": rmse,
            })
            if np.hypot(delta_dx, delta_dy) < self.tol and abs(delta_dtheta) < self.tol:
                self.stopped_early = True
                self.exit_reason = "tolerance"
                break
        else:
            self.exit_reason = "max_iter"
        return dx, dy, float(np.rad2deg(dtheta))




class Canny_CircleFit:
    def __init__(
        self,
        canny_low=50,
        canny_high=150,
        half_win=5.0,
        step=0.5,
        power=2.0,
        interp_order=3,
        eta=1e-6,
        max_iter=10,
        tol=1e-4,
    ):
        self.canny_low = canny_low
        self.canny_high = canny_high
        self.half_win = float(half_win)
        self.step = float(step)
        self.power = float(power)
        self.interp_order = interp_order
        self.eta = eta
        self.max_iter = max_iter
        self.tol = tol
        self._ref_img = None
        self._cache = None
        self.history = []
        self.exit_reason = None
        self.stopped_early = False
        self.iterations = 0
    def _fit_circle_lsq(self, pts):
        z = pts[:, 0] ** 2 + pts[:, 1] ** 2
        pfit = Poly_Fitting(basis="泰勒")
        pfit.learn(
            pts,
            z,
            order=[[0, 0], [1, 0], [0, 1]],
        )
        w = pfit.w
        cx = float(w[1]) / 2.0
        cy = float(w[2]) / 2.0
        inside = float(w[0]) + cx ** 2 + cy ** 2
        r = float(np.sqrt(max(inside, 0.0)))
        return cx, cy, r, pfit
    def _refine_circle(self, img, record_history=False, ref_center=None):
        img = np.asarray(img, dtype=np.float64)
        H_img, W_img = img.shape
        img_uint8 = np.clip(img, 0.0, 255.0).astype(np.uint8)
        edges = Imgtool(img_uint8).canny(
            low=self.canny_low, high=self.canny_high
        )
        ys, xs = np.where(edges > 0)
        num_pts = int(xs.size)
        if num_pts < 3:
            warnings.warn(
                f"[Canny_CircleFit] Canny 邊緣點數過少 (num_pts={num_pts})，退回使用影像中心。",
                RuntimeWarning,
            )
            cx_fallback = (W_img - 1) / 2.0
            cy_fallback = (H_img - 1) / 2.0
            if record_history:
                self.history = []
                self.iterations = 0
                self.stopped_early = True
                self.exit_reason = "insufficient_pts"
            return {
                "cx": cx_fallback,
                "cy": cy_fallback,
                "r": 0.0,
                "pts_init": np.empty((0, 2), dtype=np.float64),
                "pts": np.empty((0, 2), dtype=np.float64),
                "edges": edges,
                "pfit": None,
                "num_pts": num_pts,
            }
        pts_init = np.column_stack([xs, ys]).astype(np.float64)
        px = pts_init[:, 0].copy()
        py = pts_init[:, 1].copy()
        cx, cy, r, pfit = self._fit_circle_lsq(pts_init)
        if self.interp_order > 1:
            img_work = spline_filter(img, order=self.interp_order, mode="nearest")
            use_prefilter = False
        else:
            img_work = img
            use_prefilter = True
        n_steps = max(1, int(np.round(self.half_win / self.step)))
        offsets_ext = np.arange(-(n_steps + 1), n_steps + 2, dtype=np.float64) * self.step
        offsets = offsets_ext[1:-1]
        K_ext = offsets_ext.size
        inv_2step = 1.0 / (2.0 * self.step)
        if record_history:
            self.history = []
            self.exit_reason = None
            self.stopped_early = False
            self.iterations = 0
        cx0_ref = ref_center[0] if ref_center is not None else cx
        cy0_ref = ref_center[1] if ref_center is not None else cy
        for i in range(self.max_iter):
            if record_history:
                self.iterations = i + 1
            rx = px - cx
            ry = py - cy
            rn = np.hypot(rx, ry)
            valid_n = rn > self.eta
            nx = np.where(valid_n, rx / np.maximum(rn, self.eta), 1.0)
            ny = np.where(valid_n, ry / np.maximum(rn, self.eta), 0.0)
            sample_x = px[:, None] + offsets_ext[None, :] * nx[:, None]
            sample_y = py[:, None] + offsets_ext[None, :] * ny[:, None]
            I_ext = map_coordinates(
                img_work,
                [sample_y.ravel(), sample_x.ravel()],
                order=self.interp_order,
                mode="nearest",
                prefilter=use_prefilter,
            ).reshape(num_pts, K_ext)
            G_samples = np.abs(I_ext[:, 2:] - I_ext[:, :-2]) * inv_2step
            base = np.min(G_samples, axis=1, keepdims=True)
            w = np.maximum(G_samples - base, 0.0) ** self.power
            w_sum = np.sum(w, axis=1)
            valid_w = w_sum > self.eta
            delta_t = np.where(
                valid_w,
                np.sum(w * offsets[None, :], axis=1) / np.maximum(w_sum, self.eta),
                0.0,
            )
            px += delta_t * nx
            py += delta_t * ny
            pts_refined = np.column_stack([px, py])
            prev_cx, prev_cy = cx, cy
            cx, cy, r, pfit = self._fit_circle_lsq(pts_refined)
            delta_dx = cx - prev_cx
            delta_dy = cy - prev_cy
            dx_curr = cx - cx0_ref
            dy_curr = cy - cy0_ref
            err = np.hypot(px - cx, py - cy) - r
            sse = float(np.dot(err, err))
            rmse = float(np.sqrt(sse / max(num_pts, 1)))
            if record_history:
                self.history.append({
                    "iter": i + 1,
                    "delta_dx": float(delta_dx),
                    "delta_dy": float(delta_dy),
                    "delta_dtheta_deg": 0.0,
                    "dx": float(dx_curr),
                    "dy": float(dy_curr),
                    "dtheta_deg": 0.0,
                    "sse": sse,
                    "rmse": rmse,
                })
            step_center = float(np.hypot(delta_dx, delta_dy))
            step_pts = float(np.sqrt(np.mean(delta_t * delta_t)))
            if step_center < self.tol and step_pts < self.tol:
                if record_history:
                    self.stopped_early = True
                    self.exit_reason = "tolerance"
                break
        else:
            if record_history:
                self.exit_reason = "max_iter"
        return {
            "cx": cx,
            "cy": cy,
            "r": r,
            "pts_init": pts_init,
            "pts": np.column_stack([px, py]),
            "edges": edges,
            "pfit": pfit,
            "num_pts": num_pts,
        }
    def set_orginal_img(self, img0):
        img0 = np.asarray(img0, dtype=np.float64)
        self._ref_img = img0
        self._cache = self._refine_circle(img0, record_history=False)
    def predict(self, img1, init_dx=0.0, init_dy=0.0, init_dtheta_deg=0.0):
        if self._cache is None:
            raise ValueError(
                "[Canny_CircleFit] 尚未設定參考影像，請先呼叫 set_orginal_img(img0)。"
            )
        c_data = self._cache
        ref_cx, ref_cy = c_data["cx"], c_data["cy"]
        res1 = self._refine_circle(
            img1, record_history=True, ref_center=(ref_cx, ref_cy)
        )
        dx = float(res1["cx"] - ref_cx)
        dy = float(res1["cy"] - ref_cy)
        dtheta_deg = 0.0
        return dx, dy, dtheta_deg

# 



