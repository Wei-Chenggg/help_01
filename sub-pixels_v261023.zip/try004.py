import os
import time
import warnings
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

matplotlib.rcParams["font.family"] = "sans-serif"
matplotlib.rcParams["font.sans-serif"] = [
    "Microsoft JhengHei",
    "PingFang TC",
    "Noto Sans CJK TC",
    "DejaVu Sans",
]
matplotlib.rcParams["axes.unicode_minus"] = False
matplotlib.rcParams["axes.formatter.use_mathtext"] = False

from toolbox.files_helper import get_files, load_pkl
from vision_disp_meas_helper import Global_LK, Canny_CircleFit


def _log_fmt(val, pos=None):
    if val <= 0:
        return ""
    exp = np.log10(val)
    e_int = int(round(exp))
    if abs(exp - e_int) < 1e-9:
        return f"1e{e_int}"
    return f"{val:g}"


def run_trial(name, data, runs, sigma_level, repeat_levels, rng=None, verbose=False):
    if rng is None:
        rng = np.random.default_rng(42)

    repeat_levels = sorted(set(int(r) for r in repeat_levels if r >= 1))
    num_repeat = max(repeat_levels)

    img0      = data["img0"]
    img1_list = data["img1_list"]
    dxy_list  = data["dxy_list"]
    true_dth  = data.get("angle_deg1", 0.0) - data.get("angle_deg0", 0.0)
    n_samples = len(img1_list)

    print(
        f"  {name}  N={n_samples}  θtrue={true_dth:+.1f}°  "
        f"σ_level={sigma_level}  repeat_levels={repeat_levels}"
    )

    preds = {
        (sigma, tag, i): []
        for sigma in sigma_level
        for tag, _, _ in runs
        for i in range(n_samples)
    }

    for tag, lk, kw in runs:
        lk.set_orginal_img(img0)

    for sigma in sigma_level:
        for rep in range(num_repeat):
            if verbose:
                print(f"    --- σ={sigma}, rep {rep + 1}/{num_repeat} ---")

            for tag, lk, kw in runs:
                for i, (img1, true_dxy) in enumerate(zip(img1_list, dxy_list)):
                    if sigma > 0:
                        noise = rng.normal(0.0, sigma, img1.shape)
                        img1_in = img1 + noise
                    else:
                        img1_in = img1

                    t0 = time.perf_counter()
                    out = lk.predict(img1_in, **kw)
                    cost = (time.perf_counter() - t0) * 1000.0

                    preds[(sigma, tag, i)].append((out[0], out[1], out[2], cost))

                    if verbose:
                        dx, dy, dth = out
                        true_dx, true_dy = true_dxy
                        print(
                            f"      {tag} [{rep + 1}][{i + 1}]  "
                            f"err=({dx - true_dx:+.6f},{dy - true_dy:+.6f})  "
                            f"cost={cost:8.3f} ms"
                        )

    stat = {
        sigma: {
            tag: {
                "cost": [],
                "rep_err": {r: [] for r in repeat_levels},
                "rep_dth": {r: [] for r in repeat_levels},
            }
            for tag, _, _ in runs
        }
        for sigma in sigma_level
    }

    for sigma in sigma_level:
        for tag, _, _ in runs:
            for i in range(n_samples):
                true_dx, true_dy = dxy_list[i]
                ps = preds[(sigma, tag, i)]

                dx_arr   = np.array([p[0] for p in ps], dtype=np.float64)
                dy_arr   = np.array([p[1] for p in ps], dtype=np.float64)
                dth_arr  = np.array([p[2] for p in ps], dtype=np.float64)
                cost_arr = np.array([p[3] for p in ps], dtype=np.float64)

                stat[sigma][tag]["cost"].extend(cost_arr.tolist())

                for r in repeat_levels:
                    if r == 1:
                        for dx_v, dy_v, dth_v in zip(dx_arr, dy_arr, dth_arr):
                            stat[sigma][tag]["rep_err"][1].append(
                                (float(dx_v - true_dx), float(dy_v - true_dy))
                            )
                            stat[sigma][tag]["rep_dth"][1].append(float(dth_v - true_dth))
                    else:
                        dx_mean  = float(np.mean(dx_arr[:r]))
                        dy_mean  = float(np.mean(dy_arr[:r]))
                        dth_mean = float(np.mean(dth_arr[:r]))
                        stat[sigma][tag]["rep_err"][r].append(
                            (dx_mean - true_dx, dy_mean - true_dy)
                        )
                        stat[sigma][tag]["rep_dth"][r].append(dth_mean - true_dth)

    return stat


def print_summary_by_noise(stat, runs, sigma_level, repeat_levels):
    repeat_levels = sorted(set(int(r) for r in repeat_levels if r >= 1))
    base_r = repeat_levels[0]
    max_r  = repeat_levels[-1]

    for sigma in sigma_level:
        print(f"  σ={sigma}:")
        for tag, _, _ in runs:
            cost_mean = float(np.mean(stat[sigma][tag]["cost"]))
            parts = []
            for r in repeat_levels:
                err_arr = np.abs(np.array(stat[sigma][tag]["rep_err"][r]))
                dth_arr = np.abs(np.array(stat[sigma][tag]["rep_dth"][r]))
                ex, ey = float(err_arr[:, 0].mean()), float(err_arr[:, 1].mean())
                th_str = (
                    f"{np.nanmean(dth_arr):6.3f}°"
                    if not np.all(np.isnan(dth_arr))
                    else "     -"
                )
                label = "single" if r == 1 else f"avg{r}"
                parts.append(f"{label}=({ex:.5f},{ey:.5f}) θ={th_str}")

            e_base = np.abs(np.array(stat[sigma][tag]["rep_err"][base_r]))
            e_max  = np.abs(np.array(stat[sigma][tag]["rep_err"][max_r]))
            gx = e_base[:, 0].mean() / max(e_max[:, 0].mean(), 1e-12)
            gy = e_base[:, 1].mean() / max(e_max[:, 1].mean(), 1e-12)

            joined = "  |  ".join(parts)
            print(
                f"    {tag}  {joined}  |  "
                f"gain({base_r}→{max_r})=({gx:.2f}×,{gy:.2f}×)  cost={cost_mean:6.2f} ms"
            )


def plot_chart_results(chart_dir, name, true_dth, stat, runs, sigma_level, repeat_levels):
    repeat_levels = sorted(set(int(r) for r in repeat_levels if r >= 1))
    n_algos = len(runs)
    n_cols = max(3, n_algos)

    fig, axes = plt.subplots(2, n_cols, figsize=(5.2 * n_cols, 9.2), squeeze=False)
    fig.suptitle(
        f"Chart: {chart_dir} ({name}, θ_true={true_dth:+.1f}°)\n"
        f"高斯雜訊 σ 與 Repeat Mean Predict 次數對定位誤差之影響",
        fontsize=14,
        fontweight="bold",
        y=0.98,
    )

    algo_colors = ["#1f77b4", "#d62728", "#2ca02c", "#9467bd", "#ff7f0e"]
    rep_styles = [
        {"ls": "--", "marker": "o", "alpha": 0.65, "lw": 1.4},
        {"ls": "-.", "marker": "s", "alpha": 0.82, "lw": 1.8},
        {"ls": "-",  "marker": "D", "alpha": 1.00, "lw": 2.3},
        {"ls": "-",  "marker": "^", "alpha": 1.00, "lw": 2.5},
    ]

    sigmas = np.array(sigma_level, dtype=np.float64)

    top_configs = [
        (0, "Mean |err_x| (px)", "X 軸平均絕對誤差 |err_x| (對數座標)"),
        (1, "Mean |err_y| (px)", "Y 軸平均絕對誤差 |err_y| (對數座標)"),
        (2, "Mean ||err_xy|| (px)", "綜合歐氏位移誤差 ||err_xy|| (對數座標)"),
    ]

    for col_idx, ylabel, title in top_configs:
        ax = axes[0, col_idx]
        for a_idx, (tag, _, _) in enumerate(runs):
            color = algo_colors[a_idx % len(algo_colors)]
            tag_clean = tag.strip()

            for r_idx, r in enumerate(repeat_levels):
                style = rep_styles[min(r_idx, len(rep_styles) - 1)]
                y_vals = []
                for s in sigma_level:
                    err_arr = np.array(stat[s][tag]["rep_err"][r], dtype=np.float64)
                    if col_idx == 0:
                        val = float(np.mean(np.abs(err_arr[:, 0])))
                    elif col_idx == 1:
                        val = float(np.mean(np.abs(err_arr[:, 1])))
                    else:
                        val = float(np.mean(np.hypot(err_arr[:, 0], err_arr[:, 1])))
                    y_vals.append(max(val, 1e-7))

                rep_label = "single (r=1)" if r == 1 else f"avg{r} (r={r})"
                ax.plot(
                    sigmas,
                    y_vals,
                    label=f"{tag_clean} [{rep_label}]",
                    color=color,
                    linestyle=style["ls"],
                    marker=style["marker"],
                    linewidth=style["lw"],
                    alpha=style["alpha"],
                    markersize=5,
                )

        ax.set_yscale("log")
        ax.yaxis.set_major_formatter(FuncFormatter(_log_fmt))
        ax.yaxis.set_minor_formatter(FuncFormatter(lambda v, p: ""))
        ax.set_title(title, fontsize=11, fontweight="bold")
        ax.set_xlabel("高斯雜訊標準差 σ (Gray Level)")
        ax.set_ylabel(ylabel)
        ax.set_xticks(sigmas)
        ax.grid(True, which="both", linestyle=":", alpha=0.6)
        if col_idx == 0:
            ax.legend(fontsize=8, loc="best", framealpha=0.9)

    for col_idx in range(3, n_cols):
        axes[0, col_idx].axis("off")

    rep_cmap = ["#ff7f0e", "#1f77b4", "#2ca02c", "#d62728", "#9467bd"]

    for a_idx, (tag, _, _) in enumerate(runs):
        ax = axes[1, a_idx]
        tag_clean = tag.strip()
        r1_curve = None

        for r_idx, r in enumerate(repeat_levels):
            c_rep = rep_cmap[r_idx % len(rep_cmap)]
            style = rep_styles[min(r_idx, len(rep_styles) - 1)]

            xy_means = []
            x_means = []
            y_means = []
            for s in sigma_level:
                err_arr = np.array(stat[s][tag]["rep_err"][r], dtype=np.float64)
                x_means.append(float(np.mean(np.abs(err_arr[:, 0]))))
                y_means.append(float(np.mean(np.abs(err_arr[:, 1]))))
                xy_means.append(float(np.mean(np.hypot(err_arr[:, 0], err_arr[:, 1]))))

            xy_means = np.array(xy_means)
            if r == 1:
                r1_curve = xy_means

            rep_label = "r=1 (單次預測)" if r == 1 else f"r={r} ({r}次平均預測)"
            ax.plot(
                sigmas,
                xy_means,
                label=f"{rep_label} ||err_xy||",
                color=c_rep,
                linestyle="-",
                marker=style["marker"],
                linewidth=2.2,
                markersize=6,
            )
            ax.plot(
                sigmas,
                x_means,
                color=c_rep,
                linestyle="--",
                alpha=0.4,
                linewidth=1.0,
            )
            ax.plot(
                sigmas,
                y_means,
                color=c_rep,
                linestyle=":",
                alpha=0.4,
                linewidth=1.0,
            )

        max_r = repeat_levels[-1]
        if r1_curve is not None and max_r > 1:
            theo_curve = r1_curve[0] + (r1_curve - r1_curve[0]) / np.sqrt(max_r)
            ax.plot(
                sigmas,
                theo_curve,
                label=f"理論 1/√{max_r} 改善極限",
                color="black",
                linestyle=":",
                linewidth=1.8,
                alpha=0.75,
            )

        avg_cost = float(
            np.mean([np.mean(stat[s][tag]["cost"]) for s in sigma_level])
        )
        ax.set_title(
            f"[{tag_clean}] 不同 Repeat 平均次數比較\n(單次平均耗時: {avg_cost:.2f} ms)",
            fontsize=11,
            fontweight="bold",
        )
        ax.set_xlabel("高斯雜訊標準差 σ (Gray Level)")
        ax.set_ylabel("Mean ||err_xy|| (px) [線性座標]")
        ax.set_xticks(sigmas)
        ax.set_ylim(bottom=0.0)
        ax.grid(True, linestyle="--", alpha=0.5)
        ax.legend(fontsize=8.5, loc="upper left", framealpha=0.9)

    for col_idx in range(n_algos, n_cols):
        axes[1, col_idx].axis("off")

    fig.tight_layout(rect=[0, 0, 1, 0.94])


if __name__ == "__main__":
    CHART_DIRS = [
        "charts/chart12_spike_gauss/400x400",
        "charts/chart7_flower/400x400",
        "charts/chart0_circle/400x400",
        "charts/chart15_gradient_curves/400x400",
    ]

    sigma_level   = [0, 2, 4, 6]
    repeat_levels = [1, 5, 10, 20]
    seed          = 42
    verbose       = False

    runs = [
        (
            "iter20      ",
            Global_LK(margin=4, interp_order=3, energy_ratio=0.99, max_iter=20, tol=1e-4),
            {},
        ),
        (
            "iter20+b1.0 ",
            Global_LK(margin=4, interp_order=3, energy_ratio=0.99, max_iter=20, tol=1e-4, blur_level=1.0),
            {},
        ),
        (
            "canny       ",
            Canny_CircleFit(canny_low=50, canny_high=150, max_iter=10, tol=1e-4),
            {},
        ),
    ]

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        for _, lk, _ in runs:
            lk.set_orginal_img(np.zeros((64, 64)))
            lk.predict(np.zeros((64, 64)))

    for chart_dir in CHART_DIRS:
        if not os.path.exists(chart_dir):
            print(f"跳過不存在的目錄: {chart_dir}")
            continue

        print(f"\n{chart_dir}")

        for _, fpath, name, _ in get_files(chart_dir, types=["pkl"]):
            data = load_pkl(fpath)
            true_dth = data.get("angle_deg1", 0.0) - data.get("angle_deg0", 0.0)
            rng = np.random.default_rng(seed)

            stat = run_trial(
                name,
                data,
                runs,
                sigma_level=sigma_level,
                repeat_levels=repeat_levels,
                rng=rng,
                verbose=verbose,
            )
            print_summary_by_noise(stat, runs, sigma_level, repeat_levels)
            plot_chart_results(
                chart_dir,
                name,
                true_dth,
                stat,
                runs,
                sigma_level,
                repeat_levels,
            )

    plt.show()