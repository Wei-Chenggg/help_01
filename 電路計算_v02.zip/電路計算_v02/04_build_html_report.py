# -*- coding: utf-8 -*-
"""
Build a 100% offline, self-contained Interactive Engineering Calculator HTML
for the LTC6993 + LTC6990 Burst Chirp Square-Wave Generator.

v2 UX Upgrade:
1. 1.5x Enlarged Typography across HTML UI (21px base + zoom +/-), SVG Topology (16~20px),
   and 4-Channel Canvas Oscilloscope (16~19px).
2. Dual Independent Scroll Split-Pane Layout ("雙滾動視窗"):
   - Left Scroll Pane: Target Range Auto-Solver + Zone 1~4 Individual R/C Sliders & Inputs
   - Right Scroll Pane: Live Spline Circuit Topology (right at top!) + Pin Toggle + KPIs/DRC + Oscilloscope + Formulas
   - Draggable splitter bar between panes + zero external references (100% portable single .html).
"""

import os

OUT_DIR = os.path.dirname(os.path.abspath(__file__))

HTML_CONTENT = r"""<!DOCTYPE html>
<html lang="zh-Hant">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>LTC6993 + LTC6990 互動工程計算機（1.5x 大字體 · 左右雙滾動即時拓樸調參）</title>
<style>
:root {
  /* 14px * 1.5 = 21px Default Base Font Size */
  --base-font: 21px;
  --left-pane-w: 41%;
  --bg: #f1f5f9;
  --card: #ffffff;
  --border: #cbd5e1;
  --border-soft: #e2e8f0;
  --text: #0f172a;
  --muted: #475569;
  --primary: #1d4ed8;
  --primary-soft: #dbeafe;
  --danger: #dc2626;
  --danger-soft: #fee2e2;
  --warn: #d97706;
  --warn-soft: #fef3c7;
  --ok: #059669;
  --ok-soft: #d1fae5;
}
html {
  font-size: var(--base-font);
}
* { box-sizing: border-box; }
body {
  margin: 0;
  background: var(--bg);
  color: var(--text);
  font-family: "Noto Sans TC", "PingFang TC", "Microsoft JhengHei", system-ui, -apple-system, sans-serif;
  line-height: 1.5;
  height: 100vh;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

/* ==================== TOP GLOBAL BAR ==================== */
.topbar {
  flex: 0 0 auto;
  z-index: 100;
  background: #0f172a;
  color: #f8fafc;
  border-bottom: 2px solid #334155;
  padding: 0.45rem 0.9rem;
}
.topbar-inner {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: 0.55rem 0.9rem;
}
.brand-title {
  font-size: 1.02rem;
  font-weight: 800;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  flex-wrap: wrap;
}
.badge-avdd {
  background: #dc2626;
  color: #fff;
  font-weight: 800;
  padding: 0.12rem 0.55rem;
  border-radius: 999px;
  font-size: 0.82rem;
  font-family: ui-monospace, "SF Mono", Consolas, monospace;
}
.avdd-ctrl {
  display: flex;
  align-items: center;
  gap: 0.45rem;
  background: #1e293b;
  padding: 0.28rem 0.65rem;
  border-radius: 0.5rem;
  border: 1px solid #475569;
  flex-wrap: wrap;
}
.avdd-ctrl label {
  font-weight: 800;
  color: #fca5a5;
  font-size: 0.85rem;
}
.avdd-ctrl input[type="number"] {
  width: 5.2ch;
  padding: 0.15rem 0.3rem;
  border-radius: 0.35rem;
  border: 1px solid #64748b;
  background: #0f172a;
  color: #fff;
  font-weight: 800;
  font-family: ui-monospace, "SF Mono", Consolas, monospace;
  font-size: 0.9rem;
  text-align: right;
}
.avdd-ctrl input[type="range"] {
  width: 5.5rem;
  height: 0.45rem;
  accent-color: #ef4444;
  cursor: pointer;
}
.pill-btn {
  padding: 0.22rem 0.55rem;
  border-radius: 0.35rem;
  border: 1px solid #475569;
  background: #334155;
  color: #e2e8f0;
  font-size: 0.76rem;
  font-weight: 700;
  cursor: pointer;
  font-family: inherit;
  transition: background 0.12s;
  white-space: nowrap;
}
.pill-btn:hover { background: #475569; color: #fff; }
.pill-btn.primary { background: #2563eb; border-color: #3b82f6; color: #fff; }
.pill-btn.primary:hover { background: #1d4ed8; }
.pill-btn.active-pin { background: #059669; border-color: #10b981; color: #fff; }

/* ==================== DUAL-SCROLL WORKBENCH ==================== */
.workbench {
  flex: 1 1 auto;
  display: flex;
  min-height: 0;
  width: 100%;
  overflow: hidden;
}
.pane-left {
  width: var(--left-pane-w);
  min-width: 360px;
  max-width: 65%;
  height: 100%;
  overflow-y: auto;
  overflow-x: hidden;
  padding: 0.75rem 0.8rem 3rem;
  background: #eef2f7;
  border-right: 1px solid var(--border);
  scroll-behavior: smooth;
}
.splitter {
  flex: 0 0 8px;
  background: #cbd5e1;
  cursor: col-resize;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: background 0.15s;
  user-select: none;
}
.splitter:hover, .splitter.dragging {
  background: #3b82f6;
}
.splitter::after {
  content: "⋮";
  color: #475569;
  font-weight: 900;
  font-size: 0.9rem;
}
.splitter:hover::after, .splitter.dragging::after { color: #ffffff; }

.pane-right {
  flex: 1 1 0%;
  min-width: 0;
  height: 100%;
  overflow-y: auto;
  overflow-x: hidden;
  padding: 0.75rem 0.9rem 3rem;
  background: var(--bg);
}

/* Optional Sticky Topology inside Right Pane */
.topo-card.pinned {
  position: sticky;
  top: 0;
  z-index: 40;
  box-shadow: 0 6px 18px rgba(15, 23, 42, 0.12);
}

/* Responsive fallback on narrow portrait screens */
@media (max-width: 980px) {
  body { height: auto; overflow: auto; }
  .workbench { flex-direction: column; overflow: visible; }
  .pane-left, .pane-right { width: 100%; max-width: 100%; height: auto; overflow: visible; }
  .splitter { display: none; }
}

/* ==================== CARDS & CONTROLS ==================== */
.section-card {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 0.6rem;
  padding: 0.75rem 0.9rem;
  margin-bottom: 0.8rem;
  box-shadow: 0 1px 4px rgba(15, 23, 42, 0.04);
}
.section-head {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  align-items: center;
  gap: 0.45rem;
  padding-bottom: 0.45rem;
  margin-bottom: 0.65rem;
  border-bottom: 2px solid var(--border-soft);
}
.section-title {
  margin: 0;
  font-size: 0.98rem;
  font-weight: 800;
  color: var(--text);
}

/* Target Range Auto-Solver */
.synth-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 0.55rem;
}
.synth-full { grid-column: 1 / -1; }
.field-box {
  display: flex;
  flex-direction: column;
  gap: 0.2rem;
}
.field-box label {
  font-size: 0.8rem;
  font-weight: 700;
  color: var(--muted);
}
.field-box input[type="number"], .field-box select {
  width: 100%;
  padding: 0.32rem 0.5rem;
  border-radius: 0.4rem;
  border: 1px solid var(--border);
  font-size: 0.9rem;
  font-weight: 800;
  font-family: ui-monospace, "SF Mono", Consolas, inherit;
  color: var(--text);
  background: #f8fafc;
}
.field-box input:focus, .field-box select:focus {
  outline: 2px solid #93c5fd;
  border-color: var(--primary);
  background: #fff;
}
.solve-btn {
  width: 100%;
  padding: 0.45rem 0.75rem;
  border-radius: 0.45rem;
  border: none;
  background: linear-gradient(135deg, #1d4ed8, #2563eb);
  color: #fff;
  font-weight: 800;
  font-size: 0.88rem;
  cursor: pointer;
  font-family: inherit;
  box-shadow: 0 2px 6px rgba(37, 99, 235, 0.25);
}
.solve-btn:hover { background: linear-gradient(135deg, #1e40af, #1d4ed8); }

/* Zone Panels in Left Scroll Pane */
.zone-panel {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 0.6rem;
  padding: 0.7rem 0.85rem;
  margin-bottom: 0.75rem;
  transition: box-shadow 0.2s, border-color 0.2s;
}
.zone-panel.flash {
  border-color: #2563eb;
  box-shadow: 0 0 0 4px rgba(37, 99, 235, 0.28);
}
.zone-hdr {
  font-weight: 800;
  font-size: 0.95rem;
  margin-bottom: 0.55rem;
  padding-bottom: 0.35rem;
  border-bottom: 2px dashed var(--border);
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 0.4rem;
  flex-wrap: wrap;
}
.comp-row {
  margin-bottom: 0.55rem;
  padding-bottom: 0.45rem;
  border-bottom: 1px solid #f1f5f9;
}
.comp-row:last-of-type { border-bottom: none; margin-bottom: 0.25rem; }
.comp-top {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 0.4rem;
  margin-bottom: 0.2rem;
  flex-wrap: wrap;
}
.comp-name {
  font-weight: 700;
  font-size: 0.84rem;
  color: #1e293b;
}
.comp-name code {
  background: #e2e8f0;
  padding: 0.06rem 0.3rem;
  border-radius: 0.25rem;
  font-family: ui-monospace, "SF Mono", Consolas, monospace;
  color: #0f172a;
  font-size: 0.86rem;
}
.comp-inputs {
  display: flex;
  align-items: center;
  gap: 0.28rem;
  flex-wrap: wrap;
}
.comp-inputs input[type="number"] {
  width: 6.2ch;
  padding: 0.18rem 0.32rem;
  border: 1px solid var(--border);
  border-radius: 0.3rem;
  font-family: ui-monospace, "SF Mono", Consolas, monospace;
  font-weight: 800;
  font-size: 0.88rem;
  text-align: right;
  color: var(--text);
}
.comp-inputs select, .zone-hdr select {
  padding: 0.2rem 0.35rem;
  border-radius: 0.3rem;
  border: 1px solid var(--border);
  font-size: 0.8rem;
  font-weight: 700;
  font-family: inherit;
  max-width: 100%;
}
.unit-lbl {
  font-size: 0.8rem;
  color: var(--muted);
  font-family: ui-monospace, "SF Mono", Consolas, monospace;
  font-weight: 700;
}
.e96-btn {
  padding: 0.15rem 0.38rem;
  font-size: 0.74rem;
  font-weight: 800;
  border: 1px solid #94a3b8;
  background: #f1f5f9;
  color: #1e293b;
  border-radius: 0.28rem;
  cursor: pointer;
}
.e96-btn:hover { background: #dbeafe; border-color: #2563eb; color: #1d4ed8; }
.comp-slider {
  width: 100%;
  height: 0.42rem;
  accent-color: #2563eb;
  cursor: pointer;
  margin-top: 0.15rem;
}
.readout-box {
  margin-top: 0.45rem;
  background: #f1f5f9;
  border-radius: 0.45rem;
  padding: 0.45rem 0.6rem;
  font-size: 0.8rem;
}
.readout-line {
  display: flex;
  justify-content: space-between;
  padding: 0.12rem 0;
  gap: 0.4rem;
  flex-wrap: wrap;
}
.readout-line span:last-child {
  font-family: ui-monospace, "SF Mono", Consolas, monospace;
  font-weight: 800;
  color: #0f172a;
}

/* ==================== RIGHT PANE: KPIs, DRC, SVG, CANVAS ==================== */
.kpi-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(11.5rem, 1fr));
  gap: 0.55rem;
  margin-bottom: 0.75rem;
}
.kpi-card {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 0.55rem;
  padding: 0.5rem 0.7rem;
}
.kpi-lbl { font-size: 0.76rem; color: var(--muted); font-weight: 700; }
.kpi-val {
  font-size: 1.18rem;
  font-weight: 800;
  font-family: ui-monospace, "SF Mono", Consolas, monospace;
  margin: 0.1rem 0;
}
.kpi-sub { font-size: 0.74rem; color: var(--muted); }

.drc-box {
  border-radius: 0.55rem;
  padding: 0.5rem 0.75rem;
  margin-bottom: 0.8rem;
  border: 1px solid var(--border);
  background: var(--card);
  display: flex;
  flex-wrap: wrap;
  gap: 0.35rem 0.55rem;
  align-items: center;
}
.drc-tag {
  display: inline-flex;
  align-items: center;
  padding: 0.15rem 0.55rem;
  border-radius: 999px;
  font-size: 0.76rem;
  font-weight: 700;
}
.drc-ok { background: var(--ok-soft); color: #065f46; }
.drc-warn { background: var(--warn-soft); color: #92400e; }
.drc-err { background: var(--danger-soft); color: #991b1b; }

/* SVG Topology Styling with Crisp White Text Halos */
.svg-wrap {
  width: 100%;
  overflow-x: auto;
  border: 1px solid var(--border-soft);
  border-radius: 0.5rem;
  background: #ffffff;
}
.svg-wrap svg {
  width: 100%;
  min-width: 780px;
  height: auto;
  display: block;
}
.svg-wrap svg text {
  font-family: "Noto Sans TC", "PingFang TC", "Microsoft JhengHei", system-ui, sans-serif;
  paint-order: stroke;
  stroke: #ffffff;
  stroke-width: 4px;
  stroke-linejoin: round;
}
.svg-wrap svg text.no-halo {
  stroke: none;
}
.svg-clickable { cursor: pointer; transition: opacity 0.15s; }
.svg-clickable:hover { opacity: 0.78; }
.spline-wire {
  fill: none;
  stroke-linecap: round;
  stroke-linejoin: round;
  transition: stroke-width 0.15s;
}
.spline-wire:hover { stroke-width: 5px !important; }

/* Live Waveform Canvas */
.canvas-wrap {
  position: relative;
  width: 100%;
  border: 1px solid var(--border-soft);
  border-radius: 0.5rem;
  background: #ffffff;
  padding: 0.35rem;
}
canvas#waveCanvas {
  width: 100%;
  height: 820px;
  display: block;
  cursor: crosshair;
}

/* Formula Table */
table.eng-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 0.82rem;
}
table.eng-table th, table.eng-table td {
  border: 1px solid var(--border-soft);
  padding: 0.4rem 0.55rem;
  text-align: left;
  vertical-align: middle;
}
table.eng-table th {
  background: #f8fafc;
  font-weight: 800;
  color: #1e293b;
}
table.eng-table code {
  font-family: ui-monospace, "SF Mono", Consolas, monospace;
  background: #f1f5f9;
  padding: 0.08rem 0.3rem;
  border-radius: 0.25rem;
}

@media print {
  body { height: auto; overflow: visible; background: #fff; }
  .topbar { position: static; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
  .workbench { display: block; overflow: visible; }
  .pane-left, .pane-right { width: 100%; max-width: 100%; height: auto; overflow: visible; }
  .splitter { display: none; }
  .topo-card.pinned { position: static; }
  .section-card, .zone-panel, .kpi-card { break-inside: avoid; page-break-inside: avoid; }
}
</style>
</head>
<body>

<!-- ==================== TOP GLOBAL AVDD & FONT SCALE BAR ==================== -->
<header class="topbar">
  <div class="topbar-inner">
    <div class="brand-title">
      <span>LTC6993 + LTC6990 連續調頻計算機</span>
      <span class="badge-avdd" id="topAvddBadge">AVDD = 3.30 V</span>
    </div>

    <div class="avdd-ctrl">
      <label for="inp_AVDD">全域 AVDD：</label>
      <input type="range" id="sld_AVDD" min="2.25" max="5.50" step="0.05" value="3.30">
      <input type="number" id="inp_AVDD" min="2.25" max="5.50" step="0.05" value="3.30">
      <span style="font-size:0.78rem;color:#cbd5e1;">V</span>
      <button class="pill-btn" onclick="setAVDD(2.50)">2.5V</button>
      <button class="pill-btn primary" onclick="setAVDD(3.30)">3.3V</button>
      <button class="pill-btn" onclick="setAVDD(5.00)">5.0V</button>
    </div>

    <div style="display:flex;gap:0.35rem;align-items:center;flex-wrap:wrap;">
      <button class="pill-btn" onclick="adjustFont(-2)" title="縮小字體">A-</button>
      <button class="pill-btn" id="fontScaleBtn" onclick="resetFont()" title="重設為 1.5 倍大字體 (21px)">1.5x 字體</button>
      <button class="pill-btn" onclick="adjustFont(2)" title="放大字體">A+</button>
      <button class="pill-btn primary" onclick="loadPreset('down')">預設降頻 (56→54k)</button>
      <button class="pill-btn" onclick="loadPreset('up')">升頻 (54→56k)</button>
      <button class="pill-btn" onclick="copyMarkdownReport()">複製報告</button>
    </div>
  </div>
</header>

<!-- ==================== DUAL INDEPENDENT SCROLL WORKBENCH ==================== -->
<div class="workbench" id="workbench">

  <!-- ==================== LEFT SCROLL PANE: ALL PARAMETER CONTROLS ==================== -->
  <aside class="pane-left" id="paneLeft">

    <!-- MODE A: TARGET SPECIFICATION AUTO-SOLVER -->
    <section class="section-card" style="border-color:#93c5fd;background:#f8fbff;">
      <div class="section-head" style="margin-bottom:0.5rem;">
        <h2 class="section-title" style="color:#1e40af;">🎯 模式 A：目標範圍反推 R/C</h2>
        <label style="font-size:0.76rem;font-weight:800;color:var(--primary);cursor:pointer;display:flex;align-items:center;gap:0.25rem;">
          <input type="checkbox" id="chk_auto_solve" checked style="width:0.9rem;height:0.9rem;">
          即時反推
        </label>
      </div>
      <div class="synth-grid">
        <div class="field-box">
          <label for="tgt_tout">事件時間 t_EVENT (ms)</label>
          <input type="number" id="tgt_tout" min="0.002" max="33000" step="1" value="100.0" oninput="onTargetInput()">
        </div>
        <div class="field-box">
          <label for="tgt_snap">電阻取值規範</label>
          <select id="tgt_snap" onchange="solveFromTargets()">
            <option value="e96_dual" selected>E96 1% (U1 雙電阻精密)</option>
            <option value="e96_single">E96 1% (全單顆標準值)</option>
            <option value="exact">理論連續精確阻值</option>
          </select>
        </div>
        <div class="field-box">
          <label for="tgt_fstart">起始頻率 f_START (kHz)</label>
          <input type="number" id="tgt_fstart" min="0.5" max="2000" step="0.1" value="56.0" oninput="onTargetInput()">
        </div>
        <div class="field-box">
          <label for="tgt_fend">結束頻率 f_END (kHz)</label>
          <input type="number" id="tgt_fend" min="0.5" max="2000" step="0.1" value="54.0" oninput="onTargetInput()">
        </div>
        <div class="field-box synth-full">
          <button class="solve-btn" onclick="solveFromTargets()">⚡ 依目標範圍重算所有電阻 / 電容</button>
        </div>
      </div>
    </section>

    <!-- ZONE 1: BUTTON & RC DEBOUNCE -->
    <div class="zone-panel" id="panel_z1">
      <div class="zone-hdr" style="color:#b45309;">
        <span>Zone 1：手動按鈕與除彈跳</span>
        <span style="font-size:0.74rem;background:#fef3c7;padding:0.1rem 0.45rem;border-radius:99px;">SW1 + RC</span>
      </div>

      <div class="comp-row" id="ctrl_R_PU">
        <div class="comp-top">
          <span class="comp-name"><code>R_PU</code> 上拉電阻 (AVDD)</span>
          <div class="comp-inputs">
            <input type="number" id="inp_R_PU" min="1" max="2000" step="1" value="100">
            <span class="unit-lbl">kΩ</span>
            <button class="e96-btn" onclick="snapInput('R_PU')">E96</button>
          </div>
        </div>
        <input type="range" class="comp-slider" id="sld_R_PU" min="4.7" max="470" step="0.5" value="100">
      </div>

      <div class="comp-row" id="ctrl_R_DB">
        <div class="comp-top">
          <span class="comp-name"><code>R_DB</code> 除彈跳放電電阻</span>
          <div class="comp-inputs">
            <input type="number" id="inp_R_DB" min="0.1" max="1000" step="0.5" value="10">
            <span class="unit-lbl">kΩ</span>
            <button class="e96-btn" onclick="snapInput('R_DB')">E96</button>
          </div>
        </div>
        <input type="range" class="comp-slider" id="sld_R_DB" min="1" max="100" step="0.5" value="10">
      </div>

      <div class="comp-row" id="ctrl_C_DB">
        <div class="comp-top">
          <span class="comp-name"><code>C_DB</code> 除彈跳電容</span>
          <div class="comp-inputs">
            <input type="number" id="inp_C_DB" min="0.001" max="10" step="0.01" value="0.10">
            <span class="unit-lbl">µF</span>
          </div>
        </div>
        <input type="range" class="comp-slider" id="sld_C_DB" min="0.01" max="1.0" step="0.01" value="0.10">
      </div>

      <div class="comp-row">
        <div class="comp-top">
          <span class="comp-name">模擬按住時長 / 彈跳時長</span>
          <div class="comp-inputs">
            <input type="number" id="inp_t_hold" min="5" max="500" step="5" value="125" style="width:5.2ch;" title="按住時間 (ms)">
            <span class="unit-lbl">ms</span>
            <input type="number" id="inp_t_bounce" min="0" max="30" step="0.5" value="4.5" style="width:4.8ch;" title="彈跳時間 (ms)">
            <span class="unit-lbl">ms</span>
          </div>
        </div>
      </div>

      <div class="readout-box" id="readout_z1"></div>
    </div>

    <!-- ZONE 2: U1 LTC6993 -->
    <div class="zone-panel" id="panel_z2">
      <div class="zone-hdr" style="color:#1d4ed8;">
        <span>Zone 2：U1 LTC6993 單穩態</span>
        <select id="sel_u1_ver" onchange="recalcAll()">
          <option value="3" selected>LTC6993-3 (下降緣/不可重觸)</option>
          <option value="4">LTC6993-4 (下降緣/可重觸)</option>
          <option value="1">LTC6993-1 (上升緣/不可重觸)</option>
          <option value="2">LTC6993-2 (上升緣/可重觸)</option>
        </select>
      </div>

      <div class="comp-row">
        <div class="comp-top">
          <span class="comp-name">原廠 <code>DIVCODE</code> 快速帶入</span>
          <select id="sel_div1_preset" onchange="applyDivPreset(1, this.value)">
            <option value="custom">-- 自訂 R1 / R2 --</option>
            <option value="0">Code 0 (POL=0, ÷1: 1~16µs)</option>
            <option value="1">Code 1 (POL=0, ÷8: 8~128µs)</option>
            <option value="2">Code 2 (POL=0, ÷64: 64µs~1ms)</option>
            <option value="3">Code 3 (POL=0, ÷512: 0.5~8.2ms)</option>
            <option value="4">Code 4 (POL=0, ÷4096: 4.1~65.5ms)</option>
            <option value="5" selected>Code 5 (POL=0, ÷32768: 32.8~524ms)</option>
            <option value="6">Code 6 (POL=0, ÷262144: 0.26~4.2s)</option>
            <option value="7">Code 7 (POL=0, ÷2097152: 2.1~33.6s)</option>
            <option value="10">Code 10 (POL=1, ÷32768 負脈波)</option>
          </select>
        </div>
      </div>

      <div class="comp-row" id="ctrl_R1">
        <div class="comp-top">
          <span class="comp-name"><code>R1</code> 上分壓 (AVDD→DIV)</span>
          <div class="comp-inputs">
            <input type="number" id="inp_R1" min="0" max="100000" step="1" value="1000">
            <span class="unit-lbl">kΩ</span>
            <button class="e96-btn" onclick="snapInput('R1')">E96</button>
          </div>
        </div>
        <input type="range" class="comp-slider" id="sld_R1" min="10" max="2000" step="1" value="1000">
      </div>

      <div class="comp-row" id="ctrl_R2">
        <div class="comp-top">
          <span class="comp-name"><code>R2</code> 下分壓 (DIV→GND)</span>
          <div class="comp-inputs">
            <input type="number" id="inp_R2" min="0" max="100000" step="1" value="523">
            <span class="unit-lbl">kΩ</span>
            <button class="e96-btn" onclick="snapInput('R2')">E96</button>
          </div>
        </div>
        <input type="range" class="comp-slider" id="sld_R2" min="0" max="2000" step="1" value="523">
      </div>

      <div class="comp-row" id="ctrl_R_SET1">
        <div class="comp-top">
          <span class="comp-name"><code>R_SET1a</code> 主脈寬電阻</span>
          <div class="comp-inputs">
            <input type="number" id="inp_R_SET1a" min="10" max="2000" step="0.5" value="150">
            <span class="unit-lbl">kΩ</span>
            <button class="e96-btn" onclick="snapInput('R_SET1a')">E96</button>
          </div>
        </div>
        <input type="range" class="comp-slider" id="sld_R_SET1a" min="50" max="800" step="0.5" value="150">
      </div>

      <div class="comp-row">
        <div class="comp-top">
          <span class="comp-name"><code>R_SET1b</code> 串聯微調電阻</span>
          <div class="comp-inputs">
            <input type="number" id="inp_R_SET1b" min="0" max="200" step="0.05" value="2.55">
            <span class="unit-lbl">kΩ</span>
            <button class="e96-btn" onclick="snapInput('R_SET1b')">E96</button>
          </div>
        </div>
      </div>

      <div class="comp-row" id="ctrl_C1">
        <div class="comp-top">
          <span class="comp-name"><code>V_SET1</code> 基準 / <code>C1</code> 去耦</span>
          <div class="comp-inputs">
            <input type="number" id="inp_V_SET1" min="0.97" max="1.03" step="0.005" value="1.000" style="width:5.6ch;">
            <span class="unit-lbl">V</span>
            <input type="number" id="inp_C1" min="0.01" max="10" step="0.1" value="0.10" style="width:5.0ch;">
            <span class="unit-lbl">µF</span>
          </div>
        </div>
      </div>

      <div class="readout-box" id="readout_z2"></div>
    </div>

    <!-- ZONE 3: RC RAMP MODULATOR -->
    <div class="zone-panel" id="panel_z3">
      <div class="zone-hdr" style="color:#7c3aed;">
        <span>Zone 3：連續調頻 RC 斜坡</span>
        <span style="font-size:0.74rem;background:#ede9fe;padding:0.1rem 0.45rem;border-radius:99px;">V_CTRL(t)</span>
      </div>

      <div class="comp-row" id="ctrl_INV">
        <div class="comp-top">
          <span class="comp-name">斜坡極性 (<code>SN74LVC1G04</code>)</span>
          <select id="sel_inv" onchange="recalcAll()">
            <option value="0" selected>直連無反相 (充電 = 降頻)</option>
            <option value="1">加 1G04 反相 (放電 = 升頻)</option>
          </select>
        </div>
      </div>

      <div class="comp-row" id="ctrl_R_RAMP">
        <div class="comp-top">
          <span class="comp-name"><code>R_RAMP</code> 斜坡充放電電阻</span>
          <div class="comp-inputs">
            <input type="number" id="inp_R_RAMP" min="1" max="10000" step="1" value="280">
            <span class="unit-lbl">kΩ</span>
            <button class="e96-btn" onclick="snapInput('R_RAMP')">E96</button>
          </div>
        </div>
        <input type="range" class="comp-slider" id="sld_R_RAMP" min="10" max="1000" step="1" value="280">
      </div>

      <div class="comp-row" id="ctrl_C_RAMP">
        <div class="comp-top">
          <span class="comp-name"><code>C_RAMP</code> 調頻積分電容</span>
          <div class="comp-inputs">
            <input type="number" id="inp_C_RAMP" min="0.0001" max="100" step="0.05" value="1.00">
            <span class="unit-lbl">µF</span>
          </div>
        </div>
        <input type="range" class="comp-slider" id="sld_C_RAMP" min="0.05" max="4.70" step="0.05" value="1.00">
      </div>

      <div class="comp-row">
        <div class="comp-top">
          <span class="comp-name">負載 <code>C_LOAD</code> / <code>R_LOAD</code></span>
          <div class="comp-inputs">
            <input type="number" id="inp_C_LOAD" min="0" max="1000" step="1" value="15" style="width:4.8ch;">
            <span class="unit-lbl">pF</span>
            <input type="number" id="inp_R_LOAD" min="1" max="10000" step="5" value="100" style="width:5.4ch;">
            <span class="unit-lbl">kΩ</span>
          </div>
        </div>
      </div>

      <div class="readout-box" id="readout_z3"></div>
    </div>

    <!-- ZONE 4: U2 LTC6990 VCO -->
    <div class="zone-panel" id="panel_z4">
      <div class="zone-hdr" style="color:#0891b2;">
        <span>Zone 4：U2 LTC6990 壓控方波</span>
        <span style="font-size:0.74rem;background:#cffafe;padding:0.1rem 0.45rem;border-radius:99px;">50% Duty</span>
      </div>

      <div class="comp-row">
        <div class="comp-top">
          <span class="comp-name">原廠 <code>DIVCODE</code> 快速帶入</span>
          <select id="sel_div2_preset" onchange="applyDivPreset(2, this.value)">
            <option value="custom">-- 自訂 R3 / R4 --</option>
            <option value="0">Code 0 (Hi-Z=0, ÷1: 62.5~1000k)</option>
            <option value="1">Code 1 (Hi-Z=0, ÷2: 31.3~500k)</option>
            <option value="2">Code 2 (Hi-Z=0, ÷4: 15.6~250k)</option>
            <option value="3">Code 3 (Hi-Z=0, ÷8: 7.8~125k)</option>
            <option value="4" selected>Code 4 (Hi-Z=0, ÷16: 3.9~62.5k)</option>
            <option value="5">Code 5 (Hi-Z=0, ÷32: 2.0~31.3k)</option>
            <option value="6">Code 6 (Hi-Z=0, ÷64: 1.0~15.6k)</option>
            <option value="7">Code 7 (Hi-Z=0, ÷128: 0.5~7.8k)</option>
            <option value="11">Code 11 (Hi-Z=1, ÷16 高阻態)</option>
          </select>
        </div>
      </div>

      <div class="comp-row" id="ctrl_R3">
        <div class="comp-top">
          <span class="comp-name"><code>R3</code> 上分壓 (AVDD→DIV)</span>
          <div class="comp-inputs">
            <input type="number" id="inp_R3" min="0" max="100000" step="1" value="1000">
            <span class="unit-lbl">kΩ</span>
            <button class="e96-btn" onclick="snapInput('R3')">E96</button>
          </div>
        </div>
        <input type="range" class="comp-slider" id="sld_R3" min="10" max="2000" step="1" value="1000">
      </div>

      <div class="comp-row" id="ctrl_R4">
        <div class="comp-top">
          <span class="comp-name"><code>R4</code> 下分壓 (DIV→GND)</span>
          <div class="comp-inputs">
            <input type="number" id="inp_R4" min="0" max="100000" step="1" value="392">
            <span class="unit-lbl">kΩ</span>
            <button class="e96-btn" onclick="snapInput('R4')">E96</button>
          </div>
        </div>
        <input type="range" class="comp-slider" id="sld_R4" min="0" max="2000" step="1" value="392">
      </div>

      <div class="comp-row" id="ctrl_R_SET2">
        <div class="comp-top">
          <span class="comp-name"><code>R_SET2</code> VCO 基準電阻</span>
          <div class="comp-inputs">
            <input type="number" id="inp_R_SET2" min="10" max="2000" step="0.1" value="57.6">
            <span class="unit-lbl">kΩ</span>
            <button class="e96-btn" onclick="snapInput('R_SET2')">E96</button>
          </div>
        </div>
        <input type="range" class="comp-slider" id="sld_R_SET2" min="25" max="400" step="0.2" value="57.6">
      </div>

      <div class="comp-row" id="ctrl_R_VCO">
        <div class="comp-top">
          <span class="comp-name"><code>R_VCO</code> 壓控調頻電阻</span>
          <div class="comp-inputs">
            <input type="number" id="inp_R_VCO" min="10" max="20000" step="10" value="1500">
            <span class="unit-lbl">kΩ</span>
            <button class="e96-btn" onclick="snapInput('R_VCO')">E96</button>
          </div>
        </div>
        <input type="range" class="comp-slider" id="sld_R_VCO" min="100" max="5000" step="10" value="1500">
      </div>

      <div class="comp-row" id="ctrl_C2">
        <div class="comp-top">
          <span class="comp-name"><code>V_SET2</code> 基準 / <code>C2</code> 去耦</span>
          <div class="comp-inputs">
            <input type="number" id="inp_V_SET2" min="0.97" max="1.03" step="0.005" value="1.000" style="width:5.6ch;">
            <span class="unit-lbl">V</span>
            <input type="number" id="inp_C2" min="0.01" max="10" step="0.1" value="0.10" style="width:5.0ch;">
            <span class="unit-lbl">µF</span>
          </div>
        </div>
      </div>

      <div class="readout-box" id="readout_z4"></div>
    </div>

  </aside>

  <!-- DRAGGABLE SPLITTER -->
  <div class="splitter" id="splitter" title="拖曳調整左右視窗寬度比例"></div>

  <!-- ==================== RIGHT SCROLL PANE: TOPOLOGY FIRST + KPIs + WAVEFORMS ==================== -->
  <main class="pane-right" id="paneRight">

    <!-- 1. LIVE SPLINE CIRCUIT TOPOLOGY AT VERY TOP OF RIGHT PANE -->
    <section class="section-card topo-card" id="topoCard">
      <div class="section-head" style="margin-bottom:0.45rem;">
        <h2 class="section-title">📐 即時雲形線電路拓樸圖（左側滾動調參時，此圖即時更新；點擊圖上元件可跳轉左側欄位）</h2>
        <button class="pill-btn" id="pinTopoBtn" onclick="togglePinTopology()" style="background:#f1f5f9;color:#1e293b;border-color:#94a3b8;">
          📌 釘選拓樸於右窗頂部
        </button>
      </div>
      <div class="svg-wrap" id="svgContainer"></div>
    </section>

    <!-- 2. LIVE KPI SUMMARY CARDS -->
    <div class="kpi-grid">
      <div class="kpi-card">
        <div class="kpi-lbl">全域電源 AVDD</div>
        <div class="kpi-val" id="kpi_avdd" style="color:#dc2626;">3.30 V</div>
        <div class="kpi-sub" id="kpi_avdd_sub">門檻: 1.43V / 2.00V</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-lbl">U1 事件脈寬 t_OUT</div>
        <div class="kpi-val" id="kpi_tout" style="color:#2563eb;">99.98 ms</div>
        <div class="kpi-sub" id="kpi_tout_sub">Code 5 (÷32768, POL=0)</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-lbl">起點頻率 f_OUT(0)</div>
        <div class="kpi-val" id="kpi_f0" style="color:#0891b2;">56.009 kHz</div>
        <div class="kpi-sub" id="kpi_f0_sub">V_CTRL(0) = 0.157 V</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-lbl">終點頻率 f_OUT(終)</div>
        <div class="kpi-val" id="kpi_f1" style="color:#0284c7;">54.008 kHz</div>
        <div class="kpi-sub" id="kpi_f1_sub">Δf = -2.001 kHz</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-lbl">方波 Duty 與總週期</div>
        <div class="kpi-val" id="kpi_duty" style="color:#059669;">50.0% Duty</div>
        <div class="kpi-sub" id="kpi_cycles">共 5,494 個方波</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-lbl">總電流估算 (U1+U2)</div>
        <div class="kpi-val" id="kpi_icc" style="color:#7c3aed;">412 µA</div>
        <div class="kpi-sub" id="kpi_icc_sub">待機 ~128 µA</div>
      </div>
    </div>

    <!-- 3. DRC STATUS -->
    <div class="drc-box" id="drcBanner"></div>

    <!-- 4. LIVE 4-CH WAVEFORM OSCILLOSCOPE -->
    <section class="section-card">
      <div class="section-head">
        <h2 class="section-title">📈 即時微分方程四通道示波器</h2>
        <span id="cursorReadout" style="font-family:ui-monospace,'SF Mono',Consolas,monospace;font-size:0.78rem;font-weight:800;color:#1d4ed8;background:#eff6ff;padding:0.2rem 0.55rem;border-radius:0.35rem;border:1px solid #bfdbfe;">
          滑鼠移入波形讀取瞬時值
        </span>
      </div>
      <div class="canvas-wrap">
        <canvas id="waveCanvas"></canvas>
      </div>
    </section>

    <!-- 5. LIVE FORMULA BREAKDOWN -->
    <section class="section-card">
      <div class="section-head">
        <h2 class="section-title">🧮 規格書公式與即時變數代入明細</h2>
      </div>
      <div style="overflow-x:auto;">
        <table class="eng-table" id="formulaTable"></table>
      </div>
    </section>

  </main>
</div>

<script>
// ============================================================================
// 0. FONT SCALING (DEFAULT 21px = 1.5x of 14px) & SPLIT-PANE RESIZER
// ============================================================================
let currentBaseFontPx = 21;
function applyFontPx(px) {
  currentBaseFontPx = Math.max(14, Math.min(30, px));
  document.documentElement.style.setProperty("--base-font", currentBaseFontPx + "px");
  const mult = (currentBaseFontPx / 14.0).toFixed(2).replace(/\.00$/, ".0");
  document.getElementById("fontScaleBtn").textContent = `${mult}x (${currentBaseFontPx}px)`;
  drawWaveformCanvas(null);
}
function adjustFont(delta) { applyFontPx(currentBaseFontPx + delta); }
function resetFont() { applyFontPx(21); }

function togglePinTopology() {
  const card = document.getElementById("topoCard");
  const btn = document.getElementById("pinTopoBtn");
  card.classList.toggle("pinned");
  const isPinned = card.classList.contains("pinned");
  btn.classList.toggle("active-pin", isPinned);
  btn.textContent = isPinned ? "📌 已釘選拓樸於頂部 (點擊取消)" : "📌 釘選拓樸於右窗頂部";
}

// Draggable Column Splitter
(function initSplitter() {
  const splitter = document.getElementById("splitter");
  const wb = document.getElementById("workbench");
  let dragging = false;
  splitter.addEventListener("mousedown", e => {
    dragging = true;
    splitter.classList.add("dragging");
    document.body.style.cursor = "col-resize";
    e.preventDefault();
  });
  window.addEventListener("mousemove", e => {
    if (!dragging) return;
    const rect = wb.getBoundingClientRect();
    const pct = Math.max(28, Math.min(62, ((e.clientX - rect.left) / rect.width) * 100));
    document.documentElement.style.setProperty("--left-pane-w", pct.toFixed(1) + "%");
    drawWaveformCanvas(null);
  });
  window.addEventListener("mouseup", () => {
    if (!dragging) return;
    dragging = false;
    splitter.classList.remove("dragging");
    document.body.style.cursor = "";
  });
})();

// ============================================================================
// 1. E96 STANDARD SERIES & ADI DATASHEET DIVCODE TABLE
// ============================================================================
const E96_MANTISSAS = [
  100,102,105,107,110,113,115,118,121,124,127,130,133,137,140,143,147,150,154,158,162,165,169,174,
  178,182,187,191,196,200,205,210,215,221,226,232,237,243,249,255,261,267,274,280,287,294,301,309,
  316,324,332,340,348,357,365,374,383,392,402,412,422,432,442,453,464,475,487,499,511,523,536,549,
  562,576,590,604,619,634,649,665,681,698,715,732,750,768,787,806,825,845,866,887,909,931,953,976
];

const ALL_E96_KOHM = [];
for (let dec = -2; dec <= 4; dec++) {
  const scale = Math.pow(10, dec - 2);
  for (const m of E96_MANTISSAS) {
    ALL_E96_KOHM.push(+(m * scale).toPrecision(4));
  }
}

const ADI_DIV_TABLE = [
  [99999, 0],     // 0
  [976,   102],   // 1
  [976,   182],   // 2
  [1000,  280],   // 3
  [1000,  392],   // 4
  [1000,  523],   // 5
  [1000,  681],   // 6
  [1000,  887],   // 7
  [887,   1000],  // 8
  [681,   1000],  // 9
  [523,   1000],  // 10
  [392,   1000],  // 11
  [280,   1000],  // 12
  [182,   976],   // 13
  [102,   976],   // 14
  [0,     99999]  // 15
];

const LTC6993_NDIV = [1, 8, 64, 512, 4096, 32768, 262144, 2097152, 2097152, 262144, 32768, 4096, 512, 64, 8, 1];
const LTC6990_NDIV = [1, 2, 4, 8, 16, 32, 64, 128, 128, 64, 32, 16, 8, 4, 2, 1];

function snapE96(valK) {
  if (valK <= 0) return 0;
  if (valK >= 90000) return 99999;
  let best = ALL_E96_KOHM[0];
  let bestErr = Math.abs(Math.log(valK / best));
  for (const v of ALL_E96_KOHM) {
    const err = Math.abs(Math.log(valK / v));
    if (err < bestErr) { bestErr = err; best = v; }
  }
  return best;
}

function e96Neighbors(valK, span = 3) {
  if (valK <= 0) return [0];
  let bestIdx = 0;
  let bestErr = Infinity;
  for (let i = 0; i < ALL_E96_KOHM.length; i++) {
    const err = Math.abs(Math.log(valK / ALL_E96_KOHM[i]));
    if (err < bestErr) { bestErr = err; bestIdx = i; }
  }
  const res = [];
  for (let i = Math.max(0, bestIdx - span); i <= Math.min(ALL_E96_KOHM.length - 1, bestIdx + span); i++) {
    res.push(ALL_E96_KOHM[i]);
  }
  return res;
}

function fmtR(kOhm) {
  if (kOhm === 0) return "0 Ω";
  if (!isFinite(kOhm) || kOhm >= 90000) return "Open";
  if (kOhm >= 1000) return (kOhm / 1000).toFixed(2).replace(/\.00$/, ".0") + " MΩ";
  if (kOhm < 1) return (kOhm * 1000).toFixed(1).replace(/\.0$/, "") + " Ω";
  return (+kOhm.toPrecision(4)) + " kΩ";
}

function fmtTimeMs(ms) {
  if (ms < 0.1) return (ms * 1000).toFixed(2) + " µs";
  if (ms >= 1000) return (ms / 1000).toFixed(3) + " s";
  return ms.toFixed(2) + " ms";
}

// ============================================================================
// 2. BIND SLIDERS <-> NUMBER INPUTS & INDEPENDENT LEFT-PANE FOCUS
// ============================================================================
const PAIRED_CONTROLS = [
  "AVDD", "R_PU", "R_DB", "C_DB",
  "R1", "R2", "R_SET1a",
  "R_RAMP", "C_RAMP",
  "R3", "R4", "R_SET2", "R_VCO"
];

PAIRED_CONTROLS.forEach(id => {
  const inp = document.getElementById("inp_" + id);
  const sld = document.getElementById("sld_" + id);
  if (!inp || !sld) return;
  inp.addEventListener("input", () => {
    sld.value = inp.value;
    if (id === "R1" || id === "R2") document.getElementById("sel_div1_preset").value = "custom";
    if (id === "R3" || id === "R4") document.getElementById("sel_div2_preset").value = "custom";
    recalcAll();
  });
  sld.addEventListener("input", () => {
    inp.value = sld.value;
    if (id === "R1" || id === "R2") document.getElementById("sel_div1_preset").value = "custom";
    if (id === "R3" || id === "R4") document.getElementById("sel_div2_preset").value = "custom";
    recalcAll();
  });
});

["inp_R_SET1b", "inp_V_SET1", "inp_V_SET2", "inp_C1", "inp_C2", "inp_t_hold", "inp_t_bounce", "inp_C_LOAD", "inp_R_LOAD"].forEach(id => {
  const el = document.getElementById(id);
  if (el) el.addEventListener("input", recalcAll);
});

function setVal(id, val) {
  const inp = document.getElementById("inp_" + id);
  const sld = document.getElementById("sld_" + id);
  if (inp) inp.value = val;
  if (sld) sld.value = val;
}

function getVal(id, fallback = 0) {
  const el = document.getElementById("inp_" + id);
  if (!el) return fallback;
  const v = parseFloat(el.value);
  return isNaN(v) ? fallback : v;
}

function setAVDD(v) {
  setVal("AVDD", v.toFixed(2));
  if (document.getElementById("chk_auto_solve").checked) {
    solveFromTargets();
  } else {
    recalcAll();
  }
}

function snapInput(id) {
  const v = getVal(id, 0);
  if (v > 0 && v < 90000) setVal(id, snapE96(v));
  recalcAll();
}

function applyDivPreset(which, codeStr) {
  if (codeStr === "custom") return;
  const code = parseInt(codeStr, 10);
  const [rt, rb] = ADI_DIV_TABLE[code];
  if (which === 1) {
    setVal("R1", rt);
    setVal("R2", rb);
  } else {
    setVal("R3", rt);
    setVal("R4", rb);
  }
  recalcAll();
}

// Scroll ONLY the Left Pane when clicking a component on the Right Pane Topology!
function focusZone(panelId, ctrlId) {
  const paneLeft = document.getElementById("paneLeft");
  const panel = document.getElementById(panelId);
  const targetEl = (ctrlId && document.getElementById(ctrlId)) ? document.getElementById(ctrlId) : panel;
  if (paneLeft && targetEl) {
    const paneRect = paneLeft.getBoundingClientRect();
    const elRect = targetEl.getBoundingClientRect();
    const offset = (elRect.top - paneRect.top) + paneLeft.scrollTop - 60;
    paneLeft.scrollTo({ top: Math.max(0, offset), behavior: "smooth" });
  }
  if (panel) {
    panel.classList.add("flash");
    setTimeout(() => panel.classList.remove("flash"), 1100);
  }
  if (ctrlId) {
    const inp = document.querySelector("#" + ctrlId + " input[type='number']");
    if (inp) inp.focus({ preventScroll: true });
  }
}

// ============================================================================
// 3. PHYSICS & DATASHEET CALCULATION ENGINE
// ============================================================================
function decodeDivPin(R_top, R_bot) {
  let ratio = 0;
  let r_par = 0;
  const topOpen = (R_top >= 90000);
  const botOpen = (R_bot >= 90000);
  if (R_bot === 0 && !botOpen && R_top > 0) {
    ratio = 0.0;
    r_par = 0.0;
  } else if (R_top === 0 && !topOpen && R_bot > 0) {
    ratio = 1.0;
    r_par = 0.0;
  } else if (topOpen && !botOpen) {
    ratio = 0.0;
    r_par = R_bot;
  } else if (botOpen && !topOpen) {
    ratio = 1.0;
    r_par = R_top;
  } else if (R_top > 0 && R_bot > 0) {
    ratio = R_bot / (R_top + R_bot);
    r_par = (R_top * R_bot) / (R_top + R_bot);
  } else {
    ratio = 0.5;
    r_par = 0;
  }
  const code = Math.max(0, Math.min(15, Math.floor(ratio * 16.0)));
  const ideal = (code + 0.5) / 16.0;
  let errPct = (ratio - ideal) * 100.0;
  let windowOk = Math.abs(errPct) <= 1.501;
  if (code === 0 && ratio <= 0.03125 + 0.015) { windowOk = true; errPct = Math.max(0, (ratio - 0.03125) * 100); }
  if (code === 15 && ratio >= 0.96875 - 0.015) { windowOk = true; errPct = Math.min(0, (ratio - 0.96875) * 100); }
  return { ratio, r_par, code, ideal, errPct, windowOk };
}

let simCache = null;

function computeCircuitState() {
  const AVDD = Math.max(1.5, Math.min(6.0, getVal("AVDD", 3.30)));
  const R_PU = Math.max(0.1, getVal("R_PU", 100));
  const R_DB = Math.max(0.05, getVal("R_DB", 10));
  const C_DB = Math.max(0.0001, getVal("C_DB", 0.10));
  const t_hold_ms = Math.max(2, getVal("t_hold", 125));
  const t_bounce_ms = Math.max(0, getVal("t_bounce", 4.5));

  const u1_ver = parseInt(document.getElementById("sel_u1_ver").value, 10);
  const R1 = Math.max(0, getVal("R1", 1000));
  const R2 = Math.max(0, getVal("R2", 523));
  const R_SET1a = Math.max(1, getVal("R_SET1a", 150));
  const R_SET1b = Math.max(0, getVal("R_SET1b", 2.55));
  const R_SET1 = R_SET1a + R_SET1b;
  const V_SET1 = Math.max(0.8, Math.min(1.2, getVal("V_SET1", 1.000)));
  const C1 = Math.max(0.001, getVal("C1", 0.10));

  const useInv = document.getElementById("sel_inv").value === "1";
  const R_RAMP = Math.max(0.5, getVal("R_RAMP", 280));
  const C_RAMP = Math.max(0.0001, getVal("C_RAMP", 1.00));
  const C_LOAD = Math.max(0, getVal("C_LOAD", 15));
  const R_LOAD = Math.max(0.5, getVal("R_LOAD", 100));

  const R3 = Math.max(0, getVal("R3", 1000));
  const R4 = Math.max(0, getVal("R4", 392));
  const R_SET2 = Math.max(1, getVal("R_SET2", 57.6));
  const R_VCO = Math.max(1, getVal("R_VCO", 1500));
  const V_SET2 = Math.max(0.8, Math.min(1.2, getVal("V_SET2", 1.000)));
  const C2 = Math.max(0.001, getVal("C2", 0.10));

  const V_th_rise = 0.55 * AVDD + 0.185;
  const V_th_fall = 0.48 * AVDD - 0.155;
  const V_hys = V_th_rise - V_th_fall;
  const tau_press_ms = R_DB * C_DB;
  const tau_rel_ms = (R_PU + R_DB) * C_DB;
  const t_trig_delay_ms = tau_press_ms * Math.log(AVDD / Math.max(0.05, V_th_fall));
  const v_rel_bounce = AVDD * (1.0 - Math.exp(-Math.max(0.5, t_bounce_ms * 0.5) / tau_rel_ms));
  const releaseSafe = v_rel_bounce < V_th_rise;

  const div1 = decodeDivPin(R1, R2);
  const N_DIV1 = LTC6993_NDIV[div1.code];
  const POL1 = div1.code >= 8 ? 1 : 0;
  const I_SET1_uA = (V_SET1 / R_SET1) * 1000.0;
  const t_master1_us = R_SET1 / 50.0;
  const t_out_us = N_DIV1 * t_master1_us;
  const t_out_ms = t_out_us / 1000.0;
  const t_start1_ms = (500.0 * t_master1_us) / 1000.0;
  const u1_acc_max = N_DIV1 >= 512 ? 2.3 : (N_DIV1 >= 8 ? 3.4 : 4.9);

  const t_out_s = t_out_ms * 1e-3;
  let I_s1_idle_uA = 0;
  if (N_DIV1 <= 64) {
    I_s1_idle_uA = (AVDD * (N_DIV1 * 7e-12 + 4e-12) / t_out_s) * 1e6 + (AVDD / 500.0) * 1000.0 + 2.2 * I_SET1_uA + 50.0;
  } else {
    I_s1_idle_uA = (AVDD * (N_DIV1 * 7e-12) / t_out_s) * 1e6 + (AVDD / 500.0) * 1000.0 + 1.8 * I_SET1_uA + 50.0;
  }

  const gate_idle_V = (POL1 === 0) ? 0.0 : AVDD;
  const gate_active_V = (POL1 === 0) ? AVDD : 0.0;
  const drv_idle_V = useInv ? (AVDD - gate_idle_V) : gate_idle_V;
  const drv_active_V = useInv ? (AVDD - gate_active_V) : gate_active_V;

  const Rp_kOhm = (R_RAMP * R_VCO) / (R_RAMP + R_VCO);
  const tau_sweep_ms = Rp_kOhm * C_RAMP;
  const Vc0 = Rp_kOhm * (drv_idle_V / R_RAMP + V_SET2 / R_VCO);
  const VcInf = Rp_kOhm * (drv_active_V / R_RAMP + V_SET2 / R_VCO);
  const VcMid = VcInf + (Vc0 - VcInf) * Math.exp(-(0.5 * t_out_ms) / tau_sweep_ms);
  const VcEnd = VcInf + (Vc0 - VcInf) * Math.exp(-t_out_ms / tau_sweep_ms);

  const div2 = decodeDivPin(R3, R4);
  const N_DIV2 = LTC6990_NDIV[div2.code];
  const HiZ2 = div2.code >= 8 ? 1 : 0;

  function fFromVc(vc) {
    const iset_uA = (V_SET2 / R_SET2 + (V_SET2 - vc) / R_VCO) * 1000.0;
    if (iset_uA <= 0.5) return { f_khz: 0, f_master_khz: 0, iset_uA };
    const f_master_khz = 50000.0 * (iset_uA / 1000.0) / V_SET2;
    return { f_khz: f_master_khz / N_DIV2, f_master_khz, iset_uA };
  }

  const pt0 = fFromVc(Vc0);
  const ptMid = fFromVc(VcMid);
  const ptEnd = fFromVc(VcEnd);
  const ptInf = fFromVc(VcInf);

  const R_par_vco = (R_SET2 * R_VCO) / (R_SET2 + R_VCO);
  const f_0V_khz = 50000.0 / (N_DIV2 * R_par_vco);
  const K_vco_khz_per_V = 50000.0 / (N_DIV2 * V_SET2 * R_VCO);

  const f_lin_mid = 0.5 * (pt0.f_khz + ptEnd.f_khz);
  const nonlin_pct = f_lin_mid > 0 ? ((ptMid.f_khz - f_lin_mid) / f_lin_mid) * 100.0 : 0;
  const total_cycles = ptInf.f_khz * t_out_ms + (pt0.f_khz - ptInf.f_khz) * tau_sweep_ms * (1.0 - Math.exp(-t_out_ms / tau_sweep_ms));

  const max_vc_abs = Math.max(Math.abs(Vc0), Math.abs(VcEnd));
  const dvset_err_hz = K_vco_khz_per_V * 1000.0 * max_vc_abs * 0.03;

  const f_m_min = Math.min(pt0.f_master_khz, ptEnd.f_master_khz);
  const t_enable_max_us = f_m_min > 0 ? (N_DIV2 <= 2 ? 1000.0 / Math.min(pt0.f_khz, ptEnd.f_khz) : 2000.0 / f_m_min) : 0;

  const I_s2_idle_uA = AVDD * (pt0.f_master_khz * 1e3) * 7e-12 * 1e6 + (AVDD / 480.0) * 1000.0 + 1.75 * pt0.iset_uA + 50.0 + (useInv ? 2.0 : 0.0);
  const I_s2_act_uA = AVDD * (ptMid.f_master_khz * 1e3) * 7e-12 * 1e6
                    + AVDD * (ptMid.f_khz * 1e3) * ((13.0 + C_LOAD) * 1e-12) * 1e6
                    + (AVDD / 480.0) * 1000.0
                    + (AVDD / (2.0 * R_LOAD)) * 1000.0
                    + 1.75 * ptMid.iset_uA + 50.0 + (useInv ? 5.0 : 0.0);

  return {
    AVDD, R_PU, R_DB, C_DB, C1, C2, t_hold_ms, t_bounce_ms,
    u1_ver, R1, R2, R_SET1a, R_SET1b, R_SET1, V_SET1,
    useInv, R_RAMP, C_RAMP, C_LOAD, R_LOAD,
    R3, R4, R_SET2, R_VCO, V_SET2,
    V_th_rise, V_th_fall, V_hys, tau_press_ms, tau_rel_ms, t_trig_delay_ms, releaseSafe,
    div1, N_DIV1, POL1, I_SET1_uA, t_master1_us, t_out_ms, t_start1_ms, u1_acc_max, I_s1_idle_uA,
    gate_idle_V, gate_active_V, drv_idle_V, drv_active_V,
    Rp_kOhm, tau_sweep_ms, Vc0, VcMid, VcEnd, VcInf,
    div2, N_DIV2, HiZ2, pt0, ptMid, ptEnd, ptInf,
    f_0V_khz, K_vco_khz_per_V, nonlin_pct, total_cycles, dvset_err_hz, t_enable_max_us,
    I_s2_idle_uA, I_s2_act_uA
  };
}

// ============================================================================
// 4. TARGET SPECIFICATION -> AUTO RESISTOR SOLVER
// ============================================================================
function onTargetInput() {
  if (document.getElementById("chk_auto_solve").checked) {
    solveFromTargets();
  }
}

function solveFromTargets() {
  const AVDD = Math.max(2.25, Math.min(5.5, getVal("AVDD", 3.30)));
  const V_SET2 = getVal("V_SET2", 1.000);
  const t_target_ms = Math.max(0.002, Math.min(33000, parseFloat(document.getElementById("tgt_tout").value) || 100.0));
  const f_start = Math.max(0.5, Math.min(2000, parseFloat(document.getElementById("tgt_fstart").value) || 56.0));
  const f_end = Math.max(0.5, Math.min(2000, parseFloat(document.getElementById("tgt_fend").value) || 54.0));
  const snapMode = document.getElementById("tgt_snap").value;

  const t_us = t_target_ms * 1000.0;
  let bestDc1 = 7;
  for (let dc = 0; dc <= 7; dc++) {
    const ndiv = Math.pow(8, dc);
    const r_ideal = 50.0 * t_us / ndiv;
    if (r_ideal <= 800.0) { bestDc1 = dc; break; }
  }
  const ndiv1 = Math.pow(8, bestDc1);
  const r_set1_ideal = Math.max(25.0, Math.min(800.0, 50.0 * t_us / ndiv1));

  setVal("R1", ADI_DIV_TABLE[bestDc1][0]);
  setVal("R2", ADI_DIV_TABLE[bestDc1][1]);
  document.getElementById("sel_div1_preset").value = String(bestDc1);

  let r1a = r_set1_ideal, r1b = 0;
  if (snapMode === "exact") {
    r1a = +r_set1_ideal.toFixed(3);
    r1b = 0;
  } else if (snapMode === "e96_single") {
    r1a = snapE96(r_set1_ideal);
    r1b = 0;
  } else {
    let bestErr = Infinity;
    const mainCands = e96Neighbors(r_set1_ideal, 4);
    for (const ma of mainCands) {
      if (ma > r_set1_ideal) {
        const err = Math.abs(ma - r_set1_ideal);
        if (err < bestErr) { bestErr = err; r1a = ma; r1b = 0; }
      } else {
        const rem = r_set1_ideal - ma;
        const mb = rem < 0.05 ? 0 : snapE96(rem);
        const err = Math.abs(ma + mb - r_set1_ideal);
        if (err < bestErr) { bestErr = err; r1a = ma; r1b = mb; }
      }
    }
  }
  setVal("R_SET1a", r1a);
  document.getElementById("inp_R_SET1b").value = r1b;
  const t_actual_ms = (ndiv1 * (r1a + r1b) / 50.0) / 1000.0;

  const f_min = Math.min(f_start, f_end);
  const f_max = Math.max(f_start, f_end);
  let bestDc2 = 0;
  let foundRec = false;
  for (let dc = 7; dc >= 0; dc--) {
    const ndiv = Math.pow(2, dc);
    if (ndiv * f_min >= 62.5 && ndiv * f_max <= 1000.0) {
      bestDc2 = dc;
      foundRec = true;
      break;
    }
  }
  if (!foundRec) {
    for (let dc = 7; dc >= 0; dc--) {
      const ndiv = Math.pow(2, dc);
      if (ndiv * f_max <= 2000.0 && ndiv * f_min >= 30.0) { bestDc2 = dc; break; }
    }
  }
  const ndiv2 = Math.pow(2, bestDc2);
  setVal("R3", ADI_DIV_TABLE[bestDc2][0]);
  setVal("R4", ADI_DIV_TABLE[bestDc2][1]);
  document.getElementById("sel_div2_preset").value = String(bestDc2);

  const needUpSweep = f_end > f_start + 1e-4;
  document.getElementById("sel_inv").value = needUpSweep ? "1" : "0";
  const V_idle = needUpSweep ? AVDD : 0.0;
  const V_active = needUpSweep ? 0.0 : AVDD;

  const STD_CAPS = [0.001, 0.0022, 0.0047, 0.01, 0.022, 0.047, 0.10, 0.22, 0.47, 1.00, 2.20, 4.70, 10.0, 22.0, 47.0];

  if (Math.abs(f_start - f_end) < 0.005) {
    const r_set2_ideal = 50000.0 / (ndiv2 * f_start);
    setVal("R_SET2", snapMode === "exact" ? +r_set2_ideal.toFixed(3) : snapE96(r_set2_ideal));
    setVal("R_VCO", 10000);
    recalcAll();
    return;
  }

  let solved = null;
  for (const tauRatio of [2.4, 1.6, 1.0, 0.65, 0.4]) {
    const target_tau_ms = t_actual_ms * tauRatio;
    let bestCap = 1.0;
    let bestCapScore = Infinity;
    for (const c of STD_CAPS) {
      const r_est = target_tau_ms / c;
      if (r_est >= 15.0 && r_est <= 680.0) {
        const sc = Math.abs(Math.log(r_est / 220.0));
        if (sc < bestCapScore) { bestCapScore = sc; bestCap = c; }
      }
    }
    let R_ramp = snapMode === "exact" ? +(target_tau_ms / bestCap).toFixed(2) : snapE96(target_tau_ms / bestCap);
    let R_vco = 1000.0;
    let ok = true;
    for (let iter = 0; iter < 35; iter++) {
      const Rp = (R_ramp * R_vco) / (R_ramp + R_vco);
      const tau = Rp * bestCap;
      const Vc0 = Rp * (V_idle / R_ramp + V_SET2 / R_vco);
      const VcInf = Rp * (V_active / R_ramp + V_SET2 / R_vco);
      const VcEnd = VcInf + (Vc0 - VcInf) * Math.exp(-t_actual_ms / tau);
      const dVc = VcEnd - Vc0;
      const df = f_start - f_end;
      R_vco = (50000.0 / ndiv2) * (dVc / (V_SET2 * df));
      if (!isFinite(R_vco) || R_vco <= 5.0) { ok = false; break; }
    }
    if (!ok) continue;
    const Rp = (R_ramp * R_vco) / (R_ramp + R_vco);
    const Vc0 = Rp * (V_idle / R_ramp + V_SET2 / R_vco);
    const inv_Rset2 = (f_start * ndiv2) / 50000.0 - (1.0 - Vc0 / V_SET2) / R_vco;
    if (inv_Rset2 <= 1.0 / 900.0) continue;
    const R_set2 = 1.0 / inv_Rset2;
    if (R_set2 >= 22.0 && R_set2 <= 850.0 && R_vco >= 15.0 && R_vco <= 15000.0) {
      solved = { C_ramp: bestCap, R_ramp, R_set2, R_vco };
      break;
    }
  }

  if (solved) {
    if (snapMode === "exact") {
      setVal("C_RAMP", solved.C_ramp);
      setVal("R_RAMP", +solved.R_ramp.toFixed(2));
      setVal("R_SET2", +solved.R_set2.toFixed(3));
      setVal("R_VCO", +solved.R_vco.toFixed(1));
    } else {
      const cands_rr = e96Neighbors(solved.R_ramp, 3);
      const cands_rs = e96Neighbors(solved.R_set2, 2);
      const cands_rv = e96Neighbors(solved.R_vco, 3);
      let bestCombo = [snapE96(solved.R_ramp), snapE96(solved.R_set2), snapE96(solved.R_vco)];
      let minCost = Infinity;
      for (const rr of cands_rr) {
        for (const rv of cands_rv) {
          const Rp = (rr * rv) / (rr + rv);
          const tau = Rp * solved.C_ramp;
          const Vc0 = Rp * (V_idle / rr + V_SET2 / rv);
          const VcInf = Rp * (V_active / rr + V_SET2 / rv);
          const VcEnd = VcInf + (Vc0 - VcInf) * Math.exp(-t_actual_ms / tau);
          for (const rs of cands_rs) {
            const f0 = (50000.0 / ndiv2) * (1.0 / rs + (1.0 - Vc0 / V_SET2) / rv);
            const f1 = (50000.0 / ndiv2) * (1.0 / rs + (1.0 - VcEnd / V_SET2) / rv);
            const cost = Math.abs(f0 - f_start) + Math.abs(f1 - f_end);
            if (cost < minCost) { minCost = cost; bestCombo = [rr, rs, rv]; }
          }
        }
      }
      setVal("C_RAMP", solved.C_ramp);
      setVal("R_RAMP", bestCombo[0]);
      setVal("R_SET2", bestCombo[1]);
      setVal("R_VCO", bestCombo[2]);
    }
  }
  recalcAll();
}

function loadPreset(mode) {
  setVal("AVDD", "3.30");
  setVal("R_PU", 100);
  setVal("R_DB", 10);
  setVal("C_DB", "0.10");
  document.getElementById("inp_C1").value = "0.10";
  document.getElementById("inp_C2").value = "0.10";
  document.getElementById("inp_t_hold").value = 125;
  document.getElementById("inp_t_bounce").value = 4.5;
  document.getElementById("sel_u1_ver").value = "3";
  document.getElementById("inp_V_SET1").value = "1.000";
  document.getElementById("inp_V_SET2").value = "1.000";
  document.getElementById("tgt_tout").value = "100.0";
  document.getElementById("tgt_snap").value = "e96_dual";

  if (mode === "up") {
    document.getElementById("tgt_fstart").value = "54.0";
    document.getElementById("tgt_fend").value = "56.0";
    solveFromTargets();
  } else {
    document.getElementById("tgt_fstart").value = "56.0";
    document.getElementById("tgt_fend").value = "54.0";
    setVal("R1", 1000); setVal("R2", 523); document.getElementById("sel_div1_preset").value = "5";
    setVal("R_SET1a", 150); document.getElementById("inp_R_SET1b").value = "2.55";
    document.getElementById("sel_inv").value = "0";
    setVal("R_RAMP", 280); setVal("C_RAMP", "1.00");
    setVal("R3", 1000); setVal("R4", 392); document.getElementById("sel_div2_preset").value = "4";
    setVal("R_SET2", 57.6); setVal("R_VCO", 1500);
    recalcAll();
  }
}

// ============================================================================
// 5. 1.5x ENLARGED DYNAMIC SPLINE SVG TOPOLOGY RENDERER ("雲形線")
// ============================================================================
function zigzagPath(x1, y1, x2, y2, orient) {
  const n = 16;
  let d = "";
  for (let i = 0; i <= n; i++) {
    const t = i / n;
    let bx = x1 + (x2 - x1) * t;
    let by = y1 + (y2 - y1) * t;
    if (i >= 3 && i <= 13) {
      const amp = (i % 2 === 1) ? 9.5 : -9.5;
      if (orient === "v") bx += amp; else by += amp;
    }
    d += (i === 0 ? `M ${bx.toFixed(1)} ${by.toFixed(1)}` : ` L ${bx.toFixed(1)} ${by.toFixed(1)}`);
  }
  return d;
}

const Y_TOP = 935;
const sy = y => (Y_TOP - y).toFixed(1);

function cubicHermiteSvg(pA, dA, pB, dB, tension = 0.44) {
  const dist = Math.hypot(pB[0] - pA[0], pB[1] - pA[1]);
  const L = Math.max(12, dist * tension);
  const c1x = pA[0] + dA[0] * L, c1y = pA[1] + dA[1] * L;
  const c2x = pB[0] + dB[0] * L, c2y = pB[1] + dB[1] * L;
  return `M ${pA[0]} ${sy(pA[1])} C ${c1x.toFixed(1)} ${sy(c1y)}, ${c2x.toFixed(1)} ${sy(c2y)}, ${pB[0]} ${sy(pB[1])}`;
}

function catmullRomSvg(pts) {
  if (pts.length < 2) return "";
  let d = `M ${pts[0][0]} ${sy(pts[0][1])}`;
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[Math.max(0, i - 1)];
    const p1 = pts[i];
    const p2 = pts[i + 1];
    const p3 = pts[Math.min(pts.length - 1, i + 2)];
    const c1x = p1[0] + (p2[0] - p0[0]) / 6.0;
    const c1y = p1[1] + (p2[1] - p0[1]) / 6.0;
    const c2x = p2[0] - (p3[0] - p1[0]) / 6.0;
    const c2y = p2[1] - (p3[1] - p1[1]) / 6.0;
    d += ` C ${c1x.toFixed(1)} ${sy(c1y)}, ${c2x.toFixed(1)} ${sy(c2y)}, ${p2[0]} ${sy(p2[1])}`;
  }
  return d;
}

function renderSplineSchematicSVG(st) {
  const avddTxt = `AVDD ${st.AVDD.toFixed(2)}V`;
  const rset1Txt = st.R_SET1b > 0 ? `${fmtR(st.R_SET1a)}+${fmtR(st.R_SET1b)}` : fmtR(st.R_SET1a);
  const u1Part = `LTC6993-${st.u1_ver}`;
  const sweepTxt = `${st.pt0.f_khz.toFixed(2)}→${st.ptEnd.f_khz.toFixed(2)}kHz`;

  // 1.5x SVG Typography (~16.5px ~ 19.5px)
  function drawResV(x, yt, yb, ref, val, side, zoneId, ctrlId) {
    const d = zigzagPath(x, Y_TOP - yt, x, Y_TOP - yb, "v");
    const ym = Y_TOP - 0.5 * (yt + yb);
    const tx = side === "left" ? x - 16 : x + 16;
    const anchor = side === "left" ? "end" : "start";
    return `<g class="svg-clickable" onclick="focusZone('${zoneId}','${ctrlId}')">
      <path d="${d}" fill="none" stroke="#1e293b" stroke-width="2.6" stroke-linecap="round"/>
      <text x="${tx}" y="${ym - 4}" text-anchor="${anchor}" font-size="16.5" font-weight="800" fill="#0f172a">${ref}</text>
      <text x="${tx}" y="${ym + 16}" text-anchor="${anchor}" font-size="15.5" font-weight="800" fill="#1d4ed8">${val}</text>
    </g>`;
  }

  function drawResH(xl, xr, y, ref, val, zoneId, ctrlId) {
    const d = zigzagPath(xl, Y_TOP - y, xr, Y_TOP - y, "h");
    const xm = 0.5 * (xl + xr);
    const ys = Y_TOP - y;
    return `<g class="svg-clickable" onclick="focusZone('${zoneId}','${ctrlId}')">
      <path d="${d}" fill="none" stroke="#1e293b" stroke-width="2.6" stroke-linecap="round"/>
      <text x="${xm}" y="${ys - 16}" text-anchor="middle" font-size="16.5" font-weight="800" fill="#0f172a">${ref}</text>
      <text x="${xm}" y="${ys + 27}" text-anchor="middle" font-size="15.5" font-weight="800" fill="#1d4ed8">${val}</text>
    </g>`;
  }

  function drawCapV(x, yt, yb, ref, val, side, zoneId, ctrlId) {
    const yts = Y_TOP - yt, ybs = Y_TOP - yb, ym = 0.5 * (yts + ybs);
    const tx = side === "left" ? x - 21 : x + 21;
    const anchor = side === "left" ? "end" : "start";
    return `<g class="svg-clickable" onclick="focusZone('${zoneId}','${ctrlId}')">
      <line x1="${x}" y1="${yts}" x2="${x}" y2="${ym - 6}" stroke="#1e293b" stroke-width="2.5"/>
      <line x1="${x}" y1="${ym + 6}" x2="${x}" y2="${ybs}" stroke="#1e293b" stroke-width="2.5"/>
      <line x1="${x - 16}" y1="${ym - 6}" x2="${x + 16}" y2="${ym - 6}" stroke="#1e293b" stroke-width="3.2"/>
      <line x1="${x - 16}" y1="${ym + 6}" x2="${x + 16}" y2="${ym + 6}" stroke="#1e293b" stroke-width="3.2"/>
      <text x="${tx}" y="${ym - 3}" text-anchor="${anchor}" font-size="16" font-weight="800" fill="#0f172a">${ref}</text>
      <text x="${tx}" y="${ym + 16}" text-anchor="${anchor}" font-size="15.5" font-weight="800" fill="#1d4ed8">${val}</text>
    </g>`;
  }

  function drawVcc(x, yBar, yPin) {
    return `<g class="svg-clickable" onclick="document.getElementById('inp_AVDD').focus()">
      <line x1="${x}" y1="${sy(yPin)}" x2="${x}" y2="${sy(yBar)}" stroke="#dc2626" stroke-width="2.6"/>
      <line x1="${x - 18}" y1="${sy(yBar)}" x2="${x + 18}" y2="${sy(yBar)}" stroke="#dc2626" stroke-width="3.6"/>
      <text x="${x}" y="${Y_TOP - yBar - 9}" text-anchor="middle" font-size="16" font-weight="800" fill="#dc2626">${avddTxt}</text>
    </g>`;
  }

  function drawGnd(x, yBar, yPin) {
    const yb = Y_TOP - yBar;
    return `<g>
      <line x1="${x}" y1="${sy(yPin)}" x2="${x}" y2="${yb}" stroke="#475569" stroke-width="2.4"/>
      <line x1="${x - 15}" y1="${yb}" x2="${x + 15}" y2="${yb}" stroke="#475569" stroke-width="2.6"/>
      <line x1="${x - 10}" y1="${yb + 6}" x2="${x + 10}" y2="${yb + 6}" stroke="#475569" stroke-width="2.6"/>
      <line x1="${x - 4.5}" y1="${yb + 12}" x2="${x + 4.5}" y2="${yb + 12}" stroke="#475569" stroke-width="2.6"/>
    </g>`;
  }

  function drawIC6(bx, by, bw, bh, ref, part, badge1, badge2, pins, zoneId) {
    const yTop = Y_TOP - (by + bh);
    const yBot = Y_TOP - by;
    let pHtml = "";
    for (const p of pins) {
      const [px, py, sx, sy_cart, name, num, side] = p;
      const ys = parseFloat(sy(py));
      const tx = side === "L" ? sx + 10 : sx - 10;
      const nx = side === "L" ? sx - 9 : sx + 9;
      const tAnchor = side === "L" ? "start" : "end";
      const nAnchor = side === "L" ? "end" : "start";
      pHtml += `<line x1="${px}" y1="${ys}" x2="${sx}" y2="${ys}" stroke="#1e293b" stroke-width="2.6"/>
        <text x="${tx}" y="${ys + 5.5}" text-anchor="${tAnchor}" font-size="16.5" font-weight="800" fill="#0f172a">${name}</text>
        <text x="${nx}" y="${ys - 6}" text-anchor="${nAnchor}" font-size="14.5" font-weight="800" fill="#64748b">${num}</text>`;
    }
    // Status pill placed cleanly directly underneath the IC body (open empty space!)
    return `<g class="svg-clickable" onclick="focusZone('${zoneId}')">
      <rect x="${bx}" y="${yTop}" width="${bw}" height="${bh}" rx="9" fill="#fefce8" stroke="#1e293b" stroke-width="2.8"/>
      <circle cx="${bx + 15}" cy="${yTop + 15}" r="4.8" fill="#1e293b"/>
      <text x="${bx + bw/2}" y="${yTop - 11}" text-anchor="middle" font-size="19" font-weight="800" fill="#0f172a">${ref} : ${part}</text>
      <rect x="${bx - 6}" y="${yBot + 10}" width="${bw + 12}" height="52" rx="7" fill="#fef9c3" stroke="#eab308" stroke-width="1.4"/>
      <text class="no-halo" x="${bx + bw/2}" y="${yBot + 32}" text-anchor="middle" font-size="15.5" font-weight="800" fill="#713f12">${badge1}</text>
      <text class="no-halo" x="${bx + bw/2}" y="${yBot + 52}" text-anchor="middle" font-size="14.5" font-weight="800" fill="#854d0e">${badge2}</text>
      ${pHtml}
    </g>`;
  }

  const wires = [
    // Zone 1
    { d: cubicHermiteSvg([145,765],[0,-1],[145,735],[0,1]), c: "#dc2626", w: 2.6 },
    { d: cubicHermiteSvg([145,650],[0,-1],[145,622],[0,1]), c: "#d97706", w: 2.6 },
    { d: cubicHermiteSvg([145,580],[0,1],[145,622],[0,-1]), c: "#d97706", w: 2.6 },
    { d: cubicHermiteSvg([145,622],[1,0],[210,650],[-1,0],0.48), c: "#d97706", w: 2.6 },
    { d: cubicHermiteSvg([290,650],[1,0],[340,650],[-1,0]), c: "#d97706", w: 2.6 },
    { d: cubicHermiteSvg([340,585],[0,1],[340,650],[0,-1]), c: "#d97706", w: 2.6 },
    { d: catmullRomSvg([[340,650],[380,662],[415,640],[450,650]]), c: "#d97706", w: 2.8 },
    // Zone 2
    { d: cubicHermiteSvg([450,570],[-1,0],[408,540],[0,1],0.5), c: "#475569", w: 2.5 },
    { d: cubicHermiteSvg([450,490],[-1,0],[425,400],[0,1],0.45), c: "#7c3aed", w: 2.6 },
    { d: cubicHermiteSvg([800,638],[0,-1],[800,610],[0,1]), c: "#dc2626", w: 2.6 },
    { d: cubicHermiteSvg([695,570],[1,0],[800,610],[-1,0],0.45), c: "#dc2626", w: 2.6 },
    { d: cubicHermiteSvg([800,610],[-0.6,-0.8],[768,585],[0,1],0.4), c: "#dc2626", w: 2.6 },
    { d: cubicHermiteSvg([800,610],[0.8,-0.5],[832,545],[0,1],0.45), c: "#dc2626", w: 2.6 },
    { d: catmullRomSvg([[695,490],[732,482],[768,490]]), c: "#059669", w: 2.6 },
    { d: cubicHermiteSvg([768,505],[0,-1],[768,490],[0,1]), c: "#059669", w: 2.5 },
    { d: cubicHermiteSvg([768,450],[0,1],[768,490],[0,-1]), c: "#059669", w: 2.5 },
    // NET_GATE
    { d: catmullRomSvg([[695,650],[730,670],[795,745],[875,758],[935,750]]), c: "#2563eb", w: 3.2 },
    { d: catmullRomSvg([[935,750],[1010,754],[1092,720],[1146,662],[1180,650]]), c: "#2563eb", w: 3.2 },
    ...(st.useInv ? [
      { d: catmullRomSvg([[935,750],[918,706],[914,652]]), c: "#2563eb", w: 2.8 },
      { d: catmullRomSvg([[914,565],[908,515],[925,490]]), c: "#9333ea", w: 2.8 }
    ] : [
      { d: catmullRomSvg([[935,750],[920,680],[906,575],[910,505],[925,490]]), c: "#2563eb", w: 2.8 }
    ]),
    // Zone 3 V_CTRL & SET2
    { d: cubicHermiteSvg([1005,490],[1,0],[1034,490],[-1,0]), c: "#9333ea", w: 2.8 },
    { d: cubicHermiteSvg([1034,415],[0,1],[1034,490],[0,-1]), c: "#9333ea", w: 2.8 },
    { d: cubicHermiteSvg([1034,490],[1,0],[1058,490],[-1,0]), c: "#9333ea", w: 2.8 },
    { d: cubicHermiteSvg([1138,490],[1,0],[1160,490],[-1,0]), c: "#7c3aed", w: 2.8 },
    { d: cubicHermiteSvg([1160,400],[0,1],[1160,490],[0,-1]), c: "#7c3aed", w: 2.6 },
    { d: cubicHermiteSvg([1160,490],[1,0],[1180,490],[-1,0]), c: "#7c3aed", w: 2.8 },
    // Zone 4
    { d: cubicHermiteSvg([1180,570],[-1,0],[1142,545],[0,1],0.5), c: "#475569", w: 2.5 },
    { d: cubicHermiteSvg([1522,638],[0,-1],[1522,610],[0,1]), c: "#dc2626", w: 2.6 },
    { d: cubicHermiteSvg([1425,570],[1,0],[1522,610],[-1,0],0.45), c: "#dc2626", w: 2.6 },
    { d: cubicHermiteSvg([1522,610],[-0.6,-0.8],[1490,585],[0,1],0.4), c: "#dc2626", w: 2.6 },
    { d: cubicHermiteSvg([1522,610],[0.8,-0.5],[1570,545],[0,1],0.45), c: "#dc2626", w: 2.6 },
    { d: catmullRomSvg([[1425,490],[1456,482],[1490,490]]), c: "#059669", w: 2.6 },
    { d: cubicHermiteSvg([1490,505],[0,-1],[1490,490],[0,1]), c: "#059669", w: 2.5 },
    { d: cubicHermiteSvg([1490,450],[0,1],[1490,490],[0,-1]), c: "#059669", w: 2.5 },
    { d: catmullRomSvg([[1425,650],[1458,662],[1490,730],[1530,742]]), c: "#0891b2", w: 3.4 },
    // GND stubs
    { d: cubicHermiteSvg([145,490],[0,-1],[145,465],[0,1]), c: "#475569", w: 2.4 },
    { d: cubicHermiteSvg([340,525],[0,-1],[340,495],[0,1]), c: "#475569", w: 2.4 },
    { d: cubicHermiteSvg([425,320],[0,-1],[425,290],[0,1]), c: "#475569", w: 2.4 },
    { d: cubicHermiteSvg([768,370],[0,-1],[768,340],[0,1]), c: "#475569", w: 2.4 },
    { d: cubicHermiteSvg([832,485],[0,-1],[832,455],[0,1]), c: "#475569", w: 2.4 },
    { d: cubicHermiteSvg([1034,355],[0,-1],[1034,325],[0,1]), c: "#475569", w: 2.4 },
    { d: cubicHermiteSvg([1160,320],[0,-1],[1160,290],[0,1]), c: "#475569", w: 2.4 },
    { d: cubicHermiteSvg([1490,370],[0,-1],[1490,340],[0,1]), c: "#475569", w: 2.4 },
    { d: cubicHermiteSvg([1570,485],[0,-1],[1570,455],[0,1]), c: "#475569", w: 2.4 },
  ];

  const junctions = [
    [145,622,"#d97706"], [340,650,"#d97706"], [800,610,"#dc2626"], [768,490,"#059669"],
    [935,750,"#2563eb"], [1034,490,"#9333ea"], [1160,490,"#7c3aed"], [1522,610,"#dc2626"], [1490,490,"#059669"]
  ];

  let wireSvg = wires.map(w =>
    `<path d="${w.d}" stroke="#ffffff" stroke-width="${w.w + 2.8}" fill="none" stroke-linecap="round"/>` +
    `<path class="spline-wire" d="${w.d}" stroke="${w.c}" stroke-width="${w.w}"/>`
  ).join("");

  let juncSvg = junctions.map(([jx, jy, jc]) =>
    `<circle cx="${jx}" cy="${sy(jy)}" r="5.5" fill="${jc}" stroke="#fff" stroke-width="1.5"/>`
  ).join("");

  let invSvg = "";
  if (st.useInv) {
    const yTopInv = Y_TOP - 652;
    const yBotInv = Y_TOP - 578;
    invSvg = `<g class="svg-clickable" onclick="focusZone('panel_z3','ctrl_INV')">
      <polygon points="894,${yTopInv} 934,${yTopInv} 914,${yBotInv - 10}" fill="#ede9fe" stroke="#6d28d9" stroke-width="2.5"/>
      <circle cx="914" cy="${yBotInv - 4}" r="5.5" fill="#fff" stroke="#6d28d9" stroke-width="2.5"/>
      <text x="940" y="${yTopInv + 28}" font-size="15.5" font-weight="800" fill="#5b21b6">1G04</text>
    </g>`;
  }

  const swY1 = Y_TOP - 562, swY2 = Y_TOP - 508, swYm = 0.5 * (swY1 + swY2);
  const swSvg = `<g class="svg-clickable" onclick="focusZone('panel_z1')">
    <line x1="145" y1="${sy(580)}" x2="145" y2="${swY1}" stroke="#1e293b" stroke-width="2.5"/>
    <line x1="145" y1="${swY2}" x2="145" y2="${sy(490)}" stroke="#1e293b" stroke-width="2.5"/>
    <circle cx="145" cy="${swY1}" r="5.2" fill="#fff" stroke="#1e293b" stroke-width="2.3"/>
    <circle cx="145" cy="${swY2}" r="5.2" fill="#fff" stroke="#1e293b" stroke-width="2.3"/>
    <line x1="126" y1="${swY1 - 3}" x2="126" y2="${swY2 + 3}" stroke="#0284c7" stroke-width="2.8"/>
    <line x1="126" y1="${swYm}" x2="112" y2="${swYm}" stroke="#0284c7" stroke-width="2.8"/>
    <line x1="112" y1="${swYm - 10}" x2="112" y2="${swYm + 10}" stroke="#0284c7" stroke-width="3.6"/>
    <text x="104" y="${swYm - 3}" text-anchor="end" font-size="16.5" font-weight="800" fill="#0f172a">SW1</text>
    <text x="104" y="${swYm + 16}" text-anchor="end" font-size="14.5" font-weight="700" fill="#475569">按鈕</text>
  </g>`;

  const pyOut = parseFloat(sy(742));
  const portSvg = `<g class="svg-clickable" onclick="focusZone('panel_z4')">
    <polygon points="1530,${pyOut} 1550,${pyOut-18} 1695,${pyOut-18} 1712,${pyOut} 1695,${pyOut+18} 1550,${pyOut+18}"
             fill="#e0f2fe" stroke="#0284c7" stroke-width="2.6"/>
    <text class="no-halo" x="1622" y="${pyOut + 6}" text-anchor="middle" font-size="17" font-weight="800" fill="#0369a1">FM_OUT</text>
    <text x="1622" y="${pyOut + 39}" text-anchor="middle" font-size="16" font-weight="800" fill="#0f172a">${sweepTxt}</text>
    <text x="1622" y="${pyOut + 59}" text-anchor="middle" font-size="15" font-weight="800" fill="#059669">50% Duty (${st.AVDD.toFixed(1)}V)</text>
  </g>`;

  const svg = `<svg viewBox="15 20 1715 725">
    <defs>
      <pattern id="gridPat" width="32" height="32" patternUnits="userSpaceOnUse">
        <path d="M 32 0 L 0 0 0 32" fill="none" stroke="#f1f5f9" stroke-width="1"/>
      </pattern>
    </defs>
    <rect x="15" y="20" width="1715" height="725" fill="url(#gridPat)"/>

    <!-- Zone Dashed Frames -->
    <rect x="26" y="32" width="356" height="685" rx="10" fill="#f8fafc" fill-opacity="0.55" stroke="#cbd5e1" stroke-dasharray="6,4"/>
    <text x="204" y="58" text-anchor="middle" font-size="16.5" font-weight="800" fill="#334155">Zone 1：按鈕與除彈跳</text>

    <rect x="392" y="32" width="500" height="685" rx="10" fill="#f8fafc" fill-opacity="0.55" stroke="#cbd5e1" stroke-dasharray="6,4"/>
    <text x="642" y="58" text-anchor="middle" font-size="16.5" font-weight="800" fill="#334155">Zone 2：單穩態視窗 (÷${st.N_DIV1})</text>

    <rect x="900" y="32" width="248" height="685" rx="10" fill="#f8fafc" fill-opacity="0.55" stroke="#cbd5e1" stroke-dasharray="6,4"/>
    <text x="1024" y="58" text-anchor="middle" font-size="16.5" font-weight="800" fill="#334155">Zone 3：調頻斜坡</text>

    <rect x="1156" y="32" width="564" height="685" rx="10" fill="#f8fafc" fill-opacity="0.55" stroke="#cbd5e1" stroke-dasharray="6,4"/>
    <text x="1438" y="58" text-anchor="middle" font-size="16.5" font-weight="800" fill="#334155">Zone 4：壓控方波 VCO (÷${st.N_DIV2})</text>

    <!-- Spline Wires -->
    ${wireSvg}
    ${juncSvg}
    ${invSvg}

    <!-- Zone 1 -->
    ${drawVcc(145, 785, 765)}
    ${drawResV(145, 735, 650, "R_PU", fmtR(st.R_PU), "left", "panel_z1", "ctrl_R_PU")}
    ${swSvg}
    ${drawGnd(145, 445, 465)}
    ${drawResH(210, 290, 650, "R_DB", fmtR(st.R_DB), "panel_z1", "ctrl_R_DB")}
    ${drawCapV(340, 585, 525, "C_DB", st.C_DB.toFixed(2) + " µF", "left", "panel_z1", "ctrl_C_DB")}
    ${drawGnd(340, 475, 495)}

    <!-- Zone 2 -->
    ${drawIC6(480, 445, 185, 250, "U1", u1Part,
      `t_OUT = ${fmtTimeMs(st.t_out_ms)}`,
      `Code ${st.div1.code} (POL=${st.POL1})`,
      [
        [450,650,480,650,"TRIG","1","L"], [450,570,480,570,"GND","2","L"], [450,490,480,490,"SET","3","L"],
        [695,650,665,650,"OUT","6","R"],  [695,570,665,570,"V+","5","R"],  [695,490,665,490,"DIV","4","R"]
      ], "panel_z2")}
    ${drawGnd(408, 520, 540)}
    ${drawResV(425, 400, 320, "R_SET1", rset1Txt, "left", "panel_z2", "ctrl_R_SET1")}
    ${drawGnd(425, 270, 290)}
    ${drawVcc(800, 658, 638)}
    ${drawResV(768, 585, 505, "R1", fmtR(st.R1), "left", "panel_z2", "ctrl_R1")}
    ${drawResV(768, 450, 370, "R2", fmtR(st.R2), "left", "panel_z2", "ctrl_R2")}
    ${drawGnd(768, 320, 340)}
    ${drawCapV(832, 545, 485, "C1", st.C1.toFixed(2) + " µF", "right", "panel_z2", "ctrl_C1")}
    ${drawGnd(832, 435, 455)}

    <!-- Zone 3 -->
    ${drawResH(925, 1005, 490, "R_RAMP", fmtR(st.R_RAMP), "panel_z3", "ctrl_R_RAMP")}
    ${drawCapV(1034, 415, 355, "C_RAMP", st.C_RAMP.toFixed(2) + " µF", "left", "panel_z3", "ctrl_C_RAMP")}
    ${drawGnd(1034, 305, 325)}
    ${drawResH(1058, 1138, 490, "R_VCO", fmtR(st.R_VCO), "panel_z4", "ctrl_R_VCO")}

    <!-- Zone 4 -->
    ${drawIC6(1210, 445, 185, 250, "U2", "LTC6990",
      `${st.pt0.f_khz.toFixed(1)}~${st.ptEnd.f_khz.toFixed(1)} kHz`,
      `Code ${st.div2.code} (Hi-Z=${st.HiZ2})`,
      [
        [1180,650,1210,650,"OE","1","L"],  [1180,570,1210,570,"GND","2","L"], [1180,490,1210,490,"SET","3","L"],
        [1425,650,1395,650,"OUT","6","R"], [1425,570,1395,570,"V+","5","R"],  [1425,490,1395,490,"DIV","4","R"]
      ], "panel_z4")}
    ${drawGnd(1142, 525, 545)}
    ${drawResV(1160, 400, 320, "R_SET2", fmtR(st.R_SET2), "right", "panel_z4", "ctrl_R_SET2")}
    ${drawGnd(1160, 270, 290)}
    ${drawVcc(1522, 658, 638)}
    ${drawResV(1490, 585, 505, "R3", fmtR(st.R3), "left", "panel_z4", "ctrl_R3")}
    ${drawResV(1490, 450, 370, "R4", fmtR(st.R4), "left", "panel_z4", "ctrl_R4")}
    ${drawGnd(1490, 320, 340)}
    ${drawCapV(1570, 545, 485, "C2", st.C2.toFixed(2) + " µF", "right", "panel_z4", "ctrl_C2")}
    ${drawGnd(1570, 435, 455)}
    ${portSvg}

    <!-- Live Enlarged Net Callout Pills -->
    <g transform="translate(1015, ${sy(785)})">
      <rect x="-145" y="-18" width="290" height="34" rx="7" fill="#eff6ff" stroke="#2563eb" stroke-width="1.8"/>
      <text class="no-halo" x="0" y="5" text-anchor="middle" font-size="15.5" font-weight="800" fill="#1d4ed8">GATE: ${fmtTimeMs(st.t_out_ms)} @ ${st.AVDD.toFixed(2)}V</text>
    </g>
    <g transform="translate(1034, ${sy(565)})">
      <rect x="-82" y="-22" width="164" height="44" rx="7" fill="#faf5ff" stroke="#9333ea" stroke-width="1.6"/>
      <text class="no-halo" x="0" y="-3" text-anchor="middle" font-size="14.5" font-weight="800" fill="#7e22ce">V_CTRL(t)</text>
      <text class="no-halo" x="0" y="16" text-anchor="middle" font-size="14.5" font-weight="800" fill="#6b21a8">${st.Vc0.toFixed(2)}V → ${st.VcEnd.toFixed(2)}V</text>
    </g>
  </svg>`;

  document.getElementById("svgContainer").innerHTML = svg;
}

// ============================================================================
// 6. 1.5x ENLARGED 4-CHANNEL ODE WAVEFORM SIMULATOR & CANVAS RENDERER
// ============================================================================
function runTimeDomainSimulation(st) {
  const t_win_ms = Math.max(st.t_out_ms * 1.55, st.t_hold_ms * 1.28, 30.0);
  const t_pre_ms = -0.12 * t_win_ms;
  const N = 1600;
  const dt_ms = (t_win_ms - t_pre_ms) / N;

  const t_arr = new Float64Array(N);
  const sw_arr = new Float64Array(N);
  const vtrig_arr = new Float64Array(N);
  const vgate_arr = new Float64Array(N);
  const vctrl_arr = new Float64Array(N);
  const fout_arr = new Float64Array(N);

  const isFallingTrig = (st.u1_ver === 3 || st.u1_ver === 4);
  const isRetrig = (st.u1_ver === 2 || st.u1_ver === 4);

  let vt = st.AVDD;
  let vc = st.Vc0;
  let schmittHigh = true;
  let oneshotRem_ms = 0.0;

  for (let i = 0; i < N; i++) {
    const ti = t_pre_ms + i * dt_ms;
    t_arr[i] = ti;

    let closed = false;
    if (ti >= 0 && ti < st.t_bounce_ms) {
      closed = (Math.floor(ti / Math.max(0.15, st.t_bounce_ms / 8.0)) % 2 === 0);
    } else if (ti >= st.t_bounce_ms && ti < st.t_hold_ms) {
      closed = true;
    } else if (ti >= st.t_hold_ms && ti < st.t_hold_ms + st.t_bounce_ms) {
      closed = (Math.floor((ti - st.t_hold_ms) / Math.max(0.15, st.t_bounce_ms / 8.0)) % 2 === 1);
    }
    sw_arr[i] = closed ? 0.0 : st.AVDD;

    const dvt_dt_ms = closed
      ? (0.0 - vt) / st.tau_press_ms
      : (st.AVDD - vt) / st.tau_rel_ms;
    vt += dvt_dt_ms * dt_ms;
    vtrig_arr[i] = vt;

    const prevHigh = schmittHigh;
    if (schmittHigh && vt <= st.V_th_fall) schmittHigh = false;
    else if (!schmittHigh && vt >= st.V_th_rise) schmittHigh = true;

    const trigEdge = isFallingTrig ? (prevHigh && !schmittHigh) : (!prevHigh && schmittHigh);
    if (trigEdge && (oneshotRem_ms <= 0.0 || isRetrig)) {
      oneshotRem_ms = st.t_out_ms;
    }

    let gateActive = false;
    if (oneshotRem_ms > 0.0) {
      gateActive = true;
      oneshotRem_ms -= dt_ms;
    }
    const vg = gateActive ? st.gate_active_V : st.gate_idle_V;
    vgate_arr[i] = vg;

    const vdrv = st.useInv ? (st.AVDD - vg) : vg;
    const dvc_dt_ms = ((vdrv - vc) / st.R_RAMP + (st.V_SET2 - vc) / st.R_VCO) / st.C_RAMP;
    vc += dvc_dt_ms * dt_ms;
    vctrl_arr[i] = vc;

    const iset_uA = (st.V_SET2 / st.R_SET2 + (st.V_SET2 - vc) / st.R_VCO) * 1000.0;
    const f_khz = iset_uA > 0.5 ? (50000.0 * (iset_uA / 1000.0) / (st.V_SET2 * st.N_DIV2)) : 0.0;
    fout_arr[i] = (vg > 0.5 * st.AVDD) ? f_khz : NaN;
  }

  simCache = { t_arr, sw_arr, vtrig_arr, vgate_arr, vctrl_arr, fout_arr, t_pre_ms, t_win_ms, st };
  drawWaveformCanvas(null);
}

function drawWaveformCanvas(hoverX) {
  if (!simCache) return;
  const canvas = document.getElementById("waveCanvas");
  const dpr = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();
  const W = Math.max(520, rect.width);
  const H = 820;
  if (canvas.width !== Math.round(W * dpr) || canvas.height !== Math.round(H * dpr)) {
    canvas.width = Math.round(W * dpr);
    canvas.height = Math.round(H * dpr);
  }
  const ctx = canvas.getContext("2d");
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, W, H);

  const { t_arr, sw_arr, vtrig_arr, vgate_arr, vctrl_arr, fout_arr, t_pre_ms, t_win_ms, st } = simCache;
  const padL = 86, padR = 24;
  const plotW = W - padL - padR;

  const tx = t => padL + ((t - t_pre_ms) / (t_win_ms - t_pre_ms)) * plotW;

  function drawPanelFrame(y0, h, title, yMin, yMax, unit) {
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(padL, y0, plotW, h);
    ctx.strokeStyle = "#e2e8f0";
    ctx.lineWidth = 1;
    for (let g = 0; g <= 4; g++) {
      const gy = y0 + (g / 4) * h;
      ctx.beginPath(); ctx.moveTo(padL, gy); ctx.lineTo(padL + plotW, gy); ctx.stroke();
      const val = yMax - (g / 4) * (yMax - yMin);
      ctx.fillStyle = "#475569";
      ctx.font = "bold 15px ui-monospace, 'SF Mono', Consolas, monospace";
      ctx.textAlign = "right";
      ctx.fillText(val.toFixed(yMax - yMin < 5 ? 2 : 1), padL - 8, gy + 5);
    }
    for (let gx = 0; gx <= 8; gx++) {
      const xPos = padL + (gx / 8) * plotW;
      ctx.beginPath(); ctx.moveTo(xPos, y0); ctx.lineTo(xPos, y0 + h); ctx.stroke();
    }
    ctx.strokeStyle = "#cbd5e1";
    ctx.lineWidth = 1.4;
    ctx.strokeRect(padL, y0, plotW, h);
    ctx.fillStyle = "#0f172a";
    ctx.font = "bold 17.5px 'Noto Sans TC', 'PingFang TC', 'Microsoft JhengHei', system-ui, sans-serif";
    ctx.textAlign = "left";
    ctx.fillText(title, padL, y0 - 8);
    ctx.save();
    ctx.translate(20, y0 + h / 2);
    ctx.rotate(-Math.PI / 2);
    ctx.textAlign = "center";
    ctx.fillStyle = "#334155";
    ctx.font = "bold 15px sans-serif";
    ctx.fillText(unit, 0, 0);
    ctx.restore();
  }

  function plotTrace(arr, y0, h, yMin, yMax, color, lw) {
    ctx.strokeStyle = color;
    ctx.lineWidth = lw;
    ctx.beginPath();
    let started = false;
    for (let i = 0; i < t_arr.length; i++) {
      const v = arr[i];
      if (isNaN(v)) { started = false; continue; }
      const x = tx(t_arr[i]);
      const y = y0 + h - ((v - yMin) / (yMax - yMin)) * h;
      const yc = Math.max(y0, Math.min(y0 + h, y));
      if (!started) { ctx.moveTo(x, yc); started = true; }
      else ctx.lineTo(x, yc);
    }
    ctx.stroke();
  }

  const vMaxPlot = Math.max(3.8, st.AVDD * 1.15);

  // CH1
  const y1 = 34, h1 = 136;
  drawPanelFrame(y1, h1, `① TRIG 除彈跳波形 (V_FALL=${st.V_th_fall.toFixed(2)}V, V_RISE=${st.V_th_rise.toFixed(2)}V)`, -0.2, vMaxPlot, "V");
  plotTrace(sw_arr, y1, h1, -0.2, vMaxPlot, "#cbd5e1", 1.3);
  const yFall = y1 + h1 - ((st.V_th_fall + 0.2) / (vMaxPlot + 0.2)) * h1;
  const yRise = y1 + h1 - ((st.V_th_rise + 0.2) / (vMaxPlot + 0.2)) * h1;
  ctx.setLineDash([6, 4]);
  ctx.strokeStyle = "#dc2626"; ctx.beginPath(); ctx.moveTo(padL, yFall); ctx.lineTo(padL + plotW, yFall); ctx.stroke();
  ctx.strokeStyle = "#059669"; ctx.beginPath(); ctx.moveTo(padL, yRise); ctx.lineTo(padL + plotW, yRise); ctx.stroke();
  ctx.setLineDash([]);
  plotTrace(vtrig_arr, y1, h1, -0.2, vMaxPlot, "#d97706", 2.8);

  // CH2
  const y2 = 214, h2 = 136;
  drawPanelFrame(y2, h2, `② U1:OUT 閘控視窗 (${fmtTimeMs(st.t_out_ms)}, 藍) 與 V_CTRL(t) (${st.Vc0.toFixed(2)}→${st.VcEnd.toFixed(2)}V, 紫)`, -0.2, vMaxPlot, "V");
  plotTrace(vgate_arr, y2, h2, -0.2, vMaxPlot, "#2563eb", 2.8);
  plotTrace(vctrl_arr, y2, h2, -0.2, vMaxPlot, "#9333ea", 2.8);

  // CH3
  const y3 = 394, h3 = 165;
  const fLo = Math.min(st.pt0.f_khz, st.ptEnd.f_khz);
  const fHi = Math.max(st.pt0.f_khz, st.ptEnd.f_khz);
  const fSpan = Math.max(0.5, fHi - fLo);
  const fMinPlot = Math.max(0, fLo - 0.35 * fSpan);
  const fMaxPlot = fHi + 0.35 * fSpan;
  drawPanelFrame(y3, h3, `③ 連續調頻 f_OUT(t)：${st.pt0.f_khz.toFixed(3)} → ${st.ptEnd.f_khz.toFixed(3)} kHz (非線性度 ${st.nonlin_pct.toFixed(2)}%)`, fMinPlot, fMaxPlot, "kHz");

  const yBandTop = y3 + h3 - ((fHi - fMinPlot) / (fMaxPlot - fMinPlot)) * h3;
  const yBandBot = y3 + h3 - ((fLo - fMinPlot) / (fMaxPlot - fMinPlot)) * h3;
  ctx.fillStyle = "rgba(20, 184, 166, 0.14)";
  ctx.fillRect(padL, yBandTop, plotW, Math.max(2, yBandBot - yBandTop));
  plotTrace(fout_arr, y3, h3, fMinPlot, fMaxPlot, "#0891b2", 3.4);

  ctx.fillStyle = "#334155";
  ctx.font = "bold 14.5px ui-monospace, 'SF Mono', Consolas, monospace";
  ctx.textAlign = "center";
  for (let gx = 0; gx <= 8; gx++) {
    const xPos = padL + (gx / 8) * plotW;
    const tVal = t_pre_ms + (gx / 8) * (t_win_ms - t_pre_ms);
    ctx.fillText(tVal.toFixed(0) + "ms", xPos, y3 + h3 + 20);
  }

  // CH4L & CH4R
  const y4 = 626, h4 = 158;
  const subW = (plotW - 36) / 2;
  function drawZoomSq(xStart, f_khz, label, color) {
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(xStart, y4, subW, h4);
    ctx.strokeStyle = "#cbd5e1";
    ctx.lineWidth = 1.4;
    ctx.strokeRect(xStart, y4, subW, h4);
    ctx.fillStyle = "#0f172a";
    ctx.font = "bold 16.5px 'Noto Sans TC', 'PingFang TC', 'Microsoft JhengHei', system-ui, sans-serif";
    ctx.textAlign = "left";
    const T_us = f_khz > 0 ? 1000.0 / f_khz : 0;
    ctx.fillText(`${label}：${f_khz.toFixed(2)} kHz (T=${T_us.toFixed(2)}µs, 50%)`, xStart, y4 - 8);

    if (f_khz <= 0) return;
    const win_us = 4.5 * T_us;
    ctx.strokeStyle = color;
    ctx.lineWidth = 2.6;
    ctx.beginPath();
    const steps = 400;
    const yHigh = y4 + h4 - ((st.AVDD + 0.2) / (vMaxPlot + 0.2)) * h4;
    const yLow = y4 + h4 - (0.2 / (vMaxPlot + 0.2)) * h4;
    ctx.moveTo(xStart, yLow);
    for (let k = 0; k <= steps; k++) {
      const u = (k / steps) * win_us;
      const phase = (u / T_us) % 1.0;
      const px = xStart + (k / steps) * subW;
      const py = phase < 0.5 ? yHigh : yLow;
      ctx.lineTo(px, py);
    }
    ctx.stroke();

    ctx.fillStyle = "#475569";
    ctx.font = "bold 14px ui-monospace, 'SF Mono', Consolas, monospace";
    ctx.textAlign = "center";
    for (let g = 0; g <= 4; g++) {
      ctx.fillText(((g / 4) * win_us).toFixed(1) + "µs", xStart + (g / 4) * subW, y4 + h4 + 20);
    }
  }

  drawZoomSq(padL, st.pt0.f_khz, "④-A 起點方波", "#0891b2");
  drawZoomSq(padL + subW + 36, st.ptEnd.f_khz, "④-B 終點方波", "#0284c7");

  if (hoverX !== null && hoverX >= padL && hoverX <= padL + plotW) {
    const frac = (hoverX - padL) / plotW;
    const idx = Math.max(0, Math.min(t_arr.length - 1, Math.round(frac * (t_arr.length - 1))));
    ctx.strokeStyle = "#ef4444";
    ctx.lineWidth = 1.5;
    ctx.setLineDash([5, 4]);
    ctx.beginPath();
    ctx.moveTo(hoverX, y1);
    ctx.lineTo(hoverX, y3 + h3);
    ctx.stroke();
    ctx.setLineDash([]);

    const fStr = isNaN(fout_arr[idx]) ? "0 Hz (停用)" : fout_arr[idx].toFixed(3) + " kHz";
    document.getElementById("cursorReadout").textContent =
      `t=${t_arr[idx].toFixed(2)}ms | TRIG=${vtrig_arr[idx].toFixed(2)}V | GATE=${vgate_arr[idx].toFixed(2)}V | V_CTRL=${vctrl_arr[idx].toFixed(3)}V | f=${fStr}`;
  }
}

const waveCanvasEl = document.getElementById("waveCanvas");
waveCanvasEl.addEventListener("mousemove", e => {
  const r = waveCanvasEl.getBoundingClientRect();
  drawWaveformCanvas(e.clientX - r.left);
});
waveCanvasEl.addEventListener("mouseleave", () => drawWaveformCanvas(null));
window.addEventListener("resize", () => drawWaveformCanvas(null));

// ============================================================================
// 7. MASTER UI UPDATE, DRC & OFFLINE CLIPBOARD EXPORT
// ============================================================================
function recalcAll() {
  const st = computeCircuitState();

  document.getElementById("topAvddBadge").textContent = `AVDD = ${st.AVDD.toFixed(2)} V`;
  document.getElementById("kpi_avdd").textContent = `${st.AVDD.toFixed(2)} V`;
  document.getElementById("kpi_avdd_sub").textContent = `門檻: ${st.V_th_fall.toFixed(2)}V / ${st.V_th_rise.toFixed(2)}V`;

  document.getElementById("kpi_tout").textContent = fmtTimeMs(st.t_out_ms);
  document.getElementById("kpi_tout_sub").textContent = `Code ${st.div1.code} (÷${st.N_DIV1}, POL=${st.POL1})`;

  document.getElementById("kpi_f0").textContent = `${st.pt0.f_khz.toFixed(3)} kHz`;
  document.getElementById("kpi_f0_sub").textContent = `V_CTRL(0) = ${st.Vc0.toFixed(3)} V`;

  document.getElementById("kpi_f1").textContent = `${st.ptEnd.f_khz.toFixed(3)} kHz`;
  const df = st.ptEnd.f_khz - st.pt0.f_khz;
  document.getElementById("kpi_f1_sub").textContent = `Δf = ${df >= 0 ? "+" : ""}${df.toFixed(3)} kHz`;

  document.getElementById("kpi_duty").textContent = st.N_DIV2 > 1 ? "50.0% Duty" : "50% (±3%)";
  document.getElementById("kpi_cycles").textContent = `Code ${st.div2.code} (÷${st.N_DIV2}) · ${Math.round(st.total_cycles).toLocaleString()} 週期`;

  const iTotAct = Math.round(st.I_s1_idle_uA + st.I_s2_act_uA);
  const iTotIdle = Math.round(st.I_s1_idle_uA + st.I_s2_idle_uA);
  document.getElementById("kpi_icc").textContent = `${iTotAct} µA`;
  document.getElementById("kpi_icc_sub").textContent = `待機 ~${iTotIdle} µA`;

  document.getElementById("readout_z1").innerHTML = `
    <div class="readout-line"><span>遲滯 V_FALL / V_RISE</span><span>${st.V_th_fall.toFixed(2)}V / ${st.V_th_rise.toFixed(2)}V</span></div>
    <div class="readout-line"><span>按下放電 τ_press</span><span>${st.tau_press_ms.toFixed(2)} ms (延遲 ${st.t_trig_delay_ms.toFixed(2)} ms)</span></div>
    <div class="readout-line"><span>放開復歸 τ_release</span><span>${st.tau_rel_ms.toFixed(2)} ms</span></div>
    <div class="readout-line"><span>放開彈跳防護</span><span style="color:${st.releaseSafe ? '#059669':'#dc2626'}">${st.releaseSafe ? '✓ 免疫二次誤觸發' : '⚠ τ_release 偏小'}</span></div>
  `;

  document.getElementById("readout_z2").innerHTML = `
    <div class="readout-line"><span>V_DIV1 / AVDD</span><span>${st.div1.ratio.toFixed(4)} (${st.div1.errPct >= 0 ? "+" : ""}${st.div1.errPct.toFixed(2)}%)</span></div>
    <div class="readout-line"><span>解碼 DIVCODE</span><span>Code ${st.div1.code} · ÷${st.N_DIV1.toLocaleString()} · POL=${st.POL1}</span></div>
    <div class="readout-line"><span>總 R_SET1 / I_SET1</span><span>${fmtR(st.R_SET1)} / ${st.I_SET1_uA.toFixed(2)} µA</span></div>
    <div class="readout-line"><span>單發脈寬 t_OUT</span><span style="color:#1d4ed8;">${fmtTimeMs(st.t_out_ms)} (±${st.u1_acc_max}%)</span></div>
  `;

  document.getElementById("readout_z3").innerHTML = `
    <div class="readout-line"><span>等效阻抗 R_RAMP||R_VCO</span><span>${fmtR(st.Rp_kOhm)}</span></div>
    <div class="readout-line"><span>斜坡時間常數 τ_sweep</span><span>${st.tau_sweep_ms.toFixed(2)} ms</span></div>
    <div class="readout-line"><span>V_CTRL 起點 → 終點</span><span>${st.Vc0.toFixed(3)}V → ${st.VcEnd.toFixed(3)}V</span></div>
    <div class="readout-line"><span>95% 電容復歸 (3τ)</span><span>${(3 * st.tau_sweep_ms).toFixed(0)} ms</span></div>
  `;

  document.getElementById("readout_z4").innerHTML = `
    <div class="readout-line"><span>V_DIV2 / AVDD</span><span>${st.div2.ratio.toFixed(4)} → Code ${st.div2.code} (÷${st.N_DIV2})</span></div>
    <div class="readout-line"><span>f_(0V) / 增益 K_VCO</span><span>${st.f_0V_khz.toFixed(2)} kHz / -${st.K_vco_khz_per_V.toFixed(3)} kHz/V</span></div>
    <div class="readout-line"><span>起 → 中 → 終頻率</span><span style="color:#0891b2;">${st.pt0.f_khz.toFixed(2)} → ${st.ptMid.f_khz.toFixed(2)} → ${st.ptEnd.f_khz.toFixed(2)} kHz</span></div>
    <div class="readout-line"><span>主振盪器 f_MASTER2</span><span>${Math.min(st.pt0.f_master_khz, st.ptEnd.f_master_khz).toFixed(0)} ~ ${Math.max(st.pt0.f_master_khz, st.ptEnd.f_master_khz).toFixed(0)} kHz</span></div>
    <div class="readout-line"><span>ΔV_SET (±30mV) 誤差</span><span>±${st.dvset_err_hz.toFixed(1)} Hz</span></div>
  `;

  const drcs = [];
  if (st.AVDD >= 2.25 && st.AVDD <= 5.5) drcs.push(["ok", `AVDD=${st.AVDD.toFixed(2)}V OK`]);
  else drcs.push(["err", `AVDD=${st.AVDD.toFixed(2)}V 超出 2.25~5.5V`]);

  if (st.div1.windowOk && st.div1.r_par <= 500.1) drcs.push(["ok", `U1 Code ${st.div1.code} OK (${st.div1.r_par.toFixed(0)}kΩ)`]);
  else drcs.push(["err", `U1 DIV 誤差 ${st.div1.errPct.toFixed(2)}% 或阻抗超限`]);

  if (st.R_SET1 >= 50 && st.R_SET1 <= 800) drcs.push(["ok", `U1 R_SET1 (${fmtR(st.R_SET1)}) 最佳區`]);
  else drcs.push(["warn", `U1 R_SET1 超出建議 50k~800kΩ`]);

  if (st.POL1 === 0) drcs.push(["ok", "U1 POL=0 正脈波 OK"]);
  else drcs.push(["err", "U1 POL=1 將反相誤啟動 U2:OE！"]);

  if (st.div2.windowOk && st.div2.r_par <= 500.1) drcs.push(["ok", `U2 Code ${st.div2.code} OK (${st.div2.r_par.toFixed(0)}kΩ)`]);
  else drcs.push(["err", `U2 DIV 誤差 ${st.div2.errPct.toFixed(2)}% 或阻抗超限`]);

  const fmLo = Math.min(st.pt0.f_master_khz, st.ptEnd.f_master_khz);
  const fmHi = Math.max(st.pt0.f_master_khz, st.ptEnd.f_master_khz);
  if (fmLo >= 62.5 && fmHi <= 1000.0) drcs.push(["ok", `U2 主振盪器 (${fmLo.toFixed(0)}~${fmHi.toFixed(0)}kHz) 最佳區`]);
  else if (fmLo >= 25 && fmHi <= 2000.0) drcs.push(["warn", `U2 主振盪器位於擴展區`]);
  else drcs.push(["err", `U2 主振盪器超出 2MHz 或停振！`]);

  document.getElementById("drcBanner").innerHTML =
    `<strong style="font-size:0.82rem;color:#0f172a;">DRC 檢查：</strong>` +
    drcs.map(([lvl, msg]) => `<span class="drc-tag drc-${lvl}">${msg}</span>`).join("");

  document.getElementById("formulaTable").innerHTML = `
    <thead>
      <tr><th>模組</th><th>規格書公式</th><th>當前變數即時代入</th><th>計算結果</th></tr>
    </thead>
    <tbody>
      <tr>
        <td><b>TRIG 遲滯門檻</b></td>
        <td><code>V_FALL = 0.48·AVDD - 0.155V</code><br><code>V_RISE = 0.55·AVDD + 0.185V</code></td>
        <td><code>0.48 × ${st.AVDD.toFixed(2)}V - 0.155V</code><br><code>0.55 × ${st.AVDD.toFixed(2)}V + 0.185V</code></td>
        <td><b>${st.V_th_fall.toFixed(3)} V</b><br><b>${st.V_th_rise.toFixed(3)} V</b></td>
      </tr>
      <tr>
        <td><b>U1 單發脈寬</b></td>
        <td><code>t_OUT = N_DIV1 · (R_SET1 / 50kΩ) · 1µs</code></td>
        <td><code>${st.N_DIV1} × (${st.R_SET1.toFixed(2)} kΩ / 50 kΩ) × 1 µs</code></td>
        <td><b>${fmtTimeMs(st.t_out_ms)}</b></td>
      </tr>
      <tr>
        <td><b>RC 耦合斜坡</b></td>
        <td><code>R_P = R_RAMP || R_VCO</code>, <code>τ = R_P · C_RAMP</code><br><code>V_CTRL(t) = V_∞ + (V_0 - V_∞)·e^(-t/τ)</code></td>
        <td><code>R_P = ${st.Rp_kOhm.toFixed(2)} kΩ</code>, <code>τ = ${st.tau_sweep_ms.toFixed(2)} ms</code></td>
        <td><code>${st.Vc0.toFixed(3)} V → ${st.VcEnd.toFixed(3)} V</code></td>
      </tr>
      <tr>
        <td><b>U2 壓控頻率</b></td>
        <td><code>f_OUT(t) = [50GHz·Ω / (N_DIV2·R_VCO)] · (1 + R_VCO/R_SET2 - V_CTRL(t)/V_SET2)</code></td>
        <td><code>N_DIV2=${st.N_DIV2}</code>, <code>R_SET2=${st.R_SET2}k</code>, <code>R_VCO=${st.R_VCO}k</code></td>
        <td><b>${st.pt0.f_khz.toFixed(3)} → ${st.ptEnd.f_khz.toFixed(3)} kHz</b></td>
      </tr>
    </tbody>
  `;

  renderSplineSchematicSVG(st);
  runTimeDomainSimulation(st);
}

function fallbackCopyText(text) {
  const ta = document.createElement("textarea");
  ta.value = text;
  ta.setAttribute("readonly", "");
  ta.style.position = "fixed";
  ta.style.left = "-9999px";
  document.body.appendChild(ta);
  ta.select();
  let ok = false;
  try { ok = document.execCommand("copy"); } catch (e) { ok = false; }
  document.body.removeChild(ta);
  if (ok) {
    alert("已將當前完整 R/C 參數與計算結果複製為 Markdown！");
  } else {
    window.prompt("請按 Ctrl+C 複製以下 Markdown 參數摘要：", text);
  }
}

function copyMarkdownReport() {
  const st = computeCircuitState();
  const md = [
    `### LTC6993 + LTC6990 計算機參數配置摘要 (AVDD = ${st.AVDD.toFixed(2)} V)`,
    `- **全域共用電源**：AVDD = ${st.AVDD.toFixed(2)} V`,
    `- **按鈕除彈跳**：R_PU = ${fmtR(st.R_PU)}, R_DB = ${fmtR(st.R_DB)}, C_DB = ${st.C_DB} µF (τ_press = ${st.tau_press_ms.toFixed(2)} ms, τ_release = ${st.tau_rel_ms.toFixed(2)} ms)`,
    `- **U1 (LTC6993-${st.u1_ver})**：R1 = ${fmtR(st.R1)}, R2 = ${fmtR(st.R2)} (DIVCODE = ${st.div1.code}, N_DIV = ${st.N_DIV1}, POL = ${st.POL1}), R_SET1 = ${fmtR(st.R_SET1)} (R_SET1a=${fmtR(st.R_SET1a)}, R_SET1b=${fmtR(st.R_SET1b)}), C1 = ${st.C1} µF → **t_OUT = ${fmtTimeMs(st.t_out_ms)}**`,
    `- **斜坡網路**：${st.useInv ? '含 SN74LVC1G04 反相器' : '直連無反相器'}, R_RAMP = ${fmtR(st.R_RAMP)}, C_RAMP = ${st.C_RAMP} µF (V_CTRL: ${st.Vc0.toFixed(3)}V → ${st.VcEnd.toFixed(3)}V)`,
    `- **U2 (LTC6990)**：R3 = ${fmtR(st.R3)}, R4 = ${fmtR(st.R4)} (DIVCODE = ${st.div2.code}, N_DIV = ${st.N_DIV2}, Hi-Z = ${st.HiZ2}), R_SET2 = ${fmtR(st.R_SET2)}, R_VCO = ${fmtR(st.R_VCO)}, C2 = ${st.C2} µF → **f_OUT = ${st.pt0.f_khz.toFixed(3)} kHz → ${st.ptEnd.f_khz.toFixed(3)} kHz (50% Duty)**`
  ].join("\n");
  if (navigator.clipboard && window.isSecureContext) {
    navigator.clipboard.writeText(md).then(() => {
      alert("已將當前完整 R/C 參數與計算結果複製為 Markdown！");
    }).catch(() => fallbackCopyText(md));
  } else {
    fallbackCopyText(md);
  }
}

recalcAll();
</script>
</body>
</html>
"""


def main():
    out_path = os.path.join(OUT_DIR, "ltc6993_ltc6990_design_report.html")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(HTML_CONTENT)
    print("Saved 1.5x Dual-Scroll Interactive HTML:", out_path, f"({os.path.getsize(out_path):,} bytes)")


if __name__ == "__main__":
    main()
