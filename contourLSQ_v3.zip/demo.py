# demo.py — Contour_WLSQ 最小實戰應用範例 (離線標定建模 + 線上單張預測 + 疊圖視覺化)
import os
import matplotlib.pyplot as plt
from vision_localizer import Contour_WLSQ

# 1. 指定影像與模型路徑 (預設指向一組現成圖檔，實機替換為相機圖片路徑或 numpy 陣列即可)
IMG0_PATH = "./sim_data/wavy_cam_flange/img0.png"       # 基準圖 (Golden Template)
IMG1_PATH = "./sim_data/wavy_cam_flange/img1_0002.png"  # 待測圖 (Target Image)
PKL_PATH  = "./demo_golden_model.pkl"                   # 訓練後儲存的模型檔

# =====================================================================
# 【階段 A：離線訓練 (Teach)】載入基準圖 -> 視窗互動點選 P1(中心)、P2(方向) -> 存成 .pkl
# =====================================================================
loc_train = Contour_WLSQ()
loc_train.set_orginal_img(IMG0_PATH)
p1, p2 = loc_train.interactive_mark_img0(
    ds_title="Demo 離線標定", has_existing_pkl=os.path.isfile(PKL_PATH)
)
if p1 is not None and p2 is not None:
    loc_train.save(PKL_PATH)
    print(f"[訓練完成] 已儲存模型至 {PKL_PATH} | P1={p1}, P2={p2}")

# =====================================================================
# 【階段 B：線上推論 (Predict)】直接載入 .pkl (無需 img0) -> 預測 img1 姿態與防呆判定
# =====================================================================
locator = Contour_WLSQ().load(PKL_PATH)
x_cam, y_cam, theta_deg = locator.predict(IMG1_PATH)

if locator.is_ok(min_coverage=0.35, max_rmse=0.8):
    print(f"[定位 OK] X = {x_cam:+.2f} px, Y = {y_cam:+.2f} px, Θ = {theta_deg:+.2f}° "
          f"(覆蓋率={locator.coverage:.1%}, RMSE={locator.rmse:.3f} px)")
else:
    print(f"[定位 NG] 原因={locator.exit_reason}, 覆蓋率={locator.coverage:.1%}, RMSE={locator.rmse:.3f} px")





# =====================================================================
# 【階段 C：視覺化疊圖】將 img1 的 Canny 點與預測對齊後的 Template 邊緣疊加顯示
#      **  上線不需要這個可視化動作  **
# =====================================================================
img1_gray = Contour_WLSQ._load_gray_array(IMG1_PATH)

# 取得 img1 的原始 Canny 次像素邊緣點 (回傳為相對於畫面中心的偏移)
_, qx, qy, _, _, _ = locator._extract_subpixel_edges(img1_gray)

# 取得 Template 經過預測姿態轉換後的邊緣點 (絕對像素座標)
edge_x1, edge_y1 = locator.get_transformed_edges()

# 畫面中心座標 (用於將 qx, qy 轉回絕對座標)
cx, cy = locator._cache["cx"], locator._cache["cy"]

fig, ax = plt.subplots(figsize=(10, 8))
ax.imshow(img1_gray, cmap="gray", vmin=0, vmax=255)

# 畫出 img1 的原始 Canny 邊緣點 (青色)
if qx.size > 0:
    ax.scatter(qx + cx, qy + cy, s=2, c="cyan", alpha=0.6, label=f"影像 Canny 邊緣點 (N={qx.size})")

# 畫出預測後對齊的 Template 邊緣 (亮綠色)
ax.scatter(edge_x1, edge_y1, s=1.5, c="lime", alpha=0.85, label="Template 對齊邊緣")

# 畫出預測的 P1, P2 與方向箭頭
if locator.pred_p1 is not None and locator.pred_p2 is not None:
    ax.annotate("", xy=locator.pred_p2, xytext=locator.pred_p1,
                arrowprops=dict(arrowstyle="->", color="yellow", lw=2.5, mutation_scale=18))
    ax.plot(locator.pred_p1[0], locator.pred_p1[1], "ro", ms=8, fillstyle="none", mew=1.5, label="P1' 中心")
    ax.plot(locator.pred_p2[0], locator.pred_p2[1], "yo", ms=7, fillstyle="none", mew=1.5, label="P2' 轉角方向")

ax.set_xlim(0, locator._cache["W_img"])
ax.set_ylim(locator._cache["H_img"], 0)
ax.legend(loc="lower right")
ax.set_title(f"預測疊圖 | X={x_cam:+.2f}, Y={y_cam:+.2f}, Θ={theta_deg:+.2f}°", fontsize=12, fontweight="bold")
plt.tight_layout()
plt.show()

# =====================================================================
# (選用) 彈出 2x3 六宮格 X 光診斷面板檢視對位細節
# =====================================================================
# locator.plot_diagnostics(IMG1_PATH, title_prefix="Demo 單張測試")