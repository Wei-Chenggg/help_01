# test_hough_circle_ct.py
import time
import cv2
import numpy as np


def make_dummy_2500x2000(seed=42, noise_sigma=3.0):
    rng = np.random.default_rng(seed)
    H, W = 2000, 2500
    img = np.full((H, W), 40, dtype=np.uint8)

    for _ in range(15):
        x1, y1 = int(rng.integers(100, W - 400)), int(rng.integers(100, H - 400))
        x2, y2 = x1 + int(rng.integers(150, 350)), y1 + int(rng.integers(150, 350))
        cv2.rectangle(img, (x1, y1), (x2, y2), 200, thickness=2)

    if noise_sigma > 0:
        noise = rng.normal(0.0, noise_sigma, size=(H, W))
        img = np.clip(img.astype(np.float32) + noise, 0, 255).astype(np.uint8)

    return img


def bench_hough_circles(img, dp, min_dist, param1, param2, min_r, max_r, n_runs=20):
    for _ in range(2):
        _ = cv2.HoughCircles(
            img,
            cv2.HOUGH_GRADIENT,
            dp=dp,
            minDist=min_dist,
            param1=param1,
            param2=param2,
            minRadius=min_r,
            maxRadius=max_r,
        )

    times_ms = []
    for _ in range(n_runs):
        t0 = time.perf_counter()
        _ = cv2.HoughCircles(
            img,
            cv2.HOUGH_GRADIENT,
            dp=dp,
            minDist=min_dist,
            param1=param1,
            param2=param2,
            minRadius=min_r,
            maxRadius=max_r,
        )
        t1 = time.perf_counter()
        times_ms.append((t1 - t0) * 1000.0)

    return np.mean(times_ms), np.min(times_ms), np.max(times_ms)


def main():
    img_normal = make_dummy_2500x2000(noise_sigma=3.0)
    img_noisy = make_dummy_2500x2000(noise_sigma=12.0)

    edges_normal = int(np.count_nonzero(cv2.Canny(img_normal, 75, 150)))
    edges_noisy = int(np.count_nonzero(cv2.Canny(img_noisy, 75, 150)))

    print(f"影像尺寸: {img_normal.shape[1]}x{img_normal.shape[0]} (WxH)")
    print(f"一般測試圖 Canny 邊緣點數: {edges_normal:,} pts")
    print(f"高雜訊測試圖 Canny 邊緣點數: {edges_noisy:,} pts")
    print("-" * 75)

    cases = [
        ("Case 1: 一般邊緣 + 窄半徑範圍 (r=30~80, dp=1.0)", img_normal, 1.0, 100, 150, 30, 30, 80),
        ("Case 2: 一般邊緣 + 寬半徑範圍 (r=20~400, dp=1.0)", img_normal, 1.0, 100, 150, 30, 20, 400),
        ("Case 3: 一般邊緣 + 不限半徑 (maxRadius=0, dp=1.0)", img_normal, 1.0, 100, 150, 30, 0, 0),
        ("Case 4: 一般邊緣 + 降採樣累加器 (r=20~400, dp=2.0)", img_normal, 2.0, 100, 150, 30, 20, 400),
    ]

    for name, im, dp, min_d, p1, p2, r_min, r_max in cases:
        mean_ms, min_ms, max_ms = bench_hough_circles(
            im, dp=dp, min_dist=min_d, param1=p1, param2=p2,
            min_r=r_min, max_r=r_max, n_runs=10,
        )
        print(f"{name:<48} | Mean: {mean_ms:7.2f} ms (Min: {min_ms:6.2f}, Max: {max_ms:6.2f})")


if __name__ == "__main__":
    main()
