# vision_localizer.py
import os
import time
import pickle
import warnings
import cv2
import numpy as np
from scipy.ndimage import (
    gaussian_filter,
    gaussian_filter1d,
    distance_transform_edt,
)


class Contour_WLSQ:
    """
    萬用任意曲線輪廓定位器（無 ROI、不對號入座、免 ICP 迭代）：
    1. 前處理 Step 1: 1D 梯度方向直方圖 (含 sqrt 抗遮擋壓縮) FFT 互相關 -> 求候選旋轉角 θ
    2. 前處理 Step 2: 轉正後 1D X/Y 正負梯度邊際投影 FFT 互相關 -> 求粗平移 (dx, dy)
    3. 候選角寬帶預拉入與反極性懲罰評分 -> 鎖定全局唯一正確姿態
    4. 後處理 Step 3: 窄帶法線場加權最小平方法 (Tukey WLSQ) -> 次像素精修並剔除灰塵與遮擋
    5. 支援 Golden Template 雙點標記 (p1=物件中心, p2=物件轉角方向) 與 .pkl 模板輕量存取 (save/load)
    """

    def __init__(
        self,
        canny_low=50,
        canny_high=150,
        blur_level=1.0,
        angle_bins=720,
        top_k_angles=6,
        proj_len=512,
        proj_sigma=1.5,
        band_tau=2.5,
        polarity_th=0.7,
        max_iter=3,
        tol=1e-4,
        eta=1e-6,
    ):
        self.canny_low = canny_low
        self.canny_high = canny_high
        self.blur_level = float(max(blur_level, 0.0))
        self.angle_bins = int(angle_bins)
        self.top_k_angles = int(max(top_k_angles, 1))
        self.proj_len = int(proj_len)
        self.proj_sigma = float(proj_sigma)
        self.band_tau = float(band_tau)
        self.polarity_th = float(polarity_th)
        self.max_iter = int(max(max_iter, 1))
        self.tol = float(tol)
        self.eta = float(eta)

        self._ref_img = None
        self._cache = None
        self.history = []
        self.coarse_pose = None
        self.rel_pose = None
        self.pred_p1 = None
        self.pred_p2 = None
        self.exit_reason = None
        self.stopped_early = False
        self.iterations = 0
        self.valid_inliers = 0
        self.coverage = 0.0
        self.rmse = 999.0
        self.last_ct = {}
        self._edge_ct_detail = {}
        self._coarse_ct_detail = {}

    @staticmethod
    def _load_gray_u8(img_or_path):
        """支援傳入影像檔案路徑 (含中文路徑) 或 2D/3D ndarray，統一轉為 2D uint8 灰階陣列 (零冗餘浮點配置)。"""
        if isinstance(img_or_path, (str, os.PathLike)):
            with open(img_or_path, "rb") as f:
                buf = np.frombuffer(f.read(), dtype=np.uint8)
            arr = cv2.imdecode(buf, cv2.IMREAD_GRAYSCALE)
            if arr is None:
                raise FileNotFoundError(f"無法讀取影像檔案: {img_or_path}")
            return arr
        arr = np.asarray(img_or_path)
        if arr.ndim == 3:
            if arr.dtype != np.uint8:
                arr = np.clip(np.rint(arr), 0, 255).astype(np.uint8)
            return cv2.cvtColor(arr, cv2.COLOR_BGR2GRAY)
        if arr.dtype == np.uint8:
            return np.ascontiguousarray(arr)
        return np.clip(np.rint(arr), 0.0, 255.0).astype(np.uint8)

    @staticmethod
    def _load_gray_array(img_or_path):
        """相容輔助方法：回傳 2D uint8 灰階陣列。"""
        return Contour_WLSQ._load_gray_u8(img_or_path)

    def _extract_coarse_edges_fast(self, img_u8, max_pts=2500):
        """
        粗定位專用快速邊緣提取：
        當影像長寬 >= 1000 時自動以 1/2 面積縮圖先做輕量高斯平滑再跑 Canny，抑制高強雜訊並提升速度。
        """
        t0 = time.perf_counter()
        H_img, W_img = img_u8.shape
        if min(H_img, W_img) >= 1000:
            W_s, H_s = W_img // 2, H_img // 2
            img_s = cv2.resize(img_u8, (W_s, H_s), interpolation=cv2.INTER_AREA)
            scale_x = W_img / float(W_s)
            scale_y = H_img / float(H_s)
        else:
            W_s, H_s = W_img, H_img
            img_s = img_u8
            scale_x, scale_y = 1.0, 1.0

        if self.blur_level > 0.0:
            img_work = cv2.GaussianBlur(
                img_s, (3, 3), sigmaX=0.8, sigmaY=0.8, borderType=cv2.BORDER_REPLICATE
            )
        else:
            img_work = img_s

        edges_s = cv2.Canny(img_work, self.canny_low, self.canny_high)
        edges_s[:2, :] = 0
        edges_s[-2:, :] = 0
        edges_s[:, :2] = 0
        edges_s[:, -2:] = 0
        pts = cv2.findNonZero(edges_s)
        t1 = time.perf_counter()

        if pts is None:
            empty = np.empty(0, dtype=np.float64)
            return empty, empty, empty, empty, empty, (t1 - t0) * 1000.0, 0.0

        pts = pts.reshape(-1, 2)
        if max_pts is not None and pts.shape[0] > max_pts:
            step = int(np.ceil(pts.shape[0] / float(max_pts)))
            pts = pts[::step]

        xs = pts[:, 0]
        ys = pts[:, 1]

        flat_u8 = img_work.ravel()
        idx0 = ys * W_s + xs
        gx = (flat_u8[idx0 + 1].astype(np.float64) - flat_u8[idx0 - 1].astype(np.float64)) * 0.5
        gy = (flat_u8[idx0 + W_s].astype(np.float64) - flat_u8[idx0 - W_s].astype(np.float64)) * 0.5
        mag = np.maximum(np.hypot(gx, gy), self.eta)
        ux = gx / mag
        uy = gy / mag

        cx = (W_img - 1) / 2.0
        cy = (H_img - 1) / 2.0
        qx = (xs.astype(np.float64) + 0.5) * scale_x - 0.5 - cx
        qy = (ys.astype(np.float64) + 0.5) * scale_y - 0.5 - cy
        t2 = time.perf_counter()
        return qx, qy, ux, uy, mag, (t1 - t0) * 1000.0, (t2 - t1) * 1000.0

    def _extract_subpixel_edges(self, img, return_mask=False, max_pts=None, roi_bbox=None):
        """
        提取 1:1 原圖解析度 Canny 邊緣點，並利用梯度方向三點拋物線內插取得次像素邊緣座標與單位梯度向量。
        支援傳入 roi_bbox=(x0, y0, x1, y1) 僅於目標物貼身區域執行 Canny 與 GaussianBlur，省去 85% 全圖空白區耗時。
        """
        t0 = time.perf_counter()
        img_u8 = self._load_gray_u8(img)
        H_img, W_img = img_u8.shape
        t1 = time.perf_counter()

        if roi_bbox is not None:
            rx0, ry0, rx1, ry1 = roi_bbox
            rx0 = max(0, min(W_img - 16, int(rx0)))
            ry0 = max(0, min(H_img - 16, int(ry0)))
            rx1 = max(rx0 + 16, min(W_img, int(rx1)))
            ry1 = max(ry0 + 16, min(H_img, int(ry1)))
            sub_u8 = img_u8[ry0:ry1, rx0:rx1]
        else:
            rx0, ry0, rx1, ry1 = 0, 0, W_img, H_img
            sub_u8 = img_u8

        H_sub, W_sub = sub_u8.shape
        edges_u8 = cv2.Canny(sub_u8, self.canny_low, self.canny_high)

        edges_u8[:2, :] = 0
        edges_u8[-2:, :] = 0
        edges_u8[:, :2] = 0
        edges_u8[:, -2:] = 0

        pts = cv2.findNonZero(edges_u8)
        t2 = time.perf_counter()

        if pts is None:
            empty = np.empty(0, dtype=np.float64)
            mask = (edges_u8 > 0) if return_mask else edges_u8
            self._edge_ct_detail = {
                "1a_load_u8_ms": (t1 - t0) * 1000.0,
                "1b_canny_find_ms": (t2 - t1) * 1000.0,
                "1c_gaussian_blur_ms": 0.0,
                "1d_subpixel_interp_ms": 0.0,
                "raw_step": 1,
            }
            return mask, empty, empty, empty, empty, empty

        pts = pts.reshape(-1, 2)
        raw_step = 1
        if max_pts is not None and pts.shape[0] > max_pts:
            raw_step = int(np.ceil(pts.shape[0] / float(max_pts)))
            pts = pts[::raw_step]

        xs = pts[:, 0]
        ys = pts[:, 1]

        if self.blur_level > 0.0:
            img_work = cv2.GaussianBlur(
                sub_u8,
                (0, 0),
                sigmaX=self.blur_level,
                sigmaY=self.blur_level,
                borderType=cv2.BORDER_REPLICATE,
            )
        else:
            img_work = sub_u8
        t3 = time.perf_counter()

        # 保持 uint8 零拷貝，僅對稀疏邊緣索引點轉 float64 計算梯度與次像素內插
        flat_u8 = img_work.ravel()
        idx0 = ys * W_sub + xs
        gx = 0.5 * (flat_u8[idx0 + 1].astype(np.float64) - flat_u8[idx0 - 1].astype(np.float64))
        gy = 0.5 * (flat_u8[idx0 + W_sub].astype(np.float64) - flat_u8[idx0 - W_sub].astype(np.float64))
        mag = np.maximum(np.hypot(gx, gy), self.eta)
        ux = gx / mag
        uy = gy / mag

        xm = np.clip(np.rint(xs - ux).astype(np.int32), 1, W_sub - 2)
        ym = np.clip(np.rint(ys - uy).astype(np.int32), 1, H_sub - 2)
        xp = np.clip(np.rint(xs + ux).astype(np.int32), 1, W_sub - 2)
        yp = np.clip(np.rint(ys + uy).astype(np.int32), 1, H_sub - 2)

        idx_m = ym * W_sub + xm
        idx_p = yp * W_sub + xp

        gm = np.hypot(
            0.5 * (flat_u8[idx_m + 1].astype(np.float64) - flat_u8[idx_m - 1].astype(np.float64)),
            0.5 * (flat_u8[idx_m + W_sub].astype(np.float64) - flat_u8[idx_m - W_sub].astype(np.float64)),
        )
        g0 = mag
        gp = np.hypot(
            0.5 * (flat_u8[idx_p + 1].astype(np.float64) - flat_u8[idx_p - 1].astype(np.float64)),
            0.5 * (flat_u8[idx_p + W_sub].astype(np.float64) - flat_u8[idx_p - W_sub].astype(np.float64)),
        )
        denom = gm - 2.0 * g0 + gp
        valid_peak = (np.abs(denom) > self.eta) & (g0 >= gm) & (g0 >= gp)
        dt = np.where(
            valid_peak,
            0.5 * (gm - gp) / np.where(valid_peak, denom, 1.0),
            0.0,
        )
        dt = np.clip(dt, -0.6, 0.6)

        cx = (W_img - 1) / 2.0
        cy = (H_img - 1) / 2.0
        px = (xs.astype(np.float64) + rx0 + dt * ux) - cx
        py = (ys.astype(np.float64) + ry0 + dt * uy) - cy
        mask = (edges_u8 > 0) if return_mask else edges_u8
        t4 = time.perf_counter()

        self._edge_ct_detail = {
            "1a_load_u8_ms": (t1 - t0) * 1000.0,
            "1b_canny_find_ms": (t2 - t1) * 1000.0,
            "1c_gaussian_blur_ms": (t3 - t2) * 1000.0,
            "1d_subpixel_interp_ms": (t4 - t3) * 1000.0,
            "raw_step": raw_step,
        }
        return mask, px, py, ux, uy, mag

    def _build_1d_orient_hist(self, ux, uy, weights):
        """
        建立長度為 angle_bins 的 1D 梯度方向角直方圖：
        使用 sqrt 非線性壓縮抑制大塊直線型遮擋物造成的異常單一角度尖刺。
        """
        B = self.angle_bins
        ang_deg = np.mod(np.rad2deg(np.arctan2(uy, ux)), 360.0)
        bins = np.mod(np.rint(ang_deg * (B / 360.0)).astype(np.int32), B)
        hist = np.bincount(bins, weights=weights, minlength=B).astype(np.float64)
        hist = np.sqrt(np.maximum(hist, 0.0))
        hist = gaussian_filter1d(hist, sigma=2.5, mode="wrap")
        hist -= np.mean(hist)
        norm = float(np.linalg.norm(hist))
        if norm > self.eta:
            hist /= norm
        return hist

    def _build_1d_xy_proj(self, x_arr, y_arr, ux_arr, uy_arr, do_smooth=False, scale_ratio=1.0):
        """
        建立轉正後的 1D X 與 Y 正負梯度投影剖面 (長度 proj_len)。
        只在離線 img0 執行高斯平滑，線上 img1 直接使用 bincount 以大幅節省 CT。
        """
        M = self.proj_len
        half_M = M / 2.0
        ix = np.clip(np.rint(x_arr + half_M).astype(np.int32), 0, M - 1)
        iy = np.clip(np.rint(y_arr + half_M).astype(np.int32), 0, M - 1)

        wx_pos = np.maximum(ux_arr, 0.0)
        wx_neg = np.maximum(-ux_arr, 0.0)
        wy_pos = np.maximum(uy_arr, 0.0)
        wy_neg = np.maximum(-uy_arr, 0.0)
        w_abs_y = np.abs(uy_arr)
        w_abs_x = np.abs(ux_arr)

        px_pos = np.bincount(ix, weights=wx_pos, minlength=M).astype(np.float64)
        px_neg = np.bincount(ix, weights=wx_neg, minlength=M).astype(np.float64)
        px_abs = np.bincount(ix, weights=w_abs_y, minlength=M).astype(np.float64)

        py_pos = np.bincount(iy, weights=wy_pos, minlength=M).astype(np.float64)
        py_neg = np.bincount(iy, weights=wy_neg, minlength=M).astype(np.float64)
        py_abs = np.bincount(iy, weights=w_abs_x, minlength=M).astype(np.float64)

        if do_smooth and self.proj_sigma > 0.0:
            s = self.proj_sigma * np.sqrt(2.0) * float(scale_ratio)
            px_pos = gaussian_filter1d(px_pos, s)
            px_neg = gaussian_filter1d(px_neg, s)
            px_abs = gaussian_filter1d(px_abs, s)
            py_pos = gaussian_filter1d(py_pos, s)
            py_neg = gaussian_filter1d(py_neg, s)
            py_abs = gaussian_filter1d(py_abs, s)

        return (px_pos, px_neg, px_abs), (py_pos, py_neg, py_abs)

    @staticmethod
    def _parabolic_peak_1d(corr, wrap=True):
        """在 1D 互相關陣列找最大值並做三點拋物線次像素內插。"""
        N = corr.size
        k = int(np.argmax(corr))
        val = float(corr[k])
        if wrap:
            ym = float(corr[(k - 1) % N])
            yp = float(corr[(k + 1) % N])
        else:
            if k <= 0 or k >= N - 1:
                return float(k), val
            ym = float(corr[k - 1])
            yp = float(corr[k + 1])
        denom = ym - 2.0 * val + yp
        dk = 0.5 * (ym - yp) / denom if abs(denom) > 1e-12 else 0.0
        dk = float(np.clip(dk, -0.5, 0.5))
        return float(k) + dk, val

    @staticmethod
    def _build_dense_maps(H_img, W_img, ys0, xs0, px0, py0, u0x, u0y):
        """利用 OpenCV 多執行緒 SIMD 距離轉換 + 1D LUT 瞬間建立 2D 密集查找表。"""
        src_u8 = np.full((H_img, W_img), 255, dtype=np.uint8)
        src_u8[ys0, xs0] = 0
        dist_map, labels = cv2.distanceTransformWithLabels(
            src_u8, cv2.DIST_L2, cv2.DIST_MASK_PRECISE, labelType=cv2.DIST_LABEL_PIXEL
        )
        lut = np.zeros(int(labels.max()) + 1, dtype=np.int32)
        lut[labels[ys0, xs0]] = np.arange(px0.size, dtype=np.int32)
        nearest_edge_idx = lut[labels]

        px0_map = px0.astype(np.float32)[nearest_edge_idx]
        py0_map = py0.astype(np.float32)[nearest_edge_idx]
        nx_map = u0x.astype(np.float32)[nearest_edge_idx]
        ny_map = u0y.astype(np.float32)[nearest_edge_idx]
        return dist_map, px0_map, py0_map, nx_map, ny_map

    def _update_template_from_edges(self, H_img, W_img, xs0, ys0, px0, py0, u0x, u0y, mag0):
        """由指定的邊緣點集合 (xs0, ys0, px0, py0, u0x, u0y, mag0) 建立或重建 Golden Template 快取。"""
        if px0.size < 5:
            raise ValueError(
                "[Contour_WLSQ] 選取的 Template 邊緣點過少 (< 5 點)！"
            )

        cx = (W_img - 1) / 2.0
        cy = (H_img - 1) / 2.0

        # --- 自動依影像對角線與零件尺寸進行尺度自適應 (Auto-Adaptation) ---
        diag = float(np.hypot(W_img, H_img))
        auto_proj_len = int(2 ** np.ceil(np.log2(max(512.0, diag * 1.5))))
        eff_proj_len = max(self.proj_len, auto_proj_len)
        self.proj_len = eff_proj_len

        # 計算零件外圍特徵半徑 r_obj (以 75 px 為基準比例 1.0)
        r_obj = float(np.percentile(np.hypot(px0, py0), 90))
        scale_ratio = float(max(1.0, r_obj / 75.0))

        hist_theta0 = self._build_1d_orient_hist(u0x, u0y, mag0)
        fft_theta0_conj = np.conj(np.fft.rfft(hist_theta0))

        (px0_pos, px0_neg, px0_abs), (py0_pos, py0_neg, py0_abs) = (
            self._build_1d_xy_proj(px0, py0, u0x, u0y, do_smooth=True, scale_ratio=scale_ratio)
        )
        fft_x0_conj = (
            np.conj(np.fft.rfft(px0_pos)),
            np.conj(np.fft.rfft(px0_neg)),
            np.conj(np.fft.rfft(px0_abs)),
        )
        fft_y0_conj = (
            np.conj(np.fft.rfft(py0_pos)),
            np.conj(np.fft.rfft(py0_neg)),
            np.conj(np.fft.rfft(py0_abs)),
        )

        dist_map, px0_map, py0_map, nx_map, ny_map = self._build_dense_maps(
            H_img, W_img, ys0, xs0, px0, py0, u0x, u0y
        )

        prev_cache = self._cache if self._cache is not None else {}
        self._cache = {
            "H_img": H_img,
            "W_img": W_img,
            "cx": cx,
            "cy": cy,
            "xs0": xs0.astype(np.int32),
            "ys0": ys0.astype(np.int32),
            "px0": px0,
            "py0": py0,
            "u0x": u0x,
            "u0y": u0y,
            "mag0": mag0,
            "fft_theta0_conj": fft_theta0_conj,
            "fft_x0_conj": fft_x0_conj,
            "fft_y0_conj": fft_y0_conj,
            "dist_map": dist_map,
            "px0_map": px0_map,
            "py0_map": py0_map,
            "nx_map": nx_map,
            "ny_map": ny_map,
            "num_ref_pts": int(px0.size),
            "scale_ratio": scale_ratio,
            "mark_p1": prev_cache.get("mark_p1", None),
            "mark_p2": prev_cache.get("mark_p2", None),
            "gold_center_offset": prev_cache.get(
                "gold_center_offset", np.array([0.0, 0.0], dtype=np.float64)
            ),
            "gold_angle_deg": prev_cache.get("gold_angle_deg", 0.0),
        }

    def apply_roi_mask(self, keep_mask):
        """
        根據布林遮罩 keep_mask 篩選 img0 的 Canny 邊緣點，僅保留被選中的點作為 Golden Template。
        """
        if self._cache is None:
            raise ValueError("[Contour_WLSQ] 請先呼叫 set_orginal_img(img0)！")
        keep_mask = np.asarray(keep_mask, dtype=bool)
        c = self._cache
        if keep_mask.size != c["px0"].size:
            raise ValueError("[Contour_WLSQ] keep_mask 長度與當前邊緣點數不符！")
        self._update_template_from_edges(
            c["H_img"],
            c["W_img"],
            c["xs0"][keep_mask],
            c["ys0"][keep_mask],
            c["px0"][keep_mask],
            c["py0"][keep_mask],
            c["u0x"][keep_mask],
            c["u0y"][keep_mask],
            c["mag0"][keep_mask],
        )

    def set_orginal_img(self, img0, p1=None, p2=None):
        """
        離線建立 Golden Template (Teach)
        Args:
            img0: 參考影像 (支援傳入檔案路徑 str 或 2D/3D ndarray)
            p1: (x1, y1) 點 1 像素座標 -> 表達「物件中心」 (若為 None 則預設為畫面中心)
            p2: (x2, y2) 點 2 像素座標 -> 表達「物件轉角方向」 (由 p1->p2 定義物件角度，若為 None 則預設為 0°)
        """
        img0 = self._load_gray_array(img0)
        H_img, W_img = img0.shape

        edges0, px0, py0, u0x, u0y, mag0 = self._extract_subpixel_edges(img0, return_mask=True)
        if px0.size < 5:
            raise ValueError(
                "[Contour_WLSQ] 參考影像 img0 提取到的 Canny 邊緣點過少！"
            )

        ys0, xs0 = np.nonzero(edges0)
        self._ref_img = img0
        self._cache = None
        self._update_template_from_edges(
            H_img, W_img, xs0, ys0, px0, py0, u0x, u0y, mag0
        )

        if p1 is not None and p2 is not None:
            self.set_golden_points(p1, p2)

    def set_golden_points(self, p1, p2):
        """
        設定或更新 Golden Template 上的 2 個標記點 (像素座標):
            p1 = (x1, y1): 點 1 表達「物件中心」
            p2 = (x2, y2): 點 2 表達「物件轉角方向」 (由 p1 -> p2 向量定義)
        """
        if self._cache is None:
            raise ValueError(
                "[Contour_WLSQ] 請先呼叫 set_orginal_img(img0) 再設定標記點。"
            )
        p1_arr = np.asarray(p1, dtype=np.float64).reshape(2)
        p2_arr = np.asarray(p2, dtype=np.float64).reshape(2)
        vec = p2_arr - p1_arr
        if float(np.hypot(vec[0], vec[1])) < self.eta:
            raise ValueError("[Contour_WLSQ] 標記點 p1 與 p2 不可重合！")

        cx = self._cache["cx"]
        cy = self._cache["cy"]
        # 點 1 相對於攝影機畫面中心 (cx, cy) 的偏移向量
        gold_center_offset = np.array([p1_arr[0] - cx, p1_arr[1] - cy], dtype=np.float64)
        # p1 -> p2 相對於攝影機畫面右方 (+X 軸 = 0°) 的基準角度
        gold_angle_deg = float(np.rad2deg(np.arctan2(vec[1], vec[0])))

        self._cache["mark_p1"] = p1_arr
        self._cache["mark_p2"] = p2_arr
        self._cache["gold_center_offset"] = gold_center_offset
        self._cache["gold_angle_deg"] = gold_angle_deg

    def get_golden_edges(self):
        """回傳 Golden Template (img0) 上的次像素邊緣點像素座標 (edge_x0, edge_y0)。"""
        if self._cache is None:
            raise ValueError("[Contour_WLSQ] 尚未載入模板！")
        cx, cy = self._cache["cx"], self._cache["cy"]
        return self._cache["px0"] + cx, self._cache["py0"] + cy

    def get_transformed_edges(self):
        """
        回傳剛預測完的 img1 上，對齊後的 Golden Template 邊緣點像素座標 (edge_x1, edge_y1)，
        可直接疊加繪製在 img1 上檢視對位效果。
        """
        if self._cache is None or self.rel_pose is None:
            raise ValueError("[Contour_WLSQ] 請先執行 predict(img1)！")
        dx, dy, dtheta_deg = self.rel_pose
        rad = np.deg2rad(dtheta_deg)
        c, s = np.cos(rad), np.sin(rad)
        px0 = self._cache["px0"]
        py0 = self._cache["py0"]
        cx, cy = self._cache["cx"], self._cache["cy"]
        edge_x1 = c * px0 - s * py0 + dx + cx
        edge_y1 = s * px0 + c * py0 + dy + cy
        return edge_x1, edge_y1

    def save(self, pkl_path, save_ref_img=False, compact=True):
        """
        將訓練好的 Golden Template 與標記點資訊存成 .pkl 檔案。
        上機時可直接呼叫 load(pkl_path)，免除重拍 img0。
        - compact=True (預設): 存檔時不寫入 5 張大型 2D 密集查找表 (dist_map 等)，
          改於 load() 時由 1D 邊緣點瞬間重建，大幅縮小 .pkl 檔案。
        """
        if self._cache is None:
            raise ValueError(
                "[Contour_WLSQ] 尚未建立 Golden Template，無法儲存 .pkl！"
            )
        folder = os.path.dirname(os.path.abspath(pkl_path))
        if folder and not os.path.exists(folder):
            os.makedirs(folder, exist_ok=True)

        heavy_keys = {"dist_map", "px0_map", "py0_map", "nx_map", "ny_map"}
        if compact and "xs0" in self._cache and "ys0" in self._cache:
            cache_to_save = {
                k: v for k, v in self._cache.items() if k not in heavy_keys
            }
        else:
            cache_to_save = self._cache

        payload = {
            "params": {
                "canny_low": self.canny_low,
                "canny_high": self.canny_high,
                "blur_level": self.blur_level,
                "angle_bins": self.angle_bins,
                "top_k_angles": self.top_k_angles,
                "proj_len": self.proj_len,
                "proj_sigma": self.proj_sigma,
                "band_tau": self.band_tau,
                "polarity_th": self.polarity_th,
                "max_iter": self.max_iter,
                "tol": self.tol,
                "eta": self.eta,
            },
            "cache": cache_to_save,
            "ref_img": self._ref_img if save_ref_img else None,
        }
        with open(pkl_path, "wb") as f:
            pickle.dump(payload, f, protocol=pickle.HIGHEST_PROTOCOL)

    def load(self, pkl_path):
        """
        從 .pkl 檔案載入 Golden Template 與標記點設定，若為 compact 輕量格式則自動重建 2D 查找表。
        """
        with open(pkl_path, "rb") as f:
            payload = pickle.load(f)

        params = payload.get("params", {})
        for k, v in params.items():
            if hasattr(self, k):
                setattr(self, k, v)

        c = payload["cache"]
        if "dist_map" not in c:
            (
                c["dist_map"],
                c["px0_map"],
                c["py0_map"],
                c["nx_map"],
                c["ny_map"],
            ) = self._build_dense_maps(
                c["H_img"], c["W_img"], c["ys0"], c["xs0"],
                c["px0"], c["py0"], c["u0x"], c["u0y"]
            )

        self._cache = c
        self._ref_img = payload.get("ref_img", None)
        return self

    def _wlsq_step(self, qx, qy, u1x, u1y, dx, dy, dtheta, tau, pol_th):
        """執行單步法線場加權最小平方 (WLSQ) 更新（僅對窄帶內點組裝矩陣）。"""
        c_data = self._cache
        H_img, W_img = c_data["H_img"], c_data["W_img"]
        cx, cy = c_data["cx"], c_data["cy"]
        px0_map, py0_map = c_data["px0_map"], c_data["py0_map"]
        nx_map, ny_map = c_data["nx_map"], c_data["ny_map"]

        c, s = float(np.cos(dtheta)), float(np.sin(dtheta))
        gx = qx - dx
        gy = qy - dy
        px = c * gx + s * gy
        py = -s * gx + c * gy

        ux_rot = c * u1x + s * u1y
        uy_rot = -s * u1x + c * u1y

        ix = np.clip(np.rint(px + cx).astype(np.int32), 0, W_img - 1)
        iy = np.clip(np.rint(py + cy).astype(np.int32), 0, H_img - 1)

        px0_star = px0_map[iy, ix]
        py0_star = py0_map[iy, ix]
        nx = nx_map[iy, ix]
        ny = ny_map[iy, ix]

        err = (px - px0_star) * nx + (py - py0_star) * ny
        abs_err = np.abs(err)
        pol_dot = ux_rot * nx + uy_rot * ny

        in_band = (abs_err < tau) & (pol_dot >= pol_th)
        valid_cnt = int(np.count_nonzero(in_band))
        if valid_cnt < 6:
            return dx, dy, dtheta, 0.0, 0.0, 0.0, 0, 999.0, 999.0

        # 只取出窄帶內的有效內點進行後續計算，大幅減少陣列運算量
        px_b = px[in_band]
        py_b = py[in_band]
        nx_b = nx[in_band].astype(np.float64)
        ny_b = ny[in_band].astype(np.float64)
        err_b = err[in_band]
        abs_err_b = abs_err[in_band]
        pol_b = pol_dot[in_band]

        t_ratio = abs_err_b * (1.0 / tau)
        u_tmp = 1.0 - t_ratio * t_ratio
        w = (u_tmp * u_tmp) * pol_b

        Jx = -nx_b * c + ny_b * s
        Jy = -nx_b * s - ny_b * c
        Jt = nx_b * py_b - ny_b * px_b

        wJx = w * Jx
        wJy = w * Jy
        wJt = w * Jt

        H00 = float(np.dot(wJx, Jx))
        H01 = float(np.dot(wJx, Jy))
        H02 = float(np.dot(wJx, Jt))
        H11 = float(np.dot(wJy, Jy))
        H12 = float(np.dot(wJy, Jt))
        H22 = float(np.dot(wJt, Jt))

        H = np.array(
            [
                [H00, H01, H02],
                [H01, H11, H12],
                [H02, H12, H22],
            ],
            dtype=np.float64,
        )
        b_vec = -np.array(
            [np.dot(wJx, err_b), np.dot(wJy, err_b), np.dot(wJt, err_b)],
            dtype=np.float64,
        )

        if abs(float(np.linalg.det(H))) <= self.eta:
            np.fill_diagonal(H, np.maximum(np.diag(H), self.eta))

        ddx, ddy, ddth = [float(v) for v in np.linalg.solve(H, b_vec)]
        sse = float(np.dot(w, err_b * err_b))
        rmse = float(np.sqrt(sse / max(float(np.sum(w)), self.eta)))
        return dx + ddx, dy + ddy, dtheta + ddth, ddx, ddy, ddth, valid_cnt, sse, rmse

    def _estimate_coarse_pose(self, qx, qy, u1x, u1y, mag1):
        """
        前處理：1D 角度互相關 + 批次 1D X/Y 邊緣投影互相關 + 寬帶預拉入與反極性懲罰評分。
        """
        c_data = self._cache
        B = self.angle_bins
        M = self.proj_len
        scale_ratio = float(c_data.get("scale_ratio", 1.0))
        wide_tau = 7.0 * scale_ratio
        score_dist_tau = 3.0 * scale_ratio

        t_c0 = time.perf_counter()
        hist_theta1 = self._build_1d_orient_hist(u1x, u1y, mag1)
        corr_theta = np.fft.irfft(
            np.fft.rfft(hist_theta1) * c_data["fft_theta0_conj"], n=B
        )

        min_sep_bins = max(1, int(round(12.0 * B / 360.0)))
        work_corr = corr_theta.copy()
        cand_angles_deg = []
        cand_corr_vals = []
        for _ in range(self.top_k_angles):
            k_peak, peak_val = self._parabolic_peak_1d(work_corr, wrap=True)
            ang = ((k_peak * (360.0 / B)) + 180.0) % 360.0 - 180.0
            cand_angles_deg.append(float(ang))
            cand_corr_vals.append(float(peak_val))
            k_int = int(round(k_peak)) % B
            for offset in range(-min_sep_bins, min_sep_bins + 1):
                work_corr[(k_int + offset) % B] = -1e9
        t_c1 = time.perf_counter()

        fx0_pos, fx0_neg, fx0_abs = c_data["fft_x0_conj"]
        fy0_pos, fy0_neg, fy0_abs = c_data["fft_y0_conj"]
        H_img, W_img = c_data["H_img"], c_data["W_img"]
        cx, cy = c_data["cx"], c_data["cy"]
        nx_map, ny_map = c_data["nx_map"], c_data["ny_map"]
        dist_map = c_data["dist_map"]

        # 粗定位最多取 1000 點即可精準鎖定收斂盆地
        max_coarse_pts = 1000
        if qx.size > max_coarse_pts:
            step_c = int(np.ceil(qx.size / float(max_coarse_pts)))
            qx_c, qy_c = qx[::step_c], qy[::step_c]
            u1x_c, u1y_c = u1x[::step_c], u1y[::step_c]
        else:
            qx_c, qy_c, u1x_c, u1y_c = qx, qy, u1x, u1y

        # --- Step 2: 降維 M_sub <= 1024 批次投影與單次批量 rfft / irfft ---
        ta = time.perf_counter()
        K = len(cand_angles_deg)
        M_sub = min(M, 1024)
        ds_p = float(M) / float(M_sub)
        inv_ds_p = 1.0 / ds_p
        n_freq_sub = M_sub // 2 + 1

        proj_batch = np.empty((K, 6, M_sub), dtype=np.float64)
        th_arr = np.deg2rad(cand_angles_deg)
        c_arr = np.cos(th_arr)
        s_arr = np.sin(th_arr)
        half_M = M / 2.0
        half_M_sub = M_sub / 2.0

        for c_idx in range(K):
            c, s = float(c_arr[c_idx]), float(s_arr[c_idx])
            qx_rot = c * qx_c + s * qy_c
            qy_rot = -s * qx_c + c * qy_c
            ux_rot = c * u1x_c + s * u1y_c
            uy_rot = -s * u1x_c + c * u1y_c

            ix = np.clip(np.rint((qx_rot + half_M) * inv_ds_p).astype(np.int32), 0, M_sub - 1)
            iy = np.clip(np.rint((qy_rot + half_M) * inv_ds_p).astype(np.int32), 0, M_sub - 1)

            proj_batch[c_idx, 0] = np.bincount(ix, weights=np.maximum(ux_rot, 0.0), minlength=M_sub)
            proj_batch[c_idx, 1] = np.bincount(ix, weights=np.maximum(-ux_rot, 0.0), minlength=M_sub)
            proj_batch[c_idx, 2] = np.bincount(ix, weights=np.abs(uy_rot), minlength=M_sub)
            proj_batch[c_idx, 3] = np.bincount(iy, weights=np.maximum(uy_rot, 0.0), minlength=M_sub)
            proj_batch[c_idx, 4] = np.bincount(iy, weights=np.maximum(-uy_rot, 0.0), minlength=M_sub)
            proj_batch[c_idx, 5] = np.bincount(iy, weights=np.abs(ux_rot), minlength=M_sub)

        fft_batch = np.fft.rfft(proj_batch, axis=-1)
        fx0_p = fx0_pos[:n_freq_sub]
        fx0_n = fx0_neg[:n_freq_sub]
        fx0_a = 0.4 * fx0_abs[:n_freq_sub]
        fy0_p = fy0_pos[:n_freq_sub]
        fy0_n = fy0_neg[:n_freq_sub]
        fy0_a = 0.4 * fy0_abs[:n_freq_sub]

        spec_xy = np.empty((K, 2, n_freq_sub), dtype=np.complex128)
        spec_xy[:, 0, :] = (
            fft_batch[:, 0, :] * fx0_p
            + fft_batch[:, 1, :] * fx0_n
            + fft_batch[:, 2, :] * fx0_a
        )
        spec_xy[:, 1, :] = (
            fft_batch[:, 3, :] * fy0_p
            + fft_batch[:, 4, :] * fy0_n
            + fft_batch[:, 5, :] * fy0_a
        )
        corr_xy_batch = np.fft.irfft(spec_xy, n=M_sub, axis=-1)

        dx_cands = np.empty(K, dtype=np.float64)
        dy_cands = np.empty(K, dtype=np.float64)
        dx_tildes = np.empty(K, dtype=np.float64)
        dy_tildes = np.empty(K, dtype=np.float64)
        for c_idx in range(K):
            kx, _ = self._parabolic_peak_1d(corr_xy_batch[c_idx, 0], wrap=True)
            ky, _ = self._parabolic_peak_1d(corr_xy_batch[c_idx, 1], wrap=True)
            dxt = ((kx + half_M_sub) % M_sub - half_M_sub) * ds_p
            dyt = ((ky + half_M_sub) % M_sub - half_M_sub) * ds_p
            dx_tildes[c_idx] = dxt
            dy_tildes[c_idx] = dyt
            c, s = float(c_arr[c_idx]), float(s_arr[c_idx])
            dx_cands[c_idx] = c * dxt - s * dyt
            dy_cands[c_idx] = s * dxt + c * dyt
        tb = time.perf_counter()
        acc_proj_fft = tb - ta

        # --- Step 3: 寬帶 WLSQ 預拉入與反極性計分 ---
        acc_wide_wlsq = 0.0
        acc_scoring = 0.0

        def _score_pose(dx_val, dy_val, th_val):
            cr, sr = float(np.cos(th_val)), float(np.sin(th_val))
            gx_t = qx_c - dx_val
            gy_t = qy_c - dy_val
            px_test = cr * gx_t + sr * gy_t
            py_test = -sr * gx_t + cr * gy_t
            ux_test = cr * u1x_c + sr * u1y_c
            uy_test = -sr * u1x_c + cr * u1y_c

            ix = np.clip(np.rint(px_test + cx).astype(np.int32), 0, W_img - 1)
            iy = np.clip(np.rint(py_test + cy).astype(np.int32), 0, H_img - 1)
            d_val = dist_map[iy, ix]
            pol = ux_test * nx_map[iy, ix] + uy_test * ny_map[iy, ix]

            inv_tau = 1.0 / score_dist_tau
            norm_d = d_val * inv_tau
            prox = np.maximum(0.0, 1.0 - norm_d)
            pos_s = float(np.sum(np.where(pol >= 0.5, prox * pol, 0.0)))
            # 反極性扣分 + 懸空未匹配特徵點扣分 (防止圓環/圓轂局部重疊但缺角/搖臂懸空騙分)
            neg_pol_p = float(np.sum(np.where(pol < -0.2, prox * (0.8 * pol), 0.0)))
            miss_p = -0.18 * float(np.sum(np.clip(norm_d - 1.0, 0.0, 2.5)))
            neg_p = neg_pol_p + miss_p
            return pos_s, neg_p, pos_s + neg_p

        pulled_poses = []
        for c_idx in range(K):
            tw0 = time.perf_counter()
            dx_r, dy_r, th_r, *_ = self._wlsq_step(
                qx_c, qy_c, u1x_c, u1y_c,
                float(dx_cands[c_idx]), float(dy_cands[c_idx]), float(th_arr[c_idx]),
                tau=wide_tau, pol_th=0.35,
            )
            if scale_ratio > 1.5:
                dx_r, dy_r, th_r, *_ = self._wlsq_step(
                    qx_c, qy_c, u1x_c, u1y_c,
                    dx_r, dy_r, th_r,
                    tau=score_dist_tau, pol_th=0.5,
                )
            tw1 = time.perf_counter()
            pos_s, neg_p, tot_s = _score_pose(dx_r, dy_r, th_r)
            tw2 = time.perf_counter()

            acc_wide_wlsq += (tw1 - tw0)
            acc_scoring += (tw2 - tw1)
            pulled_poses.append([dx_r, dy_r, th_r, pos_s, neg_p, tot_s])

        best_score = -1e18
        best_pose = (0.0, 0.0, 0.0)
        best_idx = 0
        cand_records = []

        for c_idx in range(K):
            dx_r, dy_r, th_r, pos_score, neg_penalty, total_score = pulled_poses[c_idx]
            th_r_deg = float(((np.rad2deg(th_r) + 180.0) % 360.0) - 180.0)
            cand_records.append(
                {
                    "rank": c_idx + 1,
                    "init_ang_deg": float(cand_angles_deg[c_idx]),
                    "pulled_ang_deg": th_r_deg,
                    "dx_cand": float(dx_cands[c_idx]),
                    "dy_cand": float(dy_cands[c_idx]),
                    "dx_r": float(dx_r),
                    "dy_r": float(dy_r),
                    "corr_val": cand_corr_vals[c_idx],
                    "pos_score": pos_score,
                    "neg_penalty": neg_penalty,
                    "total_score": total_score,
                }
            )
            if total_score > best_score:
                best_score = total_score
                best_pose = (dx_r, dy_r, float(np.rad2deg(th_r)))
                best_idx = c_idx

        self._coarse_ct_detail = {
            "2a_orient_hist_fft_ms": (t_c1 - t_c0) * 1000.0,
            "2b_xy_proj_fft_loop_ms": acc_proj_fft * 1000.0,
            "2c_wide_wlsq_loop_ms": acc_wide_wlsq * 1000.0,
            "2d_polarity_score_loop_ms": acc_scoring * 1000.0,
        }

        self._last_coarse_debug = {
            "hist_theta1": hist_theta1,
            "corr_theta": corr_theta,
            "cand_records": cand_records,
            "best_idx": best_idx,
            "best_corr_x": corr_xy_batch[best_idx, 0],
            "best_corr_y": corr_xy_batch[best_idx, 1],
            "best_dx_tilde": float(dx_tildes[best_idx]),
            "best_dy_tilde": float(dy_tildes[best_idx]),
            "wide_tau": wide_tau,
            "score_dist_tau": score_dist_tau,
        }
        return best_pose

    def predict(self, img1, init_dx=None, init_dy=None, init_dtheta_deg=None):
        """
        預測目標影像 img1 (支援傳入檔案路徑 str 或 2D/3D ndarray) 的姿態：
        - 若未設定標記點 (p1, p2)，回傳相對於 img0 的 (dx, dy, dtheta_deg)。
        - 若已設定標記點 (p1=物件中心, p2=物件轉角)，則自動將標記點剛體映射至 img1，
          回傳「物件中心相對於攝影機畫面中心 (0,0) 的座標 (x_cam, y_cam)」與
          「物件相對於攝影機畫面右方 +X 軸 (0°) 的絕對角度 theta_cam_deg」。
        """
        if self._cache is None:
            raise ValueError(
                "[Contour_WLSQ] 尚未設定或載入模板，請先呼叫 set_orginal_img() 或 load()。"
            )
        t_pred_start = time.perf_counter()
        img_u8 = self._load_gray_u8(img1)
        t_load_done = time.perf_counter()
        load_u8_ms = (t_load_done - t_pred_start) * 1000.0

        c_data = self._cache
        H_img, W_img = c_data["H_img"], c_data["W_img"]
        cx, cy = c_data["cx"], c_data["cy"]
        scale_ratio = float(c_data.get("scale_ratio", 1.0))

        if init_dx is None or init_dy is None or init_dtheta_deg is None:
            # 1. 粗定位：使用 1/2 縮圖快速提取邊緣並求取粗姿態
            qx_c, qy_c, u1x_c, u1y_c, mag1_c, c_canny_ms, c_grad_ms = (
                self._extract_coarse_edges_fast(img_u8, max_pts=2500)
            )
            if qx_c.size < 5:
                self.rel_pose = None
                self.pred_p1 = None
                self.pred_p2 = None
                self.valid_inliers = 0
                self.coverage = 0.0
                self.rmse = 999.0
                self.exit_reason = "too_few_edges"
                self.last_ct = {}
                warnings.warn(
                    "[Contour_WLSQ] 目標影像提取到的邊緣點過少，退回 (0, 0, 0)。",
                    RuntimeWarning,
                )
                return 0.0, 0.0, 0.0

            t_coarse0 = time.perf_counter()
            dx, dy, dtheta_deg = self._estimate_coarse_pose(qx_c, qy_c, u1x_c, u1y_c, mag1_c)
            t_coarse1 = time.perf_counter()
            coarse_total_ms = (t_coarse1 - t_coarse0) * 1000.0
        else:
            c_canny_ms, c_grad_ms = 0.0, 0.0
            self._coarse_ct_detail = {}
            dx = float(init_dx)
            dy = float(init_dy)
            dtheta_deg = float(init_dtheta_deg)
            coarse_total_ms = 0.0

        self.coarse_pose = (dx, dy, dtheta_deg)
        dtheta = float(np.deg2rad(dtheta_deg))

        # 2. 根據粗定位姿態計算模板在 img1 上的貼身 Bounding Box ROI，僅於 ROI 內提取 1:1 次像素邊緣
        px0_sub = c_data["px0"][::8]
        py0_sub = c_data["py0"][::8]
        c_init, s_init = float(np.cos(dtheta)), float(np.sin(dtheta))
        tx_init = c_init * px0_sub - s_init * py0_sub + dx + cx
        ty_init = s_init * px0_sub + c_init * py0_sub + dy + cy
        pad_roi = int(max(36.0, 10.0 * scale_ratio))
        roi_bbox = (
            int(np.floor(tx_init.min())) - pad_roi,
            int(np.floor(ty_init.min())) - pad_roi,
            int(np.ceil(tx_init.max())) + pad_roi + 1,
            int(np.ceil(ty_init.max())) + pad_roi + 1,
        )

        t_fine_edge0 = time.perf_counter()
        _, qx, qy, u1x, u1y, mag1 = self._extract_subpixel_edges(
            img_u8, max_pts=8000, roi_bbox=roi_bbox
        )
        t_fine_edge1 = time.perf_counter()

        if qx.size < 5:
            # 萬一 ROI 內點數不足，退回全圖提取
            _, qx, qy, u1x, u1y, mag1 = self._extract_subpixel_edges(img_u8, max_pts=8000)
            t_fine_edge1 = time.perf_counter()

        # 合併粗邊緣與精邊緣耗時明細
        self._edge_ct_detail["1a_load_u8_ms"] = load_u8_ms
        self._edge_ct_detail["1b_canny_find_ms"] += c_canny_ms
        self._edge_ct_detail["1d_subpixel_interp_ms"] += c_grad_ms
        edge_total_ms = (
            load_u8_ms
            + c_canny_ms
            + c_grad_ms
            + (t_fine_edge1 - t_fine_edge0) * 1000.0
        )

        # 3. 窄帶 WLSQ 次像素精修
        t_wlsq0 = time.perf_counter()
        self.history = []
        self.exit_reason = None
        self.stopped_early = False
        self.iterations = 0
        step_f = 1
        qx_f, qy_f, u1x_f, u1y_f = qx, qy, u1x, u1y

        eff_max_iter = max(self.max_iter, 4) if scale_ratio > 1.5 else self.max_iter
        for i in range(eff_max_iter):
            self.iterations = i + 1
            if i == 0:
                tau = self.band_tau * max(1.0, min(3.2, 0.75 * scale_ratio))
            elif i == 1:
                tau = self.band_tau * max(1.0, min(1.8, 0.38 * scale_ratio))
            elif i == 2:
                tau = self.band_tau
            else:
                tau = max(1.5, self.band_tau * 0.7)
            dx, dy, dtheta, ddx, ddy, ddth, valid_cnt, sse, rmse = self._wlsq_step(
                qx_f, qy_f, u1x_f, u1y_f, dx, dy, dtheta, tau=tau, pol_th=self.polarity_th
            )
            if valid_cnt < 6:
                self.exit_reason = "insufficient_inliers"
                break

            self.history.append(
                {
                    "iter": i + 1,
                    "delta_dx": ddx,
                    "delta_dy": ddy,
                    "delta_dtheta_deg": float(np.rad2deg(ddth)),
                    "dx": dx,
                    "dy": dy,
                    "dtheta_deg": float(np.rad2deg(dtheta)),
                    "inliers": valid_cnt,
                    "sse": sse,
                    "rmse": rmse,
                }
            )

            if np.hypot(ddx, ddy) < self.tol and abs(ddth) < self.tol:
                self.stopped_early = True
                self.exit_reason = "tolerance"
                break
        else:
            self.exit_reason = "max_iter"

        dtheta_rel_deg = float(np.rad2deg(dtheta))
        self.rel_pose = (dx, dy, dtheta_rel_deg)

        if self.history:
            raw_step = int(self._edge_ct_detail.get("raw_step", 1))
            self.valid_inliers = int(self.history[-1]["inliers"]) * step_f * raw_step
            self.rmse = float(self.history[-1]["rmse"])
            self.coverage = float(
                self.valid_inliers / max(1, c_data["num_ref_pts"])
            )
        else:
            self.valid_inliers = 0
            self.rmse = 999.0
            self.coverage = 0.0

        c_rot, s_rot = np.cos(dtheta), np.sin(dtheta)
        ox, oy = c_data.get("gold_center_offset", (0.0, 0.0))
        gold_ang = c_data.get("gold_angle_deg", 0.0)

        x_cam = float(c_rot * ox - s_rot * oy + dx)
        y_cam = float(s_rot * ox + c_rot * oy + dy)
        theta_cam_deg = float((gold_ang + dtheta_rel_deg + 180.0) % 360.0 - 180.0)

        mark_p1 = c_data.get("mark_p1", None)
        mark_p2 = c_data.get("mark_p2", None)
        if mark_p1 is not None and mark_p2 is not None:
            self.pred_p1 = np.array([x_cam + cx, y_cam + cy], dtype=np.float64)
            v2x, v2y = mark_p2[0] - cx, mark_p2[1] - cy
            p2x_cam = c_rot * v2x - s_rot * v2y + dx
            p2y_cam = s_rot * v2x + c_rot * v2y + dy
            self.pred_p2 = np.array([p2x_cam + cx, p2y_cam + cy], dtype=np.float64)
        else:
            self.pred_p1 = None
            self.pred_p2 = None

        t_pred_end = time.perf_counter()
        fine_wlsq_ms = (t_pred_end - t_wlsq0) * 1000.0
        self.last_ct = {
            "num_edges_raw": int(qx.size),
            "num_iters_fine": int(self.iterations),
            "1_edge_extract_total_ms": edge_total_ms,
            **self._edge_ct_detail,
            "2_coarse_pose_total_ms": coarse_total_ms,
            **self._coarse_ct_detail,
            "3_fine_wlsq_total_ms": fine_wlsq_ms,
            "total_predict_ms": (t_pred_end - t_pred_start) * 1000.0,
        }
        return x_cam, y_cam, theta_cam_deg

    def is_ok(self, min_coverage=0.35, max_rmse=0.8):
        """
        機台防呆判定：檢查剛才的 predict() 定位結果是否健康可靠 (OK / NG)。
        - min_coverage: 最低有效內點輪廓覆蓋率 (0.0~1.0，預設 0.35，可攔截空拍、欠料或大面積嚴重遮擋)
        - max_rmse    : 最高允許窄帶法線殘差 (px，預設 0.8，可攔截放錯機種或嚴重變形)
        """
        return (
            self.rel_pose is not None
            and self.coverage >= float(min_coverage)
            and self.rmse <= float(max_rmse)
        )

    def format_ct_report(self):
        """回傳最近一次 predict() 的各階段 CT 耗時與佔比分析字串。"""
        if not self.last_ct:
            return "[Contour_WLSQ] 尚無 CT 紀錄，請先執行 predict()。"
        c = self.last_ct
        tot = max(c.get("total_predict_ms", 0.0), 1e-6)
        pct = lambda k: (c.get(k, 0.0) / tot) * 100.0
        lines = [
            f"=== Contour_WLSQ CT 診斷報告 (總耗時: {tot:.2f} ms | 邊緣點數: {c.get('num_edges_raw', 0)}) ===",
            f"  [階段 1] 次像素邊緣提取總計 : {c.get('1_edge_extract_total_ms', 0.0):7.2f} ms ({pct('1_edge_extract_total_ms'):5.1f}%)",
            f"    ├─ 1a. 灰階載入/轉換      : {c.get('1a_load_u8_ms', 0.0):7.2f} ms ({pct('1a_load_u8_ms'):5.1f}%)",
            f"    ├─ 1b. Canny + findNonZero: {c.get('1b_canny_find_ms', 0.0):7.2f} ms ({pct('1b_canny_find_ms'):5.1f}%)",
            f"    ├─ 1c. 全圖 GaussianBlur  : {c.get('1c_gaussian_blur_ms', 0.0):7.2f} ms ({pct('1c_gaussian_blur_ms'):5.1f}%)",
            f"    └─ 1d. 梯度與次像素內插   : {c.get('1d_subpixel_interp_ms', 0.0):7.2f} ms ({pct('1d_subpixel_interp_ms'):5.1f}%)",
            f"  [階段 2] 粗定位總計         : {c.get('2_coarse_pose_total_ms', 0.0):7.2f} ms ({pct('2_coarse_pose_total_ms'):5.1f}%)",
            f"    ├─ 2a. 1D 方向直方圖 FFT  : {c.get('2a_orient_hist_fft_ms', 0.0):7.2f} ms ({pct('2a_orient_hist_fft_ms'):5.1f}%)",
            f"    ├─ 2b. K組 XY投影與FFT    : {c.get('2b_xy_proj_fft_loop_ms', 0.0):7.2f} ms ({pct('2b_xy_proj_fft_loop_ms'):5.1f}%)",
            f"    ├─ 2c. K組 寬帶WLSQ預拉入 : {c.get('2c_wide_wlsq_loop_ms', 0.0):7.2f} ms ({pct('2c_wide_wlsq_loop_ms'):5.1f}%)",
            f"    └─ 2d. K組 反極性查表計分 : {c.get('2d_polarity_score_loop_ms', 0.0):7.2f} ms ({pct('2d_polarity_score_loop_ms'):5.1f}%)",
            f"  [階段 3] 窄帶 WLSQ 精修 ({c.get('num_iters_fine', 0)}步): {c.get('3_fine_wlsq_total_ms', 0.0):7.2f} ms ({pct('3_fine_wlsq_total_ms'):5.1f}%)",
        ]
        return "\n".join(lines)

    @staticmethod
    def _setup_mpl_font():
        """設定 Matplotlib 中文字型與負號顯示 (延遲載入)。"""
        import matplotlib

        matplotlib.rcParams["font.family"] = "sans-serif"
        matplotlib.rcParams["font.sans-serif"] = [
            "Microsoft JhengHei",
            "PingFang TC",
            "Noto Sans CJK TC",
            "DejaVu Sans",
        ]
        matplotlib.rcParams["axes.unicode_minus"] = False

    def interactive_mark_img0(
        self,
        img0=None,
        ds_title="",
        has_existing_pkl=False,
        ds_factor=None,
        roi_circle_idx=4,
    ):
        """
        開啟互動式同心圓靶心視窗，於基準影像 img0 上：
          1. 按住 [i 鍵] 移動滑鼠，將筆刷圓圈內的 Canny 點塗抹納入 Template 特徵點 (未選到的點不納入)
          2. 左鍵點擊標定 2 個基準點：
             - P1 (x1, y1): 物件中心
             - P2 (x2, y2): 物件轉角方向 (由 P1 -> P2 向量定義基準角)
        確認完成後自動呼叫 self.apply_roi_mask() 與 self.set_golden_points(p1, p2) 並回傳 (p1, p2)；
        若按 s 鍵跳過或未按確認即關閉視窗，回傳 (None, None)。
        """
        import matplotlib.pyplot as plt
        from matplotlib.patches import Circle

        self._setup_mpl_font()

        if img0 is not None and self._cache is None:
            self.set_orginal_img(img0)
        if self._cache is None or self._ref_img is None:
            raise ValueError(
                "[Contour_WLSQ] 請先呼叫 set_orginal_img(img0) 或於參數傳入 img0！"
            )

        ref_img = self._ref_img
        edge_x_orig, edge_y_orig = self.get_golden_edges()
        num_total_pts = edge_x_orig.size
        H_orig, W_orig = ref_img.shape[:2]

        if ds_factor is None:
            ds_factor = max(1, int(round(max(H_orig, W_orig) / 900.0)))
        else:
            ds_factor = max(1, int(ds_factor))

        img0_ds = ref_img[::ds_factor, ::ds_factor] if ds_factor > 1 else ref_img
        H, W = img0_ds.shape[:2]

        scale_x = (W_orig - 1) / (W - 1) if W > 1 else 1.0
        scale_y = (H_orig - 1) / (H - 1) if H > 1 else 1.0
        cx, cy = (W - 1) / 2.0, (H - 1) / 2.0

        # 將所有原始 Canny 點投影至顯示座標系，並建立一對一的 ROI 選取遮罩
        edge_x_ds = edge_x_orig / scale_x
        edge_y_ds = edge_y_orig / scale_y
        selected_mask = np.zeros(num_total_pts, dtype=bool)

        scale_ui = max(1.0, min(H, W) / 400.0)
        base_radii = [r * scale_ui for r in (4, 8, 12, 16, 20, 26, 34, 45)]
        roi_circle_idx = int(np.clip(roi_circle_idx, 0, len(base_radii) - 1))

        state = {
            "r_scale": 1.0,
            "press_xy": None,
            "confirmed": False,
            "skip_use_existing": False,
            "last_mouse": (cx, cy),
            "show_edges": True,
            "i_pressed": False,
            "warn_msg": "",
        }
        clicked_pts = []

        fig, ax = plt.subplots(figsize=(9.5, 8.8))
        ax.imshow(img0_ds, cmap="gray", vmin=0, vmax=255, interpolation="nearest")

        ax.axhline(cy, color="cyan", ls="--", lw=0.8, alpha=0.45, label="攝影機中心 (0, 0)")
        ax.axvline(cx, color="cyan", ls="--", lw=0.8, alpha=0.45)
        ax.plot(cx, cy, "c+", ms=10, mew=1.2)

        pt_size = 1.2 * (ds_factor ** 1.5)
        # 未選取的原始 Canny 點 (暗藍色半透明)
        unselected_scatter = ax.scatter(
            edge_x_ds,
            edge_y_ds,
            s=pt_size,
            c="deepskyblue",
            alpha=0.28,
            label="未選 Canny 點 (按 e 開關)",
        )
        # 被 i 鍵塗抹選中的 ROI Template 點 (亮綠色)
        selected_scatter = ax.scatter(
            [],
            [],
            s=pt_size * 1.6,
            c="lime",
            alpha=0.95,
            label="已選 ROI 特徵點 (按住 i 塗抹 / c 清空)",
        )

        (cursor_h,) = ax.plot([0, W], [cy, cy], color="lime", lw=0.8, ls="-", alpha=0.75)
        (cursor_v,) = ax.plot([cx, cx], [0, H], color="lime", lw=0.8, ls="-", alpha=0.75)
        (cursor_center_dot,) = ax.plot([cx], [cy], "g+", ms=8, mew=1.2, alpha=0.9)

        cursor_circles = []
        for idx_r, r in enumerate(base_radii):
            is_roi_ring = idx_r == roi_circle_idx
            circ = Circle(
                (cx, cy),
                radius=r,
                fill=False,
                edgecolor="magenta" if is_roi_ring else ("lime" if idx_r % 2 == 0 else "yellow"),
                lw=1.5 if is_roi_ring else 0.85,
                ls="--" if is_roi_ring else ("-" if idx_r % 2 == 0 else ":"),
                alpha=0.9 if is_roi_ring else 0.7,
            )
            ax.add_patch(circ)
            cursor_circles.append(circ)

        (preview_line,) = ax.plot([], [], color="yellow", lw=1.4, ls="--", alpha=0.85)
        (p1_marker,) = ax.plot([], [], "ro", ms=8, mew=1.5, fillstyle="none", label="P1 (物件中心)")
        (p1_dot,) = ax.plot([], [], "r+", ms=10, mew=1.5)
        (p2_marker,) = ax.plot([], [], "yo", ms=7, mew=1.5, fillstyle="none", label="P2 (轉角方向)")
        arrow_patch = {"ann": None}

        ax.set_xlim(0, W)
        ax.set_ylim(H, 0)
        ax.legend(loc="upper right", fontsize=8.0)

        skip_hint = " | [s]沿用舊.pkl" if has_existing_pkl else ""
        prefix = f"{ds_title} — " if ds_title else ""

        def get_brush_radius_ds():
            return base_radii[roi_circle_idx] * state["r_scale"]

        def update_roi_scatter():
            if np.any(selected_mask):
                pts_sel = np.column_stack((edge_x_ds[selected_mask], edge_y_ds[selected_mask]))
                selected_scatter.set_offsets(pts_sel)
            else:
                selected_scatter.set_offsets(np.empty((0, 2)))

        def brush_select_at(x_ds, y_ds):
            r_ds = get_brush_radius_ds()
            dx = edge_x_ds - x_ds
            dy = edge_y_ds - y_ds
            hit = (dx * dx + dy * dy) <= (r_ds * r_ds)
            if np.any(hit & ~selected_mask):
                selected_mask[hit] = True
                state["warn_msg"] = ""
                update_roi_scatter()

        def update_brush_ring_style():
            roi_circ = cursor_circles[roi_circle_idx]
            if state["i_pressed"]:
                roi_circ.set_edgecolor("magenta")
                roi_circ.set_linewidth(2.4)
                roi_circ.set_linestyle("-")
                roi_circ.set_fill(True)
                roi_circ.set_facecolor((1.0, 0.0, 1.0, 0.12))
            else:
                roi_circ.set_edgecolor("magenta")
                roi_circ.set_linewidth(1.5)
                roi_circ.set_linestyle("--")
                roi_circ.set_fill(False)

        def update_title(mouse_x=None, mouse_y=None):
            coord_str = ""
            if mouse_x is not None and mouse_y is not None:
                orig_x = mouse_x * scale_x
                orig_y = mouse_y * scale_y
                coord_str = f"游標=({orig_x:.1f}, {orig_y:.1f})"

            n_sel = int(np.sum(selected_mask))
            i_status = "【筆刷 ON】" if state["i_pressed"] else "按住 [i] 局部塗抹"
            if n_sel == 0:
                roi_str = f" | ROI: 預設全選({num_total_pts}點, {i_status})"
            else:
                roi_str = f" | ROI: 已選 {n_sel}/{num_total_pts}點 ({i_status})"

            if state["warn_msg"]:
                msg = f"{prefix}[注意] {state['warn_msg']}{roi_str}\n(請補選點數，或按 [c 鍵] 清空恢復全選)"
                col = "red"
            elif len(clicked_pts) == 0:
                msg = (
                    f"{prefix}【Step 1】左鍵點 [P1:中心] (選用: 按住 [i] 局部刷選 ROI)  {coord_str}{roi_str}\n"
                    f"(滾輪:縮放 | [/]:調筆刷圈 | c:清空恢復全選 | e:邊緣 | r:重置{skip_hint})"
                )
                col = "magenta" if state["i_pressed"] else "crimson"
            elif len(clicked_pts) == 1:
                p1 = clicked_pts[0]
                ang_str = ""
                if mouse_x is not None and mouse_y is not None:
                    ang = np.rad2deg(
                        np.arctan2((mouse_y - p1[1]) * scale_y, (mouse_x - p1[0]) * scale_x)
                    )
                    ang_str = f" | 預覽角={ang:+.2f}°"
                msg = (
                    f"{prefix}【Step 2】左鍵點 [P2:方向] (選用: 按住 [i] 局部刷選 ROI)  {coord_str}{ang_str}{roi_str}\n"
                    f"(右鍵/Backspace:重選P1 | c:清空恢復全選 | [/]:調筆刷圈{skip_hint})"
                )
                col = "magenta" if state["i_pressed"] else "darkgreen"
            else:
                p1, p2 = clicked_pts[0], clicked_pts[1]
                ang = np.rad2deg(
                    np.arctan2((p2[1] - p1[1]) * scale_y, (p2[0] - p1[0]) * scale_x)
                )
                is_roi_valid = (n_sel == 0) or (n_sel >= 5)
                ready_hint = (
                    ">>> 請按 [Enter / 空白鍵] 確認完成 (未刷 ROI 預設全選；可按住 [i] 刷選局部或 [c] 恢復全選) <<<"
                    if is_roi_valid
                    else ">>> [注意] 局部 ROI 點數過少 (<5點)！請按住 [i] 補刷，或按 [c 鍵] 清空恢復全選 <<<"
                )
                msg = (
                    f"{prefix}【已標 2 點】P1=({p1[0]*scale_x:.1f},{p1[1]*scale_y:.1f}), "
                    f"P2=({p2[0]*scale_x:.1f},{p2[1]*scale_y:.1f}), 角={ang:+.2f}°{roi_str}\n"
                    f"{ready_hint}"
                )
                col = "magenta" if state["i_pressed"] else ("navy" if is_roi_valid else "darkorange")
            ax.set_title(msg, fontsize=9.8, fontweight="bold", color=col)

        def redraw_markers():
            if arrow_patch["ann"] is not None:
                arrow_patch["ann"].remove()
                arrow_patch["ann"] = None

            if len(clicked_pts) == 0:
                p1_marker.set_data([], [])
                p1_dot.set_data([], [])
                p2_marker.set_data([], [])
                preview_line.set_data([], [])
            elif len(clicked_pts) == 1:
                p1 = clicked_pts[0]
                p1_marker.set_data([p1[0]], [p1[1]])
                p1_dot.set_data([p1[0]], [p1[1]])
                p2_marker.set_data([], [])
                mx, my = state["last_mouse"]
                preview_line.set_data([p1[0], mx], [p1[1], my])
            else:
                p1, p2 = clicked_pts[0], clicked_pts[1]
                p1_marker.set_data([p1[0]], [p1[1]])
                p1_dot.set_data([p1[0]], [p1[1]])
                p2_marker.set_data([p2[0]], [p2[1]])
                preview_line.set_data([], [])
                arrow_patch["ann"] = ax.annotate(
                    "",
                    xy=p2,
                    xytext=p1,
                    arrowprops=dict(arrowstyle="->", color="lime", lw=2.2, mutation_scale=18),
                )
            update_title(*state["last_mouse"])
            fig.canvas.draw_idle()

        def on_move(event):
            if event.inaxes != ax or event.xdata is None or event.ydata is None:
                return
            x, y = float(event.xdata), float(event.ydata)
            state["last_mouse"] = (x, y)
            cursor_h.set_data([0, W], [y, y])
            cursor_v.set_data([x, x], [0, H])
            cursor_center_dot.set_data([x], [y])
            for circ, r0 in zip(cursor_circles, base_radii):
                circ.center = (x, y)
                circ.set_radius(r0 * state["r_scale"])
            if len(clicked_pts) == 1:
                p1 = clicked_pts[0]
                preview_line.set_data([p1[0], x], [p1[1], y])
            if state["i_pressed"]:
                brush_select_at(x, y)
            update_title(x, y)
            fig.canvas.draw_idle()

        def on_scroll(event):
            if event.inaxes != ax or event.xdata is None or event.ydata is None:
                return
            scale_factor = 0.8 if event.button == "up" else 1.25
            cur_xlim = ax.get_xlim()
            cur_ylim = ax.get_ylim()
            xdata, ydata = float(event.xdata), float(event.ydata)
            new_w = (cur_xlim[1] - cur_xlim[0]) * scale_factor
            new_h = (cur_ylim[0] - cur_ylim[1]) * scale_factor
            if new_w >= W * 1.2 or abs(new_h) >= H * 1.2:
                ax.set_xlim(0, W)
                ax.set_ylim(H, 0)
            else:
                rel_x = (xdata - cur_xlim[0]) / (cur_xlim[1] - cur_xlim[0])
                rel_y = (ydata - cur_ylim[1]) / (cur_ylim[0] - cur_ylim[1])
                xmin = xdata - rel_x * new_w
                xmax = xmin + new_w
                ymin = ydata - rel_y * new_h
                ymax = ymin + new_h
                ax.set_xlim(xmin, xmax)
                ax.set_ylim(ymax, ymin)
            fig.canvas.draw_idle()

        def on_press(event):
            if event.inaxes != ax or event.xdata is None or event.ydata is None:
                return
            tb = getattr(fig.canvas, "toolbar", None)
            if tb is not None and getattr(tb, "mode", "") != "":
                return
            if event.button == 1:
                state["press_xy"] = (event.x, event.y, float(event.xdata), float(event.ydata))
            elif event.button == 3:
                if clicked_pts:
                    clicked_pts.pop()
                    redraw_markers()

        def on_release(event):
            if event.button != 1 or state["press_xy"] is None:
                return
            tb = getattr(fig.canvas, "toolbar", None)
            if tb is not None and getattr(tb, "mode", "") != "":
                state["press_xy"] = None
                return
            px_scr, py_scr, x_data, y_data = state["press_xy"]
            state["press_xy"] = None
            if event.inaxes != ax or event.x is None or event.y is None:
                return
            if np.hypot(event.x - px_scr, event.y - py_scr) > 3.0:
                return
            if len(clicked_pts) < 2:
                clicked_pts.append((x_data, y_data))
                redraw_markers()

        def on_key_press(event):
            if event.key in ("i", "I"):
                if not state["i_pressed"]:
                    state["i_pressed"] = True
                    update_brush_ring_style()
                mx, my = state["last_mouse"]
                brush_select_at(mx, my)
                update_title(mx, my)
                fig.canvas.draw_idle()
            elif event.key in ("c", "C"):
                selected_mask[:] = False
                state["warn_msg"] = ""
                update_roi_scatter()
                update_title(*state["last_mouse"])
                fig.canvas.draw_idle()
            elif event.key in ("enter", " "):
                n_sel = int(np.sum(selected_mask))
                if len(clicked_pts) < 2:
                    state["warn_msg"] = "請先左鍵點選 P1 與 P2 兩點！"
                    update_title(*state["last_mouse"])
                    fig.canvas.draw_idle()
                elif 0 < n_sel < 5:
                    state["warn_msg"] = "局部 ROI 點數過少 (< 5 點)！請補刷或按 c 恢復全選"
                    update_title(*state["last_mouse"])
                    fig.canvas.draw_idle()
                else:
                    state["confirmed"] = True
                    for cid in cids:
                        fig.canvas.mpl_disconnect(cid)
                    cids.clear()
                    plt.close(fig)
            elif event.key in ("s", "S") and has_existing_pkl:
                state["skip_use_existing"] = True
                for cid in cids:
                    fig.canvas.mpl_disconnect(cid)
                cids.clear()
                plt.close(fig)
            elif event.key in ("backspace", "delete"):
                if clicked_pts:
                    clicked_pts.pop()
                    redraw_markers()
            elif event.key == "]":
                state["r_scale"] *= 1.15
                for circ, r0 in zip(cursor_circles, base_radii):
                    circ.set_radius(r0 * state["r_scale"])
                if state["i_pressed"]:
                    brush_select_at(*state["last_mouse"])
                update_title(*state["last_mouse"])
                fig.canvas.draw_idle()
            elif event.key == "[":
                state["r_scale"] = max(0.2, state["r_scale"] / 1.15)
                for circ, r0 in zip(cursor_circles, base_radii):
                    circ.set_radius(r0 * state["r_scale"])
                if state["i_pressed"]:
                    brush_select_at(*state["last_mouse"])
                update_title(*state["last_mouse"])
                fig.canvas.draw_idle()
            elif event.key == "r":
                ax.set_xlim(0, W)
                ax.set_ylim(H, 0)
                fig.canvas.draw_idle()
            elif event.key == "e":
                state["show_edges"] = not state["show_edges"]
                unselected_scatter.set_visible(state["show_edges"])
                selected_scatter.set_visible(state["show_edges"])
                fig.canvas.draw_idle()

        def on_key_release(event):
            if event.key in ("i", "I") and state["i_pressed"]:
                state["i_pressed"] = False
                update_brush_ring_style()
                update_title(*state["last_mouse"])
                fig.canvas.draw_idle()

        update_title(cx, cy)
        plt.tight_layout()

        cids = [
            fig.canvas.mpl_connect("motion_notify_event", on_move),
            fig.canvas.mpl_connect("scroll_event", on_scroll),
            fig.canvas.mpl_connect("button_press_event", on_press),
            fig.canvas.mpl_connect("button_release_event", on_release),
            fig.canvas.mpl_connect("key_press_event", on_key_press),
            fig.canvas.mpl_connect("key_release_event", on_key_release),
        ]
        plt.show()
        for cid in cids:
            fig.canvas.mpl_disconnect(cid)

        if state["skip_use_existing"] or not state["confirmed"]:
            return None, None

        p1_ds, p2_ds = clicked_pts[0], clicked_pts[1]
        p1_orig = (p1_ds[0] * scale_x, p1_ds[1] * scale_y)
        p2_orig = (p2_ds[0] * scale_x, p2_ds[1] * scale_y)

        # 若有按 i 鍵局部選取 ROI 點，僅保留選中的點重建 Template；若未選 (0點) 則預設保留全圖所有 Canny 點
        if np.any(selected_mask):
            self.apply_roi_mask(selected_mask)
        self.set_golden_points(p1_orig, p2_orig)
        return p1_orig, p2_orig

    def plot_diagnostics(self, img1, title_prefix=""):
        """
        彈出 2×3 六宮格「全流程 X 光超參數診斷面板」：
          [左上] ① Canny 次像素邊緣 & 梯度法線小箭頭 (檢視 canny_low/high, blur_level)
          [中上] ② Step 1: 1D 梯度方向角互相關頻譜與前 K 名候選峰值 (檢視 angle_bins, top_k_angles)
          [右上] ③ Step 3: 候選角寬帶預拉入 PK 計分板 — 同向加分 vs 反極性扣分 (檢視遮擋干擾)
          [左下] ④ Step 2: 勝出角轉正後 1D X/Y 投影互相關峰值曲線 (檢視 proj_sigma, proj_len)
          [中下] ⑤ Step 4: 窄帶 WLSQ 點雲「紅綠燈」分類圖 — [●]內點 / [×]距離剔除 / [▲]極性剔除 (檢視 band_tau, polarity_th)
          [右下] ⑥ 迭代收斂軌跡 (Coarse -> Iter 1..K) 與超參數調校建議儀表板 (檢視 max_iter, tol, Coverage)
        """
        import matplotlib.pyplot as plt

        self._setup_mpl_font()

        img1_gray = self._load_gray_array(img1)
        x_cam, y_cam, theta_cam_deg = self.predict(img1_gray)
        if self.rel_pose is None:
            print(f"[plot_diagnostics] {title_prefix} 提取到的邊緣點過少，無法產生診斷面板。")
            return
        _, qx, qy, u1x, u1y, mag1 = self._extract_subpixel_edges(img1_gray)

        c_data = self._cache
        H_img, W_img = c_data["H_img"], c_data["W_img"]
        cx, cy = c_data["cx"], c_data["cy"]
        px0, py0 = c_data["px0"], c_data["py0"]
        dbg = getattr(self, "_last_coarse_debug", None)

        fig, axes = plt.subplots(2, 3, figsize=(18.5, 10.5))
        ax1, ax2, ax3 = axes[0]
        ax4, ax5, ax6 = axes[1]

        # =================================================================
        # [宮格 1 - 左上] Canny 次像素邊緣 + 梯度法線小箭頭
        # =================================================================
        ax1.imshow(img1_gray, cmap="gray", vmin=0, vmax=255)
        if qx.size > 0:
            ex1 = qx + cx
            ey1 = qy + cy
            sc1 = ax1.scatter(
                ex1, ey1, c=mag1, cmap="plasma", s=3.0, alpha=0.85, label=f"邊緣點 (N={qx.size})"
            )
            plt.colorbar(sc1, ax=ax1, fraction=0.046, pad=0.03, label="梯度強度 mag")
            step_q = max(1, qx.size // 45)
            ax1.quiver(
                ex1[::step_q],
                ey1[::step_q],
                u1x[::step_q],
                u1y[::step_q],
                color="cyan",
                angles="xy",
                scale_units="xy",
                scale=0.12,
                width=0.004,
                label="梯度法線 (指向亮區)",
            )
        ax1.set_xlim(0, W_img)
        ax1.set_ylim(H_img, 0)
        ax1.legend(loc="lower right", fontsize=8)
        ax1.set_title(
            f"① 邊緣與法線小箭頭 (N={qx.size})\n"
            f"[參數: canny=({self.canny_low},{self.canny_high}), blur={self.blur_level}]",
            fontsize=10.5,
            fontweight="bold",
        )

        # =================================================================
        # [宮格 2 - 中上] Step 1: 1D 角度投票箱互相關頻譜
        # =================================================================
        if dbg is not None:
            B = self.angle_bins
            corr_th = dbg["corr_theta"]
            angles_grid = ((np.arange(B) * (360.0 / B)) + 180.0) % 360.0 - 180.0
            sort_idx = np.argsort(angles_grid)
            ax2.plot(
                angles_grid[sort_idx],
                corr_th[sort_idx],
                color="royalblue",
                lw=1.5,
                label="1D 方向互相關 corr_θ",
            )
            ax2.axhline(0.0, color="gray", ls=":", lw=0.8)

            best_idx = dbg["best_idx"]
            for rec in dbg["cand_records"]:
                r_idx = rec["rank"] - 1
                ang0 = rec["init_ang_deg"]
                cval = rec["corr_val"]
                is_win = r_idx == best_idx
                ax2.plot(
                    ang0,
                    cval,
                    "o",
                    color="limegreen" if is_win else "crimson",
                    ms=8 if is_win else 6,
                )
                ax2.annotate(
                    f"#{rec['rank']} ({ang0:+.1f}°)",
                    xy=(ang0, cval),
                    xytext=(0, 8 if is_win else -14),
                    textcoords="offset points",
                    ha="center",
                    fontsize=8.5,
                    fontweight="bold" if is_win else "normal",
                    color="darkgreen" if is_win else "darkred",
                )
            win_ang = dbg["cand_records"][best_idx]["init_ang_deg"]
            ax2.axvline(win_ang, color="limegreen", ls="--", lw=1.2, label=f"勝出初值角 ({win_ang:+.1f}°)")
            ax2.set_xlim(-180, 180)
            ax2.set_xlabel("旋轉角度 dtheta (deg)")
            ax2.set_ylabel("正規化互相關係數")
            ax2.grid(True, ls=":", alpha=0.5)
            ax2.legend(loc="upper right", fontsize=8)
        ax2.set_title(
            f"② Step 1: 角度投票箱互相關頻譜\n"
            f"[參數: angle_bins={self.angle_bins}, top_k_angles={self.top_k_angles}]",
            fontsize=10.5,
            fontweight="bold",
        )

        # =================================================================
        # [宮格 3 - 右上] Step 3: 候選角寬帶預拉入 PK 計分板
        # =================================================================
        if dbg is not None:
            recs = dbg["cand_records"]
            best_idx = dbg["best_idx"]
            y_pos = np.arange(len(recs))
            pos_scores = [r["pos_score"] for r in recs]
            neg_pens = [r["neg_penalty"] for r in recs]
            tot_scores = [r["total_score"] for r in recs]
            labels = [
                f"#{r['rank']}: {r['init_ang_deg']:+.1f}°->{r['pulled_ang_deg']:+.1f}°"
                + (" ★勝出" if (r["rank"] - 1) == best_idx else "")
                for r in recs
            ]

            ax3.barh(y_pos, pos_scores, color="mediumseagreen", alpha=0.75, label="同向邊緣加分 (+)")
            ax3.barh(y_pos, neg_pens, color="indianred", alpha=0.75, label="反極性邊緣扣分 (-)")
            for yp, tot, r in zip(y_pos, tot_scores, recs):
                is_win = (r["rank"] - 1) == best_idx
                ax3.plot(tot, yp, "D", color="gold" if is_win else "navy", ms=7)
                ax3.text(
                    max(pos_scores) * 0.02,
                    yp,
                    f" 總分={tot:.1f}",
                    va="center",
                    fontsize=8.5,
                    fontweight="bold" if is_win else "normal",
                    color="darkgreen" if is_win else "black",
                )
            ax3.set_yticks(y_pos)
            ax3.set_yticklabels(labels, fontsize=8.5)
            ax3.invert_yaxis()
            ax3.axvline(0.0, color="black", lw=0.8)
            ax3.set_xlabel("對齊評分 (Score)")
            ax3.grid(True, axis="x", ls=":", alpha=0.5)
            ax3.legend(loc="lower right", fontsize=8)
        ax3.set_title(
            f"③ Step 3: 候選角寬帶預拉入 PK 計分板\n"
            f"[寬帶磁場 wide_tau={dbg['wide_tau']:.1f}px, 評分帶={dbg['score_dist_tau']:.1f}px]",
            fontsize=10.5,
            fontweight="bold",
        )

        # =================================================================
        # [宮格 4 - 左下] Step 2: 勝出角轉正後 X / Y 投影互相關峰值
        # =================================================================
        if dbg is not None and dbg["best_corr_x"] is not None:
            M_c = dbg["best_corr_x"].size
            ds_c = self.proj_len / float(M_c)
            shifts = (((np.arange(M_c) + M_c / 2.0) % M_c) - M_c / 2.0) * ds_c
            s_idx = np.argsort(shifts)
            shifts_sorted = shifts[s_idx]
            cx_sorted = dbg["best_corr_x"][s_idx]
            cy_sorted = dbg["best_corr_y"][s_idx]

            ax4.plot(shifts_sorted, cx_sorted, color="dodgerblue", lw=1.5, label="X 軸投影互相關 corr_x")
            ax4.plot(shifts_sorted, cy_sorted, color="darkorange", lw=1.5, label="Y 軸投影互相關 corr_y")
            ax4.axvline(
                dbg["best_dx_tilde"],
                color="dodgerblue",
                ls="--",
                lw=1.2,
                label=f"峰值 dx_tilde={dbg['best_dx_tilde']:+.1f} px",
            )
            ax4.axvline(
                dbg["best_dy_tilde"],
                color="darkorange",
                ls="--",
                lw=1.2,
                label=f"峰值 dy_tilde={dbg['best_dy_tilde']:+.1f} px",
            )
            lim_view = max(W_img, H_img) * 0.65
            ax4.set_xlim(-lim_view, lim_view)
            ax4.set_xlabel("轉正座標系下之平移偏移量 (px)")
            ax4.set_ylabel("投影互相關強度")
            ax4.grid(True, ls=":", alpha=0.5)
            ax4.legend(loc="upper right", fontsize=8)
        ax4.set_title(
            f"④ Step 2: 1D X/Y 影子投影互相關峰值\n"
            f"[參數: proj_len={self.proj_len} (自動), proj_sigma={self.proj_sigma}]",
            fontsize=10.5,
            fontweight="bold",
        )

        # =================================================================
        # [宮格 5 - 中下] Step 4: 窄帶 WLSQ 點雲「紅綠燈」分類診斷圖
        # =================================================================
        dx_f, dy_f, dth_f_deg = self.rel_pose
        dth_f = np.deg2rad(dth_f_deg)
        cf, sf = np.cos(dth_f), np.sin(dth_f)
        px_pull = cf * (qx - dx_f) + sf * (qy - dy_f)
        py_pull = -sf * (qx - dx_f) + cf * (qy - dy_f)
        ux_pull = cf * u1x + sf * u1y
        uy_pull = -sf * u1x + cf * u1y

        ix_p = np.clip(np.rint(px_pull + cx).astype(np.int32), 0, W_img - 1)
        iy_p = np.clip(np.rint(py_pull + cy).astype(np.int32), 0, H_img - 1)
        px0_s = c_data["px0_map"][iy_p, ix_p]
        py0_s = c_data["py0_map"][iy_p, ix_p]
        nx_s = c_data["nx_map"][iy_p, ix_p]
        ny_s = c_data["ny_map"][iy_p, ix_p]

        err_f = (px_pull - px0_s) * nx_s + (py_pull - py0_s) * ny_s
        abs_err_f = np.abs(err_f)
        pol_f = ux_pull * nx_s + uy_pull * ny_s

        tau_final = self.band_tau if self.max_iter <= 2 else max(1.5, self.band_tau * 0.7)
        mask_inlier = (abs_err_f < tau_final) & (pol_f >= self.polarity_th)
        mask_pol_rej = (abs_err_f < tau_final) & (~mask_inlier)
        mask_dist_rej = abs_err_f >= tau_final

        n_in = int(np.sum(mask_inlier))
        n_pol = int(np.sum(mask_pol_rej))
        n_dist = int(np.sum(mask_dist_rej))
        cov_pct = 100.0 * n_in / max(1, c_data["num_ref_pts"])

        ax5.imshow(np.minimum(c_data["dist_map"], 15.0), cmap="Greys", alpha=0.35)
        ax5.scatter(px0 + cx, py0 + cy, s=1.0, c="royalblue", alpha=0.45, label="標準圖 img0 輪廓")

        if n_dist > 0:
            ax5.scatter(
                px_pull[mask_dist_rej] + cx,
                py_pull[mask_dist_rej] + cy,
                s=14,
                c="red",
                marker="x",
                alpha=0.85,
                label=f"[×] 距離剔除 |e|>={tau_final:.2f}px ({n_dist}點: 灰塵/遮擋)",
            )
        if n_pol > 0:
            ax5.scatter(
                px_pull[mask_pol_rej] + cx,
                py_pull[mask_pol_rej] + cy,
                s=16,
                c="darkviolet",
                marker="^",
                alpha=0.85,
                label=f"[▲] 極性剔除 pol<{self.polarity_th} ({n_pol}點: 反相邊緣)",
            )
        if n_in > 0:
            ax5.scatter(
                px_pull[mask_inlier] + cx,
                py_pull[mask_inlier] + cy,
                s=6,
                c="limegreen",
                marker="o",
                alpha=0.9,
                label=f"[●] 有效內點 Inliers ({n_in}點, 覆蓋率={cov_pct:.1f}%)",
            )

        ax5.set_xlim(0, W_img)
        ax5.set_ylim(H_img, 0)
        ax5.legend(loc="lower right", fontsize=7.8)
        ax5.set_title(
            f"⑤ Step 4: 窄帶 WLSQ 點雲「紅綠燈」分類圖\n"
            f"[參數: band_tau={self.band_tau}->{tau_final:.2f}px, polarity_th={self.polarity_th}]",
            fontsize=10.5,
            fontweight="bold",
        )

        # =================================================================
        # [宮格 6 - 右下] 迭代收斂軌跡與自動調參建議
        # =================================================================
        if self.history:
            iters = [h["iter"] for h in self.history]
            step_xy = [np.hypot(h["delta_dx"], h["delta_dy"]) for h in self.history]
            rmses = [h["rmse"] for h in self.history]

            ax6_r = ax6.twinx()
            (l1,) = ax6.plot(iters, step_xy, "o-", color="royalblue", lw=2.0, ms=7, label="修正步長 ||Δdxy|| (px)")
            ax6.axhline(self.tol, color="royalblue", ls="--", lw=0.9, alpha=0.6, label=f"收斂門檻 tol={self.tol}")
            (l2,) = ax6_r.plot(iters, rmses, "s--", color="seagreen", lw=2.0, ms=7, label="窄帶殘差 RMSE (px)")

            ax6.set_xticks(iters)
            ax6.set_xticklabels([f"Iter {k}" for k in iters])
            ax6.set_ylabel("修正步長 ||Δdxy|| (px)", color="royalblue")
            ax6_r.set_ylabel("加權殘差 RMSE (px)", color="seagreen")
            ax6.grid(True, ls=":", alpha=0.5)
            ax6.legend(handles=[l1, l2], loc="upper right", fontsize=8)

        rmse_final = self.history[-1]["rmse"] if self.history else 999.0
        tips = []
        if qx.size < 0.4 * c_data["num_ref_pts"]:
            tips.append("注意：邊緣點偏少，建議調低 canny_low / canny_high")
        if cov_pct < 35.0:
            tips.append("注意：內點覆蓋率 < 35%，若零件有形變可調大 band_tau 至 3.5，或檢查是否嚴重遮擋")
        if rmse_final > 0.6:
            tips.append("注意：RMSE 偏高，若邊緣有毛邊/灰塵混入綠點，建議調小 band_tau 至 1.8")
        if not tips:
            tips.append("【正常】內點覆蓋充足、極性一致且殘差極低，無需調整超參數")

        cx_p, cy_p, th_c = self.coarse_pose
        diag_text = (
            f"【收斂狀態】 exit_reason = '{self.exit_reason}' (共跑 {self.iterations} 步)\n"
            f"  • 粗定位初值 (Coarse) : dx={cx_p:+.2f}px, dy={cy_p:+.2f}px, dθ={th_c:+.2f}°\n"
            f"  • 精修後相對 (Final)  : dx={dx_f:+.2f}px, dy={dy_f:+.2f}px, dθ={dth_f_deg:+.2f}°\n"
            f"  • 攝影機座標 (Camera) : X={x_cam:+.2f}px, Y={y_cam:+.2f}px, Θ={theta_cam_deg:+.2f}°\n"
            f"  • 輪廓覆蓋率 Coverage : {cov_pct:.1f}% ({n_in}/{c_data['num_ref_pts']} pts) | 最終 RMSE = {rmse_final:.4f} px\n"
            f"【超參數調校建議】\n  " + "\n  ".join(tips)
        )
        ax6.text(
            0.02,
            0.03,
            diag_text,
            transform=ax6.transAxes,
            fontsize=8.5,
            va="bottom",
            ha="left",
            bbox=dict(boxstyle="round,pad=0.5", facecolor="#f8fafc", edgecolor="#94a3b8", alpha=0.92),
        )
        ax6.set_title(
            f"⑥ WLSQ 收斂軌跡與健康度診斷\n"
            f"[參數: max_iter={self.max_iter}, tol={self.tol}]",
            fontsize=10.5,
            fontweight="bold",
        )

        fig.suptitle(
            f"【Contour_WLSQ 全流程 X 光診斷面板】 {title_prefix}  "
            f"(Camera Pose: X={x_cam:+.2f}, Y={y_cam:+.2f}, Θ={theta_cam_deg:+.2f}°)",
            fontsize=13,
            fontweight="bold",
        )
        plt.tight_layout(rect=[0, 0, 1, 0.95])
        plt.show()