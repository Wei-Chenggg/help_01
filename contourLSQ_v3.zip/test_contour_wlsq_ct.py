# test_contour_wlsq_ct.py
import time
import cv2
import numpy as np
from vision_localizer import Contour_WLSQ


def make_dummy_2500x2000(seed=42, noise_sigma=3.0):
    rng = np.random.default_rng(seed)
    H, W = 2000, 2500
    img = np.full((H, W), 40, dtype=np.uint8)

    for _ in range(15):
        x1, y1 = int(rng.integers(250, W - 550)), int(rng.integers(250, H - 550))
        x2, y2 = x1 + int(rng.integers(150, 350)), y1 + int(rng.integers(150, 350))
        cv2.rectangle(img, (x1, y1), (x2, y2), 200, thickness=2)

    if noise_sigma > 0:
        noise = rng.normal(0.0, noise_sigma, size=(H, W))
        img = np.clip(img.astype(np.float32) + noise, 0, 255).astype(np.uint8)

    return img


def make_part_2500x2000(dx=0.0, dy=0.0, angle_deg=0.0, seed=42, noise_sigma=3.0):
    rng = np.random.default_rng(seed)
    H, W = 2000, 2500
    canvas = np.full((H, W), 40, dtype=np.uint8)

    cx, cy = W // 2, H // 2
    cv2.rectangle(canvas, (cx - 300, cy - 200), (cx + 300, cy + 200), 200, thickness=-1)
    cv2.circle(canvas, (cx - 140, cy), 65, 40, thickness=-1)
    cv2.circle(canvas, (cx + 140, cy), 45, 40, thickness=-1)
    cv2.rectangle(canvas, (cx - 40, cy - 200), (cx + 40, cy - 150), 40, thickness=-1)

    if abs(dx) > 1e-3 or abs(dy) > 1e-3 or abs(angle_deg) > 1e-3:
        M = cv2.getRotationMatrix2D((float(cx), float(cy)), -float(angle_deg), 1.0)
        M[0, 2] += float(dx)
        M[1, 2] += float(dy)
        canvas = cv2.warpAffine(canvas, M, (W, H), flags=cv2.INTER_LINEAR, borderValue=40)

    canvas = cv2.GaussianBlur(canvas, (3, 3), 0.8)
    if noise_sigma > 0:
        noise = rng.normal(0.0, noise_sigma, size=(H, W))
        canvas = np.clip(canvas.astype(np.float32) + noise, 0, 255).astype(np.uint8)

    return canvas


def warp_image(img, dx=120.0, dy=-85.0, angle_deg=25.0):
    H, W = img.shape
    cx, cy = (W - 1) / 2.0, (H - 1) / 2.0
    M = cv2.getRotationMatrix2D((cx, cy), -float(angle_deg), 1.0)
    M[0, 2] += float(dx)
    M[1, 2] += float(dy)
    return cv2.warpAffine(img, M, (W, H), flags=cv2.INTER_LINEAR, borderValue=40)


def bench_contour_wlsq(loc, img1, n_runs=10):
    for _ in range(2):
        _ = loc.predict(img1)

    times_ms = []
    for _ in range(n_runs):
        t0 = time.perf_counter()
        _ = loc.predict(img1)
        t1 = time.perf_counter()
        times_ms.append((t1 - t0) * 1000.0)

    return np.mean(times_ms), np.min(times_ms), np.max(times_ms)


def main():
    img0_dummy = make_dummy_2500x2000(seed=42, noise_sigma=3.0)
    img1_dummy_moved = warp_image(img0_dummy, dx=120.0, dy=-85.0, angle_deg=25.0)

    img0_part = make_part_2500x2000(dx=0.0, dy=0.0, angle_deg=0.0, seed=10, noise_sigma=3.0)
    img1_part_moved = make_part_2500x2000(dx=180.0, dy=-130.0, angle_deg=37.5, seed=20, noise_sigma=3.0)

    print(f"影像尺寸: {img0_dummy.shape[1]}x{img0_dummy.shape[0]} (WxH)")
    print("-" * 88)

    configs = [
        (
            "Case 1: 15矩形圖 (與Hough同圖, 原地0偏移)",
            Contour_WLSQ(canny_low=50, canny_high=150, blur_level=1.0),
            img0_dummy,
            img0_dummy,
        ),
        (
            "Case 2: 15矩形圖 (平移+120,-85 / 旋轉+25°)",
            Contour_WLSQ(canny_low=50, canny_high=150, blur_level=1.0),
            img0_dummy,
            img1_dummy_moved,
        ),
        (
            "Case 3: 單一大型工件 (預設 blur=1.0, 旋轉+37.5°)",
            Contour_WLSQ(canny_low=50, canny_high=150, blur_level=1.0),
            img0_part,
            img1_part_moved,
        ),
        (
            "Case 4: 單一大型工件 (免除全圖模糊 blur=0.0)",
            Contour_WLSQ(canny_low=50, canny_high=150, blur_level=0.0),
            img0_part,
            img1_part_moved,
        ),
    ]

    for name, loc, im0, im1 in configs:
        t_teach0 = time.perf_counter()
        loc.set_orginal_img(im0)
        t_teach_ms = (time.perf_counter() - t_teach0) * 1000.0

        mean_ms, min_ms, max_ms = bench_contour_wlsq(loc, im1, n_runs=10)
        n_edges = loc._cache["num_ref_pts"]
        print(
            f"{name:<44} | 邊緣點:{n_edges:6,d} | "
            f"Mean: {mean_ms:6.2f} ms (Min: {min_ms:5.2f}, Max: {max_ms:5.2f}) | "
            f"[離線建模: {t_teach_ms:6.1f} ms]"
        )


if __name__ == "__main__":
    main()
