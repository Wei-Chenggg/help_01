#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
try012.py — 搜尋空間 6 頂點多邊形 (CNT) 切肉 + A1/A2 雙向分流連坐破邊 + A3 布林後削尖刺與肉厚把關 + 選擇性內/外導圓角
執行方式: python ./try012.py
輸出路徑: ./try012_out/cand_0001.png ~ cand_0100.png 及對應 .dxf
"""

import math
import os
import sys
import numpy as np
import ezdxf
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import PolyCollection
from matplotlib.path import Path
from scipy.ndimage import binary_dilation, label as nd_label

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(ROOT_DIR, "fea_toolbox"))

from try005 import DXFContourHelper, FiniteEleMeshHelper
from try007 import PolygonBooleanHelper


class PolygonFilletHelper:
    """針對布林剪裁並清理尖刺後的封閉多邊形環，僅對『CNT 切肉產生/觸碰』的頂點進行內圓角與外圓角處理。"""

    @staticmethod
    def loops_to_segments(loops: list) -> list:
        segs = []
        for lp in loops:
            arr = np.asarray(lp, dtype=float)
            if len(arr) < 2:
                continue
            closed = np.vstack([arr, arr[0]])
            for a, b in zip(closed[:-1], closed[1:]):
                if float(np.linalg.norm(b - a)) > 1e-8:
                    segs.append((a, b))
        return segs

    @staticmethod
    def point_to_seg_proj(pt: np.ndarray, a: np.ndarray, b: np.ndarray) -> tuple:
        """回傳 (最短距離, 投影點座標, 參數 t in [0, 1])。"""
        v = b - a
        l2 = float(v @ v)
        if l2 <= 1e-14:
            return float(np.linalg.norm(pt - a)), a.copy(), 0.0
        t = float(np.clip(((pt - a) @ v) / l2, 0.0, 1.0))
        proj = a + t * v
        return float(np.linalg.norm(pt - proj)), proj, t

    @classmethod
    def point_to_seg_dist(cls, pt: np.ndarray, a: np.ndarray, b: np.ndarray) -> float:
        d, _, _ = cls.point_to_seg_proj(pt, a, b)
        return d

    @classmethod
    def point_to_segments_min_dist(cls, pt: np.ndarray, seg_list: list) -> float:
        if not seg_list:
            return float("inf")
        return min(cls.point_to_seg_dist(pt, a, b) for a, b in seg_list)

    @classmethod
    def fillet_single_loop(
        cls,
        loop_pts: np.ndarray,
        is_outer: bool,
        cnt_segs: list,
        hole0_segs: list,
        bc_segs: list,
        r_in_max: float = 0.60,
        r_out_max: float = 0.45,
        r_min: float = 0.05,
        min_remain_len: float = 0.15,
        min_remain_ratio: float = 0.25,
        cnt_touch_tol: float = 2.5e-2,
        arc_subdiv: int = 8,
    ) -> dict:
        pts = np.asarray(loop_pts, dtype=float)
        m = len(pts)
        if m < 3:
            return {"poly": pts, "lines": [], "arcs": []}

        area_s = FiniteEleMeshHelper._polygon_area_signed(pts)
        if (is_outer and area_s < 0.0) or ((not is_outer) and area_s > 0.0):
            pts = pts[::-1].copy()

        edge_lens = np.zeros(m, dtype=float)
        edge_budget = np.zeros(m, dtype=float)
        for i in range(m):
            p1 = pts[i]
            p2 = pts[(i + 1) % m]
            L = float(np.linalg.norm(p2 - p1))
            edge_lens[i] = L
            keep = max(float(min_remain_len), float(min_remain_ratio) * L)
            edge_budget[i] = max(0.0, L - keep)

        corner_reqs = {}
        for i in range(m):
            v_pt = pts[i]
            if cls.point_to_segments_min_dist(v_pt, hole0_segs) <= cnt_touch_tol:
                continue
            if cls.point_to_segments_min_dist(v_pt, bc_segs) <= cnt_touch_tol:
                continue
            if cls.point_to_segments_min_dist(v_pt, cnt_segs) > cnt_touch_tol:
                continue

            idx_in = (i - 1) % m
            idx_out = i
            l_in = edge_lens[idx_in]
            l_out = edge_lens[idx_out]
            if l_in <= 1e-5 or l_out <= 1e-5:
                continue

            p_prev = pts[idx_in]
            p_next = pts[(i + 1) % m]
            u_in = (v_pt - p_prev) / l_in
            u_out = (p_next - v_pt) / l_out

            cross = float(u_in[0] * u_out[1] - u_in[1] * u_out[0])
            if abs(cross) <= 1e-3:
                continue

            kind = "inner" if cross < 0.0 else "outer"
            r_target = float(r_in_max) if kind == "inner" else float(r_out_max)

            d1 = -u_in
            d2 = u_out
            cos_theta = float(np.clip(np.dot(d1, d2), -1.0, 1.0))
            theta = math.acos(cos_theta)
            theta_deg = math.degrees(theta)
            if theta_deg < 4.0 or theta_deg > 176.0:
                continue

            half_tan = math.tan(0.5 * theta)
            half_sin = math.sin(0.5 * theta)
            if half_tan <= 1e-6 or half_sin <= 1e-6:
                continue

            t_max_local = min(edge_budget[idx_in], edge_budget[idx_out])
            t_want = min(r_target / half_tan, t_max_local)
            if t_want * half_tan < float(r_min):
                continue

            corner_reqs[i] = {
                "v": v_pt,
                "d1": d1,
                "d2": d2,
                "half_tan": half_tan,
                "half_sin": half_sin,
                "idx_in": idx_in,
                "idx_out": idx_out,
                "t_want": t_want,
                "r_target": r_target,
                "kind": kind,
            }

        edge_trim_sum = np.zeros(m, dtype=float)
        for i, req in corner_reqs.items():
            edge_trim_sum[req["idx_in"]] += req["t_want"]
            edge_trim_sum[req["idx_out"]] += req["t_want"]

        edge_scale = np.ones(m, dtype=float)
        for e_idx in range(m):
            if edge_trim_sum[e_idx] > edge_budget[e_idx] and edge_trim_sum[e_idx] > 1e-12:
                edge_scale[e_idx] = edge_budget[e_idx] / edge_trim_sum[e_idx]

        vertex_fillets = {}
        arcs_info = []
        for i, req in corner_reqs.items():
            scale = min(1.0, edge_scale[req["idx_in"]], edge_scale[req["idx_out"]])
            t_final = req["t_want"] * scale
            r_final = min(req["r_target"], t_final * req["half_tan"])
            if r_final < float(r_min):
                continue
            t_final = r_final / req["half_tan"]

            bisec = req["d1"] + req["d2"]
            b_norm = float(np.linalg.norm(bisec))
            if b_norm <= 1e-12:
                continue
            bisec /= b_norm

            center = req["v"] + (r_final / req["half_sin"]) * bisec
            t1_pt = req["v"] + t_final * req["d1"]
            t2_pt = req["v"] + t_final * req["d2"]

            phi1 = math.atan2(t1_pt[1] - center[1], t1_pt[0] - center[0])
            phi2 = math.atan2(t2_pt[1] - center[1], t2_pt[0] - center[0])
            dphi = (phi2 - phi1 + math.pi) % (2.0 * math.pi) - math.pi

            s_vals = np.linspace(0.0, 1.0, max(3, int(arc_subdiv)))
            phis = phi1 + s_vals * dphi
            arc_pts = np.column_stack([
                center[0] + r_final * np.cos(phis),
                center[1] + r_final * np.sin(phis),
            ])

            a1_deg = math.degrees(phi1) % 360.0
            a2_deg = math.degrees(phi2) % 360.0
            if dphi >= 0.0:
                sa_deg, ea_deg = a1_deg, a2_deg
            else:
                sa_deg, ea_deg = a2_deg, a1_deg

            arc_rec = {
                "center": center,
                "radius": float(r_final),
                "sa_deg": float(sa_deg),
                "ea_deg": float(ea_deg),
                "arc_pts": arc_pts,
                "vertex": req["v"],
                "kind": req["kind"],
            }
            vertex_fillets[i] = {
                "t1_pt": t1_pt,
                "t2_pt": t2_pt,
                "arc_pts": arc_pts,
            }
            arcs_info.append(arc_rec)

        smooth_pts = []
        trimmed_lines = []
        for i in range(m):
            if i in vertex_fillets:
                vf = vertex_fillets[i]
                smooth_pts.extend(vf["arc_pts"])
                line_start = vf["t2_pt"]
            else:
                smooth_pts.append(pts[i])
                line_start = pts[i]

            next_i = (i + 1) % m
            if next_i in vertex_fillets:
                line_end = vertex_fillets[next_i]["t1_pt"]
            else:
                line_end = pts[next_i]

            if float(np.linalg.norm(line_end - line_start)) > 1e-6:
                trimmed_lines.append((line_start, line_end))

        return {
            "poly": np.array(smooth_pts, dtype=float),
            "lines": trimmed_lines,
            "arcs": arcs_info,
        }

    @classmethod
    def fillet_boolean_loops(
        cls,
        sharp_outers: list,
        sharp_holes: list,
        accepted_cnts: list,
        holes_0: list,
        disp_segs: list,
        extra_cnt_vertices: list = None,
        r_in_max: float = 0.60,
        r_out_max: float = 0.45,
        r_min: float = 0.05,
    ) -> dict:
        cnt_segs = cls.loops_to_segments(accepted_cnts)
        # 若 A3 削尖刺產生了新頂點，也將其納入可導圓角範圍
        for v_pt in (extra_cnt_vertices or []):
            p = np.asarray(v_pt, dtype=float)
            cnt_segs.append((p, p + np.array([1e-5, 0.0])))

        hole0_segs = cls.loops_to_segments(holes_0)
        bc_segs = [(pts[0], pts[1]) for pts, _lay in disp_segs if len(pts) >= 2]

        filleted_outers = []
        filleted_holes = []
        all_lines = []
        all_arcs = []

        for lp in sharp_outers:
            res = cls.fillet_single_loop(
                lp, is_outer=True, cnt_segs=cnt_segs, hole0_segs=hole0_segs, bc_segs=bc_segs,
                r_in_max=r_in_max, r_out_max=r_out_max, r_min=r_min,
            )
            filleted_outers.append(res["poly"])
            all_lines.extend(res["lines"])
            all_arcs.extend(res["arcs"])

        for lp in sharp_holes:
            res = cls.fillet_single_loop(
                lp, is_outer=False, cnt_segs=cnt_segs, hole0_segs=hole0_segs, bc_segs=bc_segs,
                r_in_max=r_in_max, r_out_max=r_out_max, r_min=r_min,
            )
            filleted_holes.append(res["poly"])
            all_lines.extend(res["lines"])
            all_arcs.extend(res["arcs"])

        return {
            "filleted_outers": filleted_outers,
            "filleted_holes": filleted_holes,
            "lines": all_lines,
            "arcs": all_arcs,
        }

    @staticmethod
    def export_filleted_dxf(src_doc, geo: dict, fillet_res: dict, out_dxf_path: str):
        doc = ezdxf.new(dxfversion="R2010")
        doc.units = ezdxf.units.MM
        msp = doc.modelspace()

        for lay in src_doc.layers:
            lname = lay.dxf.name
            if lname.upper() in ("AUTO", "SEARCH_ZONE"):
                continue
            if lname not in doc.layers:
                doc.layers.add(name=lname, color=lay.dxf.color if lay.dxf.hasattr("color") else 7)

        for p1, p2 in fillet_res["lines"]:
            msp.add_line((float(p1[0]), float(p1[1])), (float(p2[0]), float(p2[1])), dxfattribs={"layer": "0"})
        for arc in fillet_res["arcs"]:
            c = arc["center"]
            msp.add_arc(
                (float(c[0]), float(c[1])),
                float(arc["radius"]),
                float(arc["sa_deg"]),
                float(arc["ea_deg"]),
                dxfattribs={"layer": "0"},
            )

        for fc in geo["fixed_circles"]:
            cx, cy = fc["center"]
            msp.add_circle((float(cx), float(cy)), float(fc["radius"]), dxfattribs={"layer": fc["layer"]})
        for seg_pts, lay in geo["disp_segs"]:
            msp.add_line(
                (float(seg_pts[0][0]), float(seg_pts[0][1])),
                (float(seg_pts[1][0]), float(seg_pts[1][1])),
                dxfattribs={"layer": lay},
            )
        for pc in geo["probe_circles"]:
            cx, cy = pc["center"]
            msp.add_circle((float(cx), float(cy)), float(pc["radius"]), dxfattribs={"layer": pc["layer"]})

        doc.saveas(out_dxf_path)


class PolygonGeometryCleaner:
    """A3: 布林剪裁後的極短碎邊坍縮、尖刺頂點 (< min_angle_deg) 自動削平、以及全域最小肉厚/夾角檢查。"""

    @classmethod
    def seg_to_seg_dist(cls, a1: np.ndarray, a2: np.ndarray, b1: np.ndarray, b2: np.ndarray) -> float:
        u = a2 - a1
        v = b2 - b1
        w = a1 - b1
        denom = float((u @ u) * (v @ v) - (u @ v) ** 2)
        if denom > 1e-12:
            s = ((u @ v) * (v @ w) - (v @ v) * (u @ w)) / denom
            t = ((u @ u) * (v @ w) - (u @ v) * (u @ w)) / denom
            if 0.0 <= s <= 1.0 and 0.0 <= t <= 1.0:
                p_a = a1 + s * u
                p_b = b1 + t * v
                if float(np.linalg.norm(p_a - p_b)) <= 1e-9:
                    return 0.0
        return min(
            PolygonFilletHelper.point_to_seg_dist(a1, b1, b2),
            PolygonFilletHelper.point_to_seg_dist(a2, b1, b2),
            PolygonFilletHelper.point_to_seg_dist(b1, a1, a2),
            PolygonFilletHelper.point_to_seg_dist(b2, a1, a2),
        )

    @classmethod
    def _clean_single_loop(
        cls,
        loop_pts: np.ndarray,
        is_outer: bool,
        cnt_segs: list,
        hole0_segs: list,
        bc_segs: list,
        min_edge_len: float = 0.42,
        min_angle_deg: float = 28.0,
        touch_tol: float = 2.5e-2,
    ) -> tuple:
        pts = np.asarray(loop_pts, dtype=float).copy()
        new_cnt_pts = []

        def is_protected(p):
            return (
                PolygonFilletHelper.point_to_segments_min_dist(p, hole0_segs) <= touch_tol
                or PolygonFilletHelper.point_to_segments_min_dist(p, bc_segs) <= touch_tol
            )

        def is_cnt_related(p):
            if is_protected(p):
                return False
            if PolygonFilletHelper.point_to_segments_min_dist(p, cnt_segs) <= touch_tol:
                return True
            for np_pt in new_cnt_pts:
                if float(np.linalg.norm(p - np_pt)) <= touch_tol:
                    return True
            return False

        for _pass in range(6):
            changed = False
            m = len(pts)
            if m <= 3:
                break

            # 1. 消除極短碎邊 (< min_edge_len)
            for i in range(m):
                p1 = pts[i]
                p2 = pts[(i + 1) % m]
                if float(np.linalg.norm(p2 - p1)) < min_edge_len:
                    c1 = is_cnt_related(p1)
                    c2 = is_cnt_related(p2)
                    if c1 and not is_protected(p1):
                        new_cnt_pts.append(p2.copy())
                        pts = np.delete(pts, i, axis=0)
                        changed = True
                        break
                    elif c2 and not is_protected(p2):
                        new_cnt_pts.append(p1.copy())
                        pts = np.delete(pts, (i + 1) % m, axis=0)
                        changed = True
                        break

            if changed:
                pts = PolygonBooleanHelper.simplify_collinear(pts)
                continue

            # 2. 削平過尖頂點 (< min_angle_deg)
            m = len(pts)
            if m <= 3:
                break
            for i in range(m):
                v = pts[i]
                if not is_cnt_related(v):
                    continue
                p_prev = pts[(i - 1) % m]
                p_next = pts[(i + 1) % m]
                d1_vec = p_prev - v
                d2_vec = p_next - v
                l1 = float(np.linalg.norm(d1_vec))
                l2 = float(np.linalg.norm(d2_vec))
                if l1 <= 1e-6 or l2 <= 1e-6:
                    continue
                d1 = d1_vec / l1
                d2 = d2_vec / l2
                cos_ang = float(np.clip(np.dot(d1, d2), -1.0, 1.0))
                ang_deg = math.degrees(math.acos(cos_ang))
                if ang_deg < min_angle_deg:
                    # 直接移除尖刺頂點 (使其退縮為底邊)，並將兩側頂點標記為可導圓角
                    new_cnt_pts.append(p_prev.copy())
                    new_cnt_pts.append(p_next.copy())
                    pts = np.delete(pts, i, axis=0)
                    changed = True
                    break

            if changed:
                pts = PolygonBooleanHelper.simplify_collinear(pts)
            else:
                break

        area_s = FiniteEleMeshHelper._polygon_area_signed(pts)
        if (is_outer and area_s < 0.0) or ((not is_outer) and area_s > 0.0):
            pts = pts[::-1].copy()

        return pts, new_cnt_pts

    @classmethod
    def clean_boolean_loops_slivers(
        cls,
        sharp_outers: list,
        sharp_holes: list,
        accepted_cnts: list,
        holes_0: list,
        disp_segs: list,
        min_edge_len: float = 0.42,
        min_angle_deg: float = 28.0,
    ) -> tuple:
        cnt_segs = PolygonFilletHelper.loops_to_segments(accepted_cnts)
        hole0_segs = PolygonFilletHelper.loops_to_segments(holes_0)
        bc_segs = [(pts[0], pts[1]) for pts, _lay in disp_segs if len(pts) >= 2]

        clean_outers = []
        clean_holes = []
        extra_cnt_vertices = []

        for lp in sharp_outers:
            clp, ex = cls._clean_single_loop(
                lp, True, cnt_segs, hole0_segs, bc_segs, min_edge_len=min_edge_len, min_angle_deg=min_angle_deg
            )
            if len(clp) >= 3 and FiniteEleMeshHelper._polygon_area(clp) > 0.25:
                clean_outers.append(clp)
                extra_cnt_vertices.extend(ex)

        for lp in sharp_holes:
            clp, ex = cls._clean_single_loop(
                lp, False, cnt_segs, hole0_segs, bc_segs, min_edge_len=min_edge_len, min_angle_deg=min_angle_deg
            )
            if len(clp) >= 3 and FiniteEleMeshHelper._polygon_area(clp) > 0.25:
                clean_holes.append(clp)
                extra_cnt_vertices.extend(ex)

        return clean_outers, clean_holes, extra_cnt_vertices

    @classmethod
    def verify_loops_clearance_and_angles(
        cls,
        outers: list,
        holes: list,
        accepted_cnts: list,
        holes_0: list,
        extra_cnt_vertices: list = None,
        min_wall_mm: float = 1.05,
        min_angle_deg: float = 26.0,
        touch_tol: float = 3.0e-2,
    ) -> bool:
        """
        向量級幾何把關：
        1. 檢查所有 CNT 相關頂點的夾角是否皆 >= min_angle_deg (無尖刺)。
        2. 檢查所有 CNT 相關邊與其他非相鄰邊的最短距離是否皆 >= min_wall_mm (無薄壁/窄縫)。
        """
        if not outers:
            return False

        cnt_segs = PolygonFilletHelper.loops_to_segments(accepted_cnts)
        for v_pt in (extra_cnt_vertices or []):
            p = np.asarray(v_pt, dtype=float)
            cnt_segs.append((p, p + np.array([1e-5, 0.0])))
        hole0_segs = PolygonFilletHelper.loops_to_segments(holes_0)

        def is_cnt_pt(p):
            if PolygonFilletHelper.point_to_segments_min_dist(p, hole0_segs) <= touch_tol:
                return False
            return PolygonFilletHelper.point_to_segments_min_dist(p, cnt_segs) <= touch_tol

        all_loops = list(outers) + list(holes)
        all_edges = []  # (loop_idx, edge_idx, n_loop, p1, p2, is_cnt_edge)

        for l_idx, lp in enumerate(all_loops):
            m = len(lp)
            if m < 3:
                return False
            for i in range(m):
                v = lp[i]
                p_prev = lp[(i - 1) % m]
                p_next = lp[(i + 1) % m]
                l1 = float(np.linalg.norm(p_prev - v))
                l2 = float(np.linalg.norm(p_next - v))
                if l1 <= 1e-5 or l2 <= 1e-5:
                    return False
                if is_cnt_pt(v):
                    cos_a = float(np.clip(np.dot((p_prev - v) / l1, (p_next - v) / l2), -1.0, 1.0))
                    ang = math.degrees(math.acos(cos_a))
                    if ang < min_angle_deg:
                        return False

                p1 = lp[i]
                p2 = lp[(i + 1) % m]
                mid = 0.5 * (p1 + p2)
                cnt_edge = is_cnt_pt(p1) or is_cnt_pt(p2) or is_cnt_pt(mid)
                all_edges.append((l_idx, i, m, p1, p2, cnt_edge))

        n_e = len(all_edges)
        for i in range(n_e):
            l1, e1, m1, a1, a2, c1 = all_edges[i]
            for j in range(i + 1, n_e):
                l2, e2, m2, b1, b2, c2 = all_edges[j]
                if not (c1 or c2):
                    continue
                if l1 == l2:
                    diff = abs(e1 - e2)
                    if diff <= 1 or diff >= m1 - 1:
                        continue
                d = cls.seg_to_seg_dist(a1, a2, b1, b2)
                if d < min_wall_mm:
                    return False

        return True


class Random6PtCntGenerator:
    def __init__(
        self,
        doc,
        min_hinge_mm: float = 1.25,
        d_snap_outer_mm: float = 0.95,
        d_over_outer_mm: float = 1.05,
        d_merge_cnt_mm: float = 0.75,
        d_merge_depth_mm: float = 0.85,
        raster_pitch_mm: float = 0.30,
    ):
        self.doc = doc
        self.min_hinge_mm = float(min_hinge_mm)
        self.d_snap_outer = float(d_snap_outer_mm)
        self.d_over_outer = float(d_over_outer_mm)
        self.d_merge_cnt = float(d_merge_cnt_mm)
        self.d_merge_depth = float(d_merge_depth_mm)
        self.raster_pitch = float(raster_pitch_mm)

        self.geo = self._extract_blank_and_bcs(doc)
        self._init_raster_grid()
        self._classify_boundary_segments()

    @staticmethod
    def _extract_blank_and_bcs(doc) -> dict:
        msp = doc.modelspace()
        raw_lines, _, _, arc_polys, circle_polys = DXFContourHelper.extract_primitives_from_msp(msp)
        outer0_segs, auto_segs, disp_segs = [], [], []
        fixed_circles, probe_circles = [], []

        for s in raw_lines:
            info = DXFContourHelper.parse_bc_layer_name(s.layer)
            btype = info.get("type")
            pts = np.array([s.p1, s.p2], dtype=float)
            if str(s.layer).upper() in ("AUTO", "SEARCH_ZONE"):
                auto_segs.append((pts, s.layer))
            elif btype in ("FREE", "DISP", "FORCE", "FIXED"):
                outer0_segs.append((pts, "0"))
                if btype in ("DISP", "FORCE"):
                    disp_segs.append((pts, s.layer))

        for pts, _h, layer in arc_polys:
            arr = np.asarray(pts, dtype=float)
            if str(layer).upper() in ("AUTO", "SEARCH_ZONE"):
                auto_segs.append((arr, layer))
            else:
                outer0_segs.append((arr, "0"))

        for pts, _h, layer in circle_polys:
            arr = np.asarray(pts, dtype=float)
            info = DXFContourHelper.parse_bc_layer_name(layer)
            btype = info.get("type")
            cx, cy = float(arr[:, 0].mean()), float(arr[:, 1].mean())
            r = float(np.mean(np.hypot(arr[:, 0] - cx, arr[:, 1] - cy)))
            if btype == "PROBE":
                probe_circles.append({"layer": layer, "center": (cx, cy), "radius": r})
            elif btype == "FIXED":
                fixed_circles.append({"layer": layer, "center": (cx, cy), "radius": r, "poly": arr[:-1]})

        chains_0 = FiniteEleMeshHelper._chain_segments_with_layers(outer0_segs, snap_tol=0.12)
        loops_0 = [c[0] for c in chains_0 if len(c[0]) >= 3]
        loops_0.sort(key=FiniteEleMeshHelper._polygon_area, reverse=True)
        outer_0 = loops_0[0] if loops_0 else np.zeros((0, 2))
        holes_0 = loops_0[1:] if len(loops_0) > 1 else []

        chains_auto = FiniteEleMeshHelper._chain_segments_with_layers(auto_segs, snap_tol=0.05)
        loops_auto = [c[0] for c in chains_auto if len(c[0]) >= 3]
        loops_auto.sort(key=FiniteEleMeshHelper._polygon_area, reverse=True)

        if len(outer_0) >= 3:
            blank_outers, _ = PolygonBooleanHelper.boolean_op([outer_0] + loops_auto, cut_loops=None)
            unified_blank = blank_outers[0] if blank_outers else outer_0
        else:
            unified_blank = outer_0

        # 求出非 AUTO 的預設 Layer 0 保護實體多邊形 (如左臂、右下施力腳座)
        if len(outer_0) >= 3 and loops_auto:
            prot_outers, _ = PolygonBooleanHelper.boolean_op([outer_0], cut_loops=loops_auto)
        else:
            prot_outers = []

        return {
            "outer_0": outer_0,
            "holes_0": holes_0,
            "auto_loops": loops_auto,
            "unified_blank": unified_blank,
            "protected_0_loops": prot_outers,
            "fixed_circles": fixed_circles,
            "disp_segs": disp_segs,
            "probe_circles": probe_circles,
        }

    def _init_raster_grid(self):
        blank = self.geo["unified_blank"]
        xmin, ymin = blank.min(axis=0) - 4.0
        xmax, ymax = blank.max(axis=0) + 4.0
        p = self.raster_pitch
        self.xs = np.arange(xmin, xmax + p, p)
        self.ys = np.arange(ymin, ymax + p, p)
        gx, gy = np.meshgrid(self.xs, self.ys)
        self.grid_pts = np.column_stack([gx.ravel(), gy.ravel()])
        self.grid_shape = gx.shape
        self.hinge_px = max(1, int(round(self.min_hinge_mm / p)))

        self.blank_mask = PolygonBooleanHelper.as_path(blank).contains_points(self.grid_pts).reshape(self.grid_shape)
        self.auto_mask = np.zeros(self.grid_shape, dtype=bool)
        for alp in self.geo["auto_loops"]:
            self.auto_mask |= PolygonBooleanHelper.as_path(alp).contains_points(self.grid_pts).reshape(self.grid_shape)
        if not self.auto_mask.any():
            self.auto_mask = self.blank_mask.copy()

        # 關鍵修正：非 AUTO 的預設實體區 (左臂、右下角 DISP 腳座) 必須外擴 hinge_px 作為保護緩衝！
        raw_protected_solid = self.blank_mask & (~self.auto_mask)
        self.protected_solid_mask = binary_dilation(raw_protected_solid, iterations=self.hinge_px)

        auto_pts = np.vstack(self.geo["auto_loops"]) if self.geo["auto_loops"] else blank
        self.auto_span = float(min(np.ptp(auto_pts[:, 0]), np.ptp(auto_pts[:, 1])))

        self.forbidden_mask = self.protected_solid_mask.copy()
        for h0 in self.geo["holes_0"]:
            h_mask = PolygonBooleanHelper.as_path(h0).contains_points(self.grid_pts).reshape(self.grid_shape)
            self.blank_mask &= (~h_mask)
            self.forbidden_mask |= binary_dilation(h_mask, iterations=self.hinge_px)

        for fc in self.geo["fixed_circles"]:
            cx, cy = fc["center"]
            r_safe = fc["radius"] + self.min_hinge_mm
            d2 = (gx - cx) ** 2 + (gy - cy) ** 2
            self.blank_mask &= (d2 > fc["radius"] ** 2)
            self.forbidden_mask |= (d2 <= r_safe ** 2)

        for seg_pts, _lay in self.geo["disp_segs"]:
            a, b = seg_pts[0], seg_pts[1]
            v = b - a
            l2 = max(float(v @ v), 1e-12)
            t = np.clip(((self.grid_pts - a) @ v) / l2, 0.0, 1.0)
            proj = a + t[:, None] * v
            d = np.hypot(self.grid_pts[:, 0] - proj[:, 0], self.grid_pts[:, 1] - proj[:, 1]).reshape(self.grid_shape)
            self.forbidden_mask |= (d <= self.min_hinge_mm * 1.2)

        self.anchor_masks = []
        for fc in self.geo["fixed_circles"]:
            cx, cy = fc["center"]
            r_ring = fc["radius"] + self.min_hinge_mm + 1.5 * p
            m = self.blank_mask & (((gx - cx) ** 2 + (gy - cy) ** 2) <= r_ring ** 2)
            if m.any():
                self.anchor_masks.append(m)

        if self.geo["disp_segs"]:
            a, b = self.geo["disp_segs"][0][0]
            mid = 0.5 * (a + b)
            m = self.blank_mask & (((gx - mid[0]) ** 2 + (gy - mid[1]) ** 2) <= (self.min_hinge_mm + 2.5 * p) ** 2)
            if m.any():
                self.anchor_masks.append(m)

        if self.geo["probe_circles"]:
            pc = self.geo["probe_circles"][0]["center"]
            valid_idx = np.argwhere(self.blank_mask)
            if len(valid_idx):
                pts_valid = np.column_stack([self.xs[valid_idx[:, 1]], self.ys[valid_idx[:, 0]]])
                nearest = valid_idx[int(np.argmin(np.hypot(pts_valid[:, 0] - pc[0], pts_valid[:, 1] - pc[1])))]
                m = np.zeros(self.grid_shape, dtype=bool)
                m[nearest[0], nearest[1]] = True
                self.anchor_masks.append(binary_dilation(m, iterations=2) & self.blank_mask)

    def _classify_boundary_segments(self):
        """區分『可切破的 AUTO 外邊界線段』與『不可切破的保護邊界線段』。"""
        blank = self.geo["unified_blank"]
        area_s = FiniteEleMeshHelper._polygon_area_signed(blank)
        if area_s < 0.0:
            blank = blank[::-1].copy()

        auto_segs = PolygonFilletHelper.loops_to_segments(self.geo["auto_loops"])
        prot_segs = PolygonFilletHelper.loops_to_segments(self.geo["protected_0_loops"])
        hole0_segs = PolygonFilletHelper.loops_to_segments(self.geo["holes_0"])
        bc_segs = [(pts[0], pts[1]) for pts, _lay in self.geo["disp_segs"] if len(pts) >= 2]

        # 將 unified_blank 與 auto_loops 先做交點切分，以便精確識別哪一段外邊界屬於 AUTO
        raw_blank_segs = PolygonFilletHelper.loops_to_segments([blank])
        split_blank = PolygonBooleanHelper.split_and_dedup_segments(raw_blank_segs + auto_segs, tol=1e-4)

        self.breakable_outer_segs = []  # list of dict: {"a", "b", "u", "n_out", "len"}
        self.protected_segs = list(prot_segs) + list(hole0_segs) + list(bc_segs)

        blank_edges = PolygonFilletHelper.loops_to_segments([blank])
        for s_a, s_b in split_blank:
            mid = 0.5 * (s_a + s_b)
            L = float(np.linalg.norm(s_b - s_a))
            if L < 0.25:
                continue
            # 確認該子段位於 unified_blank 外邊界上
            if PolygonFilletHelper.point_to_segments_min_dist(mid, blank_edges) > 1e-2:
                continue
            # 找出對應的 CCW 有向方向與朝外法向量 n_out
            chosen_dir = None
            for ba, bb in blank_edges:
                if PolygonFilletHelper.point_to_seg_dist(mid, ba, bb) <= 1e-2:
                    chosen_dir = bb - ba
                    break
            if chosen_dir is None:
                continue
            if float(np.dot(s_b - s_a, chosen_dir)) < 0.0:
                s_a, s_b = s_b, s_a

            u = (s_b - s_a) / L
            # CCW 外環的右側為外部空氣: n_out = (u_y, -u_x)
            n_out = np.array([u[1], -u[0]], dtype=float)

            # 若該外邊界子段同時屬於 AUTO 且遠離保護區/BC，則為可切破外邊界
            on_auto = PolygonFilletHelper.point_to_segments_min_dist(mid, auto_segs) <= 0.15
            near_bc = PolygonFilletHelper.point_to_segments_min_dist(mid, bc_segs) <= self.min_hinge_mm
            if on_auto and (not near_bc):
                self.breakable_outer_segs.append({
                    "a": s_a, "b": s_b, "u": u, "n_out": n_out, "len": L
                })
            else:
                self.protected_segs.append((s_a, s_b))

    def _morph_cnt_polygon(self, raw_pts: np.ndarray, accepted_cnts: list) -> np.ndarray:
        """
        執行 A1 (外邊界雙向分流 + 相鄰頂點連坐破邊) 與 A2 (孔與孔雙向分流融合/推開)。
        """
        pts = np.asarray(raw_pts, dtype=float).copy()
        n = len(pts)
        d_wall = self.min_hinge_mm
        d_snap = self.d_snap_outer
        d_over = self.d_over_outer
        d_merge = self.d_merge_cnt
        d_mdepth = self.d_merge_depth

        # =====================================================================
        # 1. A1: 可切破外邊界 (AUTO 外緣) 雙向分流 + 相鄰點連坐破邊
        # =====================================================================
        broke_seg_by_vertex = {}  # vertex_idx -> breakable_seg_dict

        for i in range(n):
            p = pts[i]
            best_seg = None
            best_abs_s = float("inf")
            best_s = 0.0

            for bseg in self.breakable_outer_segs:
                a, b, u, n_out, L = bseg["a"], bseg["b"], bseg["u"], bseg["n_out"], bseg["len"]
                rel = p - a
                t_along = float(rel @ u)
                if t_along < -0.25 or t_along > L + 0.25:
                    continue
                # s > 0 代表在毛坯外部空氣側；s < 0 代表在毛坯內部實體側
                s = float(rel @ n_out)
                if abs(s) < best_abs_s:
                    best_abs_s = abs(s)
                    best_s = s
                    best_seg = bseg

            if best_seg is not None:
                n_out = best_seg["n_out"]
                # 若頂點在毛坯內側且距離 < d_snap，或已在毛坯外側但突出不足 d_over -> 推穿到 +d_over
                if -d_snap <= best_s < d_over:
                    pts[i] = p + (d_over - best_s) * n_out
                    broke_seg_by_vertex[i] = best_seg
                elif best_s >= d_over:
                    broke_seg_by_vertex[i] = best_seg
                # 若頂點落在薄壁禁區帶 [-d_wall, -d_snap) -> 往毛坯內部退縮至 -d_wall
                elif -d_wall < best_s < -d_snap:
                    pts[i] = p + (-d_wall - best_s) * n_out

        # 相鄰頂點連坐破邊 (避免單點破邊、相鄰點留在內側造成斜切尖角！)
        for i, bseg in list(broke_seg_by_vertex.items()):
            a, u, n_out, L = bseg["a"], bseg["u"], bseg["n_out"], bseg["len"]
            for nb in ((i - 1) % n, (i + 1) % n):
                if nb in broke_seg_by_vertex:
                    continue
                p_nb = pts[nb]
                rel_nb = p_nb - a
                t_along = float(rel_nb @ u)
                if t_along < -0.5 or t_along > L + 0.5:
                    continue
                s_nb = float(rel_nb @ n_out)
                # 計算連接邊 (pts[i] -> pts[nb]) 與外邊界 u 的切入夾角
                edge_vec = p_nb - pts[i]
                edge_len = float(np.linalg.norm(edge_vec))
                grazing_deg = 90.0
                if edge_len > 1e-6:
                    sin_ang = abs(float((edge_vec / edge_len) @ n_out))
                    grazing_deg = math.degrees(math.asin(np.clip(sin_ang, 0.0, 1.0)))

                # 若相鄰點在內側且距離 < 1.55 * d_wall，或斜切角 < 34° -> 連坐一起推出外邊界 +d_over！
                if s_nb < d_over and (s_nb > -1.55 * d_wall or grazing_deg < 34.0):
                    pts[nb] = p_nb + (d_over - s_nb) * n_out
                    broke_seg_by_vertex[nb] = bseg

        # =====================================================================
        # 2. A2: 孔與孔之間 (CNT 對既有 CNT) 雙向分流 (融合 vs 推開保持肉厚)
        # =====================================================================
        for prev_cnt in accepted_cnts:
            prev_path = PolygonBooleanHelper.as_path(prev_cnt)
            prev_cen = prev_cnt.mean(axis=0)
            prev_segs = PolygonFilletHelper.loops_to_segments([prev_cnt])
            merged_indices = set()

            for i in range(n):
                p = pts[i]
                inside_prev = bool(prev_path.contains_point(p))
                min_d = float("inf")
                near_proj = None
                for sa, sb in prev_segs:
                    d, proj, _ = PolygonFilletHelper.point_to_seg_proj(p, sa, sb)
                    if d < min_d:
                        min_d = d
                        near_proj = proj

                if near_proj is None:
                    continue

                dir_to_cen = prev_cen - p
                norm_c = float(np.linalg.norm(dir_to_cen))
                u_to_cen = dir_to_cen / max(norm_c, 1e-9)

                if inside_prev:
                    # 已在既有 CNT 內部，但深入不足 d_mdepth -> 往既有 CNT 中心拉深，避免淺交尖角
                    if min_d < d_mdepth and norm_c > 1e-4:
                        pts[i] = p + min(d_mdepth - min_d, 0.55 * norm_c) * u_to_cen
                    merged_indices.add(i)
                else:
                    if min_d < d_merge:
                        # 距離 < d_merge: 直接拉進既有 CNT 內部融合！
                        pull_dist = min_d + d_mdepth
                        pts[i] = p + min(pull_dist, 0.65 * norm_c) * u_to_cen
                        merged_indices.add(i)
                    elif min_d < d_wall:
                        # 落在 [d_merge, d_wall) 薄壁帶: 往外推開以確保兩孔間肉厚 >= d_wall
                        away = p - near_proj
                        na = float(np.linalg.norm(away))
                        u_away = (away / na) if na > 1e-8 else -u_to_cen
                        pts[i] = near_proj + d_wall * u_away

            # 孔與孔融合連坐：若單點拉入既有 CNT，而相鄰點距離既有 CNT < 1.3 * d_wall，一併拉入避免交界尖刺
            for i in list(merged_indices):
                for nb in ((i - 1) % n, (i + 1) % n):
                    if nb in merged_indices:
                        continue
                    p_nb = pts[nb]
                    d_nb = PolygonFilletHelper.point_to_segments_min_dist(p_nb, prev_segs)
                    if d_nb < 1.25 * d_wall:
                        dir_c = prev_cen - p_nb
                        nc = float(np.linalg.norm(dir_c))
                        if nc > 1e-4:
                            pts[nb] = p_nb + min(d_nb + 0.75 * d_mdepth, 0.60 * nc) * (dir_c / nc)
                            merged_indices.add(nb)

        # =====================================================================
        # 3. 保護邊界退縮 (不可破邊之 Layer 0 內孔、左臂、右下施力腳座)
        # =====================================================================
        poly_cen = pts.mean(axis=0)
        for i in range(n):
            p = pts[i]
            for sa, sb in self.protected_segs:
                d, proj, _ = PolygonFilletHelper.point_to_seg_proj(p, sa, sb)
                if d < d_wall:
                    away = poly_cen - proj
                    na = float(np.linalg.norm(away))
                    if na > 1e-8:
                        pts[i] = proj + (d_wall + 0.10) * (away / na)

        # 重新以質心極角排序，確保 6 邊形不自交
        cen = pts.mean(axis=0)
        angs = np.arctan2(pts[:, 1] - cen[1], pts[:, 0] - cen[0])
        pts = pts[np.argsort(angs)]
        return pts

    def _poly_to_mask(self, poly_pts: np.ndarray) -> np.ndarray:
        return PolygonBooleanHelper.as_path(poly_pts).contains_points(self.grid_pts).reshape(self.grid_shape)

    def _is_cut_state_valid(self, current_solid_mask: np.ndarray, cut_mask: np.ndarray) -> bool:
        if np.any(cut_mask & self.forbidden_mask):
            return False
        next_solid = current_solid_mask & (~cut_mask)
        if not next_solid.any():
            return False

        lab_full, n_full = nd_label(next_solid)
        if n_full > 1:
            sizes = np.bincount(lab_full.ravel())[1:]
            if np.sum(sizes > 4) > 1:
                return False

        cut_buffered = binary_dilation(cut_mask, iterations=self.hinge_px)
        neck_check_mask = current_solid_mask & (~cut_buffered)
        lab_neck, n_neck = nd_label(neck_check_mask)
        if n_neck == 0:
            return False
        if not self.anchor_masks:
            return True

        anchor_labels = set()
        for am in self.anchor_masks:
            overlap = lab_neck[am & (lab_neck > 0)]
            if len(overlap) == 0:
                return False
            anchor_labels.add(int(overlap[0]))
        return len(anchor_labels) == 1

    def _sample_raw_6pt_polygon(self, rng: np.random.Generator) -> tuple:
        avail = self.auto_mask & (~self.forbidden_mask)
        coords = np.argwhere(avail)
        if len(coords) == 0:
            return None, None
        pick = coords[int(rng.integers(0, len(coords)))]
        cx = float(self.xs[pick[1]])
        cy = float(self.ys[pick[0]])

        base_ang = float(rng.uniform(0.0, 2.0 * math.pi))
        sector = (2.0 * math.pi) / 6.0
        angles = np.array([
            base_ang + k * sector + float(rng.uniform(0.18 * sector, 0.82 * sector))
            for k in range(6)
        ])
        base_r = float(rng.uniform(0.16, 0.34)) * self.auto_span
        radii = base_r * rng.uniform(0.72, 1.25, size=6)
        pts = np.column_stack([cx + radii * np.cos(angles), cy + radii * np.sin(angles)])
        return (cx, cy), pts

    def _try_place_one_cnt(
        self,
        center: tuple,
        raw_pts: np.ndarray,
        current_mask: np.ndarray,
        accepted_cnts: list,
        min_new_cut_px: int = 8,
    ):
        cen = np.asarray(center, dtype=float)
        for scale in (1.0, 0.85, 0.72, 0.60, 0.48, 0.38):
            scaled_pts = cen + scale * (raw_pts - cen)
            # 套用 A1 + A2 雙向分流與連坐破邊
            morphed_pts = self._morph_cnt_polygon(scaled_pts, accepted_cnts)

            # 檢查單一 6 邊形自身最小邊長與內角
            edges = np.roll(morphed_pts, -1, axis=0) - morphed_pts
            lens = np.linalg.norm(edges, axis=1)
            if np.min(lens) < 0.75:
                continue

            cand_mask = self._poly_to_mask(morphed_pts)
            if np.count_nonzero(cand_mask & current_mask) < min_new_cut_px:
                continue
            if not self._is_cut_state_valid(current_mask, cand_mask):
                continue

            # 試算布林剪裁 + A3 消除尖刺與最小肉厚向量級檢查
            trial_cnts = accepted_cnts + [morphed_pts]
            cnt_u, _ = PolygonBooleanHelper.boolean_op(trial_cnts, cut_loops=None)
            s_outers, s_holes = PolygonBooleanHelper.boolean_op(
                [self.geo["unified_blank"]], cut_loops=list(self.geo["holes_0"]) + cnt_u
            )
            c_outers, c_holes, ex_pts = PolygonGeometryCleaner.clean_boolean_loops_slivers(
                s_outers, s_holes, trial_cnts, self.geo["holes_0"], self.geo["disp_segs"],
                min_edge_len=0.42, min_angle_deg=28.0,
            )
            if len(c_outers) != 1:
                continue
            if not PolygonGeometryCleaner.verify_loops_clearance_and_angles(
                c_outers, c_holes, trial_cnts, self.geo["holes_0"],
                extra_cnt_vertices=ex_pts, min_wall_mm=1.05, min_angle_deg=26.0,
            ):
                continue

            return morphed_pts, cand_mask, c_outers, c_holes, ex_pts

        return None, None, None, None, None

    def sample_random_candidate(
        self,
        rng: np.random.Generator,
        min_cnt: int = 5,
        max_cnt: int = 6,
        r_in_max: float = 0.60,
        r_out_max: float = 0.45,
    ) -> dict:
        target_n = int(rng.integers(min_cnt, max_cnt + 1))
        current_mask = self.blank_mask.copy()
        accepted_cnts = []
        sharp_outers = [self.geo["unified_blank"]]
        sharp_holes = list(self.geo["holes_0"])
        extra_cnt_pts = []

        for _ in range(target_n):
            for _retry in range(60):
                center, raw_pts = self._sample_raw_6pt_polygon(rng)
                if raw_pts is None:
                    break
                res = self._try_place_one_cnt(center, raw_pts, current_mask, accepted_cnts)
                best_pts, best_mask, c_outers, c_holes, ex_pts = res
                if best_pts is not None:
                    current_mask &= (~best_mask)
                    accepted_cnts.append(best_pts)
                    sharp_outers = c_outers
                    sharp_holes = c_holes
                    extra_cnt_pts = ex_pts
                    break

        # 對清理完尖刺與確認無薄壁後的封閉輪廓進行選擇性內/外導圓角
        fillet_res = PolygonFilletHelper.fillet_boolean_loops(
            sharp_outers=sharp_outers,
            sharp_holes=sharp_holes,
            accepted_cnts=accepted_cnts,
            holes_0=self.geo["holes_0"],
            disp_segs=self.geo["disp_segs"],
            extra_cnt_vertices=extra_cnt_pts,
            r_in_max=r_in_max,
            r_out_max=r_out_max,
            r_min=0.05,
        )

        return {
            "accepted_cnts": accepted_cnts,
            "sharp_outers": sharp_outers,
            "sharp_holes": sharp_holes,
            "filleted_outers": fillet_res["filleted_outers"],
            "filleted_holes": fillet_res["filleted_holes"],
            "fillet_lines": fillet_res["lines"],
            "fillet_arcs": fillet_res["arcs"],
            "lines": fillet_res["lines"],
            "arcs": fillet_res["arcs"],
        }


def _draw_bcs(ax, geo: dict, show_labels: bool = False):
    for i, fc in enumerate(geo["fixed_circles"]):
        cx, cy = fc["center"]
        r = fc["radius"]
        th = np.linspace(0.0, 2.0 * math.pi, 49)
        ax.plot(
            cx + r * np.cos(th), cy + r * np.sin(th),
            color="#38bdf8", lw=1.4, zorder=9, label="FIXED" if (show_labels and i == 0) else None,
        )
    for i, (seg_pts, lay) in enumerate(geo["disp_segs"]):
        ax.plot(
            seg_pts[:, 0], seg_pts[:, 1],
            color="#ff3355", lw=2.5, zorder=10, label=lay if (show_labels and i == 0) else None,
        )
    for i, pc in enumerate(geo["probe_circles"]):
        cx, cy = pc["center"]
        ax.plot(
            [cx], [cy], marker="+", ms=10, mew=2.0,
            color="#a3e635", zorder=11, label=pc["layer"] if (show_labels and i == 0) else None,
        )


def render_candidate_png(fig, axes, geo: dict, cand_res: dict, cand_idx: int, out_png_path: str):
    ax_top, ax_bot = axes
    ax_top.clear()
    ax_bot.clear()
    fig.patch.set_facecolor("#0b0f17")

    blank = geo["unified_blank"]
    xmin, ymin = blank.min(axis=0) - 5.0
    xmax, ymax = blank.max(axis=0) + 5.0

    # =========================================================================
    # 上圖 (ax_top): A1/A2 拉點後之 6 頂點 CNT + A3 削尖刺布林剪裁輪廓
    # =========================================================================
    ax_top.set_facecolor("#0b0f17")
    if len(geo["outer_0"]) >= 3:
        c0 = np.vstack([geo["outer_0"], geo["outer_0"][0]])
        ax_top.plot(c0[:, 0], c0[:, 1], color="#64748b", lw=1.0, ls="--", zorder=2, label="Layer 0 (Preset)")
    for h0 in geo["holes_0"]:
        ch0 = np.vstack([h0, h0[0]])
        ax_top.plot(ch0[:, 0], ch0[:, 1], color="#64748b", lw=1.0, ls="--", zorder=2)
    for i, alp in enumerate(geo["auto_loops"]):
        ca = np.vstack([alp, alp[0]])
        ax_top.plot(ca[:, 0], ca[:, 1], color="#00e5ff", lw=1.2, ls=":", zorder=3, label="Layer AUTO" if i == 0 else None)

    cnt_polys = cand_res["accepted_cnts"]
    if cnt_polys:
        ax_top.add_collection(PolyCollection(
            cnt_polys, facecolors="#ff8800", edgecolors="#ff8800",
            alpha=0.20, linewidths=1.1, linestyles="--", zorder=4,
            label=f"Morphed 6-Pt CNTs ({len(cnt_polys)})",
        ))
        for idx, cp in enumerate(cnt_polys, start=1):
            ax_top.scatter(cp[:, 0], cp[:, 1], s=12, c="#ffae42", zorder=5)
            ax_top.text(
                cp[:, 0].mean(), cp[:, 1].mean(), f"C{idx}",
                color="#ffae42", fontsize=7.0, fontweight="bold", ha="center", va="center", zorder=6,
            )

    sharp_loops = list(cand_res["sharp_outers"]) + list(cand_res["sharp_holes"])
    for i, slp in enumerate(sharp_loops):
        cs = np.vstack([slp, slp[0]])
        ax_top.plot(
            cs[:, 0], cs[:, 1], color="#38bdf8", lw=1.6, zorder=7,
            label="Boolean + Sliver Cleaned" if i == 0 else None,
        )

    _draw_bcs(ax_top, geo, show_labels=False)
    ax_top.set_xlim(xmin, xmax)
    ax_top.set_ylim(ymin, ymax)
    ax_top.set_aspect("equal", adjustable="box")
    ax_top.tick_params(colors="#94a3b8", labelsize=7)
    ax_top.set_title(
        f"Candidate #{cand_idx:04d} [Step 1: A1/A2 Co-Pulling + A3 Boolean Cleanup] | CNTs: {len(cnt_polys)} | Loops: {len(sharp_loops)}",
        color="#e2e8f0", fontsize=9.0,
    )
    ax_top.legend(loc="upper left", facecolor="#161b26", edgecolor="#334155", labelcolor="#e2e8f0", fontsize=7.0)

    # =========================================================================
    # 下圖 (ax_bot): 選擇性導圓角後之簡單封閉輪廓 + 內圓角(粉紅) / 外圓角(金黃)
    # =========================================================================
    ax_bot.set_facecolor("#0b0f17")
    if cand_res["filleted_outers"]:
        ax_bot.add_collection(PolyCollection(
            cand_res["filleted_outers"], facecolors="#22c55e", edgecolors="none", alpha=0.24, zorder=2,
        ))
    if cand_res["filleted_holes"]:
        ax_bot.add_collection(PolyCollection(
            cand_res["filleted_holes"], facecolors="#0b0f17", edgecolors="none", alpha=0.98, zorder=3,
        ))

    filleted_loops = list(cand_res["filleted_outers"]) + list(cand_res["filleted_holes"])
    for i, flp in enumerate(filleted_loops):
        cf = np.vstack([flp, flp[0]])
        ax_bot.plot(
            cf[:, 0], cf[:, 1], color="#00ff66", lw=1.8, zorder=5,
            label="Filleted Simple Contour (Mesh-Ready)" if i == 0 else None,
        )

    inner_arcs = [a for a in cand_res["fillet_arcs"] if a["kind"] == "inner"]
    outer_arcs = [a for a in cand_res["fillet_arcs"] if a["kind"] == "outer"]

    for i, arc in enumerate(inner_arcs):
        ap = arc["arc_pts"]
        ax_bot.plot(
            ap[:, 0], ap[:, 1], color="#f43f5e", lw=2.8, zorder=8,
            label=f"Inner Fillets / 內圓角 ({len(inner_arcs)})" if i == 0 else None,
        )
    for i, arc in enumerate(outer_arcs):
        ap = arc["arc_pts"]
        ax_bot.plot(
            ap[:, 0], ap[:, 1], color="#facc15", lw=2.8, zorder=8.5,
            label=f"Outer Fillets / 外圓角 ({len(outer_arcs)})" if i == 0 else None,
        )

    _draw_bcs(ax_bot, geo, show_labels=True)
    ax_bot.set_xlim(xmin, xmax)
    ax_bot.set_ylim(ymin, ymax)
    ax_bot.set_aspect("equal", adjustable="box")
    ax_bot.tick_params(colors="#94a3b8", labelsize=7)
    ax_bot.set_title(
        f"Candidate #{cand_idx:04d} [Step 2: Selective Filleting] | Inner Fillets: {len(inner_arcs)} (Pink) | Outer Fillets: {len(outer_arcs)} (Gold)",
        color="#e2e8f0", fontsize=9.0,
    )
    ax_bot.legend(loc="upper left", facecolor="#161b26", edgecolor="#334155", labelcolor="#e2e8f0", fontsize=7.0)

    fig.savefig(out_png_path, dpi=135)


def main():
    dxf_in = os.path.join(ROOT_DIR, "part01.dxf")
    save_path = "./try012_out"
    save_dxf = False
    os.makedirs(save_path, exist_ok=True)

    src_doc = ezdxf.readfile(dxf_in)
    gen = Random6PtCntGenerator(
        src_doc,
        min_hinge_mm=1.25,
        d_snap_outer_mm=0.95,
        d_over_outer_mm=1.05,
        d_merge_cnt_mm=0.75,
        d_merge_depth_mm=0.85,
        raster_pitch_mm=0.30,
    )
    rng = np.random.default_rng(seed=42)

    fig, axes = plt.subplots(2, 1, figsize=(11.0, 9.2))
    fig.subplots_adjust(left=0.06, right=0.98, top=0.95, bottom=0.05, hspace=0.18)

    for idx in range(1, 101):
        cand_res = gen.sample_random_candidate(
            rng, min_cnt=5, max_cnt=6, r_in_max=0.60, r_out_max=0.45
        )
        out_png = os.path.join(save_path, f"cand_{idx:04d}.png")
        render_candidate_png(fig, axes, gen.geo, cand_res, idx, out_png)

        if save_dxf:
            out_dxf = os.path.join(save_path, f"cand_{idx:04d}.dxf")
            PolygonFilletHelper.export_filleted_dxf(src_doc, gen.geo, cand_res, out_dxf)

        if idx % 10 == 0 or idx == 1:
            n_in = sum(1 for a in cand_res["fillet_arcs"] if a["kind"] == "inner")
            n_out = sum(1 for a in cand_res["fillet_arcs"] if a["kind"] == "outer")
            print(
                f"[{idx:03d}/100] CNTs={len(cand_res['accepted_cnts'])} | "
                f"Loops={len(cand_res['filleted_outers']) + len(cand_res['filleted_holes'])} | "
                f"Fillets(In={n_in}, Out={n_out}) -> {out_png}"
            )

    plt.close(fig)


if __name__ == "__main__":
    main()