#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
try014.py — 焦點區域 2M 維 GP-BO 切肉：均勻初始孔洞 + 跨孔 Top-M 最近頂點協同微調 + 退火步長 + 動態加洞
執行方式: python ./try014.py
輸出路徑: ./try014_output/{YYYYMMDD_HHMMSS}/01_geometry_samples, 02_bo_knife_progress, 03_global_convergence, 04_fea_stress_samples
"""

import math
import os
import sys
import time
import warnings
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass, field
from datetime import datetime

for _env_key in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ.setdefault(_env_key, "1")

import numpy as np
import ezdxf
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import PolyCollection
from scipy.cluster.vq import kmeans2
from scipy.ndimage import distance_transform_edt, label as nd_label
from scipy.optimize import minimize
from scipy.stats import norm
from sklearn.exceptions import ConvergenceWarning
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import ConstantKernel, Matern

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(ROOT_DIR, "fea_toolbox"))

from try005 import (
    DXFContourHelper,
    FeaMeshGenerator,
    FeaSolver,
    FeaVisualizer,
    FiniteEleMeshHelper,
    MeshHyperParams,
    SolverHyperParams,
)
from try007 import PolygonBooleanHelper
from try012 import PolygonFilletHelper, PolygonGeometryCleaner, Random6PtCntGenerator


@dataclass
class BOHyperParams:
    # =========================================================================
    # 1. 初始孔洞 (CNT) 幾何、修剪與動態加洞設定
    # =========================================================================
    init_num_cnts: int = 0              # 初始在 AUTO 搜尋區內放置的孔洞 (下刀多邊形) 總數量
    num_pts_per_cnt: int = 6            # 每個孔洞多邊形的頂點數量 (預設 6 代表六邊形；支援任意 >= 3 之整數)
    init_cnt_area_mm2: float = 20.0     # 每個孔洞在初始化時的目標面積 (mm^2)；進入 BO 微調後完全不限制面積
    noise_dxy_level: float = 0.0        # 初始孔洞位置的隨機擾動程度 (0.0 = 完全等分空間均勻放置；>0 則加入高斯偏移)
    add_cnt_at_episodes: dict = field(
        default_factory=lambda: {20: 1, 40: 1}
    )                                   # 動態加洞排程：{第幾個Episode: 新增幾個孔洞}，例 {7: 1, 13: 1}
    prune_area_tol_mm2: float = 0.05    # 冗餘孔洞修剪面積容差 (mm^2)：若移除某孔洞後實體面積變化 <= 此值，判定被吞沒並刪除
    active_boundary_tol_mm: float = 1.5 # 有效邊界頂點容差 (mm)：只選取距離實際切肉邊界 <= 此距離的頂點參與微調，排除洞內死點

    # --- 解除幾何最薄牆厚限制 (改由 FEA 應力把關) ---
    geom_merge_and_snap_mm: float = 0.22 # 僅當頂點貼近外牆或鄰孔 < 0.22 mm 時才自動破邊/融合，不推開任何薄壁

    # --- FEA 應力安全紅線與超標懲罰 (由有限元素應力圖評估，取代幾何牆厚檢查) ---
    stress_limit_ratio: float = 2.80    # 材料降伏強度允許上限比例 (0.80 = 當 Max Von Mises > 80% yield_mpa 時重罰)
    stress_penalty_base_mm: float = 0.10  # 應力一超過 80% 紅線時的固定基礎扣分 (mm)，直接讓 +dy 分數變負值
    stress_penalty_slope_mm: float = 0.20 # 隨超標比例 (vm - limit)/limit 線性加重的懲罰斜率 (mm)

    # =========================================================================
    # 2. 局部區域結構 (Focus Region) 均勻網格採樣設定
    # =========================================================================
    max_episodes: int = 20              # 總共執行幾個「局部焦點區域 (Focus Episode)」微調回合
    focus_grid_pitch_mm: float = 1.0    # AUTO 搜尋空間均勻採樣網格的點距 (mm)，確保所有面積被抽中機率 100% 均勻
    k_nearest_vertices: int = 12         # 每回合抽中焦點中心 C 後，跨孔抓取距離 C 最近的前 M 個有效邊界頂點 (GP 維度 = 2 * M)

    # =========================================================================
    # 3. 由粗到細步長退火 (Step Shrink) 與早停 (Early Stopping) 設定
    # =========================================================================
    initial_step_ratio: float = 0.30    # 初始最大移動範圍佔 AUTO 搜尋空間長度的比例 (0.80 = 最多移動搜尋空間長度的 80%)
    patience: int = 8                   # 早停耐心值：連續幾個合法 FEA 樣本未刷新最佳 +dy 分數，即觸發縮小步長並清空 GP 池
    shrink_factor: float = 5.0          # 步長縮小倍數：每次觸發 patience 時，step_size = step_size / shrink_factor
    min_step_tol_mm: float = 0.12       # 步長終止閾值 (mm)：當 step_size 小於此值時，判定該局部區域收斂，換下一個焦點 C
    improve_tol_mm: float = 1e-4        # 有效進步門檻 (mm)：新樣本的 PROBE +dy 必須超出目前最佳值此數量，才算有實質進步

    # =========================================================================
    # 4. 高斯過程貝氏優化 (GP-BO) 內層設定
    # =========================================================================
    n_warmup_per_stage: int = 5         # 每個步長階段剛開始 (或縮步長清池後)，先隨機探索幾個合法樣本再啟動 GP 推論
    max_valid_evals_per_episode: int = 45 # 單一 Episode 最多評估幾個合法 FEA 樣本的安全上限
    max_try012_retries: int = 120       # 單一候選點未通過 try012 幾何檢查時，Worker 在本地微擾重抽的最大嘗試次數
    acq_xi: float = 0.01                # Expected Improvement (EI) 採集函數的探索權重 (越小越貪婪)
    gp_restarts: int = 12               # L-BFGS-B 在搜尋 EI 最大值時的隨機多起點數量

    # =========================================================================
    # 5. 多核心 CPU 平行運算與「平行時空非同步繪圖」設定
    # =========================================================================
    n_workers: int = field(
        default_factory=lambda: max(1, os.cpu_count() or 4)
    )                                   # FEA 平行求解子行程數量，預設吃滿所有 CPU 邏輯核心
    batch_size: int = field(
        default_factory=lambda: max(1, os.cpu_count() or 4)
    )                                   # 每一輪 GP 同時提議並平行送進 FEA 求解的批次大小
    n_plot_workers: int = 2             # 獨立「平行時空繪圖專用」背景子行程數量 (主迴圈射後不理，0 秒等待畫圖)

    # =========================================================================
    # 6. 四大資料夾視覺化輸出與跳存設定
    # =========================================================================
    output_root: str = "./try014_output"# 輸出根資料夾路徑 (每次執行自動建立 {YYYYMMDD_HHMMSS} 時間戳記子目錄)
    save_every_n_samples: int = 3       # 資料夾 1 (幾何) 與資料夾 4 (應力) 每 N 個合法樣本存 1 張圖 (FINAL 最佳必存)
    dpi: int = 100                      # 輸出 PNG 圖片的解析度 (DPI)

    # =========================================================================
    # 7. 人機協作 ("TRY" 圖層經驗孔洞導入) 設定
    # =========================================================================
    try_layer_name: str = "TRY"             # DXF 中工程師手繪初始下刀輪廓的圖層名稱 (不分大小寫，亦支援 TRY_* / TRY# 前綴)
    try_layer_mode: str = "supplement"      # "supplement": 先放入 TRY 孔洞，不足 init_num_cnts 的數量由均勻網格自動補足
                                            # "only_try"  : 若有讀到 TRY 孔洞，初始僅使用 TRY 孔洞，不自動補孔
    try_max_vertices_keep: int = 48         # 若工程師畫的多邊形頂點數 <= 此值則原樣保留頂點；若 > 此值(如畫圓)則重採樣為此數量


def _is_try_layer(layer_name: str, target_prefix: str = "TRY") -> bool:
    u = str(layer_name).strip().upper()
    t = str(target_prefix).strip().upper()
    return u == t or u.startswith(t + "_") or u.startswith(t + "#")


def extract_and_strip_try_layer_cnts(
    doc,
    try_layer_name: str = "TRY",
    num_pts_fallback: int = 6,
    max_vertices_keep: int = 48,
    snap_tol: float = 0.12,
) -> list:
    """
    1. 從 DXF modelspace 識別名稱為 'TRY' (或 'TRY_*') 圖層的線條/聚合線/圓弧/圓，
       自動串接為封閉多邊形孔洞 (CNT)。
    2. 在記憶體中將這些 'TRY' 圖元從 doc.modelspace() 移除，避免干擾 try012 的毛坯解析。
    """
    msp = doc.modelspace()
    raw_lines, _curve_edges, _disp, arc_polys, circle_polys = DXFContourHelper.extract_primitives_from_msp(msp)

    try_segs = []
    try_loops = []

    for s in raw_lines:
        if _is_try_layer(s.layer, try_layer_name):
            pts = np.array([s.p1, s.p2], dtype=float)
            try_segs.append((pts, "TRY"))

    for pts, _h, layer in arc_polys:
        if _is_try_layer(layer, try_layer_name):
            arr = np.asarray(pts, dtype=float)
            if len(arr) >= 2:
                try_segs.append((arr, "TRY"))

    for pts, _h, layer in circle_polys:
        if _is_try_layer(layer, try_layer_name):
            arr = np.asarray(pts, dtype=float)[:-1]
            if len(arr) >= 3:
                try_loops.append(arr)

    if try_segs:
        chained = FiniteEleMeshHelper._chain_segments_with_layers(try_segs, snap_tol=snap_tol)
        for loop_pts, _lays in chained:
            if len(loop_pts) >= 3:
                try_loops.append(loop_pts)

    entities_to_remove = [
        ent for ent in msp
        if _is_try_layer(ent.dxf.layer if ent.dxf.hasattr("layer") else "0", try_layer_name)
    ]
    for ent in entities_to_remove:
        try:
            msp.delete_entity(ent)
        except Exception:
            pass

    final_try_cnts = []
    for lp in try_loops:
        clean_lp = PolygonBooleanHelper.simplify_collinear(np.asarray(lp, dtype=float), angle_tol=1e-3)
        if len(clean_lp) < 3 or FiniteEleMeshHelper._polygon_area(clean_lp) <= 1e-2:
            continue
        # 若為單一凸多邊形則直接極角排序；若為 L 槽等凹多邊形則自動拆解為多個重疊凸多邊形
        convex_pieces = _decompose_concave_to_convex_cnts(
            clean_lp, target_num_pts=num_pts_fallback
        )
        final_try_cnts.extend(convex_pieces)

    final_try_cnts.sort(key=FiniteEleMeshHelper._polygon_area, reverse=True)
    return final_try_cnts


def _build_in_memory_dxf(src_doc, geo: dict, cand_res: dict):
    doc = ezdxf.new(dxfversion="R2010")
    doc.units = ezdxf.units.MM
    msp = doc.modelspace()

    for lay in src_doc.layers:
        lname = lay.dxf.name
        if lname.upper() in ("AUTO", "SEARCH_ZONE"):
            continue
        if lname not in doc.layers:
            doc.layers.add(name=lname, color=lay.dxf.color if lay.dxf.hasattr("color") else 7)

    for p1, p2 in cand_res["lines"]:
        msp.add_line((float(p1[0]), float(p1[1])), (float(p2[0]), float(p2[1])), dxfattribs={"layer": "0"})
    for arc in cand_res["arcs"]:
        c = arc["center"]
        msp.add_arc(
            (float(c[0]), float(c[1])),
            float(arc["radius"]),
            float(arc["sa_deg"]),
            float(arc["ea_deg"]),
            dxfattribs={"layer": "0"},
        )

    for fc in geo["fixed_circles"]:
        cx, cy = fc["center"]
        msp.add_circle((float(cx), float(cy)), float(fc["radius"]), dxfattribs={"layer": fc["layer"]})
    for seg_pts, lay in geo["disp_segs"]:
        msp.add_line(
            (float(seg_pts[0][0]), float(seg_pts[0][1])),
            (float(seg_pts[1][0]), float(seg_pts[1][1])),
            dxfattribs={"layer": lay},
        )
    for pc in geo["probe_circles"]:
        cx, cy = pc["center"]
        msp.add_circle((float(cx), float(cy)), float(pc["radius"]), dxfattribs={"layer": pc["layer"]})
    return doc


def _polar_sort_ccw(poly: np.ndarray) -> np.ndarray:
    """
    強制以多邊形質心為核心進行逆時針 (CCW) 極角排序。
    所有單一 CNT 皆維持星形/凸多邊形，100% 根除自我交叉蝴蝶結 (Bowtie)。
    """
    pts = np.asarray(poly, dtype=float)
    if len(pts) < 3:
        return pts.copy()
    cen = pts.mean(axis=0)
    angs = np.arctan2(pts[:, 1] - cen[1], pts[:, 0] - cen[0])
    return pts[np.argsort(angs)].copy()


def _align_by_cyclic_roll(raw_poly: np.ndarray, polar_sorted_poly: np.ndarray) -> np.ndarray:
    """
    僅透過環狀平移 (np.roll) 對齊 polar_sorted_poly 與 raw_poly 的起點索引 (消除 +-pi 跨界跳號)，
    【絕對不交換頂點的環繞順序】，徹底防止 linear_sum_assignment 將頂點洗回蝴蝶結！
    """
    raw_arr = np.asarray(raw_poly, dtype=float)
    srt_arr = _polar_sort_ccw(polar_sorted_poly)
    n = len(srt_arr)
    if n <= 1 or len(raw_arr) != n:
        return srt_arr

    best_k = 0
    best_cost = float("inf")
    for k in range(n):
        rolled = np.roll(srt_arr, k, axis=0)
        cost = float(np.sum(np.linalg.norm(raw_arr - rolled, axis=1)))
        if cost < best_cost:
            best_cost = cost
            best_k = k
    return np.roll(srt_arr, best_k, axis=0).copy()


def _is_convex_ccw(poly: np.ndarray, sin_tol: float = -0.08) -> bool:
    """
    檢查逆時針多邊形是否為凸多邊形 (允許約 4.5 度以內的極微小共線/繪圖折角誤差 sin_tol=-0.08，
    避免把近似直線的長邊切出微小碎三角形)。
    """
    pts = np.asarray(poly, dtype=float)
    if len(pts) < 3:
        return False
    if FiniteEleMeshHelper._polygon_area_signed(pts) < 0.0:
        pts = pts[::-1]
    prv = np.roll(pts, 1, axis=0)
    nxt = np.roll(pts, -1, axis=0)
    e1 = pts - prv
    e2 = nxt - pts
    l1 = np.maximum(np.linalg.norm(e1, axis=1), 1e-9)
    l2 = np.maximum(np.linalg.norm(e2, axis=1), 1e-9)
    sin_turn = (e1[:, 0] * e2[:, 1] - e1[:, 1] * e2[:, 0]) / (l1 * l2)
    return bool(np.all(sin_turn >= float(sin_tol)))


def _pad_polygon_vertices_keep_corners(poly: np.ndarray, target_num_pts: int = 6) -> np.ndarray:
    """
    在不削減任何原始轉角頂點的前提下，將多邊形頂點數調整至 target_num_pts：
    - 若頂點數 < target_num_pts：每次在最長邊的中點插入新頂點 (100% 保持原始轉角與邊界形狀，絕不切角！)
    - 若頂點數 > target_num_pts：每次移除轉角最接近 180 度 (最平坦共線) 的多餘頂點
    """
    pts = _polar_sort_ccw(poly)
    n_target = max(4, int(target_num_pts))

    while len(pts) < n_target:
        m = len(pts)
        nxt = np.roll(pts, -1, axis=0)
        lens = np.linalg.norm(nxt - pts, axis=1)
        idx_max = int(np.argmax(lens))
        mid_pt = 0.5 * (pts[idx_max] + pts[(idx_max + 1) % m])
        pts = np.insert(pts, idx_max + 1, mid_pt, axis=0)

    while len(pts) > n_target and len(pts) > 4:
        m = len(pts)
        prv = np.roll(pts, 1, axis=0)
        nxt = np.roll(pts, -1, axis=0)
        v1 = pts - prv
        v2 = nxt - pts
        l1 = np.maximum(np.linalg.norm(v1, axis=1), 1e-9)
        l2 = np.maximum(np.linalg.norm(v2, axis=1), 1e-9)
        sin_ang = np.abs(v1[:, 0] * v2[:, 1] - v1[:, 1] * v2[:, 0]) / (l1 * l2)
        idx_flat = int(np.argmin(sin_ang))
        pts = np.delete(pts, idx_flat, axis=0)

    return _polar_sort_ccw(pts)


def _decompose_concave_to_convex_cnts(
    loop_pts: np.ndarray,
    seam_overlap_mm: float = 1.25,
    target_num_pts: int = 6,
) -> list:
    """
    將工程師在 TRY 圖層繪製的輪廓轉為全凸多邊形列表：
    1. 先移除近乎共線的微小折點，避免切出 C5 那種碎小三角形。
    2. 若為凸多邊形 (如 C1, C2)，直接以 _pad_polygon_vertices_keep_corners 保留原始轉角返回。
    3. 若為 L 槽等凹多邊形，以 Ear-Clipping + Hertel-Mehlhorn 拆解為凸多邊形，
       並將兩塊凸多邊形在「內部切割接縫處」互相往對方延伸 seam_overlap_mm (1.25 mm)，
       確保布林聯集 (Union) 時 100% 融合成連續無斷肉的 L 槽！
    """
    pts = np.asarray(loop_pts, dtype=float).copy()
    if len(pts) < 3:
        return []
    if FiniteEleMeshHelper._polygon_area_signed(pts) < 0.0:
        pts = pts[::-1].copy()

    # 預先消除 < 12 度的近共線微折點 (如 L 槽上緣的微小折角)，避免產生碎三角形
    pts = PolygonBooleanHelper.simplify_collinear(pts, angle_tol=math.radians(12.0))
    if FiniteEleMeshHelper._polygon_area_signed(pts) < 0.0:
        pts = pts[::-1].copy()

    if _is_convex_ccw(pts, sin_tol=-0.08):
        return [_pad_polygon_vertices_keep_corners(pts, target_num_pts=target_num_pts)]

    orig_boundary_segs = PolygonFilletHelper.loops_to_segments([pts])

    # 1. Ear-Clipping 耳切法拆解為三角形列表
    verts = [pts[i].copy() for i in range(len(pts))]
    triangles = []
    guard = 0
    while len(verts) > 3 and guard < 400:
        guard += 1
        m = len(verts)
        ear_found = False
        best_ear_idx = -1
        best_ear_score = -1.0
        for i in range(m):
            p_prev = verts[(i - 1) % m]
            p_cur = verts[i]
            p_next = verts[(i + 1) % m]
            cross = ((p_cur[0] - p_prev[0]) * (p_next[1] - p_cur[1])
                     - (p_cur[1] - p_prev[1]) * (p_next[0] - p_cur[0]))
            if cross <= 1e-6:
                continue
            tri = np.array([p_prev, p_cur, p_next], dtype=float)
            tri_path = PolygonBooleanHelper.as_path(tri)
            others = np.array([verts[j] for j in range(m) if j not in ((i - 1) % m, i, (i + 1) % m)])
            if len(others) > 0 and np.any(tri_path.contains_points(others, radius=-1e-4)):
                continue
            area_t = abs(0.5 * cross)
            peri_t = (np.linalg.norm(p_cur - p_prev)
                      + np.linalg.norm(p_next - p_cur)
                      + np.linalg.norm(p_prev - p_next))
            score = area_t / max(peri_t ** 2, 1e-9)
            if score > best_ear_score:
                best_ear_score = score
                best_ear_idx = i

        if best_ear_idx >= 0:
            i = best_ear_idx
            tri = np.array([verts[(i - 1) % m], verts[i], verts[(i + 1) % m]], dtype=float)
            triangles.append(tri)
            verts.pop(i)
            ear_found = True

        if not ear_found:
            break
    if len(verts) == 3:
        triangles.append(np.array(verts, dtype=float))

    if not triangles:
        return [_pad_polygon_vertices_keep_corners(pts, target_num_pts=target_num_pts)]

    # 2. Hertel-Mehlhorn 貪婪凸合併 (把碎三角形合併成完整的大橫臂與大豎臂)
    convex_polys = [t.copy() for t in triangles]
    merged = True
    while merged and len(convex_polys) > 1:
        merged = False
        for i in range(len(convex_polys)):
            for j in range(i + 1, len(convex_polys)):
                u_outers, _ = PolygonBooleanHelper.boolean_op([convex_polys[i], convex_polys[j]], cut_loops=None)
                if len(u_outers) == 1:
                    cand = PolygonBooleanHelper.simplify_collinear(u_outers[0], angle_tol=math.radians(8.0))
                    if _is_convex_ccw(cand, sin_tol=-0.10):
                        convex_polys[i] = _polar_sort_ccw(cand)
                        convex_polys.pop(j)
                        merged = True
                        break
            if merged:
                break

    # 過濾掉面積過小的碎塊 (< 4.0 mm^2)
    total_a = sum(FiniteEleMeshHelper._polygon_area(cp) for cp in convex_polys)
    convex_polys = [
        cp for cp in convex_polys
        if FiniteEleMeshHelper._polygon_area(cp) >= min(4.0, 0.08 * total_a)
    ]

    # 3. 針對相鄰凸塊之間的「內部切割接縫邊 (Internal Seam)」，往鄰塊內部延伸 seam_overlap_mm，
    #    確保兩塊凸多邊形在轉角處深度重疊，聯集後絕對不會留下 C3-C4 之間的殘肉牆！
    out_cnts = []
    n_pieces = len(convex_polys)
    for cpoly in convex_polys:
        work_p = _polar_sort_ccw(cpoly)
        m = len(work_p)
        if n_pieces > 1 and seam_overlap_mm > 0.0:
            expanded_pts = list(work_p)
            for e_i in range(m):
                a = work_p[e_i]
                b = work_p[(e_i + 1) % m]
                mid = 0.5 * (a + b)
                # 若這條邊的中點不在原始 TRY 外邊界上，代表它是拆解出來的「內部切割縫」！
                d_orig = PolygonFilletHelper.point_to_segments_min_dist(mid, orig_boundary_segs)
                if d_orig > 0.15:
                    edge_vec = b - a
                    el = max(float(np.linalg.norm(edge_vec)), 1e-9)
                    # CCW 多邊形的朝外法向量 n_out = (u_y, -u_x)，朝鄰塊內部突入 seam_overlap_mm
                    n_out_seam = np.array([edge_vec[1] / el, -edge_vec[0] / el], dtype=float)
                    seam_wedge_pt = mid + float(seam_overlap_mm) * n_out_seam
                    expanded_pts.append(seam_wedge_pt)
            work_p = _polar_sort_ccw(np.asarray(expanded_pts, dtype=float))

        padded = _pad_polygon_vertices_keep_corners(work_p, target_num_pts=target_num_pts)
        out_cnts.append(padded)

    return out_cnts if out_cnts else [_pad_polygon_vertices_keep_corners(pts, target_num_pts=target_num_pts)]


def _shrink_polygon_inward(poly: np.ndarray, offset_mm: float) -> np.ndarray:
    """
    沿著多邊形每個頂點的「向內角平分線法向量 (Inward Miter Normal)」內縮 offset_mm。
    適用於 L 槽、U 槽等凹多邊形，內縮時只會讓槽變窄，不會像質心縮放一樣平移撞上外部固定孔。
    """
    pts = np.asarray(poly, dtype=float).copy()
    if abs(offset_mm) <= 1e-9 or len(pts) < 3:
        return pts
    if FiniteEleMeshHelper._polygon_area_signed(pts) < 0.0:
        pts = pts[::-1].copy()

    m = len(pts)
    new_pts = pts.copy()
    for i in range(m):
        p_prev = pts[(i - 1) % m]
        p_cur = pts[i]
        p_next = pts[(i + 1) % m]
        e1 = p_cur - p_prev
        e2 = p_next - p_cur
        l1 = float(np.linalg.norm(e1))
        l2 = float(np.linalg.norm(e2))
        if l1 <= 1e-8 or l2 <= 1e-8:
            continue
        u1 = e1 / l1
        u2 = e2 / l2
        # 逆時針 (CCW) 多邊形的左側為內部: n_in = (-u_y, u_x)
        n1_in = np.array([-u1[1], u1[0]], dtype=float)
        n2_in = np.array([-u2[1], u2[0]], dtype=float)
        bisec = n1_in + n2_in
        bn = float(np.linalg.norm(bisec))
        u_in = (bisec / bn) if bn > 1e-6 else n1_in
        new_pts[i] = p_cur + float(offset_mm) * u_in
    return new_pts


def _morph_cnt_polygon_concave_safe(
    gen: Random6PtCntGenerator,
    raw_pts: np.ndarray,
    accepted_cnts: list,
) -> np.ndarray:
    """
    全凸/星形多邊形頂點修正 (搭配聯集直接剪肉)：
    1. 全程強制使用質心極角排序 (_polar_sort_ccw) + 環狀對齊 (_align_by_cyclic_roll)，100% 杜絕蝴蝶結。
    2. 允許不同 CNT 之間自由交疊 (不推開鄰孔)，直接由後續 boolean_op 取聯集剪出 L 槽或任意複合形狀。
    """
    # Step 0: 先以質心極角排順頂點，避免 BO 提議交叉影響相鄰點判斷
    pts = _align_by_cyclic_roll(raw_pts, raw_pts)
    n = len(pts)
    d_wall = gen.min_hinge_mm
    d_snap = gen.d_snap_outer
    d_over = gen.d_over_outer
    d_merge = gen.d_merge_cnt
    d_mdepth = gen.d_merge_depth

    # 1. A1: 可切破外邊界雙向分流 + 相鄰點連坐破邊
    broke_seg_by_vertex = {}
    for i in range(n):
        p = pts[i]
        best_seg = None
        best_abs_s = float("inf")
        best_s = 0.0
        for bseg in gen.breakable_outer_segs:
            a, _b, u, n_out, L = bseg["a"], bseg["b"], bseg["u"], bseg["n_out"], bseg["len"]
            rel = p - a
            t_along = float(rel @ u)
            if t_along < -0.25 or t_along > L + 0.25:
                continue
            s = float(rel @ n_out)
            if abs(s) < best_abs_s:
                best_abs_s = abs(s)
                best_s = s
                best_seg = bseg

        if best_seg is not None:
            n_out = best_seg["n_out"]
            if -d_snap <= best_s < d_over:
                pts[i] = p + (d_over - best_s) * n_out
                broke_seg_by_vertex[i] = best_seg
            elif best_s >= d_over:
                broke_seg_by_vertex[i] = best_seg
            elif -d_wall < best_s < -d_snap:
                pts[i] = p + (-d_wall - best_s) * n_out

    for i, bseg in list(broke_seg_by_vertex.items()):
        a, u, n_out, L = bseg["a"], bseg["u"], bseg["n_out"], bseg["len"]
        for nb in ((i - 1) % n, (i + 1) % n):
            if nb in broke_seg_by_vertex:
                continue
            p_nb = pts[nb]
            rel_nb = p_nb - a
            t_along = float(rel_nb @ u)
            if t_along < -0.5 or t_along > L + 0.5:
                continue
            s_nb = float(rel_nb @ n_out)
            edge_vec = p_nb - pts[i]
            edge_len = float(np.linalg.norm(edge_vec))
            grazing_deg = 90.0
            if edge_len > 1e-6:
                sin_ang = abs(float((edge_vec / edge_len) @ n_out))
                grazing_deg = math.degrees(math.asin(np.clip(sin_ang, 0.0, 1.0)))
            if s_nb < d_over and (s_nb > -1.55 * d_wall or grazing_deg < 34.0):
                pts[nb] = p_nb + (d_over - s_nb) * n_out
                broke_seg_by_vertex[nb] = bseg

    # 2. A2 鄰孔極近距離微融合 (確保兩凸孔交疊聯集時不會留下 < d_merge 的極薄碎刺)
    for prev_cnt in accepted_cnts:
        prev_cen = prev_cnt.mean(axis=0)
        prev_segs = PolygonFilletHelper.loops_to_segments([prev_cnt])
        for i in range(n):
            p = pts[i]
            min_d = float("inf")
            for sa, sb in prev_segs:
                d, _proj, _ = PolygonFilletHelper.point_to_seg_proj(p, sa, sb)
                if d < min_d:
                    min_d = d
            if min_d < d_merge:
                dir_to_cen = prev_cen - p
                norm_c = float(np.linalg.norm(dir_to_cen))
                if norm_c > 1e-4:
                    pts[i] = p + min(d_mdepth, 0.45 * norm_c) * (dir_to_cen / norm_c)

    # 3. 保護邊界垂直法向退縮 (確保貼著 y=-50.293 畫的橫臂能垂直往上退離保護區，不會因斜率過小而退縮失敗)
    poly_cen = pts.mean(axis=0)
    d_clear = max(float(d_wall) + 0.15, float(gen.raster_pitch) * 1.8)
    for i in range(n):
        p = pts[i]
        for sa, sb in gen.protected_segs:
            d, proj, _ = PolygonFilletHelper.point_to_seg_proj(p, sa, sb)
            if d < d_clear:
                seg_v = sb - sa
                seg_l = float(np.linalg.norm(seg_v))
                if seg_l > 1e-8:
                    # 取垂直於保護邊線段的單位法向量 n_perp，方向朝向 poly_cen 所在側
                    n_perp = np.array([-seg_v[1] / seg_l, seg_v[0] / seg_l], dtype=float)
                    if float(np.dot(n_perp, poly_cen - proj)) < 0.0:
                        n_perp = -n_perp
                    pts[i] = proj + d_clear * n_perp

    # 3b. 網格像素級防呆：若仍有頂點擦到 gen.forbidden_mask，直接吸回最近的合法 AUTO 安全像素
    safe_mask = gen.auto_mask & (~gen.forbidden_mask)
    offenders = []
    for i in range(n):
        p = pts[i]
        c_idx = int(np.clip(np.argmin(np.abs(gen.xs - p[0])), 0, len(gen.xs) - 1))
        r_idx = int(np.clip(np.argmin(np.abs(gen.ys - p[1])), 0, len(gen.ys) - 1))
        if bool(gen.forbidden_mask[r_idx, c_idx]):
            offenders.append(i)
    if offenders and safe_mask.any():
        safe_rc = np.argwhere(safe_mask)
        safe_xy = np.column_stack([gen.xs[safe_rc[:, 1]], gen.ys[safe_rc[:, 0]]])
        for i in offenders:
            p = pts[i]
            d2 = (safe_xy[:, 0] - p[0]) ** 2 + (safe_xy[:, 1] - p[1]) ** 2
            nearest_xy = safe_xy[int(np.argmin(d2))]
            dir_in = poly_cen - nearest_xy
            ni = float(np.linalg.norm(dir_in))
            pts[i] = nearest_xy + (0.25 * (dir_in / ni) if ni > 1e-6 else 0.0)

    # 4. 強制以質心極角排序並用環狀平移對齊，100% 消除自我交叉蝴蝶結
    return _align_by_cyclic_roll(raw_pts, pts)


def _is_topology_valid_no_wall_gate(gen: Random6PtCntGenerator, cut_mask: np.ndarray) -> bool:
    """
    僅檢查純拓樸連通性，【不進行任何最小牆厚/絞鏈厚度的幾何膨脹攔截】：
    1. 不可切入 FIXED 固定孔、DISP 施力區或非 AUTO 保護區 (forbidden_mask)
    2. 切完後的實體不可斷裂成 2 個以上互不相連的孤島
    3. 各邊界條件錨點 (FIXED, DISP, PROBE) 必須仍位在同一個連通實體上
    至於牆壁太薄會不會斷裂或屈服，100% 交由後續 FEA Von Mises 應力分析來評估與扣分！
    """
    if np.any(cut_mask & gen.forbidden_mask):
        return False
    next_solid = gen.blank_mask & (~cut_mask)
    if not next_solid.any():
        return False

    lab_full, n_full = nd_label(next_solid)
    if n_full == 0:
        return False
    if n_full > 1:
        sizes = np.bincount(lab_full.ravel())[1:]
        if np.sum(sizes > 4) > 1:
            return False

    if not gen.anchor_masks:
        return True

    anchor_labels = set()
    for am in gen.anchor_masks:
        overlap = lab_full[am & (lab_full > 0)]
        if len(overlap) == 0:
            return False
        anchor_labels.add(int(overlap[0]))
    return len(anchor_labels) == 1


def check_cnt_batch_geometry(gen: Random6PtCntGenerator, raw_cnt_list: list):
    morphed_cnts = []
    combined_cut_mask = np.zeros(gen.grid_shape, dtype=bool)

    for raw_pts in raw_cnt_list:
        m_pts = _morph_cnt_polygon_concave_safe(gen, raw_pts, morphed_cnts)
        morphed_cnts.append(m_pts)
        combined_cut_mask |= gen._poly_to_mask(m_pts)

    if not morphed_cnts:
        return None
    # 使用無最小牆厚限制的純拓樸連通檢查
    if not _is_topology_valid_no_wall_gate(gen, combined_cut_mask):
        return None

    cnt_union, _ = PolygonBooleanHelper.boolean_op(morphed_cnts, cut_loops=None)
    s_outers, s_holes = PolygonBooleanHelper.boolean_op(
        [gen.geo["unified_blank"]], cut_loops=list(gen.geo["holes_0"]) + cnt_union
    )
    c_outers, c_holes, ex_pts = PolygonGeometryCleaner.clean_boolean_loops_slivers(
        s_outers, s_holes, morphed_cnts, gen.geo["holes_0"], gen.geo["disp_segs"],
        min_edge_len=0.25, min_angle_deg=18.0,
    )
    if len(c_outers) != 1:
        return None

    # 關鍵：min_wall_mm=0.0，徹底關閉幾何薄壁檢查關卡！
    if not PolygonGeometryCleaner.verify_loops_clearance_and_angles(
        c_outers, c_holes, morphed_cnts, gen.geo["holes_0"],
        extra_cnt_vertices=ex_pts, min_wall_mm=0.0, min_angle_deg=15.0,
    ):
        return None

    fillet_res = PolygonFilletHelper.fillet_boolean_loops(
        sharp_outers=c_outers, sharp_holes=c_holes, accepted_cnts=morphed_cnts,
        holes_0=gen.geo["holes_0"], disp_segs=gen.geo["disp_segs"],
        extra_cnt_vertices=ex_pts, r_in_max=0.60, r_out_max=0.45, r_min=0.05,
    )
    return {
        "accepted_cnts": morphed_cnts,
        "sharp_outers": c_outers,
        "sharp_holes": c_holes,
        "filleted_outers": fillet_res["filleted_outers"],
        "filleted_holes": fillet_res["filleted_holes"],
        "fillet_lines": fillet_res["lines"],
        "fillet_arcs": fillet_res["arcs"],
        "lines": fillet_res["lines"],
        "arcs": fillet_res["arcs"],
    }


def evaluate_cnt_batch_with_try012_and_fea(
    gen: Random6PtCntGenerator,
    src_doc,
    raw_cnt_list: list,
    mesh_hp: MeshHyperParams,
    solver_hp: SolverHyperParams,
    bo_hp: BOHyperParams = None,
) -> dict:
    cand_res = check_cnt_batch_geometry(gen, raw_cnt_list)
    if cand_res is None:
        return {"is_valid": False}

    mem_doc = _build_in_memory_dxf(src_doc, gen.geo, cand_res)
    try:
        mesh = FeaMeshGenerator.build_t6_mesh_from_dxf(mem_doc, hp=mesh_hp)
        fea = FeaSolver.solve(mesh, hp=solver_hp)
    except Exception:
        return {"is_valid": False}

    probes = fea.get("probes") or {}
    if not probes:
        return {"is_valid": False}
    if float(fea.get("converged_lambda", 0.0)) < 0.99:
        return {"is_valid": False}

    first_probe = next(iter(probes.values()))
    raw_dy = float(first_probe["dy"])

    # --- 從 FEA 應力場讀取最大 Von Mises 應力，超過材料強度 80% 施加懲罰 ---
    vm_max = float(fea.get("max_von_mises", 0.0))
    yield_mpa = float(solver_hp.yield_mpa)
    limit_ratio = 0.80 if bo_hp is None else float(bo_hp.stress_limit_ratio)
    pen_base = 0.10 if bo_hp is None else float(bo_hp.stress_penalty_base_mm)
    pen_slope = 0.20 if bo_hp is None else float(bo_hp.stress_penalty_slope_mm)

    stress_limit_mpa = limit_ratio * yield_mpa
    if vm_max > stress_limit_mpa:
        over_ratio = (vm_max - stress_limit_mpa) / max(stress_limit_mpa, 1e-6)
        penalty_mm = pen_base + pen_slope * min(over_ratio, 5.0)
        dy_score = raw_dy - penalty_mm
        is_over_stress = True
    else:
        penalty_mm = 0.0
        dy_score = raw_dy
        is_over_stress = False

    return {
        "is_valid": True,
        "dy_score": float(dy_score),
        "raw_dy": float(raw_dy),
        "vm_max": float(vm_max),
        "stress_limit_mpa": float(stress_limit_mpa),
        "penalty_mm": float(penalty_mm),
        "is_over_stress": bool(is_over_stress),
        "cand_res": cand_res,
        "mesh": mesh,
        "fea": fea,
        "morphed_cnts": cand_res["accepted_cnts"],
    }


def make_regular_6pt_from_area(center_xy, area_mm2: float, rng: np.random.Generator,
                               noise_level: float = 0.0, auto_span: float = 10.0,
                               num_pts: int = 6) -> np.ndarray:
    n_pts = max(3, int(num_pts))
    r_base = math.sqrt((2.0 * max(float(area_mm2), 1e-3)) / (n_pts * math.sin(2.0 * math.pi / n_pts)))
    base_angles = np.linspace(0.0, 2.0 * math.pi, n_pts, endpoint=False)
    pts = np.column_stack([
        float(center_xy[0]) + r_base * np.cos(base_angles),
        float(center_xy[1]) + r_base * np.sin(base_angles),
    ])
    if noise_level > 0.0:
        sigma_mm = float(noise_level) * 0.15 * float(auto_span)
        pts += rng.normal(0.0, sigma_mm, size=pts.shape)
        cen = pts.mean(axis=0)
        angs = np.arctan2(pts[:, 1] - cen[1], pts[:, 0] - cen[0])
        pts = pts[np.argsort(angs)]
    return pts


def init_uniform_cnt_centers(gen: Random6PtCntGenerator, k_cnts: int,
                             noise_level: float, rng: np.random.Generator) -> np.ndarray:
    avail_mask = gen.auto_mask & (~gen.forbidden_mask)
    rc_coords = np.argwhere(avail_mask)
    if len(rc_coords) == 0:
        rc_coords = np.argwhere(gen.blank_mask)
    xy_avail = np.column_stack([gen.xs[rc_coords[:, 1]], gen.ys[rc_coords[:, 0]]])

    k = max(1, int(k_cnts))
    idx_init = np.linspace(0, len(xy_avail) - 1, k, dtype=int)
    init_centroids = np.asarray(xy_avail[idx_init], dtype=float)

    if len(xy_avail) > k:
        centroids, _lab = kmeans2(xy_avail, k=init_centroids, iter=30, minit="matrix")
        centroids = np.asarray(centroids, dtype=float)
    else:
        centroids = init_centroids.copy()

    bad = ~np.isfinite(centroids).all(axis=1)
    if np.any(bad):
        centroids[bad] = init_centroids[bad]

    if noise_level > 0.0:
        jitter = rng.uniform(-1.0, 1.0, size=centroids.shape) * (float(noise_level) * 0.25 * gen.auto_span)
        centroids = centroids + jitter
    return centroids


def place_initial_cnts(
    gen: Random6PtCntGenerator,
    hp: BOHyperParams,
    rng: np.random.Generator,
    user_try_cnts: list = None,
) -> list:
    cnt_list = []

    # 1. 優先置入工程師在 DXF 'TRY' 圖層指定的孔洞 (支援 L 槽、U 槽等任意凹多邊形)
    for idx, try_pts in enumerate(user_try_cnts or []):
        cen = try_pts.mean(axis=0)
        placed = False
        for inward_offset_mm in (0.0, 0.15, 0.30, 0.50):
            cand_pts = _shrink_polygon_inward(try_pts, inward_offset_mm)
            if check_cnt_batch_geometry(gen, cnt_list + [cand_pts]) is not None:
                cnt_list.append(cand_pts)
                placed = True
                print(
                    f"[TRY 圖層] 成功載入工程師指定孔洞 #{idx + 1} "
                    f"(頂點數={len(cand_pts)}, 內縮={inward_offset_mm:.2f} mm)"
                )
                break
        if not placed:
            print(f"[TRY 圖層] 警告：工程師指定孔洞 #{idx + 1} @ ({cen[0]:.1f}, {cen[1]:.1f}) 未通過拓樸檢查，已略過")

    if str(hp.try_layer_mode).lower() == "only_try" and len(cnt_list) > 0:
        return cnt_list

    # 2. 若數量未達 hp.init_num_cnts，在扣除既有 TRY 孔洞後的剩餘 AUTO 可用空間內均勻補足
    remain_k = max(0, int(hp.init_num_cnts) - len(cnt_list))
    if remain_k <= 0:
        return cnt_list

    avail_mask = gen.auto_mask & (~gen.forbidden_mask)
    for existing_p in cnt_list:
        cut_m = gen._poly_to_mask(existing_p)
        avail_mask &= (~cut_m)

    rc_coords = np.argwhere(avail_mask)
    if len(rc_coords) == 0:
        return cnt_list

    xy_avail = np.column_stack([gen.xs[rc_coords[:, 1]], gen.ys[rc_coords[:, 0]]])
    idx_init = np.linspace(0, len(xy_avail) - 1, remain_k, dtype=int)
    init_centroids = np.asarray(xy_avail[idx_init], dtype=float)
    if len(xy_avail) > remain_k:
        centroids, _lab = kmeans2(xy_avail, k=init_centroids, iter=30, minit="matrix")
        centroids = np.asarray(centroids, dtype=float)
    else:
        centroids = init_centroids.copy()

    bad = ~np.isfinite(centroids).all(axis=1)
    if np.any(bad):
        centroids[bad] = init_centroids[bad]
    if hp.noise_dxy_level > 0.0:
        jitter = rng.uniform(-1.0, 1.0, size=centroids.shape) * (float(hp.noise_dxy_level) * 0.25 * gen.auto_span)
        centroids = centroids + jitter

    for cen in centroids:
        placed = False
        for scale in (1.0, 0.85, 0.70, 0.55, 0.42):
            pts = make_regular_6pt_from_area(
                cen, hp.init_cnt_area_mm2 * scale * scale, rng,
                hp.noise_dxy_level, gen.auto_span, num_pts=hp.num_pts_per_cnt,
            )
            if check_cnt_batch_geometry(gen, cnt_list + [pts]) is not None:
                cnt_list.append(pts)
                placed = True
                break
        if not placed:
            print(f"[初始化] 跳過自動補孔中心 ({cen[0]:.2f}, {cen[1]:.2f})：幾何檢查未通過")

    return cnt_list


def add_one_cnt(gen: Random6PtCntGenerator, src_doc, cnt_list: list, hp: BOHyperParams,
                rng: np.random.Generator, mesh_hp: MeshHyperParams, solver_hp: SolverHyperParams):
    remain = gen.blank_mask.copy()
    for c in cnt_list:
        remain &= (~gen._poly_to_mask(c))
    if not remain.any():
        return None

    dist = distance_transform_edt(remain)
    d_min_px = max(1.0, gen.min_hinge_mm / max(gen.raster_pitch, 1e-6))
    n_col = dist.shape[1]
    order = np.argsort(dist.ravel())[::-1]

    for flat in order[:600]:
        row = int(flat // n_col)
        col = int(flat % n_col)
        if dist[row, col] < d_min_px:
            break
        center = (float(gen.xs[col]), float(gen.ys[row]))
        for scale in (1.0, 0.80, 0.65, 0.50):
            pts = make_regular_6pt_from_area(
                center, hp.init_cnt_area_mm2 * scale * scale, rng, hp.noise_dxy_level, gen.auto_span,
                num_pts=hp.num_pts_per_cnt,
            )
            trial = cnt_list + [pts]
            if check_cnt_batch_geometry(gen, trial) is None:
                continue
            res = evaluate_cnt_batch_with_try012_and_fea(gen, src_doc, trial, mesh_hp, solver_hp, bo_hp=hp)
            if res["is_valid"]:
                return trial, res
    return None


def build_uniform_auto_grid(gen: Random6PtCntGenerator, pitch_mm: float) -> np.ndarray:
    auto_loops = gen.geo["auto_loops"] if gen.geo["auto_loops"] else [gen.geo["unified_blank"]]
    all_pts = np.vstack(auto_loops)
    xmin, ymin = all_pts.min(axis=0)
    xmax, ymax = all_pts.max(axis=0)

    p = max(float(pitch_mm), 0.1)
    xs = np.arange(xmin, xmax + p, p)
    ys = np.arange(ymin, ymax + p, p)
    gx, gy = np.meshgrid(xs, ys)
    cand_pts = np.column_stack([gx.ravel(), gy.ravel()])

    in_auto = np.zeros(len(cand_pts), dtype=bool)
    for alp in auto_loops:
        in_auto |= PolygonBooleanHelper.as_path(alp).contains_points(cand_pts)

    valid_pts = cand_pts[in_auto]
    return valid_pts if len(valid_pts) > 0 else cand_pts


def prune_and_snap_redundant_cnts(
    gen: Random6PtCntGenerator,
    src_doc,
    cnt_list: list,
    current_eval: dict,
    hp: BOHyperParams,
    mesh_hp: MeshHyperParams,
    solver_hp: SolverHyperParams,
) -> tuple:
    """
    1. 剔除被其他孔洞完全包圍吞沒的冗餘孔洞 (如圖中的 C3)：
       若移除某個 CNT 後，切出的實體總面積變化量 <= hp.prune_area_tol_mm2，則將其刪除。
    2. 對留存孔洞中深埋在空洞肚子裡 (距離實際切肉邊界 > hp.active_boundary_tol_mm) 的死點，
       將其往最近的實際切肉邊界線段拉近，避免頂點卡死在空洞內部。
    """
    if len(cnt_list) <= 1:
        return cnt_list, current_eval

    def _solid_area(cand_res_dict: dict) -> float:
        a_out = sum(FiniteEleMeshHelper._polygon_area(lp) for lp in cand_res_dict["sharp_outers"])
        a_hol = sum(FiniteEleMeshHelper._polygon_area(lp) for lp in cand_res_dict["sharp_holes"])
        return float(a_out - a_hol)

    base_area = _solid_area(current_eval["cand_res"])
    pruned_list = [np.asarray(p, dtype=float).copy() for p in cnt_list]
    changed = False

    # Step 1: Leave-One-Out 檢查並刪除被完全包圍的冗餘孔洞
    idx = len(pruned_list) - 1
    while idx >= 0 and len(pruned_list) > 1:
        trial_list = pruned_list[:idx] + pruned_list[idx + 1:]
        cand_check = check_cnt_batch_geometry(gen, trial_list)
        if cand_check is not None:
            trial_area = _solid_area(cand_check)
            if abs(trial_area - base_area) <= float(hp.prune_area_tol_mm2):
                pruned_list = [np.asarray(p, dtype=float).copy() for p in cand_check["accepted_cnts"]]
                changed = True
        idx -= 1

    # Step 2: 將埋在聯集空洞內部的無效頂點往實際切肉邊界 (sharp_outers + sharp_holes) 拉近
    sharp_loops = list(current_eval["cand_res"].get("sharp_outers", [])) + list(
        current_eval["cand_res"].get("sharp_holes", [])
    )
    cut_segs = PolygonFilletHelper.loops_to_segments(sharp_loops)
    if cut_segs:
        snapped_list = [p.copy() for p in pruned_list]
        snap_triggered = False
        for p_i, poly in enumerate(snapped_list):
            poly_changed = False
            for v_i in range(len(poly)):
                pt = poly[v_i]
                best_d = float("inf")
                best_proj = None
                for sa, sb in cut_segs:
                    d, proj, _ = PolygonFilletHelper.point_to_seg_proj(pt, sa, sb)
                    if d < best_d:
                        best_d = d
                        best_proj = proj
                if best_proj is not None and best_d > float(hp.active_boundary_tol_mm):
                    poly[v_i] = pt + 0.85 * (best_proj - pt)
                    poly_changed = True
                    snap_triggered = True
            if poly_changed:
                snapped_list[p_i] = _align_by_cyclic_roll(poly, poly)

        if snap_triggered:
            cand_snap = check_cnt_batch_geometry(gen, snapped_list)
            if cand_snap is not None and abs(_solid_area(cand_snap) - base_area) <= 2.5:
                pruned_list = [np.asarray(p, dtype=float).copy() for p in cand_snap["accepted_cnts"]]
                changed = True

    if changed:
        res = evaluate_cnt_batch_with_try012_and_fea(gen, src_doc, pruned_list, mesh_hp, solver_hp, bo_hp=hp)
        if res["is_valid"]:
            return [np.asarray(p, dtype=float).copy() for p in res["morphed_cnts"]], res

    return cnt_list, current_eval


def select_k_nearest_vertices(
    cnt_list: list,
    cand_res: dict,
    focus_center: np.ndarray,
    k_nearest: int,
    active_boundary_tol_mm: float = 1.5,
) -> tuple:
    """
    優先篩選「距離實際切肉邊界 (sharp_outers + sharp_holes) <= active_boundary_tol_mm」的有效邊界頂點，
    再從中選出離 focus_center 最近的前 k_nearest 個頂點，徹底避免選中空洞內部的死點。
    """
    sharp_loops = list(cand_res.get("sharp_outers", [])) + list(cand_res.get("sharp_holes", []))
    cut_segs = PolygonFilletHelper.loops_to_segments(sharp_loops)

    flat_map = []
    flat_coords = []
    is_boundary_active = []

    for p_idx, poly in enumerate(cnt_list):
        for v_idx in range(len(poly)):
            pt = np.asarray(poly[v_idx], dtype=float)
            flat_map.append((p_idx, v_idx))
            flat_coords.append(pt)
            d_cut = PolygonFilletHelper.point_to_segments_min_dist(pt, cut_segs) if cut_segs else 0.0
            is_boundary_active.append(d_cut <= float(active_boundary_tol_mm))

    coords_arr = np.asarray(flat_coords, dtype=float)
    dists_to_focus = np.hypot(coords_arr[:, 0] - focus_center[0], coords_arr[:, 1] - focus_center[1])
    active_mask = np.asarray(is_boundary_active, dtype=bool)

    m = min(int(k_nearest), len(dists_to_focus))
    valid_ids = np.where(active_mask)[0]

    if len(valid_ids) >= m:
        sub_order = np.argsort(dists_to_focus[valid_ids])[:m]
        nearest_ids = valid_ids[sub_order]
    else:
        inactive_ids = np.where(~active_mask)[0]
        sub_inact = inactive_ids[np.argsort(dists_to_focus[inactive_ids])[: (m - len(valid_ids))]]
        nearest_ids = np.concatenate([valid_ids, sub_inact])

    active_map = [flat_map[int(i)] for i in nearest_ids]
    x_init_2m = coords_arr[nearest_ids].reshape(-1).copy()
    return active_map, x_init_2m


def apply_active_vertices_to_cnt_list(base_cnt_list: list, active_map: list, x_vec_2m: np.ndarray) -> list:
    new_cnt_list = [np.asarray(poly, dtype=float).copy() for poly in base_cnt_list]
    pts_m = np.asarray(x_vec_2m, dtype=float).reshape(-1, 2)
    for idx, (p_idx, v_idx) in enumerate(active_map):
        new_cnt_list[p_idx][v_idx] = pts_m[idx]
    return new_cnt_list


def clamp_vec_to_auto_band(gen: Random6PtCntGenerator, x_vec_2m: np.ndarray) -> np.ndarray:
    pts = np.asarray(x_vec_2m, dtype=float).reshape(-1, 2).copy()
    auto_loops = gen.geo["auto_loops"] if gen.geo["auto_loops"] else [gen.geo["unified_blank"]]
    auto_paths = [PolygonBooleanHelper.as_path(lp) for lp in auto_loops]
    auto_segs = PolygonFilletHelper.loops_to_segments(auto_loops)
    max_out_dist = float(gen.d_over_outer)

    in_auto = np.zeros(len(pts), dtype=bool)
    for path in auto_paths:
        in_auto |= path.contains_points(pts)

    for i in range(len(pts)):
        if in_auto[i]:
            continue
        p = pts[i]
        best_d = float("inf")
        best_proj = None
        for sa, sb in auto_segs:
            d, proj, _ = PolygonFilletHelper.point_to_seg_proj(p, sa, sb)
            if d < best_d:
                best_d = d
                best_proj = proj
        if best_proj is not None and best_d > max_out_dist:
            vec = p - best_proj
            norm_v = float(np.linalg.norm(vec))
            if norm_v > 1e-9:
                pts[i] = best_proj + max_out_dist * (vec / norm_v)
            else:
                pts[i] = best_proj.copy()

    return pts.reshape(-1)


def extract_morphed_state_and_active_vec(
    trial_cnts: list,
    morphed_cnts: list,
    active_map: list,
) -> tuple:
    aligned_cnts = []
    for raw_p, morph_p in zip(trial_cnts, morphed_cnts):
        # 只允許環狀平移對齊起點，嚴禁交換頂點順序，確保 aligned_cnts 100% 維持極角排序無蝴蝶結
        aligned_p = _align_by_cyclic_roll(raw_p, morph_p)
        aligned_cnts.append(aligned_p)

    x_morphed = np.array([aligned_cnts[p_i][v_i] for p_i, v_i in active_map], dtype=float).reshape(-1)
    return aligned_cnts, x_morphed


_W_DOC = None
_W_GEN = None
_W_MESH_HP = None
_W_SOLVER_HP = None
_W_BO_HP = None


def _init_fea_worker(
    dxf_path: str,
    mesh_hp: MeshHyperParams,
    solver_hp: SolverHyperParams,
    bo_hp: BOHyperParams,
):
    global _W_DOC, _W_GEN, _W_MESH_HP, _W_SOLVER_HP, _W_BO_HP
    _W_MESH_HP = mesh_hp
    _W_SOLVER_HP = solver_hp
    _W_BO_HP = bo_hp
    _W_DOC = ezdxf.readfile(dxf_path)
    extract_and_strip_try_layer_cnts(_W_DOC, try_layer_name=bo_hp.try_layer_name)

    d_micro = float(bo_hp.geom_merge_and_snap_mm)
    _W_GEN = Random6PtCntGenerator(
        _W_DOC,
        min_hinge_mm=d_micro,
        d_snap_outer_mm=d_micro,
        d_over_outer_mm=1.05,
        d_merge_cnt_mm=d_micro,
        d_merge_depth_mm=0.55,
        raster_pitch_mm=0.30,
    )


def _worker_eval_candidate_task(task_args: tuple) -> dict:
    base_cnt_list, active_map, x_prop, x_best, lb, ub, step_size, max_retries, seed_int = task_args
    rng = np.random.default_rng(seed_int)
    dim = len(x_prop)

    x_clamped = clamp_vec_to_auto_band(_W_GEN, x_prop)
    for retry in range(max_retries):
        if retry == 0:
            x_raw = x_clamped
        else:
            jitter_scale = min(step_size * 0.25, 0.05 * retry * step_size)
            base_pt = x_clamped if retry <= 4 else rng.uniform(lb, ub)
            x_raw = np.clip(base_pt + rng.normal(0.0, jitter_scale, size=dim), lb, ub)
            x_raw = clamp_vec_to_auto_band(_W_GEN, x_raw)

        trial_cnts = apply_active_vertices_to_cnt_list(base_cnt_list, active_map, x_raw)
        try:
            res = evaluate_cnt_batch_with_try012_and_fea(
                _W_GEN, _W_DOC, trial_cnts, _W_MESH_HP, _W_SOLVER_HP, bo_hp=_W_BO_HP
            )
        except Exception:
            return {"is_valid": False}
        if res["is_valid"]:
            try:
                aligned_cnts, x_morphed = extract_morphed_state_and_active_vec(
                    trial_cnts, res["morphed_cnts"], active_map
                )
            except Exception:
                return {"is_valid": False}
            res["x_morphed"] = x_morphed
            res["aligned_cnts"] = aligned_cnts
            return res

    return {"is_valid": False}


def propose_next_nd_point(
    x_pool: np.ndarray,
    y_pool: np.ndarray,
    lb: np.ndarray,
    ub: np.ndarray,
    rng: np.random.Generator,
    xi: float = 0.01,
    n_restarts: int = 12,
    fixed_kernel=None,
) -> tuple:
    """
    回傳 (x_next_2m, fitted_gp)。
    若傳入 fixed_kernel，則跳過 L-BFGS-B 超參數優化 (optimizer=None)，速度提升 5~8 倍。
    """
    dim = lb.shape[0]
    span = np.maximum(ub - lb, 1e-9)

    x_norm = (np.asarray(x_pool, dtype=float) - lb) / span
    y_arr = np.asarray(y_pool, dtype=float)

    if float(np.std(y_arr)) <= 1e-12:
        return rng.uniform(lb, ub), None

    if fixed_kernel is None:
        kernel = ConstantKernel(1.0, (1e-2, 1e2)) * Matern(
            length_scale=0.5, length_scale_bounds=(0.05, 5.0), nu=2.5
        )
        gp = GaussianProcessRegressor(
            kernel=kernel,
            alpha=1e-6,
            normalize_y=True,
            n_restarts_optimizer=1,
            random_state=int(rng.integers(1, 100000)),
        )
    else:
        gp = GaussianProcessRegressor(
            kernel=fixed_kernel,
            alpha=1e-6,
            normalize_y=True,
            optimizer=None,
        )

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=ConvergenceWarning)
        gp.fit(x_norm, y_arr)

    y_best = float(np.max(y_arr))
    unit_bounds = np.column_stack([np.zeros(dim), np.ones(dim)])

    def neg_ei(u_vec: np.ndarray) -> float:
        mu, sigma = gp.predict(np.asarray(u_vec, dtype=float).reshape(1, -1), return_std=True)
        m, s = float(mu[0]), float(np.atleast_1d(sigma)[0])
        if s <= 1e-12:
            return 0.0
        imp = m - y_best - xi
        z = imp / s
        return -float(imp * norm.cdf(z) + s * norm.pdf(z))

    cand_u = rng.uniform(0.0, 1.0, size=(256, dim))
    mu_b, sig_b = gp.predict(cand_u, return_std=True)
    imp_b = mu_b - y_best - xi
    sig_b = np.asarray(sig_b, dtype=float)
    z_b = np.where(sig_b > 1e-12, imp_b / np.maximum(sig_b, 1e-12), 0.0)
    ei_b = np.where(sig_b > 1e-12, imp_b * norm.cdf(z_b) + sig_b * norm.pdf(z_b), 0.0)

    top_indices = np.argsort(ei_b)[::-1][:max(1, int(n_restarts))]
    best_u = cand_u[top_indices[0]].copy()
    best_val = -float(ei_b[top_indices[0]])

    for idx in top_indices:
        res = minimize(neg_ei, x0=cand_u[idx], bounds=unit_bounds, method="L-BFGS-B")
        if float(res.fun) < best_val:
            best_val = float(res.fun)
            best_u = np.asarray(res.x, dtype=float).copy()

    return lb + np.clip(best_u, 0.0, 1.0) * span, gp


def propose_batch_nd_points(
    gen: Random6PtCntGenerator,
    x_pool: np.ndarray,
    y_pool: np.ndarray,
    lb: np.ndarray,
    ub: np.ndarray,
    batch_size: int,
    rng: np.random.Generator,
    xi: float = 0.01,
    n_restarts: int = 8,
) -> list:
    b_count = max(1, int(batch_size))
    span = np.maximum(ub - lb, 1e-9)

    x_halluc = list(np.asarray(x_pool, dtype=float))
    y_halluc = list(np.asarray(y_pool, dtype=float))
    proposals = []
    learned_kernel = None

    for b_idx in range(b_count):
        x_next, fitted_gp = propose_next_nd_point(
            np.asarray(x_halluc, dtype=float),
            np.asarray(y_halluc, dtype=float),
            lb, ub, rng,
            xi=xi * (1.25 ** b_idx),
            n_restarts=n_restarts if b_idx == 0 else max(4, n_restarts // 2),
            fixed_kernel=learned_kernel,
        )
        if b_idx == 0 and fitted_gp is not None:
            learned_kernel = fitted_gp.kernel_

        x_next = clamp_vec_to_auto_band(gen, x_next)
        proposals.append(x_next)

        if b_idx < b_count - 1:
            if fitted_gp is not None:
                u_next = ((x_next - lb) / span).reshape(1, -1)
                mu_pred = float(fitted_gp.predict(u_next)[0])
            else:
                mu_pred = float(np.mean(y_halluc))

            x_halluc.append(np.asarray(x_next, dtype=float).copy())
            y_halluc.append(mu_pred)

    return proposals


def _init_plot_worker():
    """初始化平行時空繪圖子行程：確保使用無 GUI 的 Agg 後端並關閉多餘執行緒。"""
    for env_key in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
        os.environ.setdefault(env_key, "1")
    import matplotlib
    matplotlib.use("Agg")


class AsyncPlotDispatcher:
    """
    平行時空非同步繪圖治理器 (Fire-and-Forget Plotter Pool)：
    讓 BO + FEA 主迴圈只負責把繪圖數據丟進背景佇列並立即返回 (0 秒等待)，
    由獨立的背景行程池負責 Matplotlib 渲染與 PNG 壓縮存檔。
    """

    def __init__(self, max_workers: int = 2):
        self._executor = ProcessPoolExecutor(
            max_workers=max(1, int(max_workers)),
            initializer=_init_plot_worker,
        )
        self._futures = []

    def _prune_done_futures(self):
        if len(self._futures) > 32:
            self._futures = [f for f in self._futures if not f.done()]

    def submit_geometry(
        self,
        geo: dict,
        cand_res: dict,
        episode_idx: int,
        samp_label,
        dy_score: float,
        best_dy: float,
        focus_center,
        active_pts,
        out_png_path: str,
        dpi: int = 100,
        try_cnts: list = None,
    ):
        self._prune_done_futures()
        fut = self._executor.submit(
            render_white_geometry_png,
            geo,
            cand_res,
            int(episode_idx),
            samp_label,
            float(dy_score),
            float(best_dy),
            None if focus_center is None else np.asarray(focus_center, dtype=float).copy(),
            None if active_pts is None else np.asarray(active_pts, dtype=float).copy(),
            str(out_png_path),
            int(dpi),
            None if try_cnts is None else [np.asarray(p, dtype=float).copy() for p in try_cnts],
        )
        self._futures.append(fut)

    def submit_stress(
        self,
        mesh: dict,
        fea: dict,
        episode_idx: int,
        samp_label,
        dy_score: float,
        best_dy: float,
        out_png_path: str,
        dpi: int = 100,
    ):
        self._prune_done_futures()
        fut = self._executor.submit(
            render_white_stress_png,
            mesh,
            fea,
            int(episode_idx),
            samp_label,
            float(dy_score),
            float(best_dy),
            str(out_png_path),
            int(dpi),
        )
        self._futures.append(fut)

    def submit_bo_trace(self, trace_records: list, episode_idx: int, out_png_path: str, dpi: int = 100):
        self._prune_done_futures()
        fut = self._executor.submit(
            render_episode_bo_trace_png,
            list(trace_records),
            int(episode_idx),
            str(out_png_path),
            int(dpi),
        )
        self._futures.append(fut)

    def submit_global_convergence(self, global_history: list, out_png_path: str, dpi: int = 100):
        self._prune_done_futures()
        fut = self._executor.submit(
            render_global_convergence_png,
            list(global_history),
            str(out_png_path),
            int(dpi),
        )
        self._futures.append(fut)

    def close_and_wait(self):
        """在整個程式結束前呼叫，確保背景尚未畫完的圖片全部落盤。"""
        pending = sum(1 for f in self._futures if not f.done())
        if pending > 0:
            print(f"[平行繪圖池] 等待背景剩餘 {pending} 張圖片完成寫入...")
        for f in self._futures:
            try:
                f.result()
            except Exception as exc:
                print(f"[平行繪圖警告] 背景繪圖發生例外: {exc}")
        self._executor.shutdown(wait=True)


def optimize_focus_region_bo(
    gen: Random6PtCntGenerator,
    src_doc,
    cnt_list: list,
    focus_center: np.ndarray,
    active_map: list,
    x_init: np.ndarray,
    current_best_eval: dict,
    episode_idx: int,
    hp: BOHyperParams,
    mesh_hp: MeshHyperParams,
    solver_hp: SolverHyperParams,
    rng: np.random.Generator,
    dirs: dict,
    executor,
    plot_dispatcher,
    t_start: float,
    try_cnts: list = None,
) -> tuple:
    dim = len(x_init)
    m_pts = dim // 2

    auto_pts = np.vstack(gen.geo["auto_loops"]) if gen.geo["auto_loops"] else gen.geo["unified_blank"]
    gx_min, gy_min = auto_pts.min(axis=0)
    gx_max, gy_max = auto_pts.max(axis=0)
    global_lb = np.tile([gx_min, gy_min], m_pts)
    global_ub = np.tile([gx_max, gy_max], m_pts)

    max_span = float(max(gx_max - gx_min, gy_max - gy_min))
    # 視窗 [x_center - step_size, x_center + step_size] 的總移動範圍寬度 = initial_step_ratio * max_span (80%)
    step_size = 0.5 * float(hp.initial_step_ratio) * max_span

    x_best = clamp_vec_to_auto_band(gen, np.asarray(x_init, dtype=float).reshape(dim))
    best_cnt_list = [np.asarray(p, dtype=float).copy() for p in cnt_list]
    best_eval = current_best_eval
    y_best = float(best_eval["dy_score"])

    x_pool = [x_best.copy()]
    y_pool = [y_best]

    no_improve_count = 0
    valid_sample_idx = 0
    trace_records = []

    while step_size >= hp.min_step_tol_mm and valid_sample_idx < hp.max_valid_evals_per_episode:
        x_center = np.clip(x_best, global_lb, global_ub)
        lb = np.maximum(global_lb, x_center - step_size)
        ub = np.minimum(global_ub, x_center + step_size)

        cur_batch = max(1, int(hp.batch_size))

        if len(x_pool) < hp.n_warmup_per_stage:
            x_props = [clamp_vec_to_auto_band(gen, rng.uniform(lb, ub)) for _ in range(cur_batch)]
        else:
            raw_props = propose_batch_nd_points(
                gen,
                np.asarray(x_pool, dtype=float), np.asarray(y_pool, dtype=float),
                lb, ub, cur_batch, rng, xi=hp.acq_xi, n_restarts=hp.gp_restarts,
            )
            x_props = [clamp_vec_to_auto_band(gen, p) for p in raw_props]

        seeds = rng.integers(1, 2 ** 31 - 1, size=cur_batch)
        tasks = [
            (best_cnt_list, active_map, x_props[i], x_best, lb, ub, step_size,
             hp.max_try012_retries, int(seeds[i]))
            for i in range(cur_batch)
        ]
        batch_results = list(executor.map(_worker_eval_candidate_task, tasks))

        valid_batch = [r for r in batch_results if r.get("is_valid") and r.get("x_morphed") is not None]
        if not valid_batch:
            step_size /= hp.shrink_factor
            no_improve_count = 0
            x_pool = [x_best.copy()]
            y_pool = [y_best]
            continue

        for eval_res in valid_batch:
            valid_sample_idx += 1
            x_morphed = np.asarray(eval_res["x_morphed"], dtype=float).reshape(dim)
            y_cand = float(eval_res["dy_score"])
            is_over_stress = bool(eval_res.get("is_over_stress", False))

            # 無論是否超應力，皆放進 GP 池，讓 GP 模型從大額扣分中學習「薄壁應力過高不可去」
            x_pool.append(x_morphed.copy())
            y_pool.append(y_cand)

            shrunk_now = False
            # 只有「未超過 80% 材料強度」且「分數實質提升」的樣本，才可更新為最佳解
            if (not is_over_stress) and (y_cand > y_best + hp.improve_tol_mm):
                y_best = y_cand
                x_best = x_morphed.copy()
                best_eval = eval_res
                best_cnt_list = [np.asarray(p, dtype=float).copy() for p in eval_res["aligned_cnts"]]
                no_improve_count = 0
            else:
                no_improve_count += 1

            if no_improve_count >= hp.patience:
                step_size /= hp.shrink_factor
                no_improve_count = 0
                shrunk_now = True
                x_pool = [x_best.copy()]
                y_pool = [y_best]

            elapsed_s = time.perf_counter() - t_start
            trace_records.append((valid_sample_idx, y_cand, y_best, step_size, elapsed_s, shrunk_now))

            if valid_sample_idx % max(1, hp.save_every_n_samples) == 0:
                stem = f"ep{episode_idx:03d}_samp{valid_sample_idx:04d}_dy{y_cand:+.4f}"
                active_pts = [eval_res["aligned_cnts"][p_i][v_i] for p_i, v_i in active_map]
                plot_dispatcher.submit_geometry(
                    gen.geo, eval_res["cand_res"], episode_idx, valid_sample_idx, y_cand, y_best,
                    focus_center, active_pts, os.path.join(dirs["geo"], f"{stem}.png"), dpi=hp.dpi,
                    try_cnts=try_cnts,
                )
                plot_dispatcher.submit_stress(
                    eval_res["mesh"], eval_res["fea"], episode_idx, valid_sample_idx, y_cand, y_best,
                    os.path.join(dirs["stress"], f"{stem}.png"), dpi=hp.dpi,
                )

            if shrunk_now or step_size < hp.min_step_tol_mm or valid_sample_idx >= hp.max_valid_evals_per_episode:
                break

    return best_cnt_list, best_eval, trace_records


def _draw_bcs_white(ax, geo: dict):
    for fc in geo["fixed_circles"]:
        cx, cy = fc["center"]
        r = fc["radius"]
        th = np.linspace(0.0, 2.0 * math.pi, 49)
        ax.plot(cx + r * np.cos(th), cy + r * np.sin(th), color="#0284c7", lw=1.3, zorder=9)
    for seg_pts, lay in geo["disp_segs"]:
        ax.plot(seg_pts[:, 0], seg_pts[:, 1], color="#be123c", lw=2.4, zorder=10)
    for pc in geo["probe_circles"]:
        cx, cy = pc["center"]
        ax.plot([cx], [cy], marker="+", ms=10, mew=2.0, color="#15803d", zorder=11)


def render_white_geometry_png(
    geo: dict,
    cand_res: dict,
    episode_idx: int,
    samp_label,
    dy_score: float,
    best_dy: float,
    focus_center,
    active_pts,
    out_png_path: str,
    dpi: int = 135,
    try_cnts: list = None,
):
    fig, ax = plt.subplots(figsize=(10.5, 6.0))
    fig.patch.set_facecolor("#ffffff")
    ax.set_facecolor("#ffffff")

    blank = geo["unified_blank"]
    xmin, ymin = blank.min(axis=0) - 5.0
    xmax, ymax = blank.max(axis=0) + 5.0

    if len(geo["outer_0"]) >= 3:
        c0 = np.vstack([geo["outer_0"], geo["outer_0"][0]])
        ax.plot(c0[:, 0], c0[:, 1], color="#94a3b8", lw=0.9, ls="--", zorder=1, label="Layer 0 (Preset)")
    for h0 in geo["holes_0"]:
        ch0 = np.vstack([h0, h0[0]])
        ax.plot(ch0[:, 0], ch0[:, 1], color="#94a3b8", lw=0.9, ls="--", zorder=1)
    for i, alp in enumerate(geo["auto_loops"]):
        ca = np.vstack([alp, alp[0]])
        ax.plot(ca[:, 0], ca[:, 1], color="#38bdf8", lw=1.0, ls=":", zorder=2, label="Layer AUTO" if i == 0 else None)

    if cand_res["filleted_outers"]:
        ax.add_collection(PolyCollection(
            cand_res["filleted_outers"], facecolors="#e2e8f0", edgecolors="none", zorder=3,
        ))
    if cand_res["filleted_holes"]:
        ax.add_collection(PolyCollection(
            cand_res["filleted_holes"], facecolors="#ffffff", edgecolors="none", zorder=4,
        ))

    loops = list(cand_res["filleted_outers"]) + list(cand_res["filleted_holes"])
    for i, lp in enumerate(loops):
        c = np.vstack([lp, lp[0]])
        ax.plot(c[:, 0], c[:, 1], color="#0f172a", lw=1.6, zorder=6, label="Filleted Contour (Mesh-Ready)" if i == 0 else None)

    for i, cp in enumerate(cand_res["accepted_cnts"]):
        cc = np.vstack([cp, cp[0]])
        ax.plot(cc[:, 0], cc[:, 1], color="#ea580c", lw=1.0, ls="--", zorder=7, label="Morphed 6-Pt CNT" if i == 0 else None)
        ax.scatter(cp[:, 0], cp[:, 1], s=9, c="#ea580c", zorder=8)
        ax.text(
            cp[:, 0].mean(), cp[:, 1].mean(), f"C{i + 1}",
            color="#9a3412", fontsize=7.0, fontweight="bold", ha="center", va="center", zorder=9,
        )

    for i, tlp in enumerate(try_cnts or []):
        tc = np.vstack([tlp, tlp[0]])
        ax.plot(tc[:, 0], tc[:, 1], color="#10b981", lw=1.1, ls=":", zorder=5,
                label="Layer TRY (Engineer Seed)" if i == 0 else None)

    inner_arcs = [a for a in cand_res["fillet_arcs"] if a["kind"] == "inner"]
    outer_arcs = [a for a in cand_res["fillet_arcs"] if a["kind"] == "outer"]
    for i, arc in enumerate(inner_arcs):
        ap = arc["arc_pts"]
        ax.plot(ap[:, 0], ap[:, 1], color="#db2777", lw=2.6, zorder=10,
                label=f"Inner Fillets ({len(inner_arcs)})" if i == 0 else None)
    for i, arc in enumerate(outer_arcs):
        ap = arc["arc_pts"]
        ax.plot(ap[:, 0], ap[:, 1], color="#b45309", lw=2.6, zorder=10,
                label=f"Outer Fillets ({len(outer_arcs)})" if i == 0 else None)

    fx, fy = None, None
    if focus_center is not None:
        fx, fy = float(focus_center[0]), float(focus_center[1])
        ax.scatter([fx], [fy], marker="*", s=170, c="#7c3aed", edgecolors="#ffffff",
                   linewidths=0.8, zorder=13, label="Focus Center C")
    if active_pts is not None and len(active_pts) > 0:
        act_arr = np.asarray(active_pts, dtype=float)
        if fx is not None:
            for pt in act_arr:
                ax.plot([fx, pt[0]], [fy, pt[1]], color="#7c3aed", lw=0.8, ls=":", alpha=0.65, zorder=11)
        ax.scatter(act_arr[:, 0], act_arr[:, 1], s=42, facecolors="none", edgecolors="#7c3aed",
                   linewidths=1.8, zorder=13, label=f"Active Vertices (M={len(act_arr)})")

    _draw_bcs_white(ax, geo)
    ax.set_xlim(xmin, xmax)
    ax.set_ylim(ymin, ymax)
    ax.set_aspect("equal", adjustable="box")
    ax.tick_params(colors="#334155", labelsize=7)
    for spine in ax.spines.values():
        spine.set_edgecolor("#94a3b8")
    ax.set_title(
        f"[Episode {episode_idx:03d} | Sample {samp_label}]  "
        f"Score (PROBE +dy) = {dy_score:+.4f} mm (Best: {best_dy:+.4f} mm)  |  "
        f"CNTs: {len(cand_res['accepted_cnts'])} | Loops: {len(loops)}",
        color="#0f172a", fontsize=9.5, fontweight="bold", pad=10,
    )
    ax.legend(loc="upper left", facecolor="#f8fafc", edgecolor="#cbd5e1", labelcolor="#0f172a", fontsize=7.0)
    fig.tight_layout()
    fig.savefig(out_png_path, dpi=dpi, facecolor="#ffffff")
    plt.close(fig)


def render_white_stress_png(
    mesh: dict,
    fea: dict,
    episode_idx: int,
    samp_label,
    dy_score: float,
    best_dy: float,
    out_png_path: str,
    dpi: int = 135,
):
    fig, ax = plt.subplots(figsize=(10.5, 6.8))
    FeaVisualizer.plot_fea_on_ax(fea, mesh, ax=ax, mode="Von Mises 應力", show_undeformed=True)

    fig.patch.set_facecolor("#ffffff")
    ax.set_facecolor("#ffffff")
    ax.tick_params(colors="#1e293b", labelsize=8)
    for spine in ax.spines.values():
        spine.set_edgecolor("#94a3b8")

    cbar = getattr(ax, "_fea_cbar", None)
    if cbar is not None:
        cbar.set_label("Von Mises Stress (MPa)", color="#0f172a", fontsize=8.5)
        cbar.ax.tick_params(colors="#0f172a", labelsize=7.5)

    for txt in ax.texts:
        txt.set_color("#0f172a")
        bbox = txt.get_bbox_patch()
        if bbox is not None:
            bbox.set_facecolor("#f8fafc")
            bbox.set_edgecolor("#475569")

    vm_max = float(fea.get("max_von_mises", 0.0))
    sf = float(fea.get("safety_factor", 0.0))
    ax.set_title(
        f"[Episode {episode_idx:03d} | Sample {samp_label}]  "
        f"Score (PROBE +dy) = {dy_score:+.4f} mm (Best: {best_dy:+.4f} mm)  |  "
        f"Max VM = {vm_max:.1f} MPa (SF={sf:.2f})",
        color="#0f172a", fontsize=9.5, fontweight="bold", pad=10,
    )
    fig.tight_layout()
    fig.savefig(out_png_path, dpi=dpi, facecolor="#ffffff")
    plt.close(fig)


def render_episode_bo_trace_png(
    trace_records: list,
    episode_idx: int,
    out_png_path: str,
    dpi: int = 135,
):
    fig, ax = plt.subplots(figsize=(10.0, 5.6))
    fig.patch.set_facecolor("#ffffff")
    ax.set_facecolor("#ffffff")
    ax.tick_params(colors="#334155", labelsize=7.5)
    for spine in ax.spines.values():
        spine.set_edgecolor("#94a3b8")

    if not trace_records:
        ax.set_title(
            f"Focus Episode BO Progress [Episode {episode_idx:03d}]  (NO VALID SAMPLE)",
            color="#0f172a", fontsize=9.5, fontweight="bold",
        )
        fig.savefig(out_png_path, dpi=dpi, facecolor="#ffffff")
        plt.close(fig)
        return

    xs = np.array([r[0] for r in trace_records], dtype=float)
    y_cand = np.array([r[1] for r in trace_records], dtype=float)
    y_best = np.array([r[2] for r in trace_records], dtype=float)
    steps = np.array([r[3] for r in trace_records], dtype=float)
    shrink_x = [r[0] for r in trace_records if r[5]]

    ax.plot(xs, y_cand, marker="o", ms=3.2, lw=0.9, color="#2563eb", label="Sample PROBE +dy (mm)")
    ax.step(xs, y_best, where="post", lw=1.8, color="#16a34a", label="Best PROBE +dy (mm)")
    for sx in shrink_x:
        ax.axvline(sx, color="#dc2626", lw=0.9, ls="--")
    if shrink_x:
        ax.plot([], [], color="#dc2626", lw=0.9, ls="--", label=f"Step Shrink ({len(shrink_x)})")

    ax2 = ax.twinx()
    ax2.plot(xs, steps, lw=1.0, color="#94a3b8", ls=":", label="Step size (mm)")
    ax2.set_ylabel("Step size (mm)", color="#475569", fontsize=8.5)
    ax2.tick_params(colors="#475569", labelsize=7.5)
    for spine in ax2.spines.values():
        spine.set_edgecolor("#cbd5e1")

    ax.set_xlabel("Valid FEA Sample Index", color="#334155", fontsize=8.5)
    ax.set_ylabel("PROBE +dy (mm)", color="#334155", fontsize=8.5)
    ax.set_title(
        f"Focus Episode BO Progress [Episode {episode_idx:03d}]  "
        f"samples={len(trace_records)}  best={float(y_best[-1]):+.4f} mm  final step={float(steps[-1]):.3f} mm",
        color="#0f172a", fontsize=9.5, fontweight="bold", pad=10,
    )
    handles1, labels1 = ax.get_legend_handles_labels()
    handles2, labels2 = ax2.get_legend_handles_labels()
    ax.legend(handles1 + handles2, labels1 + labels2, loc="lower right",
              facecolor="#f8fafc", edgecolor="#cbd5e1", labelcolor="#0f172a", fontsize=7.5)
    fig.tight_layout()
    fig.savefig(out_png_path, dpi=dpi, facecolor="#ffffff")
    plt.close(fig)


def render_global_convergence_png(global_history: list, out_png_path: str, dpi: int = 135):
    fig, ax = plt.subplots(figsize=(10.5, 5.6))
    fig.patch.set_facecolor("#ffffff")
    ax.set_facecolor("#ffffff")
    ax.tick_params(colors="#334155", labelsize=7.5)
    for spine in ax.spines.values():
        spine.set_edgecolor("#94a3b8")

    if not global_history:
        fig.savefig(out_png_path, dpi=dpi, facecolor="#ffffff")
        plt.close(fig)
        return

    tt = np.array([h[0] for h in global_history], dtype=float)
    yy = np.array([h[1] for h in global_history], dtype=float)

    ax.plot(tt, yy, color="#0f172a", lw=1.4, marker="o", ms=4.0, zorder=3)
    ax.fill_between(tt, yy, yy.min() - 0.05 * max(abs(yy.min()), 1e-6), color="#e2e8f0", alpha=0.6, zorder=2)
    for t_i, y_i, lab in global_history:
        ax.annotate(lab, xy=(t_i, y_i), xytext=(4, 6), textcoords="offset points",
                    fontsize=6.5, color="#334155", zorder=4)

    ax.set_xlabel("Elapsed time (s)", color="#334155", fontsize=8.5)
    ax.set_ylabel("Best PROBE +dy (mm)", color="#334155", fontsize=8.5)
    ax.set_title(
        f"Global Convergence [elapsed {tt[-1]:.1f} s | nodes {len(global_history)}]  "
        f"best={float(yy.max()):+.4f} mm",
        color="#0f172a", fontsize=9.5, fontweight="bold", pad=10,
    )
    ax.grid(True, color="#e2e8f0", lw=0.7, ls="-")
    fig.tight_layout()
    fig.savefig(out_png_path, dpi=dpi, facecolor="#ffffff")
    plt.close(fig)


def main():
    hp = BOHyperParams()
    mesh_hp = MeshHyperParams()
    solver_hp = SolverHyperParams()

    run_dir = os.path.join(hp.output_root, datetime.now().strftime("%Y%m%d_%H%M%S"))
    dirs = {
        "geo": os.path.join(run_dir, "01_geometry_samples"),
        "bo": os.path.join(run_dir, "02_bo_knife_progress"),
        "global": os.path.join(run_dir, "03_global_convergence"),
        "stress": os.path.join(run_dir, "04_fea_stress_samples"),
    }
    for p in dirs.values():
        os.makedirs(p, exist_ok=True)

    dxf_in = os.path.join(ROOT_DIR, "part01.dxf")
    src_doc = ezdxf.readfile(dxf_in)
    user_try_cnts = extract_and_strip_try_layer_cnts(
        src_doc,
        try_layer_name=hp.try_layer_name,
        num_pts_fallback=hp.num_pts_per_cnt,
        max_vertices_keep=hp.try_max_vertices_keep,
    )
    if user_try_cnts:
        print(f"[TRY 圖層] 偵測到 {len(user_try_cnts)} 個工程師手繪初始孔洞 (mode={hp.try_layer_mode})")
    gen = Random6PtCntGenerator(
        src_doc,
        min_hinge_mm=float(hp.geom_merge_and_snap_mm),
        d_snap_outer_mm=float(hp.geom_merge_and_snap_mm),
        d_over_outer_mm=1.05,
        d_merge_cnt_mm=float(hp.geom_merge_and_snap_mm),
        d_merge_depth_mm=0.55,
        raster_pitch_mm=0.30,
    )
    rng = np.random.default_rng(seed=42)
    t_start = time.perf_counter()
    global_history = []

    uniform_auto_pts = build_uniform_auto_grid(gen, hp.focus_grid_pitch_mm)
    print(f"[輸出] {run_dir}")
    print(f"[AUTO 均勻網格] 焦點候選點 {len(uniform_auto_pts)} 個 (pitch={hp.focus_grid_pitch_mm} mm)")
    print(f"[多工] workers={hp.n_workers} | batch_size={hp.batch_size}")

    cnt_list = place_initial_cnts(gen, hp, rng, user_try_cnts=user_try_cnts)
    eval_res = None
    while cnt_list:
        eval_res = evaluate_cnt_batch_with_try012_and_fea(
            gen, src_doc, cnt_list, mesh_hp, solver_hp, bo_hp=hp
        )
        if eval_res["is_valid"]:
            cnt_list = [np.asarray(p, dtype=float).copy() for p in eval_res["morphed_cnts"]]
            break
        cnt_list = cnt_list[:-1]
    if not cnt_list:
        print("[錯誤] 初始均勻孔洞全部未通過 try012 / FEA 檢查")
        return

    best_dy = float(eval_res["dy_score"])
    elapsed_s = time.perf_counter() - t_start
    plot_dispatcher = AsyncPlotDispatcher(max_workers=hp.n_plot_workers)
    global_history.append((elapsed_s, best_dy, "INIT"))
    plot_dispatcher.submit_global_convergence(
        global_history, os.path.join(dirs["global"], "global_convergence.png"), dpi=hp.dpi,
    )
    print(f"[初始化] cnts={len(cnt_list)} | PROBE +dy={best_dy:+.4f} mm"
          f" | MaxVM={float(eval_res.get('vm_max', 0.0)):.1f} MPa"
          f"{' (超標已懲罰)' if eval_res.get('is_over_stress') else ''} | {elapsed_s:.1f}s")

    with ProcessPoolExecutor(
        max_workers=hp.n_workers,
        initializer=_init_fea_worker,
        initargs=(dxf_in, mesh_hp, solver_hp, hp),
    ) as executor:
        for ep in range(1, int(hp.max_episodes) + 1):
            prev_n = len(cnt_list)
            cnt_list, eval_res = prune_and_snap_redundant_cnts(
                gen, src_doc, cnt_list, eval_res, hp, mesh_hp, solver_hp
            )
            if len(cnt_list) < prev_n:
                best_dy = float(eval_res["dy_score"])
                print(f"[修剪] Episode {ep:03d} 剔除冗餘包圍孔洞: {prev_n} -> {len(cnt_list)} 洞 | PROBE +dy={best_dy:+.4f} mm")

            n_add = int(hp.add_cnt_at_episodes.get(ep, 0))
            for _ in range(n_add):
                added = add_one_cnt(gen, src_doc, cnt_list, hp, rng, mesh_hp, solver_hp)
                if added is None:
                    print(f"[加洞] Episode {ep:03d} 找不到可放置空間，跳過")
                    break
                cnt_list, eval_res = added
                best_dy = float(eval_res["dy_score"])
                elapsed_s = time.perf_counter() - t_start
                global_history.append((elapsed_s, best_dy, f"E{ep}-ADD{len(cnt_list)}"))
                print(f"[加洞] Episode {ep:03d} -> cnts={len(cnt_list)} | PROBE +dy={best_dy:+.4f} mm")

            focus_center = uniform_auto_pts[int(rng.integers(0, len(uniform_auto_pts)))]
            active_map, x_init = select_k_nearest_vertices(
                cnt_list, eval_res["cand_res"], focus_center,
                hp.k_nearest_vertices, hp.active_boundary_tol_mm,
            )
            if not active_map:
                continue

            init_dy = float(eval_res["dy_score"])
            init_pts = [cnt_list[p_i][v_i] for p_i, v_i in active_map]
            init_stem = f"ep{ep:03d}_INIT_dy{init_dy:+.4f}"
            plot_dispatcher.submit_geometry(
                gen.geo, eval_res["cand_res"], ep, "INIT", init_dy, best_dy,
                focus_center, init_pts, os.path.join(dirs["geo"], f"{init_stem}.png"), dpi=hp.dpi,
                try_cnts=user_try_cnts,
            )
            plot_dispatcher.submit_stress(
                eval_res["mesh"], eval_res["fea"], ep, "INIT", init_dy, best_dy,
                os.path.join(dirs["stress"], f"{init_stem}.png"), dpi=hp.dpi,
            )

            cnt_list, eval_res, trace_records = optimize_focus_region_bo(
                gen, src_doc, cnt_list, focus_center, active_map, x_init, eval_res, ep,
                hp, mesh_hp, solver_hp, rng, dirs, executor, plot_dispatcher, t_start,
                try_cnts=user_try_cnts,
            )
            best_dy = float(eval_res["dy_score"])
            elapsed_s = time.perf_counter() - t_start

            active_pts = [cnt_list[p_i][v_i] for p_i, v_i in active_map]
            stem = f"ep{ep:03d}_FINAL_dy{best_dy:+.4f}"
            plot_dispatcher.submit_geometry(
                gen.geo, eval_res["cand_res"], ep, "FINAL", best_dy, best_dy,
                focus_center, active_pts, os.path.join(dirs["geo"], f"{stem}.png"), dpi=hp.dpi,
                try_cnts=user_try_cnts,
            )
            plot_dispatcher.submit_stress(
                eval_res["mesh"], eval_res["fea"], ep, "FINAL", best_dy, best_dy,
                os.path.join(dirs["stress"], f"{stem}.png"), dpi=hp.dpi,
            )
            plot_dispatcher.submit_bo_trace(
                trace_records, ep, os.path.join(dirs["bo"], f"ep{ep:03d}_bo_trace.png"), dpi=hp.dpi,
            )

            global_history.append((elapsed_s, best_dy, f"E{ep}"))
            plot_dispatcher.submit_global_convergence(
                global_history, os.path.join(dirs["global"], "global_convergence.png"), dpi=hp.dpi,
            )
            print(
                f"[Episode {ep:03d}] focus=({focus_center[0]:.2f}, {focus_center[1]:.2f}) M={len(active_map)} | "
                f"samples={len(trace_records)} | PROBE +dy={best_dy:+.4f} mm | {elapsed_s:.1f}s"
            )

    plot_dispatcher.close_and_wait()
    render_global_convergence_png(global_history, os.path.join(dirs["global"], "global_convergence.png"), dpi=hp.dpi)
    print(f"[完成] 全域最佳 PROBE +dy={best_dy:+.4f} mm | 總耗時 {time.perf_counter() - t_start:.1f}s | {run_dir}")


if __name__ == "__main__":
    main()
