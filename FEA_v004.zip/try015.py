#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""try015.py — 獨立 DXF 互動編輯器（matplotlib 原生視窗，不依賴 Tkinter 多頁籤架構）。"""

import math
import os
import re
import sys
from dataclasses import dataclass, field

import matplotlib

try:
    matplotlib.use("TkAgg")
except Exception:
    pass

import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
import numpy as np
import ezdxf

DEFAULT_BRUSH_STYLES = [
    {"name": "0",              "colors": "#ffffff", "linewidths": 1.3, "linestyles": "solid", "zorder": 4, "dxf_color": 7},
    {"name": "FIXED",          "colors": "#00bfff", "linewidths": 2.2, "linestyles": "solid", "zorder": 5, "dxf_color": 5},
    {"name": "AUTO",           "colors": "#00e5ff", "linewidths": 1.8, "linestyles": "dashed", "zorder": 4, "dxf_color": 4},
    {"name": "TRY",            "colors": "#d946ef", "linewidths": 2.0, "linestyles": "solid", "zorder": 7, "dxf_color": 6},
    {"name": "PROBE",          "colors": "#00ff88", "linewidths": 2.2, "linestyles": "solid", "zorder": 5, "dxf_color": 3},
    {"name": "DISP_X-100Y10",  "colors": "#ff3355", "linewidths": 2.2, "linestyles": "solid", "zorder": 6, "dxf_color": 1},
    {"name": "FORCE_X-100Y10", "colors": "#ffaa00", "linewidths": 2.2, "linestyles": "solid", "zorder": 6, "dxf_color": 2},
]

BC_COLOR_DISP = "#ff3355"
BC_COLOR_FORCE = "#ffaa00"
BC_COLOR_PROBE = "#00ff88"
BC_COLOR_FIXED = "#00bfff"
BC_COLOR_AUTO = "#00e5ff"
BC_COLOR_DEFAULT = "#cccccc"
TRY_PALETTE = ["#d946ef", "#a855f7", "#ec4899", "#f43f5e", "#8b5cf6", "#06b6d4"]


class DXFEditingHelper:
    PROBE_RE = re.compile(r"^PROBE(?:#|_)?(\d+)?$")
    VECTOR_RE = re.compile(r"^(DISP|FORCE)(?:#(\d+))?_X([+-]?\d+(?:\.\d+)?)Y([+-]?\d+(?:\.\d+)?)$")
    TRY_RE = re.compile(r"^TRY(?:#|_)?(\d+)?$")

    # ---------------------------------------------------------------- BC 圖層
    @staticmethod
    def format_bc_layer_name(bc_type: str, x: float = 0.0, y: float = 0.0, seq: int = None) -> str:
        btype = str(bc_type).strip().upper()
        if btype == "FIXED":
            return "FIXED"
        if btype == "PROBE":
            return f"PROBE#{int(seq):03d}" if seq is not None else "PROBE"
        if btype not in ("DISP", "FORCE"):
            raise ValueError(f"bc_type 必須為 'FIXED', 'PROBE', 'DISP' 或 'FORCE'，收到: {bc_type}")
        x_s = f"{int(x)}" if float(x).is_integer() else f"{float(x):g}"
        y_s = f"{int(y)}" if float(y).is_integer() else f"{float(y):g}"
        prefix = f"{btype}#{int(seq):03d}" if seq is not None else btype
        return f"{prefix}_X{x_s}Y{y_s}"

    @staticmethod
    def parse_bc_layer_name(layer_name: str) -> dict:
        lname = str(layer_name).strip()
        u_name = lname.upper()
        if lname == "0":
            return {"type": "FREE", "x": 0.0, "y": 0.0, "unit": None}
        if u_name == "FIXED":
            return {"type": "FIXED", "x": 0.0, "y": 0.0, "unit": "mm"}
        if u_name in ("AUTO", "SEARCH_ZONE"):
            return {"type": "AUTO", "x": 0.0, "y": 0.0, "unit": None, "raw": lname}
        m_probe = DXFEditingHelper.PROBE_RE.match(u_name)
        if m_probe:
            idx = int(m_probe.group(1)) if m_probe.group(1) else 1
            return {
                "type": "PROBE",
                "probe_id": f"PROBE#{idx:03d}",
                "x": 0.0,
                "y": 0.0,
                "unit": "mm",
                "raw": lname,
            }
        if u_name == "TRY" or DXFEditingHelper.TRY_RE.match(u_name):
            return {"type": "TRY", "seq": 1, "try_id": "TRY", "x": 0.0, "y": 0.0, "raw": "TRY"}
        m = DXFEditingHelper.VECTOR_RE.match(u_name)
        if m:
            btype, seq_str, xs, ys = m.groups()
            seq = int(seq_str) if seq_str else None
            return {
                "type": btype,
                "seq": seq,
                "bc_id": f"{btype}#{seq:03d}" if seq is not None else btype,
                "x": float(xs),
                "y": float(ys),
                "unit": "mm" if btype == "DISP" else "gf",
            }
        return {"type": "CUSTOM", "x": 0.0, "y": 0.0, "unit": None, "raw": lname}

    @staticmethod
    def layer_priority(layer_name: str) -> int:
        info = DXFEditingHelper.parse_bc_layer_name(layer_name)
        btype = info.get("type")
        if btype == "FREE":
            return 0
        if btype == "FIXED":
            return 10
        if btype == "AUTO":
            return 5
        if btype == "PROBE":
            return 15
        if btype in ("DISP", "FORCE"):
            return 20
        return 1

    @staticmethod
    def get_layer_style(layer_name: str) -> dict:
        u_name = str(layer_name).upper()
        style = DXFEditingHelper.parse_bc_layer_name(layer_name)
        btype = style.get("type")
        if btype in ("DISP", "FORCE"):
            return {
                "colors": BC_COLOR_DISP if btype == "DISP" else BC_COLOR_FORCE,
                "linewidths": 2.2,
                "linestyles": "solid",
                "zorder": 6,
                "dxf_color": 1 if btype == "DISP" else 2,
            }
        if btype == "AUTO":
            return {"colors": BC_COLOR_AUTO, "linewidths": 1.8, "linestyles": "dashed", "zorder": 4, "dxf_color": 4}
        if btype == "PROBE":
            return {"colors": BC_COLOR_PROBE, "linewidths": 2.2, "linestyles": "solid", "zorder": 5, "dxf_color": 3}
        if btype == "FIXED":
            return {"colors": BC_COLOR_FIXED, "linewidths": 2.2, "linestyles": "solid", "zorder": 5, "dxf_color": 5}
        if btype == "TRY":
            seq = int(style.get("seq", 1))
            return {
                "colors": TRY_PALETTE[(seq - 1) % len(TRY_PALETTE)],
                "linewidths": 1.8,
                "linestyles": "dashed",
                "zorder": 7,
                "dxf_color": 6,
            }
        if u_name == "0":
            return {"colors": "#ffffff", "linewidths": 1.3, "linestyles": "solid", "zorder": 4, "dxf_color": 7}
        return {"colors": BC_COLOR_DEFAULT, "linewidths": 1.2, "linestyles": "solid", "zorder": 3, "dxf_color": 7}

    @staticmethod
    def get_layer_color(layer_name: str) -> str:
        return DXFEditingHelper.get_layer_style(layer_name)["colors"]

    @staticmethod
    def get_bc_summary(msp) -> dict:
        summary = {}
        for ent in msp:
            lay = ent.dxf.layer if ent.dxf.hasattr("layer") else "0"
            if lay not in summary:
                info = DXFEditingHelper.parse_bc_layer_name(lay)
                info["count"] = 0
                info["handles"] = []
                summary[lay] = info
            summary[lay]["count"] += 1
            summary[lay]["handles"].append(ent.dxf.handle)
        return summary

    # ---------------------------------------------------------------- DXF IO
    @staticmethod
    def load_doc(filepath: str):
        return ezdxf.readfile(filepath)

    @staticmethod
    def explode_all_lwpolylines(msp) -> int:
        count = 0
        for pl in [e for e in msp if e.dxftype() == "LWPOLYLINE"]:
            lay = pl.dxf.layer if pl.dxf.hasattr("layer") else "0"
            if DXFEditingHelper.TRY_RE.match(str(lay).strip().upper()):
                continue
            try:
                pl.explode(msp)
                count += 1
            except Exception:
                pass
        return count

    @staticmethod
    def ensure_layer(doc, layer: str, color: int = 7) -> str:
        if doc is not None and layer not in doc.layers:
            doc.layers.add(name=layer, color=color)
        return layer

    @staticmethod
    def next_probe_layer_name(doc) -> str:
        if doc is None:
            return "PROBE#001"
        max_id = 0
        for lay in doc.layers:
            m = re.match(r"^PROBE#(\d+)$", str(lay.dxf.name).upper())
            if m:
                max_id = max(max_id, int(m.group(1)))
        for ent in doc.modelspace():
            m = re.match(r"^PROBE#(\d+)$", str(ent.dxf.layer).upper())
            if m:
                max_id = max(max_id, int(m.group(1)))
        return f"PROBE#{max_id + 1:03d}"

    # ---------------------------------------------------------------- 幾何
    @staticmethod
    def entity_to_segments(ent):
        etype = ent.dxftype()
        if etype == "INSERT":
            segs = []
            try:
                for sub in ent.virtual_entities():
                    segs.extend(DXFEditingHelper.entity_to_segments(sub))
            except Exception:
                pass
            return segs
        if etype == "LINE":
            p1 = (float(ent.dxf.start.x), float(ent.dxf.start.y))
            p2 = (float(ent.dxf.end.x), float(ent.dxf.end.y))
            return [(p1, p2)]
        if etype == "CIRCLE":
            cx, cy = float(ent.dxf.center.x), float(ent.dxf.center.y)
            r = float(ent.dxf.radius)
            angles = np.linspace(0.0, 2.0 * math.pi, 49)
            pts = np.column_stack([cx + r * np.cos(angles), cy + r * np.sin(angles)])
            return list(zip(pts[:-1].tolist(), pts[1:].tolist()))
        if etype == "ARC":
            cx, cy = float(ent.dxf.center.x), float(ent.dxf.center.y)
            r = float(ent.dxf.radius)
            a1 = float(ent.dxf.start_angle)
            a2 = float(ent.dxf.end_angle)
            span = (a2 - a1) % 360.0
            if span <= 1e-6:
                span = 360.0
            steps = max(int(span / 7.5), 6)
            angles = np.radians(a1 + np.linspace(0.0, span, steps + 1))
            pts = np.column_stack([cx + r * np.cos(angles), cy + r * np.sin(angles)])
            return list(zip(pts[:-1].tolist(), pts[1:].tolist()))
        if etype == "LWPOLYLINE":
            segs = []
            try:
                for sub in ent.virtual_entities():
                    segs.extend(DXFEditingHelper.entity_to_segments(sub))
                if segs:
                    return segs
            except Exception:
                pass
            pts = [(float(p[0]), float(p[1])) for p in ent.get_points("xy")]
            if ent.closed and len(pts) > 1:
                pts.append(pts[0])
            return list(zip(pts[:-1], pts[1:]))
        try:
            from ezdxf.path import make_path
            path = make_path(ent)
            pts = [(float(p.x), float(p.y)) for p in path.flattening(0.5)]
            return list(zip(pts[:-1], pts[1:]))
        except Exception:
            return []

    @staticmethod
    def entity_keypoints(ent):
        etype = ent.dxftype()
        kpts = []
        if etype == "LINE":
            x1, y1 = float(ent.dxf.start.x), float(ent.dxf.start.y)
            x2, y2 = float(ent.dxf.end.x), float(ent.dxf.end.y)
            mx, my = (x1 + x2) * 0.5, (y1 + y2) * 0.5
            kpts.append(((x1, y1), "END"))
            kpts.append(((x2, y2), "END"))
            kpts.append(((mx, my), "MID"))
        elif etype == "ARC":
            cx, cy = float(ent.dxf.center.x), float(ent.dxf.center.y)
            r = float(ent.dxf.radius)
            a1 = math.radians(float(ent.dxf.start_angle))
            a2 = math.radians(float(ent.dxf.end_angle))
            p1 = (cx + r * math.cos(a1), cy + r * math.sin(a1))
            p2 = (cx + r * math.cos(a2), cy + r * math.sin(a2))
            kpts.append(((cx, cy), "CEN"))
            kpts.append((p1, "END"))
            kpts.append((p2, "END"))
        elif etype == "CIRCLE":
            cx, cy = float(ent.dxf.center.x), float(ent.dxf.center.y)
            r = float(ent.dxf.radius)
            kpts.append(((cx, cy), "CEN"))
            for dx, dy in ((r, 0.0), (-r, 0.0), (0.0, r), (0.0, -r)):
                kpts.append(((cx + dx, cy + dy), "END"))
        elif etype == "LWPOLYLINE":
            try:
                for sub in ent.virtual_entities():
                    kpts.extend(DXFEditingHelper.entity_keypoints(sub))
            except Exception:
                pass
        return kpts

    @staticmethod
    def circle_from_2_points(p1, p2):
        cx, cy = float(p1[0]), float(p1[1])
        r = math.hypot(p2[0] - cx, p2[1] - cy)
        return (cx, cy), r

    @staticmethod
    def circle_from_3_points(p1, p2, p3):
        ax, ay = p1
        bx, by = p2
        cx, cy = p3
        d = 2.0 * (ax * (by - cy) + bx * (cy - ay) + cx * (ay - by))
        if abs(d) < 1e-9:
            return None, None
        a2 = ax * ax + ay * ay
        b2 = bx * bx + by * by
        c2 = cx * cx + cy * cy
        ux = (a2 * (by - cy) + b2 * (cy - ay) + c2 * (ay - by)) / d
        uy = (a2 * (cx - bx) + b2 * (ax - cx) + c2 * (bx - ax)) / d
        return (ux, uy), math.hypot(ax - ux, ay - uy)

    @classmethod
    def arc_from_3_points(cls, p1, p2, p3):
        cen, r = cls.circle_from_3_points(p1, p2, p3)
        if cen is None or r < 1e-6:
            return None, None, None, None
        cx, cy = cen
        a1 = math.degrees(math.atan2(p1[1] - cy, p1[0] - cx)) % 360.0
        a2 = math.degrees(math.atan2(p2[1] - cy, p2[0] - cx)) % 360.0
        a3 = math.degrees(math.atan2(p3[1] - cy, p3[0] - cx)) % 360.0
        ccw_12 = (a2 - a1) % 360.0
        ccw_13 = (a3 - a1) % 360.0
        if ccw_12 <= ccw_13:
            return cen, r, a1, a3
        return cen, r, a3, a1

    # ---------------------------------------------------------------- 鎖點
    @staticmethod
    def build_segment_arrays(segments_by_handle: dict):
        all_p1, all_p2, seg_handles = [], [], []
        for handle, segs in segments_by_handle.items():
            for p1, p2 in segs:
                all_p1.append(p1)
                all_p2.append(p2)
                seg_handles.append(handle)
        p1_arr = np.array(all_p1, dtype=float) if all_p1 else np.empty((0, 2))
        p2_arr = np.array(all_p2, dtype=float) if all_p2 else np.empty((0, 2))
        v_arr = p2_arr - p1_arr
        c2_arr = np.sum(v_arr * v_arr, axis=1) if len(p1_arr) else np.empty(0)
        return p1_arr, p2_arr, v_arr, c2_arr, seg_handles

    @staticmethod
    def point_to_segments_dist(px: float, py: float, segs):
        arr = np.asarray(segs, dtype=float)
        if arr.size == 0:
            return float("inf"), -1
        p1 = arr[:, 0, :]
        v = arr[:, 1, :] - p1
        c2 = np.sum(v * v, axis=1)
        w = np.array([px, py], dtype=float) - p1
        c1 = np.sum(w * v, axis=1)
        t = np.where(c2 > 1e-12, np.clip(c1 / c2, 0.0, 1.0), 0.0)
        proj = p1 + t[:, None] * v
        dists = np.hypot(proj[:, 0] - px, proj[:, 1] - py)
        idx = int(np.argmin(dists))
        return float(dists[idx]), idx

    @staticmethod
    def compute_hover_and_snap(
        px,
        py,
        p1_arr,
        p2_arr,
        v_arr,
        c2_arr,
        seg_handles,
        snap_pts_arr,
        snap_types,
        pick_tol,
        snap_tol,
    ):
        hover_handle = None
        if len(p1_arr) > 0:
            w = np.array([px, py], dtype=float) - p1_arr
            c1 = np.sum(w * v_arr, axis=1)
            t = np.where(c2_arr > 1e-12, np.clip(c1 / c2_arr, 0.0, 1.0), 0.0)
            proj = p1_arr + t[:, None] * v_arr
            dists = np.hypot(proj[:, 0] - px, proj[:, 1] - py)
            min_idx = int(np.argmin(dists))
            if float(dists[min_idx]) < pick_tol:
                hover_handle = seg_handles[min_idx]
        snap_pt = None
        snap_type = None
        if len(snap_pts_arr) > 0:
            sdists = np.hypot(snap_pts_arr[:, 0] - px, snap_pts_arr[:, 1] - py)
            s_idx = int(np.argmin(sdists))
            if float(sdists[s_idx]) < snap_tol:
                snap_pt = (float(snap_pts_arr[s_idx, 0]), float(snap_pts_arr[s_idx, 1]))
                snap_type = snap_types[s_idx]
        eff_pt = snap_pt if snap_pt is not None else (float(px), float(py))
        return hover_handle, snap_pt, snap_type, eff_pt

    # ---------------------------------------------------------------- msp 操作
    @staticmethod
    def add_line(msp, p1, p2, layer):
        if math.hypot(p2[0] - p1[0], p2[1] - p1[1]) < 1e-6:
            return None
        return msp.add_line(p1, p2, dxfattribs={"layer": layer})

    @staticmethod
    def add_rect_2p(msp, p1, p2, layer):
        x1, y1 = float(p1[0]), float(p1[1])
        x2, y2 = float(p2[0]), float(p2[1])
        if abs(x2 - x1) < 1e-6 or abs(y2 - y1) < 1e-6:
            return None
        xmin, xmax = min(x1, x2), max(x1, x2)
        ymin, ymax = min(y1, y2), max(y1, y2)
        pts = [(xmin, ymin), (xmax, ymin), (xmax, ymax), (xmin, ymax)]
        pl = msp.add_lwpolyline(pts, format="xy", dxfattribs={"layer": layer})
        pl.closed = True
        return pl

    @staticmethod
    def add_circle_2p(msp, p1, p2, layer):
        cen, r = DXFEditingHelper.circle_from_2_points(p1, p2)
        if r < 1e-6:
            return None
        return msp.add_circle(center=cen, radius=r, dxfattribs={"layer": layer})

    @staticmethod
    def add_circle_3p(msp, p1, p2, p3, layer):
        cen, r = DXFEditingHelper.circle_from_3_points(p1, p2, p3)
        if cen is None or r < 1e-6:
            return None
        return msp.add_circle(center=cen, radius=r, dxfattribs={"layer": layer})

    @staticmethod
    def add_arc_3p(msp, p1, p2, p3, layer):
        cen, r, a_start, a_end = DXFEditingHelper.arc_from_3_points(p1, p2, p3)
        if cen is None:
            return None
        return msp.add_arc(
            center=cen, radius=r, start_angle=a_start, end_angle=a_end,
            dxfattribs={"layer": layer},
        )

    @staticmethod
    def find_entity(doc, handle):
        if doc is None or not handle:
            return None
        try:
            return doc.entitydb.get(handle)
        except Exception:
            return None

    @classmethod
    def delete_entity(cls, doc, handle) -> bool:
        ent = cls.find_entity(doc, handle)
        if ent is None:
            return False
        doc.modelspace().delete_entity(ent)
        return True

    @classmethod
    def paint_entity_layer(cls, doc, handle, new_layer) -> bool:
        ent = cls.find_entity(doc, handle)
        if ent is None:
            return False
        ent.dxf.layer = new_layer
        return True


TOOLS = ["line", "rect", "2p-circle", "3p-circle", "3p-arc", "paint"]
TOOL_NEED = {"line": 2, "rect": 2, "2p-circle": 2, "3p-circle": 3, "3p-arc": 3, "paint": 1}


@dataclass
class EditorHyperParams:
    dxf_path: str = "./part01.dxf"
    save_path: str = "./part01.dxf"
    window_size: tuple = (13.0, 8.5)
    bg_color: str = "#0a0a0a"
    disp_values: list = field(default_factory=lambda: [(0.1, 0.0)])
    force_values: list = field(default_factory=lambda: [(0.0, -100.0)])
    pick_tol_ratio: float = 0.015
    snap_tol_ratio: float = 0.018
    align_tol_ratio: float = 0.018
    dwell_ms: int = 500


def build_brushes_from_hp(hp: EditorHyperParams) -> list:
    brushes = []
    for name in ("0", "FIXED", "AUTO", "TRY", "PROBE"):
        brushes.append({"name": name, **DXFEditingHelper.get_layer_style(name)})
    n_disp = len(hp.disp_values)
    for i, (dx, dy) in enumerate(hp.disp_values, start=1):
        lname = DXFEditingHelper.format_bc_layer_name("DISP", dx, dy, seq=(i if n_disp > 1 else 1))
        brushes.append({"name": lname, **DXFEditingHelper.get_layer_style(lname)})
    n_force = len(hp.force_values)
    for i, (fx, fy) in enumerate(hp.force_values, start=1):
        lname = DXFEditingHelper.format_bc_layer_name("FORCE", fx, fy, seq=(i if n_force > 1 else 1))
        brushes.append({"name": lname, **DXFEditingHelper.get_layer_style(lname)})
    return brushes


class StandaloneDXFEditor:
    def __init__(self, hp: EditorHyperParams):
        self.hp = hp
        self.base_dir = os.path.dirname(os.path.abspath(__file__))
        self.doc = None
        self.brushes = build_brushes_from_hp(hp)
        self.brush_idx = 0
        self.cur_tool = "line"
        self.draw_pts = []
        self.added = []
        self.ortho_mode = False
        self.align_ref_pt = None
        self.mouse_xy = (0.0, 0.0)
        self.hover_handle = None
        self.snapped_pt = None
        self.snapped_type = None
        self.effective_pt = (0.0, 0.0)
        self.guide_pts = None
        self.pan_anchor = None
        self._dwell_candidate_pt = None
        self._dwell_timer = None
        self.entity_collections = []
        self.layer_by_handle = {}
        self.message = ""
        self._load_doc()
        self._init_figure()
        self._init_artists()
        self._init_dwell_timer()
        self._bind_events()
        self.rebuild_scene()
        self.fit_view()
        self._update_hud()

    def _load_doc(self):
        path = self.hp.dxf_path if os.path.isabs(self.hp.dxf_path) else os.path.join(self.base_dir, self.hp.dxf_path)
        try:
            self.doc = DXFEditingHelper.load_doc(path)
            n_exp = DXFEditingHelper.explode_all_lwpolylines(self.doc.modelspace())
            self.message = f"LOADED {os.path.basename(path)} (explode {n_exp})"
            self._register_try_brushes()
        except Exception as exc:
            self.doc = ezdxf.new("R2010")
            self.doc.units = ezdxf.units.MM
            self.message = f"NEW DOC ({exc})"

    def _register_try_brushes(self):
        existing = {b["name"] for b in self.brushes}
        found = []
        for lay in self.doc.layers:
            name = str(lay.dxf.name)
            info = DXFEditingHelper.parse_bc_layer_name(name)
            if info.get("type") == "TRY" and name not in existing:
                found.append((info.get("seq", 1), name))
        for _seq, name in sorted(found):
            self.brushes.append({"name": name, **DXFEditingHelper.get_layer_style(name)})

    def switch_to_try_line_mode(self):
        try_idx = next(
            (i for i, b in enumerate(self.brushes) if str(b["name"]).upper() == "TRY"),
            None,
        )
        if try_idx is None:
            style = DXFEditingHelper.get_layer_style("TRY")
            self.brushes.append({"name": "TRY", **style})
            try_idx = len(self.brushes) - 1

        self.brush_idx = try_idx
        self._ensure_layer("TRY")
        self.cur_tool = "line"
        self.draw_pts = []
        self.message = "SWITCH -> LAYER=TRY (TOOL=line)"
        self._refresh_cursor_and_preview(self.mouse_xy[0], self.mouse_xy[1])

    def _init_figure(self):
        self.fig, self.ax = plt.subplots(figsize=self.hp.window_size)
        self.fig.patch.set_facecolor(self.hp.bg_color)
        self.ax.set_facecolor(self.hp.bg_color)
        self.ax.set_aspect("equal", adjustable="box")
        self.ax.tick_params(colors="#666666", labelsize=7)
        for sp in self.ax.spines.values():
            sp.set_color("#333333")
        try:
            self.fig.canvas.manager.set_window_title("try015 — DXF Editor")
        except Exception:
            pass
        for key in (
            "keymap.quit", "keymap.quit_all", "keymap.fullscreen", "keymap.save",
            "keymap.pan", "keymap.zoom", "keymap.home", "keymap.grid",
            "keymap.grid_minor", "keymap.back", "keymap.forward",
            "keymap.all_axes", "keymap.xscale", "keymap.yscale",
        ):
            try:
                matplotlib.rcParams[key] = []
            except KeyError:
                pass

    def _init_artists(self):
        self.hover_col = LineCollection([], colors="#00ffff", linewidths=3.0, zorder=30)
        self.ax.add_collection(self.hover_col)
        self.preview_line, = self.ax.plot([], [], ls="--", lw=1.4, zorder=31)
        self.pts_marker, = self.ax.plot([], [], "o", color="#22c55e", ms=5, zorder=32)
        self.snap_marker, = self.ax.plot([], [], "s", mfc="none", mec="#ffd400", ms=11, mew=1.8, zorder=33)
        self.align_ref_marker, = self.ax.plot([], [], "+", color="#ff9900", ms=14, mew=2.0, zorder=34)
        self.align_guide_line, = self.ax.plot([], [], ls=":", color="#ff9900", lw=1.2, zorder=34)
        self.dim_line, = self.ax.plot([], [], ls="-.", lw=1.1, color="#38bdf8", zorder=35)
        self.dim_label = self.ax.text(
            0.0, 0.0, "", color="#fef08a", fontsize=8.5, family="monospace", fontweight="bold",
            ha="center", va="bottom", zorder=38, visible=False,
            bbox=dict(boxstyle="round,pad=0.22", facecolor="#1e293b", edgecolor="#38bdf8", alpha=0.88),
        )
        self.hud = self.ax.text(
            0.012, 0.985, "", transform=self.ax.transAxes, va="top", ha="left",
            color="#e2e8f0", fontsize=8.5, family="monospace", zorder=40,
            bbox=dict(boxstyle="round,pad=0.35", facecolor="#151515", edgecolor="#383838", alpha=0.9),
        )
        self.hover_label = self.ax.annotate(
            "", xy=(0.0, 0.0), xytext=(12, -16), textcoords="offset points",
            color="#00ffff", fontsize=8.5, family="monospace", fontweight="bold",
            ha="left", va="top", zorder=39, visible=False,
            bbox=dict(boxstyle="round,pad=0.22", facecolor="#111827", edgecolor="#00ffff", alpha=0.9),
        )

    def _init_dwell_timer(self):
        try:
            timer = self.fig.canvas.new_timer(interval=int(self.hp.dwell_ms))
            timer.single_shot = True
            timer.add_callback(self._on_dwell_timeout)
            self._dwell_timer = timer
        except Exception:
            self._dwell_timer = None

    def _bind_events(self):
        canvas = self.fig.canvas
        canvas.mpl_connect("button_press_event", self.on_press)
        canvas.mpl_connect("button_release_event", self.on_release)
        canvas.mpl_connect("motion_notify_event", self.on_motion)
        canvas.mpl_connect("scroll_event", self.on_scroll)
        canvas.mpl_connect("key_press_event", self.on_key)

    @property
    def cur_brush(self):
        return self.brushes[self.brush_idx % len(self.brushes)]

    @property
    def cur_layer(self):
        return self.cur_brush["name"]

    def _view_width(self):
        xlim = self.ax.get_xlim()
        return max(abs(xlim[1] - xlim[0]), 1e-6)

    def rebuild_scene(self):
        msp = self.doc.modelspace()
        self.segments_by_handle = {}
        self.layer_by_handle = {}
        snap_pts = []
        snap_types = []
        for ent in msp:
            handle = ent.dxf.handle
            self.layer_by_handle[handle] = ent.dxf.layer if ent.dxf.hasattr("layer") else "0"
            segs = DXFEditingHelper.entity_to_segments(ent)
            if segs:
                self.segments_by_handle.setdefault(handle, []).extend(segs)
            for pt, typ in DXFEditingHelper.entity_keypoints(ent):
                snap_pts.append(pt)
                snap_types.append(typ)
        self.p1_arr, self.p2_arr, self.v_arr, self.c2_arr, self.seg_handles = \
            DXFEditingHelper.build_segment_arrays(self.segments_by_handle)
        self.snap_pts_arr = np.asarray(snap_pts, dtype=float) if snap_pts else np.empty((0, 2))
        self.snap_types = snap_types
        self._redraw_entities()

    def _redraw_entities(self):
        for col in self.entity_collections:
            try:
                col.remove()
            except Exception:
                pass
        self.entity_collections = []
        by_layer = {}
        for ent in self.doc.modelspace():
            segs = self.segments_by_handle.get(ent.dxf.handle, [])
            if segs:
                by_layer.setdefault(ent.dxf.layer, []).extend(segs)
        for layer, segs in by_layer.items():
            style = DXFEditingHelper.get_layer_style(layer)
            col = LineCollection(
                segs, colors=style["colors"], linewidths=style["linewidths"],
                linestyles=style["linestyles"], zorder=style["zorder"],
            )
            self.ax.add_collection(col)
            self.entity_collections.append(col)

    def fit_view(self):
        pts = []
        for segs in self.segments_by_handle.values():
            for p1, p2 in segs:
                pts.append(p1)
                pts.append(p2)
        if not pts:
            self.ax.set_xlim(-10.0, 10.0)
            self.ax.set_ylim(-10.0, 10.0)
            return
        arr = np.asarray(pts, dtype=float)
        xmin, ymin = arr.min(axis=0)
        xmax, ymax = arr.max(axis=0)
        dx = max(xmax - xmin, 1.0) * 0.12
        dy = max(ymax - ymin, 1.0) * 0.12
        self.ax.set_xlim(xmin - dx, xmax + dx)
        self.ax.set_ylim(ymin - dy, ymax + dy)

    def _ensure_layer(self, layer=None):
        layer = layer or self.cur_layer
        style = DXFEditingHelper.get_layer_style(layer)
        DXFEditingHelper.ensure_layer(self.doc, layer, int(style.get("dxf_color", 7)))

    def _target_layer(self):
        if self.cur_tool in ("2p-circle", "3p-circle") and self.cur_layer.upper() == "PROBE":
            return DXFEditingHelper.next_probe_layer_name(self.doc)
        return self.cur_layer

    def _update_dwell_state(self, candidate):
        if self._dwell_timer is None:
            return
        if candidate is None:
            self._dwell_timer.stop()
            self._dwell_candidate_pt = None
            return
        if self._dwell_candidate_pt is not None:
            dx = candidate[0] - self._dwell_candidate_pt[0]
            dy = candidate[1] - self._dwell_candidate_pt[1]
            if math.hypot(dx, dy) < 1e-6:
                return
        self._dwell_timer.stop()
        self._dwell_candidate_pt = candidate
        self._dwell_timer.start()

    def _on_dwell_timeout(self):
        if self._dwell_candidate_pt is None:
            return
        self.align_ref_pt = self._dwell_candidate_pt
        rx, ry = self.align_ref_pt
        self.align_ref_marker.set_data([rx], [ry])
        self._refresh_cursor_and_preview(self.mouse_xy[0], self.mouse_xy[1])
        self._update_hud()
        self.fig.canvas.draw_idle()

    def _resolve_next_pt(self, px, py, align_tol):
        base_pt = self.draw_pts[-1] if self.draw_pts else None
        if self.snapped_pt is not None:
            sx, sy = self.snapped_pt
            if self.ortho_mode and base_pt is not None:
                bx, by = base_pt
                eff = (sx, by) if abs(sx - bx) >= abs(sy - by) else (bx, sy)
                return eff, f"SNAP[{self.snapped_type}]+ORTHO", [(sx, sy), eff]
            return (sx, sy), f"SNAP[{self.snapped_type}]", None
        ex, ey = float(px), float(py)
        guide_pts = None
        tags = []
        if self.align_ref_pt is not None:
            rx, ry = self.align_ref_pt
            dx_r = abs(px - rx)
            dy_r = abs(py - ry)
            if self.ortho_mode and base_pt is not None:
                bx, by = base_pt
                if abs(px - bx) >= abs(py - by):
                    if dx_r <= align_tol:
                        ex, ey = rx, by
                        guide_pts = [(rx, ry), (ex, ey)]
                        tags.append("ALIGN-X")
                    else:
                        ex, ey = px, by
                else:
                    if dy_r <= align_tol:
                        ex, ey = bx, ry
                        guide_pts = [(rx, ry), (ex, ey)]
                        tags.append("ALIGN-Y")
                    else:
                        ex, ey = bx, py
                tags.append("ORTHO")
            else:
                if dx_r <= dy_r and dx_r <= align_tol:
                    ex, ey = rx, py
                    guide_pts = [(rx, ry), (ex, ey)]
                    tags.append("ALIGN-X")
                elif dy_r < dx_r and dy_r <= align_tol:
                    ex, ey = px, ry
                    guide_pts = [(rx, ry), (ex, ey)]
                    tags.append("ALIGN-Y")
        elif self.ortho_mode and base_pt is not None:
            bx, by = base_pt
            ex, ey = (px, by) if abs(px - bx) >= abs(py - by) else (bx, py)
            tags.append("ORTHO")
        return (ex, ey), ("+".join(tags) if tags else "FREE"), guide_pts

    def on_scroll(self, event):
        if event.inaxes != self.ax or event.xdata is None:
            return
        scale = 1.0 / 1.2 if event.button == "up" else 1.2
        xlim = self.ax.get_xlim()
        ylim = self.ax.get_ylim()
        x, y = event.xdata, event.ydata
        self.ax.set_xlim(x - (x - xlim[0]) * scale, x + (xlim[1] - x) * scale)
        self.ax.set_ylim(y - (y - ylim[0]) * scale, y + (ylim[1] - y) * scale)
        self.fig.canvas.draw_idle()

    def on_press(self, event):
        if event.button == 3:
            if event.xdata is not None:
                self.pan_anchor = (event.xdata, event.ydata, self.ax.get_xlim(), self.ax.get_ylim())
            return
        if event.button != 1 or event.inaxes != self.ax or event.xdata is None:
            return
        self._refresh_cursor_and_preview(event.xdata, event.ydata)
        if self.cur_tool == "paint":
            self.paint_hovered_entity()
            return
        self._add_point(self.effective_pt)

    def on_release(self, event):
        if event.button == 3:
            self.pan_anchor = None

    def on_motion(self, event):
        if self.pan_anchor is not None and event.xdata is not None:
            ax0, ay0, xlim0, ylim0 = self.pan_anchor
            sx = xlim0[0] - event.xdata + ax0
            self.ax.set_xlim(sx, sx + (xlim0[1] - xlim0[0]))
            sy = ylim0[0] - event.ydata + ay0
            self.ax.set_ylim(sy, sy + (ylim0[1] - ylim0[0]))
            self.fig.canvas.draw_idle()
            return
        if event.inaxes != self.ax or event.xdata is None:
            return
        self._refresh_cursor_and_preview(event.xdata, event.ydata)

    def _refresh_cursor_and_preview(self, px, py):
        self.mouse_xy = (float(px), float(py))
        view_w = self._view_width()
        pick_tol = self.hp.pick_tol_ratio * view_w
        snap_tol = self.hp.snap_tol_ratio * view_w
        align_tol = self.hp.align_tol_ratio * view_w
        self.hover_handle, self.snapped_pt, self.snapped_type, _ = DXFEditingHelper.compute_hover_and_snap(
            px, py, self.p1_arr, self.p2_arr, self.v_arr, self.c2_arr, self.seg_handles,
            self.snap_pts_arr, self.snap_types, pick_tol, snap_tol,
        )
        self._update_dwell_state(self.snapped_pt)
        self.effective_pt, tag, self.guide_pts = self._resolve_next_pt(px, py, align_tol)
        self._refresh_artists(tag)
        self._update_hud(tag)
        self.fig.canvas.draw_idle()

    def _refresh_artists(self, tag):
        if self.hover_handle is not None:
            segs = self.segments_by_handle.get(self.hover_handle, [])
            self.hover_col.set_segments(segs if segs else [])
        else:
            self.hover_col.set_segments([])
        if self.snapped_pt is not None:
            self.snap_marker.set_data([self.snapped_pt[0]], [self.snapped_pt[1]])
        else:
            self.snap_marker.set_data([], [])
        if self.guide_pts is not None:
            xs = [p[0] for p in self.guide_pts]
            ys = [p[1] for p in self.guide_pts]
            self.align_guide_line.set_data(xs, ys)
        else:
            self.align_guide_line.set_data([], [])
        self._update_preview_geometry()
        self._update_dimension_overlay()
        self._refresh_hover_layer_label()

    def _refresh_hover_layer_label(self):
        if self.hover_handle is None:
            self.hover_label.set_visible(False)
            return
        h_layer = self.layer_by_handle.get(self.hover_handle)
        if h_layer is None:
            ent = DXFEditingHelper.find_entity(self.doc, self.hover_handle)
            h_layer = ent.dxf.layer if (ent is not None and ent.dxf.hasattr("layer")) else "0"
        l_color = DXFEditingHelper.get_layer_color(h_layer)
        self.hover_label.xy = (float(self.mouse_xy[0]), float(self.mouse_xy[1]))
        self.hover_label.set_text(f"Layer: {h_layer}")
        self.hover_label.set_color(l_color)
        patch = self.hover_label.get_bbox_patch()
        if patch is not None:
            patch.set_edgecolor(l_color)
        self.hover_label.set_visible(True)

    def _update_preview_geometry(self):
        if not self.draw_pts:
            self.preview_line.set_data([], [])
            self.pts_marker.set_data([], [])
            return
        xs = [p[0] for p in self.draw_pts]
        ys = [p[1] for p in self.draw_pts]
        self.pts_marker.set_data(xs, ys)
        self.preview_line.set_color(self.cur_brush["colors"])
        t = self.cur_tool
        n = len(self.draw_pts)
        cur = self.effective_pt
        if t == "line" and n == 1:
            p1 = self.draw_pts[0]
            self.preview_line.set_data([p1[0], cur[0]], [p1[1], cur[1]])
        elif t == "rect" and n == 1:
            x1, y1 = self.draw_pts[0]
            x2, y2 = cur
            self.preview_line.set_data([x1, x2, x2, x1, x1], [y1, y1, y2, y2, y1])
        elif t == "2p-circle" and n == 1:
            cen, r = DXFEditingHelper.circle_from_2_points(self.draw_pts[0], cur)
            if cen is not None and r > 1e-6:
                ang = np.linspace(0.0, 2.0 * math.pi, 65)
                self.preview_line.set_data(cen[0] + r * np.cos(ang), cen[1] + r * np.sin(ang))
            else:
                self.preview_line.set_data([], [])
        elif t == "3p-circle":
            if n == 1:
                p1 = self.draw_pts[0]
                self.preview_line.set_data([p1[0], cur[0]], [p1[1], cur[1]])
            elif n == 2:
                cen, r = DXFEditingHelper.circle_from_3_points(self.draw_pts[0], self.draw_pts[1], cur)
                if cen is not None and r > 1e-6:
                    ang = np.linspace(0.0, 2.0 * math.pi, 65)
                    self.preview_line.set_data(cen[0] + r * np.cos(ang), cen[1] + r * np.sin(ang))
                else:
                    p1, p2 = self.draw_pts
                    self.preview_line.set_data([p1[0], p2[0], cur[0]], [p1[1], p2[1], cur[1]])
        elif t == "3p-arc":
            if n == 1:
                p1 = self.draw_pts[0]
                self.preview_line.set_data([p1[0], cur[0]], [p1[1], cur[1]])
            elif n == 2:
                cen, r, a1, a2 = DXFEditingHelper.arc_from_3_points(self.draw_pts[0], self.draw_pts[1], cur)
                if cen is not None and r > 1e-6:
                    span = (a2 - a1) % 360.0 or 360.0
                    ang = np.radians(a1 + np.linspace(0.0, span, 49))
                    self.preview_line.set_data(cen[0] + r * np.cos(ang), cen[1] + r * np.sin(ang))
                else:
                    p1, p2 = self.draw_pts
                    self.preview_line.set_data([p1[0], p2[0], cur[0]], [p1[1], p2[1], cur[1]])

    def _update_dimension_overlay(self):
        if not self.draw_pts:
            self.dim_line.set_data([], [])
            self.dim_label.set_visible(False)
            return
        t = self.cur_tool
        n = len(self.draw_pts)
        cur = self.effective_pt
        if (t == "line" and n == 1) or (t in ("3p-circle", "3p-arc") and n == 1):
            p1 = self.draw_pts[0]
            length = math.hypot(cur[0] - p1[0], cur[1] - p1[1])
            if length <= 1e-6:
                self.dim_line.set_data([], [])
                self.dim_label.set_visible(False)
                return
            self.dim_line.set_data([], [])
            self.dim_label.set_position(((p1[0] + cur[0]) * 0.5, (p1[1] + cur[1]) * 0.5))
            self.dim_label.set_text(f"L = {length:.2f}")
            self.dim_label.set_visible(True)
            return
        if t == "2p-circle" and n == 1:
            cen, r = DXFEditingHelper.circle_from_2_points(self.draw_pts[0], cur)
            if cen is None or r <= 1e-6:
                self.dim_line.set_data([], [])
                self.dim_label.set_visible(False)
                return
            self.dim_line.set_data([cen[0], cur[0]], [cen[1], cur[1]])
            self.dim_label.set_position(((cen[0] + cur[0]) * 0.5, (cen[1] + cur[1]) * 0.5))
            self.dim_label.set_text(f"R = {r:.2f}")
            self.dim_label.set_visible(True)
            return
        if t == "rect" and n == 1:
            x1, y1 = self.draw_pts[0]
            w, h = abs(cur[0] - x1), abs(cur[1] - y1)
            if w <= 1e-6 or h <= 1e-6:
                self.dim_line.set_data([], [])
                self.dim_label.set_visible(False)
                return
            self.dim_line.set_data([], [])
            self.dim_label.set_position(((x1 + cur[0]) * 0.5, (y1 + cur[1]) * 0.5))
            self.dim_label.set_text(f"W = {w:.2f}, H = {h:.2f}")
            self.dim_label.set_visible(True)
            return
        if t in ("3p-circle", "3p-arc") and n == 2:
            cen, r = DXFEditingHelper.circle_from_3_points(self.draw_pts[0], self.draw_pts[1], cur)
            if cen is None or r <= 1e-6:
                self.dim_line.set_data([], [])
                self.dim_label.set_visible(False)
                return
            self.dim_line.set_data([cen[0], cur[0]], [cen[1], cur[1]])
            self.dim_label.set_position(((cen[0] + cur[0]) * 0.5, (cen[1] + cur[1]) * 0.5))
            self.dim_label.set_text(f"R = {r:.2f}")
            self.dim_label.set_visible(True)
            return
        self.dim_line.set_data([], [])
        self.dim_label.set_visible(False)

    def _update_hud(self, tag=None):
        if tag is None:
            tag = "FREE" if self.align_ref_pt is None else "ALIGN"
        align_txt = "none" if self.align_ref_pt is None else f"({self.align_ref_pt[0]:.3f}, {self.align_ref_pt[1]:.3f})"
        snap_txt = "-" if self.snapped_pt is None else self.snapped_type
        hover_lay = "-" if self.hover_handle is None else self.layer_by_handle.get(self.hover_handle, "-")
        lines = [
            f"LAYER {self.cur_layer}  |  TOOL {self.cur_tool}  |  F8 {'ON' if self.ortho_mode else 'OFF'}  |  {tag}",
            f"PT ({self.effective_pt[0]:+.3f}, {self.effective_pt[1]:+.3f})   HOVER [{hover_lay}]   SNAP {snap_txt}   ALIGN {align_txt}",
            f"Q/1-9 layer   W tool   T TRY(line)   F8 ortho   E del   F paint   R fit   Ctrl+Z undo   Ctrl+S save   Esc cancel",
        ]
        if self.message:
            lines.append(self.message)
        self.hud.set_text("\n".join(lines))

    def _add_point(self, pt):
        pt = (float(pt[0]), float(pt[1]))
        if self.draw_pts and math.hypot(pt[0] - self.draw_pts[-1][0], pt[1] - self.draw_pts[-1][1]) < 1e-6:
            return
        self.draw_pts.append(pt)
        need = TOOL_NEED.get(self.cur_tool, 2)
        if len(self.draw_pts) < need:
            return
        msp = self.doc.modelspace()
        layer = self._target_layer()
        self._ensure_layer(layer)
        if self.cur_tool == "line":
            ent = DXFEditingHelper.add_line(msp, self.draw_pts[0], self.draw_pts[1], layer)
            if ent is not None:
                self.added.append(ent.dxf.handle)
                self.draw_pts = [self.draw_pts[1]]
            else:
                self.draw_pts = []
        elif self.cur_tool == "2p-circle":
            ent = DXFEditingHelper.add_circle_2p(msp, self.draw_pts[0], self.draw_pts[1], layer)
            self._finish_shape(ent, layer)
        elif self.cur_tool == "rect":
            ent = DXFEditingHelper.add_rect_2p(msp, self.draw_pts[0], self.draw_pts[1], layer)
            self._finish_shape(ent, layer)
        elif self.cur_tool == "3p-circle":
            ent = DXFEditingHelper.add_circle_3p(msp, self.draw_pts[0], self.draw_pts[1], self.draw_pts[2], layer)
            self._finish_shape(ent, layer)
        elif self.cur_tool == "3p-arc":
            ent = DXFEditingHelper.add_arc_3p(msp, self.draw_pts[0], self.draw_pts[1], self.draw_pts[2], layer)
            self._finish_shape(ent, layer)
        else:
            self.draw_pts = []
        self.rebuild_scene()
        self._refresh_cursor_and_preview(self.mouse_xy[0], self.mouse_xy[1])

    def _finish_shape(self, ent, layer=None):
        if ent is not None:
            self.added.append(ent.dxf.handle)
            self.message = f"ADD {ent.dxftype()} on {layer or self.cur_layer}"
        self.draw_pts = []

    def switch_layer(self, target="next"):
        if isinstance(target, int):
            self.brush_idx = target % len(self.brushes)
        else:
            self.brush_idx = (self.brush_idx + 1) % len(self.brushes)
        # 若切到 TRY 圖層且當前工具不是 line，自動強制切回 line
        if self.cur_layer.upper() == "TRY" and self.cur_tool != "line":
            self.cur_tool = "line"
            self.draw_pts = []
            self.message = "LAYER TRY -> auto locked to TOOL=line"
        self._refresh_cursor_and_preview(self.mouse_xy[0], self.mouse_xy[1])

    def set_draw_tool(self, tool="next"):
        # 在 TRY 圖層下禁止切換到直線以外的工具
        if self.cur_layer.upper() == "TRY":
            self.cur_tool = "line"
            self.draw_pts = []
            self.message = "TRY 圖層僅限繪製直線 (TOOL=line)"
            self._refresh_cursor_and_preview(self.mouse_xy[0], self.mouse_xy[1])
            return
        if isinstance(tool, int):
            self.cur_tool = TOOLS[tool % len(TOOLS)]
        else:
            self.cur_tool = TOOLS[(TOOLS.index(self.cur_tool) + 1) % len(TOOLS)]
        self.draw_pts = []
        self._refresh_cursor_and_preview(self.mouse_xy[0], self.mouse_xy[1])

    def toggle_ortho_mode(self):
        self.ortho_mode = not self.ortho_mode
        self._refresh_cursor_and_preview(self.mouse_xy[0], self.mouse_xy[1])

    def delete_hovered_entity(self):
        if self.hover_handle is None:
            self.message = "DEL nothing hovered"
        elif DXFEditingHelper.delete_entity(self.doc, self.hover_handle):
            self.message = f"DEL {self.hover_handle}"
            self.hover_handle = None
            self.rebuild_scene()
        self._refresh_hover_layer_label()
        self.fig.canvas.draw_idle()

    def paint_hovered_entity(self):
        if self.hover_handle is None:
            self.message = "PAINT nothing hovered"
        elif self.cur_layer.upper() == "PROBE":
            self.message = "PAINT skipped (PROBE 需用 2p/3p-circle 自動編號)"
        elif self.cur_layer.upper() == "TRY":
            ent = DXFEditingHelper.find_entity(self.doc, self.hover_handle)
            if ent is None or ent.dxftype() != "LINE":
                self.message = "PAINT skipped (TRY 圖層僅支援 LINE 直線)"
            else:
                self._ensure_layer("TRY")
                DXFEditingHelper.paint_entity_layer(self.doc, self.hover_handle, "TRY")
                self.message = f"PAINT {self.hover_handle} -> TRY"
                self.rebuild_scene()
        else:
            self._ensure_layer()
            ent = DXFEditingHelper.find_entity(self.doc, self.hover_handle)
            if ent is not None and ent.dxf.layer == self.cur_layer:
                self.message = f"PAINT already on {self.cur_layer}"
            elif DXFEditingHelper.paint_entity_layer(self.doc, self.hover_handle, self.cur_layer):
                self.message = f"PAINT {self.hover_handle} -> {self.cur_layer}"
                self.rebuild_scene()
        self._refresh_hover_layer_label()
        self.fig.canvas.draw_idle()

    def undo_last_added(self):
        was_chaining_line = (self.cur_tool == "line" and len(self.draw_pts) == 1)
        while self.added:
            handle = self.added.pop()
            ent = DXFEditingHelper.find_entity(self.doc, handle)
            if ent is not None:
                prev_start = None
                if was_chaining_line and ent.dxftype() == "LINE":
                    prev_start = (float(ent.dxf.start.x), float(ent.dxf.start.y))
                DXFEditingHelper.delete_entity(self.doc, handle)
                self.rebuild_scene()
                if prev_start is not None:
                    self.draw_pts = [prev_start]
                elif self.draw_pts:
                    self.draw_pts = []
                self.message = f"UNDO {handle}"
                self._refresh_cursor_and_preview(self.mouse_xy[0], self.mouse_xy[1])
                return
        if self.draw_pts:
            self.draw_pts.pop()
            self.message = "UNDO point"
        else:
            self.message = "UNDO empty"
        self._refresh_cursor_and_preview(self.mouse_xy[0], self.mouse_xy[1])

    def cancel_drawing(self):
        self.draw_pts = []
        self.align_ref_pt = None
        self.align_ref_marker.set_data([], [])
        self.align_guide_line.set_data([], [])
        self.message = "CANCEL"
        self._refresh_cursor_and_preview(self.mouse_xy[0], self.mouse_xy[1])

    def save_dxf(self):
        path = self.hp.save_path if os.path.isabs(self.hp.save_path) else os.path.join(self.base_dir, self.hp.save_path)
        try:
            self.doc.saveas(path)
            self.message = f"SAVED {os.path.basename(path)}"
        except Exception as exc:
            self.message = f"SAVE FAILED {exc}"
        self._update_hud()
        self.fig.canvas.draw_idle()

    def on_key(self, event):
        key = (event.key or "").lower()
        if key in ("q",) or (len(key) == 1 and key.isdigit()):
            self.switch_layer(int(key) - 1 if key.isdigit() else "next")
        elif key == "w":
            self.set_draw_tool("next")
        elif key == "f8":
            self.toggle_ortho_mode()
        elif key in ("e", "delete"):
            self.delete_hovered_entity()
        elif key == "f":
            self.paint_hovered_entity()
        elif key == "t":
            self.switch_to_try_line_mode()
        elif key == "ctrl+z":
            self.undo_last_added()
        elif key == "ctrl+s":
            self.save_dxf()
        elif key in ("r", "home"):
            self.fit_view()
            self.fig.canvas.draw_idle()
        elif key == "escape":
            self.cancel_drawing()


def main():
    hp = EditorHyperParams()
    editor = StandaloneDXFEditor(hp)
    if matplotlib.get_backend().lower() in ("agg", "pdf", "svg", "ps", "cairo", "template"):
        print("[警告] 目前 backend 沒有互動視窗；請確認 matplotlib 有可用的 GUI backend。")
    print(f"[try015] layer={editor.cur_layer} tool={editor.cur_tool} brushes={len(editor.brushes)}")
    plt.show()
    return editor


if __name__ == "__main__":
    main()
