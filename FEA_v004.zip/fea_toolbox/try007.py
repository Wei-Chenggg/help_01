#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""try007.py — 第一關：大一統毛坯聯集 + 參數化逐刀 RECT 生成 + 批次 Candidate 輸出（PNG / DXF）。"""

import math
import os
import sys
from dataclasses import dataclass

import matplotlib

matplotlib.use("Agg")

import numpy as np
import ezdxf
import matplotlib.pyplot as plt
from matplotlib.collections import PolyCollection
from matplotlib.path import Path
from scipy.ndimage import binary_dilation, binary_erosion, label as nd_label

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from try005 import DXFContourHelper, FiniteEleMeshHelper


@dataclass
class AxisAlignedRect:
    x0: float
    y0: float
    x1: float
    y1: float
    direction: str = "-y"
    mode: str = "frame"

    def normalized(self) -> "AxisAlignedRect":
        return AxisAlignedRect(
            min(self.x0, self.x1), min(self.y0, self.y1),
            max(self.x0, self.x1), max(self.y0, self.y1),
            self.direction, self.mode,
        )

    def to_polygon(self) -> np.ndarray:
        r = self.normalized()
        return np.array([
            [r.x0, r.y0],
            [r.x1, r.y0],
            [r.x1, r.y1],
            [r.x0, r.y1],
        ], dtype=float)

    def scaled_along_direction(self, ratio: float) -> "AxisAlignedRect":
        r = self.normalized()
        t = float(np.clip(ratio, 0.0, 1.0))
        if r.direction == "+x":
            return AxisAlignedRect(r.x0, r.y0, r.x0 + (r.x1 - r.x0) * t, r.y1, r.direction, r.mode)
        if r.direction == "-x":
            return AxisAlignedRect(r.x1 - (r.x1 - r.x0) * t, r.y0, r.x1, r.y1, r.direction, r.mode)
        if r.direction == "+y":
            return AxisAlignedRect(r.x0, r.y0, r.x1, r.y0 + (r.y1 - r.y0) * t, r.direction, r.mode)
        return AxisAlignedRect(r.x0, r.y1 - (r.y1 - r.y0) * t, r.x1, r.y1, r.direction, r.mode)


class PolygonBooleanHelper:
    @staticmethod
    def as_path(pts: np.ndarray) -> Path:
        arr = np.asarray(pts, dtype=float)
        return Path(np.vstack([arr, arr[0]]), closed=True)

    @classmethod
    def split_and_dedup_segments(cls, segments, tol: float = 1e-6):
        n = len(segments)
        if n == 0:
            return []
        params = [[0.0, 1.0] for _ in range(n)]
        for i in range(n):
            a, b = segments[i]
            r = b - a
            r_len2 = float(r @ r)
            if r_len2 < 1e-14:
                continue
            for j in range(i + 1, n):
                c, d = segments[j]
                s = d - c
                s_len2 = float(s @ s)
                if s_len2 < 1e-14:
                    continue
                denom = r[0] * s[1] - r[1] * s[0]
                qp = c - a
                if abs(denom) > 1e-10:
                    t = (qp[0] * s[1] - qp[1] * s[0]) / denom
                    u = (qp[0] * r[1] - qp[1] * r[0]) / denom
                    if -1e-7 <= t <= 1.0 + 1e-7 and -1e-7 <= u <= 1.0 + 1e-7:
                        params[i].append(float(np.clip(t, 0.0, 1.0)))
                        params[j].append(float(np.clip(u, 0.0, 1.0)))
                else:
                    dist_perp = abs(qp[0] * r[1] - qp[1] * r[0]) / math.sqrt(r_len2)
                    if dist_perp <= tol:
                        for pt in (c, d):
                            t_proj = float(((pt - a) @ r) / r_len2)
                            if 1e-7 < t_proj < 1.0 - 1e-7:
                                params[i].append(t_proj)
                        for pt in (a, b):
                            u_proj = float(((pt - c) @ s) / s_len2)
                            if 1e-7 < u_proj < 1.0 - 1e-7:
                                params[j].append(u_proj)
        sub_segs = []
        seen_keys = set()
        scale = 1.0 / max(tol, 1e-7)
        for i in range(n):
            a, b = segments[i]
            ts = sorted(params[i])
            for k in range(len(ts) - 1):
                t0, t1 = ts[k], ts[k + 1]
                if t1 - t0 < 1e-7:
                    continue
                p0 = a + t0 * (b - a)
                p1 = a + t1 * (b - a)
                if float(np.linalg.norm(p1 - p0)) <= tol:
                    continue
                k0 = (int(round(p0[0] * scale)), int(round(p0[1] * scale)))
                k1 = (int(round(p1[0] * scale)), int(round(p1[1] * scale)))
                if k0 == k1:
                    continue
                edge_key = (k0, k1) if k0 < k1 else (k1, k0)
                if edge_key not in seen_keys:
                    seen_keys.add(edge_key)
                    sub_segs.append((p0, p1))
        return sub_segs

    @classmethod
    def boolean_op(cls, union_loops, cut_loops=None, eps: float = 1e-3):
        u_loops = [np.asarray(lp, dtype=float) for lp in (union_loops or []) if len(lp) >= 3]
        c_loops = [np.asarray(lp, dtype=float) for lp in (cut_loops or []) if len(lp) >= 3]
        if not u_loops:
            return [], []
        u_paths = [cls.as_path(lp) for lp in u_loops]
        c_paths = [cls.as_path(lp) for lp in c_loops]

        def is_inside(pts: np.ndarray) -> np.ndarray:
            mask = np.zeros(len(pts), dtype=bool)
            for up in u_paths:
                mask |= up.contains_points(pts)
            for cp in c_paths:
                mask &= ~cp.contains_points(pts)
            return mask

        raw_segs = []
        for lp in u_loops + c_loops:
            closed = np.vstack([lp, lp[0]])
            for a, b in zip(closed[:-1], closed[1:]):
                if float(np.linalg.norm(b - a)) > 1e-8:
                    raw_segs.append((a, b))
        sub_segs = cls.split_and_dedup_segments(raw_segs, tol=1e-5)
        if not sub_segs:
            return [], []
        mids = np.array([0.5 * (a + b) for a, b in sub_segs], dtype=float)
        tangents = np.array([b - a for a, b in sub_segs], dtype=float)
        lengths = np.linalg.norm(tangents, axis=1, keepdims=True)
        unit_t = tangents / np.maximum(lengths, 1e-12)
        normals = np.column_stack([-unit_t[:, 1], unit_t[:, 0]])
        left_in = is_inside(mids + eps * normals)
        right_in = is_inside(mids - eps * normals)
        directed = []
        for (a, b), l_in, r_in in zip(sub_segs, left_in, right_in):
            if l_in and not r_in:
                directed.append((a, b))
            elif r_in and not l_in:
                directed.append((b, a))
        rings = cls._chain_directed_rings(directed, snap_tol=1e-4)
        outers, holes = [], []
        for ring in rings:
            clean_ring = cls.simplify_collinear(ring)
            if len(clean_ring) < 3:
                continue
            area = FiniteEleMeshHelper._polygon_area_signed(clean_ring)
            if area > 1e-4:
                outers.append(clean_ring)
            elif area < -1e-4:
                holes.append(clean_ring)
        outers.sort(key=FiniteEleMeshHelper._polygon_area, reverse=True)
        holes.sort(key=FiniteEleMeshHelper._polygon_area, reverse=True)
        return outers, holes

    @staticmethod
    def _chain_directed_rings(edges, snap_tol: float = 1e-4):
        if not edges:
            return []
        scale = 1.0 / max(snap_tol, 1e-9)

        def key(p):
            return (int(round(float(p[0]) * scale)), int(round(float(p[1]) * scale)))

        buckets = {}
        for idx, (a, _b) in enumerate(edges):
            buckets.setdefault(key(a), []).append(idx)
        used = [False] * len(edges)
        rings = []
        for i in range(len(edges)):
            if used[i]:
                continue
            used[i] = True
            ring = [edges[i][0]]
            prev_dir = edges[i][1] - edges[i][0]
            cur = edges[i][1]
            for _ in range(len(edges) + 2):
                if key(cur) == key(ring[0]):
                    break
                cands = [j for j in buckets.get(key(cur), []) if not used[j]]
                if not cands:
                    break
                if len(cands) == 1:
                    nxt = cands[0]
                else:
                    in_ang = math.atan2(prev_dir[1], prev_dir[0])
                    nxt = min(
                        cands,
                        key=lambda j: (
                            math.atan2(edges[j][1][1] - edges[j][0][1], edges[j][1][0] - edges[j][0][0]) - in_ang
                        ) % (2.0 * math.pi),
                    )
                used[nxt] = True
                ring.append(edges[nxt][0])
                prev_dir = edges[nxt][1] - edges[nxt][0]
                cur = edges[nxt][1]
            if len(ring) >= 3 and key(cur) == key(ring[0]):
                rings.append(np.array(ring, dtype=float))
        return rings

    @staticmethod
    def simplify_collinear(pts: np.ndarray, angle_tol: float = 1e-4) -> np.ndarray:
        arr = np.asarray(pts, dtype=float)
        if len(arr) < 3:
            return arr
        keep = []
        n = len(arr)
        for i in range(n):
            p_prev = arr[(i - 1) % n]
            p_cur = arr[i]
            p_next = arr[(i + 1) % n]
            v1 = p_cur - p_prev
            v2 = p_next - p_cur
            l1 = float(np.linalg.norm(v1))
            l2 = float(np.linalg.norm(v2))
            if l1 < 1e-6 or l2 < 1e-6:
                continue
            cross = abs(v1[0] * v2[1] - v1[1] * v2[0]) / (l1 * l2)
            dot = (v1[0] * v2[0] + v1[1] * v2[1]) / (l1 * l2)
            if cross <= angle_tol and dot > 0:
                continue
            keep.append(p_cur)
        return np.array(keep, dtype=float) if len(keep) >= 3 else arr


class SequentialRectGenerator:
    def __init__(self, doc, min_hinge_mm: float = 1.1, raster_pitch_mm: float = 0.35):
        self.doc = doc
        self.min_hinge_mm = float(min_hinge_mm)
        self.raster_pitch = float(raster_pitch_mm)
        self.geo = self._extract_blank_and_bcs(doc)
        self._init_raster_grid()

    @staticmethod
    def _extract_blank_and_bcs(doc) -> dict:
        msp = doc.modelspace()
        raw_lines, _, _, arc_polys, circle_polys = DXFContourHelper.extract_primitives_from_msp(msp)
        outer0_segs = []
        auto_segs = []
        disp_segs = []
        fixed_circles = []
        probe_circles = []
        for s in raw_lines:
            info = DXFContourHelper.parse_bc_layer_name(s.layer)
            btype = info.get("type")
            pts = np.array([s.p1, s.p2], dtype=float)
            if str(s.layer).upper() in ("AUTO", "SEARCH_ZONE"):
                auto_segs.append((pts, s.layer))
            elif btype in ("FREE", "DISP", "FORCE", "FIXED"):
                outer0_segs.append((pts, "0"))
                if btype in ("DISP", "FORCE"):
                    disp_segs.append((pts, s.layer))
        for pts, _h, layer in arc_polys:
            arr = np.asarray(pts, dtype=float)
            if str(layer).upper() in ("AUTO", "SEARCH_ZONE"):
                auto_segs.append((arr, layer))
            else:
                outer0_segs.append((arr, "0"))
        for pts, _h, layer in circle_polys:
            arr = np.asarray(pts, dtype=float)
            info = DXFContourHelper.parse_bc_layer_name(layer)
            btype = info.get("type")
            cx, cy = float(arr[:, 0].mean()), float(arr[:, 1].mean())
            r = float(np.mean(np.hypot(arr[:, 0] - cx, arr[:, 1] - cy)))
            if btype == "PROBE":
                probe_circles.append({"layer": layer, "center": (cx, cy), "radius": r})
            elif btype == "FIXED":
                fixed_circles.append({"layer": layer, "center": (cx, cy), "radius": r, "poly": arr[:-1]})
        chains_0 = FiniteEleMeshHelper._chain_segments_with_layers(outer0_segs, snap_tol=0.12)
        loops_0 = [c[0] for c in chains_0 if len(c[0]) >= 3]
        loops_0.sort(key=FiniteEleMeshHelper._polygon_area, reverse=True)
        outer_0 = loops_0[0] if loops_0 else np.zeros((0, 2))
        chains_auto = FiniteEleMeshHelper._chain_segments_with_layers(auto_segs, snap_tol=0.05)
        loops_auto = [c[0] for c in chains_auto if len(c[0]) >= 3]
        loops_auto.sort(key=FiniteEleMeshHelper._polygon_area, reverse=True)
        if len(outer_0) >= 3:
            blank_outers, _ = PolygonBooleanHelper.boolean_op([outer_0] + loops_auto, cut_loops=None)
            unified_blank = blank_outers[0] if blank_outers else outer_0
        else:
            unified_blank = outer_0
        return {
            "outer_0": outer_0,
            "auto_loops": loops_auto,
            "unified_blank": unified_blank,
            "fixed_circles": fixed_circles,
            "disp_segs": disp_segs,
            "probe_circles": probe_circles,
        }

    def _init_raster_grid(self):
        blank = self.geo["unified_blank"]
        if len(blank) < 3:
            raise ValueError("無法從 DXF 取得外輪廓，請確認圖層 0 的封閉輪廓")
        xmin, ymin = blank.min(axis=0) - 3.0
        xmax, ymax = blank.max(axis=0) + 3.0
        p = self.raster_pitch
        self.xs = np.arange(xmin, xmax + p, p)
        self.ys = np.arange(ymin, ymax + p, p)
        gx, gy = np.meshgrid(self.xs, self.ys)
        self.grid_pts = np.column_stack([gx.ravel(), gy.ravel()])
        self.grid_shape = gx.shape
        self.blank_mask = PolygonBooleanHelper.as_path(blank).contains_points(self.grid_pts).reshape(self.grid_shape)
        self.auto_mask = np.zeros(self.grid_shape, dtype=bool)
        for alp in self.geo["auto_loops"]:
            self.auto_mask |= PolygonBooleanHelper.as_path(alp).contains_points(self.grid_pts).reshape(self.grid_shape)
        if not self.auto_mask.any():
            self.auto_mask = self.blank_mask.copy()
        auto_pts = np.vstack(self.geo["auto_loops"]) if self.geo["auto_loops"] else blank
        self.auto_xmin, self.auto_ymin = auto_pts.min(axis=0)
        self.auto_xmax, self.auto_ymax = auto_pts.max(axis=0)
        self.auto_span_x = float(self.auto_xmax - self.auto_xmin)
        self.auto_span_y = float(self.auto_ymax - self.auto_ymin)
        self.forbidden_mask = np.zeros(self.grid_shape, dtype=bool)
        for fc in self.geo["fixed_circles"]:
            cx, cy = fc["center"]
            r_safe = fc["radius"] + self.min_hinge_mm
            d2 = (gx - cx) ** 2 + (gy - cy) ** 2
            self.blank_mask &= (d2 > fc["radius"] ** 2)
            self.forbidden_mask |= (d2 <= r_safe ** 2)
        for seg_pts, _lay in self.geo["disp_segs"]:
            a, b = seg_pts[0], seg_pts[1]
            v = b - a
            l2 = max(float(v @ v), 1e-12)
            t = np.clip(((self.grid_pts - a) @ v) / l2, 0.0, 1.0)
            proj = a + t[:, None] * v
            d = np.hypot(self.grid_pts[:, 0] - proj[:, 0], self.grid_pts[:, 1] - proj[:, 1]).reshape(self.grid_shape)
            self.forbidden_mask |= (d <= self.min_hinge_mm)
        self.anchor_masks = []
        for fc in self.geo["fixed_circles"]:
            cx, cy = fc["center"]
            r_ring = fc["radius"] + self.min_hinge_mm + 1.2 * p
            m = self.blank_mask & (((gx - cx) ** 2 + (gy - cy) ** 2) <= r_ring ** 2)
            if m.any():
                self.anchor_masks.append(m)
        if self.geo["disp_segs"]:
            a, b = self.geo["disp_segs"][0][0]
            mid = 0.5 * (a + b)
            m = self.blank_mask & (((gx - mid[0]) ** 2 + (gy - mid[1]) ** 2) <= (self.min_hinge_mm + 2.0 * p) ** 2)
            if m.any():
                self.anchor_masks.append(m)
        if self.geo["probe_circles"]:
            pc = self.geo["probe_circles"][0]["center"]
            valid_idx = np.argwhere(self.blank_mask)
            if len(valid_idx):
                pts_valid = np.column_stack([self.xs[valid_idx[:, 1]], self.ys[valid_idx[:, 0]]])
                nearest = valid_idx[int(np.argmin(np.hypot(pts_valid[:, 0] - pc[0], pts_valid[:, 1] - pc[1])))]
                m = np.zeros(self.grid_shape, dtype=bool)
                m[nearest[0], nearest[1]] = True
                self.anchor_masks.append(binary_dilation(m, iterations=2) & self.blank_mask)

    def _is_cut_state_valid(self, current_solid_mask: np.ndarray, rect_mask: np.ndarray) -> bool:
        if np.any(rect_mask & self.forbidden_mask):
            return False
        next_solid = current_solid_mask & (~rect_mask)
        if not next_solid.any():
            return False
        lab_full, n_full = nd_label(next_solid)
        if n_full > 1:
            sizes = np.bincount(lab_full.ravel())[1:]
            if np.sum(sizes > 4) > 1:
                return False
        erode_iters = max(1, int(round(0.5 * self.min_hinge_mm / self.raster_pitch)))
        core_solid = binary_erosion(next_solid, iterations=erode_iters)
        core_regrown = binary_dilation(core_solid, iterations=erode_iters) & next_solid
        lab_core, n_core = nd_label(core_regrown)
        if n_core == 0:
            return False
        if not self.anchor_masks:
            return True
        anchor_labels = set()
        for am in self.anchor_masks:
            overlap = lab_core[am & (lab_core > 0)]
            if len(overlap) == 0:
                return False
            anchor_labels.add(int(overlap[0]))
        return len(anchor_labels) == 1

    def _rect_to_mask(self, rect: AxisAlignedRect) -> np.ndarray:
        r = rect.normalized()
        return (
            (self.xs[None, :] >= r.x0) & (self.xs[None, :] <= r.x1) &
            (self.ys[:, None] >= r.y0) & (self.ys[:, None] <= r.y1)
        )

    def _build_single_rect_from_params(self, u_row, step_idx, current_mask, accepted_rects):
        u_mode, u_anchor, u_width, u_len, u_dir = (float(v) for v in u_row)
        ref_size = min(self.auto_span_x, self.auto_span_y)
        w = (0.08 + 0.18 * u_width) * ref_size
        use_frame = (len(accepted_rects) == 0) or (u_mode < 0.45)
        if use_frame:
            outside_now = ~current_mask
            avail_frame = (
                binary_dilation(outside_now, iterations=2)
                & current_mask
                & self.auto_mask
                & (~self.forbidden_mask)
            )
            coords = np.argwhere(avail_frame)
            if len(coords) == 0:
                return None
            pick = coords[int(u_anchor * (len(coords) - 1))]
            ax = float(self.xs[pick[1]])
            ay = float(self.ys[pick[0]])
            dirs = []
            step_px = 3
            r_i, c_i = int(pick[0]), int(pick[1])
            if r_i + step_px < self.grid_shape[0] and not current_mask[r_i + step_px, c_i]:
                dirs.append("-y")
            if r_i - step_px >= 0 and not current_mask[r_i - step_px, c_i]:
                dirs.append("+y")
            if c_i + step_px < self.grid_shape[1] and not current_mask[r_i, c_i + step_px]:
                dirs.append("-x")
            if c_i - step_px >= 0 and not current_mask[r_i, c_i - step_px]:
                dirs.append("+x")
            if not dirs:
                dirs = ["+x", "-x", "+y", "-y"]
            direction = dirs[int(u_dir * len(dirs)) % len(dirs)]
            overshoot = 1.5
            mode_tag = "frame"
        else:
            parent = accepted_rects[int(u_anchor * len(accepted_rects)) % len(accepted_rects)]
            if parent.direction in ("+x", "-x"):
                if parent.direction == "+x":
                    ax = parent.x1 - 0.35 * (parent.x1 - parent.x0)
                else:
                    ax = parent.x0 + 0.35 * (parent.x1 - parent.x0)
                ay = 0.5 * (parent.y0 + parent.y1)
                direction = "+y" if u_dir >= 0.5 else "-y"
            else:
                ax = 0.5 * (parent.x0 + parent.x1)
                if parent.direction == "+y":
                    ay = parent.y1 - 0.35 * (parent.y1 - parent.y0)
                else:
                    ay = parent.y0 + 0.35 * (parent.y1 - parent.y0)
                direction = "+x" if u_dir >= 0.5 else "-x"
            overshoot = 0.5 * min(parent.x1 - parent.x0, parent.y1 - parent.y0)
            mode_tag = "branch"
        if direction == "+x":
            length = (0.35 + 0.60 * u_len) * self.auto_span_x
            return AxisAlignedRect(ax - overshoot, ay - 0.5 * w, ax + length, ay + 0.5 * w, "+x", mode_tag)
        if direction == "-x":
            length = (0.35 + 0.60 * u_len) * self.auto_span_x
            return AxisAlignedRect(ax - length, ay - 0.5 * w, ax + overshoot, ay + 0.5 * w, "-x", mode_tag)
        if direction == "+y":
            length = (0.35 + 0.60 * u_len) * self.auto_span_y
            return AxisAlignedRect(ax - 0.5 * w, ay - overshoot, ax + 0.5 * w, ay + length, "+y", mode_tag)
        length = (0.35 + 0.60 * u_len) * self.auto_span_y
        return AxisAlignedRect(ax - 0.5 * w, ay - length, ax + 0.5 * w, ay + overshoot, "-y", mode_tag)

    def _apply_one_rect(self, raw_rect, current_mask, accepted_rects, min_cut_px: int = 6):
        m_full = self._rect_to_mask(raw_rect)
        if np.count_nonzero(m_full & current_mask) < min_cut_px:
            return None, None
        if self._is_cut_state_valid(current_mask, m_full):
            return raw_rect.normalized(), m_full
        lo, hi = 0.0, 1.0
        best_rect = None
        best_mask = None
        for _ in range(8):
            mid = 0.5 * (lo + hi)
            sub_rect = raw_rect.scaled_along_direction(mid)
            m_sub = self._rect_to_mask(sub_rect)
            if self._is_cut_state_valid(current_mask, m_sub):
                lo = mid
                if np.count_nonzero(m_sub & current_mask) >= min_cut_px:
                    best_rect = sub_rect.normalized()
                    best_mask = m_sub
            else:
                hi = mid
        return best_rect, best_mask

    def _finalize(self, accepted_rects) -> dict:
        cut_polys = [r.to_polygon() for r in accepted_rects]
        final_outers, final_holes = PolygonBooleanHelper.boolean_op(
            [self.geo["unified_blank"]], cut_loops=cut_polys
        )
        return {
            "accepted_rects": accepted_rects,
            "final_outers": final_outers,
            "final_holes": final_holes,
        }

    def generate_from_parameter_matrix(self, u_matrix) -> dict:
        current_mask = self.blank_mask.copy()
        accepted_rects = []
        for step_idx, u_row in enumerate(u_matrix):
            raw_rect = self._build_single_rect_from_params(u_row, step_idx, current_mask, accepted_rects)
            if raw_rect is None:
                continue
            best_rect, best_mask = self._apply_one_rect(raw_rect, current_mask, accepted_rects, min_cut_px=4)
            if best_rect is None:
                continue
            current_mask &= (~best_mask)
            accepted_rects.append(best_rect)
        return self._finalize(accepted_rects)

    def sample_random_candidate(self, rng: np.random.Generator, n_rects: int = 8, max_retries_per_slot: int = 4) -> dict:
        current_mask = self.blank_mask.copy()
        accepted_rects = []
        for step_idx in range(n_rects):
            for _ in range(max_retries_per_slot):
                u_row = rng.uniform(0.0, 1.0, size=5)
                raw_rect = self._build_single_rect_from_params(u_row, step_idx, current_mask, accepted_rects)
                if raw_rect is None:
                    continue
                best_rect, best_mask = self._apply_one_rect(raw_rect, current_mask, accepted_rects, min_cut_px=6)
                if best_rect is None:
                    continue
                current_mask &= (~best_mask)
                accepted_rects.append(best_rect)
                break
        return self._finalize(accepted_rects)


def render_candidate_png(fig, ax, geo: dict, cand_res: dict, cand_idx: int, out_png_path: str):
    ax.clear()
    ax.set_facecolor("#0b0f17")
    fig.patch.set_facecolor("#0b0f17")
    if len(geo["outer_0"]) >= 3:
        c0 = np.vstack([geo["outer_0"], geo["outer_0"][0]])
        ax.plot(c0[:, 0], c0[:, 1], color="#64748b", lw=1.0, ls="--", zorder=2, label="Layer 0 (Original)")
    for i, alp in enumerate(geo["auto_loops"]):
        ca = np.vstack([alp, alp[0]])
        ax.plot(ca[:, 0], ca[:, 1], color="#00e5ff", lw=1.1, ls=":", zorder=3, label="Layer AUTO" if i == 0 else None)
    rect_polys = [r.to_polygon() for r in cand_res["accepted_rects"]]
    if rect_polys:
        ax.add_collection(PolyCollection(
            rect_polys, facecolors="#ff8800", edgecolors="#ff8800",
            alpha=0.18, linewidths=1.3, linestyles="-", zorder=4,
            label=f"RECT_RAW ({len(rect_polys)})",
        ))
        for idx, rp in enumerate(rect_polys, start=1):
            closed_r = np.vstack([rp, rp[0]])
            ax.plot(closed_r[:, 0], closed_r[:, 1], color="#ff8800", lw=1.2, alpha=0.85, zorder=5)
            ax.text(rp[:, 0].mean(), rp[:, 1].mean(), f"R{idx}", color="#ffae42",
                    fontsize=6.5, ha="center", va="center", zorder=6)
    if cand_res["final_outers"]:
        ax.add_collection(PolyCollection(
            cand_res["final_outers"], facecolors="#22c55e", edgecolors="none", alpha=0.22, zorder=3,
        ))
    if cand_res["final_holes"]:
        ax.add_collection(PolyCollection(
            cand_res["final_holes"], facecolors="#0b0f17", edgecolors="none", alpha=0.95, zorder=3.5,
        ))
    all_final_loops = list(cand_res["final_outers"]) + list(cand_res["final_holes"])
    for i, flp in enumerate(all_final_loops):
        cf = np.vstack([flp, flp[0]])
        ax.plot(cf[:, 0], cf[:, 1], color="#00ff66", lw=2.0, zorder=7, label="FINAL_CONTOUR (Green)" if i == 0 else None)
    for i, fc in enumerate(geo["fixed_circles"]):
        cx, cy = fc["center"]
        r = fc["radius"]
        th = np.linspace(0.0, 2.0 * math.pi, 49)
        ax.plot(cx + r * np.cos(th), cy + r * np.sin(th), color="#38bdf8", lw=1.6, zorder=8, label="FIXED" if i == 0 else None)
    for i, (seg_pts, lay) in enumerate(geo["disp_segs"]):
        ax.plot(seg_pts[:, 0], seg_pts[:, 1], color="#ff3355", lw=2.8, zorder=9, label=lay if i == 0 else None)
    for i, pc in enumerate(geo["probe_circles"]):
        cx, cy = pc["center"]
        ax.plot([cx], [cy], marker="+", ms=11, mew=2.2, color="#a3e635", zorder=10, label=pc["layer"] if i == 0 else None)
    blank = geo["unified_blank"]
    xmin, ymin = blank.min(axis=0) - 6.0
    xmax, ymax = blank.max(axis=0) + 6.0
    ax.set_xlim(xmin, xmax)
    ax.set_ylim(ymin, ymax)
    ax.set_aspect("equal", adjustable="box")
    ax.tick_params(colors="#94a3b8", labelsize=7)
    ax.set_title(
        f"Candidate #{cand_idx:04d} | RECTs: {len(rect_polys)} (Orange) | Final Loops: {len(all_final_loops)} (Green)",
        color="#e2e8f0", fontsize=9.5,
    )
    handles, labels = ax.get_legend_handles_labels()
    if handles:
        ax.legend(loc="upper left", facecolor="#161b26", edgecolor="#334155", labelcolor="#e2e8f0", fontsize=7.5)
    fig.savefig(out_png_path, dpi=130)


def export_candidate_dxf(src_doc, geo: dict, cand_res: dict, out_dxf_path: str):
    doc = ezdxf.new(dxfversion="R2010")
    doc.units = ezdxf.units.MM
    msp = doc.modelspace()
    for lay in src_doc.layers:
        lname = lay.dxf.name
        if lname not in doc.layers:
            doc.layers.add(name=lname, color=lay.dxf.color if lay.dxf.hasattr("color") else 7)
    for ent in src_doc.modelspace():
        etype = ent.dxftype()
        lay = ent.dxf.layer
        if etype == "LINE":
            msp.add_line((float(ent.dxf.start.x), float(ent.dxf.start.y)),
                         (float(ent.dxf.end.x), float(ent.dxf.end.y)), dxfattribs={"layer": lay})
        elif etype == "CIRCLE":
            msp.add_circle((float(ent.dxf.center.x), float(ent.dxf.center.y)),
                           float(ent.dxf.radius), dxfattribs={"layer": lay})
        elif etype == "ARC":
            msp.add_arc((float(ent.dxf.center.x), float(ent.dxf.center.y)), float(ent.dxf.radius),
                        float(ent.dxf.start_angle), float(ent.dxf.end_angle), dxfattribs={"layer": lay})
        elif etype == "LWPOLYLINE":
            pts = [(float(p[0]), float(p[1])) for p in ent.get_points("xy")]
            if len(pts) >= 2:
                pl = msp.add_lwpolyline(pts, format="xy", dxfattribs={"layer": lay})
                pl.closed = bool(ent.closed)
    if "RECT_RAW" not in doc.layers:
        doc.layers.add(name="RECT_RAW", color=30)
    for r in cand_res["accepted_rects"]:
        poly = r.to_polygon()
        closed = np.vstack([poly, poly[0]])
        for a, b in zip(closed[:-1], closed[1:]):
            msp.add_line((float(a[0]), float(a[1])), (float(b[0]), float(b[1])),
                         dxfattribs={"layer": "RECT_RAW", "color": 30})
    if "FINAL_CONTOUR" not in doc.layers:
        doc.layers.add(name="FINAL_CONTOUR", color=3)
    for loop in list(cand_res["final_outers"]) + list(cand_res["final_holes"]):
        if len(loop) < 3:
            continue
        closed = np.vstack([loop, loop[0]])
        for a, b in zip(closed[:-1], closed[1:]):
            if float(np.linalg.norm(b - a)) > 1e-6:
                msp.add_line((float(a[0]), float(a[1])), (float(b[0]), float(b[1])),
                             dxfattribs={"layer": "FINAL_CONTOUR", "color": 3})
    for fc in geo["fixed_circles"]:
        cx, cy = fc["center"]
        msp.add_circle((cx, cy), float(fc["radius"]), dxfattribs={"layer": "FINAL_CONTOUR", "color": 3})
    doc.saveas(out_dxf_path)


def main():
    folder = os.path.dirname(os.path.abspath(__file__))
    dxf_path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(folder, "part01.dxf")
    num_candidates = int(sys.argv[2]) if len(sys.argv) > 2 else 20
    n_rects_per_cand = int(sys.argv[3]) if len(sys.argv) > 3 else 8
    out_dir = os.path.join(folder, "out", "try007_candidates")
    os.makedirs(out_dir, exist_ok=True)
    print(f"[讀取] {dxf_path}")
    src_doc = ezdxf.readfile(dxf_path)
    gen = SequentialRectGenerator(src_doc, min_hinge_mm=1.1, raster_pitch_mm=0.35)
    geo = gen.geo
    print(f"[毛坯] Outer(0) {len(geo['outer_0'])} 頂點 | AUTO 迴圈 {len(geo['auto_loops'])} 個 | "
          f"聯集後 {len(geo['unified_blank'])} 頂點 面積 {FiniteEleMeshHelper._polygon_area(geo['unified_blank']):.2f} mm2")
    print(f"[AUTO] 範圍 x {gen.auto_xmin:.2f}~{gen.auto_xmax:.2f} (span {gen.auto_span_x:.2f}) | "
          f"y {gen.auto_ymin:.2f}~{gen.auto_ymax:.2f} (span {gen.auto_span_y:.2f})")
    print(f"[BC] FIXED {len(geo['fixed_circles'])} | DISP {len(geo['disp_segs'])} | PROBE {len(geo['probe_circles'])}")
    rng = np.random.default_rng(seed=42)
    fig, ax = plt.subplots(figsize=(10.5, 5.8))
    fig.subplots_adjust(left=0.06, right=0.98, top=0.92, bottom=0.07)
    for cand_idx in range(1, num_candidates + 1):
        cand_res = gen.sample_random_candidate(rng, n_rects=n_rects_per_cand)
        png_path = os.path.join(out_dir, f"cand_{cand_idx:04d}.png")
        dxf_out = os.path.join(out_dir, f"cand_{cand_idx:04d}.dxf")
        render_candidate_png(fig, ax, geo, cand_res, cand_idx, png_path)
        export_candidate_dxf(src_doc, geo, cand_res, dxf_out)
        if cand_idx % 10 == 0 or cand_idx == 1 or cand_idx == num_candidates:
            print(f"  [{cand_idx:04d}/{num_candidates:04d}] RECTs={len(cand_res['accepted_rects'])} "
                  f"outer={len(cand_res['final_outers'])} hole={len(cand_res['final_holes'])}")
    plt.close(fig)
    print(f"[完成] 共 {num_candidates} 組 Candidate -> {out_dir}")


if __name__ == "__main__":
    main()
