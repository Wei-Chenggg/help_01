import math
import os
import pickle
from dataclasses import dataclass
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection, PolyCollection
from dxf_contour_transformer import ContourCheckResult, DXFContourTransformer
from fea_mesh_generator import FeaMeshGenerator
from fea_solver import FeaSolver
matplotlib.rcParams["font.sans-serif"] = ["Microsoft JhengHei", "SimHei", "Arial"]
matplotlib.rcParams["axes.unicode_minus"] = False

VIEW_MODES = [
    "Von Mises 應力",
    "總位移 |dxy|",
    "位移角 disp_theta",
    "X位移 dx",
    "Y位移 dy",
]

VIEW_FIELD = {
    "Von Mises 應力": ("von_mises", "Von Mises (MPa)", "turbo"),
    "總位移 |dxy|": ("u_mag", "|dxy| (mm)", "viridis"),
    "位移角 disp_theta": ("disp_theta_deg", "disp_theta (deg)", "hsv"),
    "X位移 dx": ("u_x", "dx (mm)", "coolwarm"),
    "Y位移 dy": ("u_y", "dy (mm)", "coolwarm"),
}

@dataclass
class FeaBundle:
    dxf_path: str
    check: ContourCheckResult | None = None
    mesh: dict | None = None
    fea: dict | None = None

class FeaVisualizer:
    @classmethod
    def plot_check_result(
        cls,
        result: ContourCheckResult,
        ax=None,
        show_clean_endpoints: bool = True,
    ):
        created_fig = None
        if ax is None:
            created_fig, ax = plt.subplots(figsize=(10, 6.5))
        ax.clear()
        ax.set_facecolor("#0a0a0a")
        if ax.figure is not None:
            ax.figure.patch.set_facecolor("#0a0a0a")
        bg_segs = [(s.p1, s.p2) for s in result.raw_line_segments]
        for c1, c2, _ in result.display_curve_segments:
            bg_segs.append((c1, c2))
        if bg_segs:
            bg_col = LineCollection(bg_segs, colors="#555555", linewidths=1.2, zorder=2)
            ax.add_collection(bg_col)
        if show_clean_endpoints and len(result.node_coords) > 0:
            ok_mask = result.node_degrees == 2
            if np.any(ok_mask):
                ok_pts = result.node_coords[ok_mask]
                ax.scatter(ok_pts[:, 0], ok_pts[:, 1], c="#22aa55", s=14, alpha=0.75, zorder=4, label="Closed Node (Deg=2)")
        ov_segs = []
        ov_pts = []
        open_pts = []
        junc_pts = []
        gap_pts = []
        island_polys = []
        island_pts = []
        intersect_polys = []
        intersect_pts = []
        for iss in result.issues:
            if iss.issue_type in ("EXACT_DUPLICATE", "CONTAINMENT", "PARTIAL_OVERLAP"):
                if iss.highlight_seg is not None:
                    ov_segs.append(iss.highlight_seg)
                ov_pts.extend(iss.marker_pts)
            elif iss.issue_type == "OPEN_ENDPOINT":
                open_pts.extend(iss.marker_pts)
            elif iss.issue_type == "MULTI_JUNCTION":
                junc_pts.extend(iss.marker_pts)
            elif iss.issue_type in ("DEGENERATE", "MICRO_GAP"):
                gap_pts.extend(iss.marker_pts)
            elif iss.issue_type in ("EXTERIOR_ISLAND", "NESTED_ISLAND"):
                if iss.island_poly:
                    island_polys.append(np.asarray(iss.island_poly, dtype=float))
                island_pts.extend(iss.marker_pts)
            elif iss.issue_type == "LOOP_INTERSECT":
                if iss.island_poly:
                    intersect_polys.append(np.asarray(iss.island_poly, dtype=float))
                intersect_pts.extend(iss.marker_pts)
        if island_polys:
            island_col = PolyCollection(
                island_polys,
                facecolors="#00ffff", edgecolors="#00ffff",
                alpha=0.28, linestyles="dashed", zorder=7,
                label="Island (Floating)",
            )
            ax.add_collection(island_col)
        if island_pts:
            arr = np.array(island_pts, dtype=float)
            ax.scatter(arr[:, 0], arr[:, 1], s=190, facecolors="none", edgecolors="#00ffff", linewidths=2.4, zorder=14, label="Island Center")
            ax.scatter(arr[:, 0], arr[:, 1], s=90, c="#00ffff", marker="x", linewidths=2.0, zorder=14)
        if intersect_polys:
            inter_col = PolyCollection(
                intersect_polys,
                facecolors="none", edgecolors="#ffcc00",
                linestyles="dashed", linewidths=2.2, zorder=9,
                label="Loop Intersect",
            )
            ax.add_collection(inter_col)
        if intersect_pts:
            arr = np.array(intersect_pts, dtype=float)
            ax.scatter(arr[:, 0], arr[:, 1], s=170, facecolors="none", edgecolors="#ffcc00", marker="D", linewidths=2.2, zorder=15, label="Loop Intersect Center")
        for probe in (result.probe_circles or []):
            cx, cy = probe["center"]
            r = float(probe.get("radius", 0.0))
            if r > 0:
                th = np.linspace(0.0, 2.0 * math.pi, 49)
                ax.plot(cx + r * np.cos(th), cy + r * np.sin(th), color="#00ff88", lw=1.8, ls="--", zorder=16)
            ax.plot([cx], [cy], marker="+", markersize=12, color="#00ff88", mew=2.0, zorder=16)
            ax.annotate(
                str(probe.get("probe_id", "PROBE")), xy=(cx, cy), xytext=(cx + 2.0, cy + 2.0),
                color="#00ff88", fontsize=8, zorder=17,
            )
        if ov_segs:
            ov_col = LineCollection(ov_segs, colors="#ff00ff", linewidths=4.8, alpha=0.85, zorder=8, label="Overlap Segment")
            ax.add_collection(ov_col)
        if ov_pts:
            arr = np.array(ov_pts, dtype=float)
            ax.scatter(arr[:, 0], arr[:, 1], s=130, facecolors="none", edgecolors="#ff00ff", linewidths=2.2, zorder=11, label="Overlap Endpoint")
        if open_pts:
            arr = np.array(open_pts, dtype=float)
            ax.scatter(arr[:, 0], arr[:, 1], s=170, facecolors="none", edgecolors="#ff2244", linewidths=2.5, zorder=12, label="Open Endpoint (Deg=1)")
            ax.scatter(arr[:, 0], arr[:, 1], s=50, c="#ff2244", marker="+", linewidths=1.8, zorder=12)
        if junc_pts:
            arr = np.array(junc_pts, dtype=float)
            ax.scatter(arr[:, 0], arr[:, 1], s=150, facecolors="none", edgecolors="#ff9900", marker="o", linewidths=2.2, zorder=10, label="Multi-Junction (Deg>=3)")
        if gap_pts:
            arr = np.array(gap_pts, dtype=float)
            ax.scatter(arr[:, 0], arr[:, 1], s=160, facecolors="none", edgecolors="#ffff00", marker="D", linewidths=2.2, zorder=13, label="Micro-Gap / Degenerate")
        counts = result.summary_dict()
        n_ov = counts["EXACT_DUPLICATE"] + counts["CONTAINMENT"] + counts["PARTIAL_OVERLAP"]
        status_color = "#00ff88" if result.is_clean else "#ff3355"
        hud_text = (
            f"STATUS: {'CLEAN (PASS)' if result.is_clean else 'ISSUES FOUND'}\n"
            f"Raw Lines: {len(result.raw_line_segments)} -> Clean Lines: {len(result.clean_line_segments)}   |   "
            f"Overlaps(Purple): {n_ov}   |   Open Ends(Red): {counts['OPEN_ENDPOINT']}   |   "
            f"Junctions(Orange): {counts['MULTI_JUNCTION']}   |   Gaps(Yellow): {counts['MICRO_GAP'] + counts['DEGENERATE']}   |   "
            f"Islands(Cyan): {counts['EXTERIOR_ISLAND'] + counts['NESTED_ISLAND']}   |   "
            f"Loop X(Yellow): {counts['LOOP_INTERSECT']}"
        )
        ax.text(
            0.015, 0.975, hud_text, transform=ax.transAxes,
            color=status_color, fontsize=9.5, fontweight="bold", va="top", ha="left", zorder=20,
            bbox=dict(boxstyle="round,pad=0.35", facecolor="#161616", edgecolor="#444444", alpha=0.92),
        )
        ax.set_aspect("equal", adjustable="box")
        if bg_segs:
            all_xy = np.vstack([np.array(bg_segs).reshape(-1, 2)])
            xmin, ymin = all_xy.min(axis=0)
            xmax, ymax = all_xy.max(axis=0)
            dx = max(xmax - xmin, 10.0) * 0.12
            dy = max(ymax - ymin, 10.0) * 0.12
            ax.set_xlim(xmin - dx, xmax + dx)
            ax.set_ylim(ymin - dy, ymax + dy)
        handles_leg, labels_leg = ax.get_legend_handles_labels()
        if handles_leg:
            ax.legend(loc="lower right", facecolor="#181818", edgecolor="#444444", labelcolor="#dddddd", fontsize=8)
        return created_fig, ax

    @staticmethod
    def plot_t6_mesh_on_ax(mesh: dict, ax):
        if ax is None:
            return None
        ax.clear()
        ax.set_facecolor("#0a0a0a")
        if ax.figure is not None:
            ax.figure.patch.set_facecolor("#0a0a0a")
        nodes = mesh["nodes"]
        elements = mesh["elements"]
        n_corner = mesh["n_corner_nodes"]
        areas = mesh.get("areas")
        char_len = np.sqrt(2.0 * np.asarray(areas, dtype=float)) if areas is not None and len(areas) else np.array([0.0])
        # T6 純線框：每元素 6 段 (角點-中點-角點)，依節點編號去重後繪製
        half_edges = np.vstack([
            elements[:, [0, 3]],
            elements[:, [3, 1]],
            elements[:, [1, 4]],
            elements[:, [4, 2]],
            elements[:, [2, 5]],
            elements[:, [5, 0]],
        ])
        uniq_edges = np.unique(np.sort(half_edges, axis=1), axis=0)
        wire_segs = np.stack([nodes[uniq_edges[:, 0]], nodes[uniq_edges[:, 1]]], axis=1)
        ax.add_collection(LineCollection(wire_segs, colors="#8fb8c9", linewidths=0.45, alpha=0.9, zorder=2))
        for loop in [mesh.get("outer_loop")] + list(mesh.get("hole_loops") or []):
            if loop is None or len(loop) < 2:
                continue
            closed = np.vstack([loop, loop[0]])
            ax.plot(closed[:, 0], closed[:, 1], color="#dddddd", lw=1.2, zorder=5)
        for lay, ginfo in (mesh.get("bc_groups") or {}).items():
            edges = ginfo.get("edges_t6")
            if edges is None or len(edges) == 0:
                continue
            lay_up = str(lay).upper()
            if lay_up == "FIXED":
                color, label = "#00bfff", "FIXED"
            elif lay_up.startswith("DISP_"):
                color, label = "#ff3355", f"DISP {lay}"
            elif lay_up.startswith("FORCE_"):
                color, label = "#ffaa00", f"FORCE {lay}"
            elif lay_up == "PROBE" or lay_up.startswith("PROBE_"):
                color, label = "#00ff88", f"PROBE {lay}"
            else:
                color, label = "#9aa0a6", str(lay)
            bc_segs = np.vstack([
                np.stack([nodes[edges[:, 0]], nodes[edges[:, 2]]], axis=1),
                np.stack([nodes[edges[:, 2]], nodes[edges[:, 1]]], axis=1),
            ])
            ax.add_collection(LineCollection(bc_segs, colors=color, linewidths=2.4, zorder=8, label=label))
        for pid, pinfo in (mesh.get("probes") or {}).items():
            cx, cy = pinfo.get("center_xy", (0.0, 0.0))
            r = float(pinfo.get("radius", 0.0))
            if r > 0:
                th = np.linspace(0.0, 2.0 * np.pi, 49)
                ax.plot(cx + r * np.cos(th), cy + r * np.sin(th), color="#00ff88", lw=1.6, ls="--", zorder=16)
            ax.plot([cx], [cy], marker="+", markersize=11, color="#00ff88", mew=2.0, zorder=16)
            nx, ny = pinfo.get("node_xy", (cx, cy))
            ax.plot([cx, nx], [cy, ny], color="#00ff88", lw=0.8, ls=":", zorder=15)
            ax.annotate(
                f"{pid} -> Node #{pinfo.get('node_id', -1)}",
                xy=(cx, cy), xytext=(cx + 1.5, cy + 1.5),
                color="#00ff88", fontsize=7.5, zorder=17,
            )
        bc_counts = ", ".join(
            f"{k}:{len(v.get('node_ids', []))}" for k, v in (mesh.get("bc_groups") or {}).items()
        )
        hud_lines = [
            f"T6 MESH | Nodes {len(nodes)} (corner {n_corner} + mid {len(nodes) - n_corner})",
            f"Elements {len(elements)} | Size {float(char_len.min()):.2f} ~ {float(char_len.max()):.2f} mm "
            f"| {float(mesh.get('elapsed_ms', 0.0)):.0f} ms",
        ]
        if bc_counts:
            hud_lines.append(f"BC Nodes: {bc_counts}")
        ax.text(
            0.012, 0.985, "\n".join(hud_lines), transform=ax.transAxes,
            color="#00ff88", fontsize=8.5, va="top", ha="left", zorder=20,
            bbox=dict(boxstyle="round,pad=0.35", facecolor="#161616", edgecolor="#444444", alpha=0.92),
        )
        outer = mesh.get("outer_loop")
        if outer is not None and len(outer) > 0:
            xmin, ymin = np.min(outer, axis=0)
            xmax, ymax = np.max(outer, axis=0)
            dx = max(xmax - xmin, 1.0) * 0.06
            dy = max(ymax - ymin, 1.0) * 0.06
            ax.set_xlim(xmin - dx, xmax + dx)
            ax.set_ylim(ymin - dy, ymax + dy)
        ax.set_aspect("equal", adjustable="box")
        ax.tick_params(colors="#888888", labelsize=7)
        handles, labels = ax.get_legend_handles_labels()
        if handles:
            ax.legend(
                loc="lower right", facecolor="#181818", edgecolor="#444444",
                labelcolor="#dddddd", fontsize=7,
            )
        return ax

    @staticmethod
    def plot_fea_on_ax(result: dict, mesh: dict, ax, mode: str = "Von Mises 應力",
                       show_undeformed: bool = True, deform_scale: float = None):
        if ax is None or result is None:
            return None
        ax.clear()
        ax.set_facecolor("#0a0a0a")
        if ax.figure is not None:
            ax.figure.patch.set_facecolor("#0a0a0a")
        field_key, field_label, cmap = VIEW_FIELD.get(mode, VIEW_FIELD[VIEW_MODES[0]])
        hp = result.get("hp")
        if deform_scale is None:
            deform_scale = float(getattr(hp, "deform_scale", 1.0)) if hp is not None else 1.0
        scale = float(deform_scale)
        nodes0 = np.asarray(mesh["nodes"], dtype=float)
        elements = np.asarray(mesh["elements"], dtype=int)
        nodes = nodes0 + scale * np.asarray(result["u"], dtype=float)
        values = np.asarray(result[field_key], dtype=float)
        n0, n1, n2 = elements[:, 0], elements[:, 1], elements[:, 2]
        m01, m12, m20 = elements[:, 3], elements[:, 4], elements[:, 5]
        sub = np.stack([
            np.stack([n0, m01, m20], axis=1),
            np.stack([m01, n1, m12], axis=1),
            np.stack([m20, m12, n2], axis=1),
            np.stack([m01, m12, m20], axis=1),
        ], axis=1)
        tri = sub.reshape(-1, 3)
        tri_vals = values[tri].mean(axis=1)
        coll = PolyCollection(
            nodes[tri], array=tri_vals, cmap=cmap,
            edgecolors="none", alpha=0.95, zorder=2,
        )
        ax.add_collection(coll)
        prev_cbar = getattr(ax, "_fea_cbar", None)
        if prev_cbar is not None:
            try:
                prev_cbar.remove()
            except Exception:
                pass
            ax._fea_cbar = None
        cbar = ax.figure.colorbar(coll, ax=ax, shrink=0.8, pad=0.015)
        ax._fea_cbar = cbar
        cbar.set_label(field_label, color="#cccccc", fontsize=8)
        cbar.ax.tick_params(colors="#cccccc", labelsize=7)
        if show_undeformed:
            for loop in [mesh.get("outer_loop")] + list(mesh.get("hole_loops") or []):
                if loop is None or len(loop) < 2:
                    continue
                closed = np.vstack([loop, loop[0]])
                ax.plot(closed[:, 0], closed[:, 1], color="#55606a", lw=0.8, ls="--", zorder=3)
        for pid, pinfo in (result.get("probes") or {}).items():
            nid = int(pinfo.get("node_id", -1))
            if 0 <= nid < len(nodes):
                px, py = float(nodes[nid, 0]), float(nodes[nid, 1])
                ax.plot([px], [py], marker="+", markersize=12, color="#00ff88", mew=2.2, zorder=8)
                ax.annotate(
                    f"{pid}\ndx={pinfo['dx']:+.3f} dy={pinfo['dy']:+.3f}\n|d|={pinfo['dxy']:.3f} mm\n"
                    f"vm={pinfo['stress']:.1f} MPa",
                    xy=(px, py), xytext=(px + 2.5, py + 2.5),
                    color="#00ff88", fontsize=7.5, zorder=9,
                    bbox=dict(boxstyle="round,pad=0.25", facecolor="#101010", edgecolor="#00ff88", alpha=0.85),
                )
        hud = [
            f"T6 TL-SVK FEA | {getattr(hp, 'material', '')} | lambda={result['converged_lambda']:.3f}",
            f"Nodes {len(nodes)} | Elements {len(elements)} | iter {result['n_iter_total']} "
            f"| {result['elapsed_ms']:.0f} ms | Visual: {scale:g}x",
            f"max vm {result['max_von_mises']:.2f} MPa | SF {result['safety_factor']:.2f} | "
            f"eq-res {result['equilibrium_residual_n']:.3e} N",
        ]
        if result.get("warning"):
            hud.append(f"WARNING: {result['warning']}")
        ax.text(
            0.012, 0.985, "\n".join(hud), transform=ax.transAxes,
            color="#ffdd55", fontsize=8, va="top", ha="left", zorder=20,
            bbox=dict(boxstyle="round,pad=0.35", facecolor="#161616", edgecolor="#444444", alpha=0.92),
        )
        outer = mesh.get("outer_loop")
        if outer is not None and len(outer) > 0:
            allpts = np.vstack([nodes[tri].reshape(-1, 2), np.asarray(outer, dtype=float)])
            xmin, ymin = allpts.min(axis=0)
            xmax, ymax = allpts.max(axis=0)
            dx = max(xmax - xmin, 1.0) * 0.06
            dy = max(ymax - ymin, 1.0) * 0.06
            ax.set_xlim(xmin - dx, xmax + dx)
            ax.set_ylim(ymin - dy, ymax + dy)
        ax.set_aspect("equal", adjustable="box")
        ax.tick_params(colors="#888888", labelsize=7)
        return ax

    @staticmethod
    def save_bundle_pkl(bundle, pkl_path: str) -> str:
        os.makedirs(os.path.dirname(os.path.abspath(pkl_path)), exist_ok=True)
        if isinstance(bundle, dict):
            bundle = FeaBundle(
                dxf_path=str(bundle.get("dxf_path", "")),
                check=bundle.get("check"),
                mesh=bundle.get("mesh"),
                fea=bundle.get("fea"),
            )
        with open(pkl_path, "wb") as f:
            pickle.dump(bundle, f, protocol=pickle.HIGHEST_PROTOCOL)
        return pkl_path

    @staticmethod
    def load_bundle_pkl(pkl_path: str) -> FeaBundle:
        with open(pkl_path, "rb") as f:
            obj = pickle.load(f)
        if isinstance(obj, FeaBundle):
            return obj
        if isinstance(obj, dict):
            return FeaBundle(
                dxf_path=str(obj.get("dxf_path", pkl_path)),
                check=obj.get("check"),
                mesh=obj.get("mesh"),
                fea=obj.get("fea"),
            )
        raise TypeError(f"不支援的 PKL 內容型別: {type(obj)}")

    @classmethod
    def render_all_from_bundle(
        cls,
        bundle_or_pkl,
        out_dir: str,
        stem: str | None = None,
        fea_modes: list[tuple[str, str]] | None = None,
        deform_scale: float | None = None,
        show_undeformed: bool = True,
        figsize: tuple[float, float] = (10.0, 6.5),
        dpi: int = 140,
    ) -> dict[str, str]:
        if isinstance(bundle_or_pkl, str):
            bundle = cls.load_bundle_pkl(bundle_or_pkl)
            default_stem = os.path.splitext(os.path.basename(bundle_or_pkl))[0].replace("_bundle", "")
        elif isinstance(bundle_or_pkl, dict):
            bundle = FeaBundle(
                dxf_path=str(bundle_or_pkl.get("dxf_path", "model")),
                check=bundle_or_pkl.get("check"),
                mesh=bundle_or_pkl.get("mesh"),
                fea=bundle_or_pkl.get("fea"),
            )
            default_stem = os.path.splitext(os.path.basename(bundle.dxf_path))[0] or "model"
        else:
            bundle = bundle_or_pkl
            default_stem = os.path.splitext(os.path.basename(bundle.dxf_path))[0] or "model"

        os.makedirs(out_dir, exist_ok=True)
        stem = stem or default_stem
        if fea_modes is None:
            fea_modes = [
                ("disp", VIEW_MODES[1]),
                ("stress", VIEW_MODES[0]),
            ]
        saved_paths = {}

        if bundle.check is not None:
            fig, ax = plt.subplots(figsize=figsize)
            cls.plot_check_result(bundle.check, ax=ax)
            fig.tight_layout()
            p_check = os.path.join(out_dir, f"{stem}_check.png")
            fig.savefig(p_check, dpi=dpi)
            plt.close(fig)
            saved_paths["check"] = p_check

        if bundle.mesh is not None:
            fig, ax = plt.subplots(figsize=figsize)
            cls.plot_t6_mesh_on_ax(bundle.mesh, ax=ax)
            fig.tight_layout()
            p_mesh = os.path.join(out_dir, f"{stem}_mesh.png")
            fig.savefig(p_mesh, dpi=dpi)
            plt.close(fig)
            saved_paths["mesh"] = p_mesh

        if bundle.fea is not None and bundle.mesh is not None:
            eff_scale = deform_scale
            if eff_scale is None:
                hp = bundle.fea.get("hp")
                eff_scale = float(getattr(hp, "deform_scale", 1.0)) if hp is not None else 1.0
            for suffix, mode_name in fea_modes:
                fig, ax = plt.subplots(figsize=figsize)
                cls.plot_fea_on_ax(
                    bundle.fea, bundle.mesh, ax=ax,
                    mode=mode_name,
                    show_undeformed=show_undeformed,
                    deform_scale=eff_scale,
                )
                p_fea = os.path.join(out_dir, f"{stem}_{suffix}.png")
                fig.savefig(p_fea, dpi=dpi)
                plt.close(fig)
                saved_paths[suffix] = p_fea

        return saved_paths

DXFContourTransformer.plot_check_result = FeaVisualizer.plot_check_result
FeaMeshGenerator.plot_t6_mesh_on_ax = staticmethod(FeaVisualizer.plot_t6_mesh_on_ax)
FeaSolver.plot_fea_on_ax = staticmethod(FeaVisualizer.plot_fea_on_ax)
