import os
import sys
import numpy as np
import ezdxf
import matplotlib

from dxf_contour_transformer import (
    ContourHyperParams,
    LineSegment,
    ContourIssue,
    ContourCheckResult,
    DXFContourTransformer,
    DXFContourHelper,
)
from fea_mesh_generator import (
    MeshHyperParams,
    FeaMeshGenerator,
    FiniteEleMeshHelper,
)
from fea_solver import (
    GF_TO_N,
    SolverHyperParams,
    FeaSolver,
    FiniteEleSolverHelper,
)
from fea_visualizer import (
    VIEW_MODES,
    VIEW_FIELD,
    FeaBundle,
    FeaVisualizer,
)


def main():
    matplotlib.use("Agg")
    folder = os.path.dirname(os.path.abspath(__file__))
    in_path = sys.argv[1] if len(sys.argv) > 1 else None
    out_dir = os.path.join(folder, "out")
    os.makedirs(out_dir, exist_ok=True)
    if in_path is not None and in_path.lower().endswith(".pkl"):
        print(f"[載入 PKL] {in_path}")
        bundle = FeaVisualizer.load_bundle_pkl(in_path)
        saved = FeaVisualizer.render_all_from_bundle(bundle, out_dir=out_dir)
        for k, p in saved.items():
            print(f"[重繪輸出] ({k}) {p}")
        return bundle.mesh, bundle.fea
    if in_path is None:
        dxf_files = sorted(f for f in os.listdir(folder) if f.lower().endswith(".dxf"))
        if not dxf_files:
            print("[錯誤] 資料夾內找不到 .dxf 檔案")
            return
        in_path = os.path.join(folder, dxf_files[0])
    print(f"[輸入] {in_path}")
    stem = os.path.splitext(os.path.basename(in_path))[0]
    doc = ezdxf.readfile(in_path)
    print("[1/3] 輪廓與去重檢查 ...")
    check = DXFContourTransformer.check_dxf(doc, hp=ContourHyperParams())
    counts = check.summary_dict()
    n_ov = counts["EXACT_DUPLICATE"] + counts["CONTAINMENT"] + counts["PARTIAL_OVERLAP"]
    print(f"      {'CLEAN (PASS)' if check.is_clean else 'ISSUES FOUND'} | 直線 {len(check.raw_line_segments)} -> 去重後 {len(check.clean_line_segments)}")
    print(f"      重疊={n_ov} 懸空={counts['OPEN_ENDPOINT']} 分岔={counts['MULTI_JUNCTION']} 微縫/退化={counts['MICRO_GAP'] + counts['DEGENERATE']} 端點相接={counts['HEAD_TO_TAIL']} 問題總數={len(check.issues)}")
    for iss in check.issues:
        print(f"      [#{iss.issue_id:02d}] [{iss.severity}] [{iss.issue_type}] {iss.description}")
    print("[2/3] T6 網格 ...")
    mesh = FeaMeshGenerator.build_t6_mesh_from_dxf(doc, hp=MeshHyperParams())
    print(f"      T6: {len(mesh['elements'])} 元素 / {len(mesh['nodes'])} 節點 | {mesh['elapsed_ms']:.0f} ms | 斷裂邊界邊 {mesh.get('broken_boundary_edges', 0)}")
    for lay, ginfo in (mesh.get("bc_groups") or {}).items():
        print(f"      BC {lay}: {len(ginfo.get('node_ids', []))} 節點")
    print("[3/3] FEA 求解 ...")
    fea_hp = SolverHyperParams()
    fea = FeaSolver.solve(mesh, hp=fea_hp)
    print(f"      vm_max={fea['max_von_mises']:.2f} MPa | SF={fea['safety_factor']:.2f} | λ={fea['converged_lambda']:.3f} | {fea['elapsed_ms']:.0f} ms")
    u_mag = np.asarray(fea["u_mag"], dtype=float)
    if len(u_mag):
        i_umax = int(np.argmax(u_mag))
        print(f"      |d|max={u_mag[i_umax]:.4f} mm @Node#{i_umax} | 節點位移中位數={float(np.median(u_mag)):.6f} mm")
    if fea.get("warning"):
        print(f"      [警告] {fea['warning']}")
    for btype, rinfo in (fea.get("reactions") or {}).items():
        print(f"      反力 {btype} Rx={rinfo['rx_n']:+.3f} N Ry={rinfo['ry_n']:+.3f} N (|R|={rinfo['r_gf']:.2f} gf, n={rinfo['n_nodes']})")
    for pid, pinfo in (fea.get("probes") or {}).items():
        print(f"      {pid} -> Node #{pinfo['node_id']} dx={pinfo['dx']:+.4f} dy={pinfo['dy']:+.4f} |d|={pinfo['dxy']:.4f} mm vm={pinfo['stress']:.2f} MPa")
    bundle = FeaBundle(dxf_path=in_path, check=check, mesh=mesh, fea=fea)
    pkl_path = os.path.join(out_dir, f"{stem}_bundle.pkl")
    FeaVisualizer.save_bundle_pkl(bundle, pkl_path)
    print(f"[輸出 PKL] {pkl_path}")
    saved = FeaVisualizer.render_all_from_bundle(
        bundle, out_dir=out_dir, stem=stem, deform_scale=fea_hp.deform_scale
    )
    for p in saved.values():
        print(f"[輸出] {p}")
    print("===== 結果摘要 =====")
    print(f"  模型      : {os.path.basename(in_path)}")
    print(f"  網格      : {len(mesh['elements'])} T6 元素 / {len(mesh['nodes'])} 節點 / 斷裂邊界邊 {mesh.get('broken_boundary_edges', 0)}")
    print(f"  材料      : {fea_hp.material} (E={fea_hp.E_mpa:.0f} MPa, nu={fea_hp.nu}, t={fea_hp.thickness_mm} mm)")
    print(f"  收斂      : lambda={fea['converged_lambda']:.4f}")
    if len(u_mag):
        print(f"  位移      : |d|max={float(u_mag.max()):.4f} mm")
    print(f"  應力      : vm_max={fea['max_von_mises']:.3f} MPa, SF={fea['safety_factor']:.3f}")
    return mesh, fea


if __name__ == "__main__":
    main()
