import math
import time
from dataclasses import dataclass
import numpy as np
from scipy.sparse import csc_matrix
from scipy.sparse.linalg import splu
from dxf_contour_transformer import DXFContourTransformer

GF_TO_N = 0.00980665

@dataclass
class SolverHyperParams:
    material: str = "Al-7075-T6"
    E_mpa: float = 71700.0
    nu: float = 0.33
    yield_mpa: float = 503.0
    thickness_mm: float = 10.0
    large_disp: bool = True
    n_steps: int = 5
    max_nr_iter: int = 20
    tol_rel: float = 1e-4
    deform_scale: float = 1.0
    min_det_f: float = 1e-3
    n_gauss: int = 3

class FeaSolver:
    _GP_L = (0.445948490915965, 0.091576213509771)
    _GP_W = (0.223381589678011, 0.109951743655322)
    _EYE2 = np.eye(2)

    @classmethod
    def _quadrature(cls, n_gauss: int = 3):
        """三角形積分點；3 點 (degree-2) 為預設，6 點可作對照。權重已換算到參考面積 0.5。"""
        if int(n_gauss) >= 6:
            a1, a2 = cls._GP_L
            w1, w2 = cls._GP_W
            b1 = 1.0 - 2.0 * a1
            b2 = 1.0 - 2.0 * a2
            pts = []
            for l2, l3 in ((a1, a1), (b1, a1), (a1, b1)):
                pts.append((l2, l3, 0.5 * w1))
            for l2, l3 in ((a2, a2), (b2, a2), (a2, b2)):
                pts.append((l2, l3, 0.5 * w2))
            return pts
        a = 1.0 / 6.0
        b = 2.0 / 3.0
        return [(a, a, 1.0 / 6.0), (b, a, 1.0 / 6.0), (a, b, 1.0 / 6.0)]

    @staticmethod
    def _shape(xi, eta):
        L1 = 1.0 - xi - eta
        L2 = xi
        L3 = eta
        N = np.array([
            L1 * (2.0 * L1 - 1.0),
            L2 * (2.0 * L2 - 1.0),
            L3 * (2.0 * L3 - 1.0),
            4.0 * L1 * L2,
            4.0 * L2 * L3,
            4.0 * L3 * L1,
        ])
        dL = np.array([[-1.0, -1.0], [1.0, 0.0], [0.0, 1.0]])
        dN = np.empty((6, 2))
        dN[0] = (4.0 * L1 - 1.0) * dL[0]
        dN[1] = (4.0 * L2 - 1.0) * dL[1]
        dN[2] = (4.0 * L3 - 1.0) * dL[2]
        dN[3] = 4.0 * (L2 * dL[0] + L1 * dL[1])
        dN[4] = 4.0 * (L3 * dL[1] + L2 * dL[2])
        dN[5] = 4.0 * (L1 * dL[2] + L3 * dL[0])
        return N, dN

    @staticmethod
    def _parse_layer(layer_name: str) -> dict:
        return dict(DXFContourTransformer.parse_bc_layer_name(layer_name))

    @staticmethod
    def _plane_stress_matrix(E: float, nu: float) -> np.ndarray:
        c = E / (1.0 - nu * nu)
        return np.array([
            [c, c * nu, 0.0],
            [c * nu, c, 0.0],
            [0.0, 0.0, c * (1.0 - nu) / 2.0],
        ])

    @classmethod
    def _precompute_reference(cls, nodes, elements, thickness, n_gauss: int = 3):
        """回傳 dNdX: (Nel, Ngp, 6, 2) 與 dV0: (Nel, Ngp)。"""
        gps = cls._quadrature(n_gauss)
        Xe = nodes[elements]
        dNdX_list = []
        dV0_list = []
        for xi, eta, w in gps:
            _N, dN = cls._shape(xi, eta)
            J0 = np.einsum('eai,aj->eij', Xe, dN)
            detJ = J0[:, 0, 0] * J0[:, 1, 1] - J0[:, 0, 1] * J0[:, 1, 0]
            detJ = np.where(np.abs(detJ) < 1e-14, 1e-14, detJ)
            invJ = np.empty_like(J0)
            invJ[:, 0, 0] = J0[:, 1, 1] / detJ
            invJ[:, 0, 1] = -J0[:, 0, 1] / detJ
            invJ[:, 1, 0] = -J0[:, 1, 0] / detJ
            invJ[:, 1, 1] = J0[:, 0, 0] / detJ
            dNdX_list.append(np.einsum('ai,eij->eaj', dN, invJ))
            dV0_list.append(np.abs(detJ) * w * thickness)
        return np.stack(dNdX_list, axis=1), np.stack(dV0_list, axis=1)

    @classmethod
    def _kinematics(cls, u_e, dNdX, D):
        grad_u = np.einsum('eai,egaj->egij', u_e, dNdX)
        F = cls._EYE2 + grad_u
        detF = F[..., 0, 0] * F[..., 1, 1] - F[..., 0, 1] * F[..., 1, 0]
        FtF = np.einsum('egji,egjk->egik', F, F)
        E = np.stack([
            0.5 * (FtF[..., 0, 0] - 1.0),
            0.5 * (FtF[..., 1, 1] - 1.0),
            FtF[..., 0, 1],
        ], axis=2)
        S = np.einsum('egk,jk->egj', E, D)
        return F, detF, S

    @classmethod
    def _bmatrix(cls, F, dNdX):
        Nel = F.shape[0]
        ngp = F.shape[1]
        B = np.empty((Nel, ngp, 3, 12))
        for k in (0, 1):
            B[:, :, 0, k::2] = F[:, :, k, 0][:, :, None] * dNdX[:, :, :, 0]
            B[:, :, 1, k::2] = F[:, :, k, 1][:, :, None] * dNdX[:, :, :, 1]
            B[:, :, 2, k::2] = (
                F[:, :, k, 0][:, :, None] * dNdX[:, :, :, 1]
                + F[:, :, k, 1][:, :, None] * dNdX[:, :, :, 0]
            )
        return B

    @classmethod
    def _assemble_residual(cls, u_flat, elements, dNdX, dV0, D, dof_map, n_dof: int):
        u_e = u_flat.reshape(-1, 2)[elements]
        F, detF, S = cls._kinematics(u_e, dNdX, D)
        min_det = float(np.min(detF))
        B = cls._bmatrix(F, dNdX)
        f_int_e = np.einsum('eg,egja,egj->ea', dV0, B, S)
        f_int = np.bincount(dof_map.ravel(), weights=f_int_e.ravel(), minlength=n_dof)
        return f_int, min_det, F, S, B

    @classmethod
    def _assemble_tangent(cls, F, S, B, dNdX, dV0, D):
        DB_t = (B.swapaxes(-1, -2) @ D) * dV0[:, :, None, None]
        K_e = (DB_t @ B).sum(axis=1)
        S_dNdX = np.empty_like(dNdX)
        S_dNdX[..., 0] = (S[..., 0:1] * dNdX[..., 0] + S[..., 2:3] * dNdX[..., 1]) * dV0[..., None]
        S_dNdX[..., 1] = (S[..., 2:3] * dNdX[..., 0] + S[..., 1:2] * dNdX[..., 1]) * dV0[..., None]
        KG = (dNdX @ S_dNdX.swapaxes(-1, -2)).sum(axis=1)
        K_e[:, 0::2, 0::2] += KG
        K_e[:, 1::2, 1::2] += KG
        return K_e

    @classmethod
    def _min_det_f(cls, u_flat, elements, dNdX):
        u_e = u_flat.reshape(-1, 2)[elements]
        grad_u = np.einsum('eai,egaj->egij', u_e, dNdX)
        F = cls._EYE2 + grad_u
        detF = F[..., 0, 0] * F[..., 1, 1] - F[..., 0, 1] * F[..., 1, 0]
        return float(np.min(detF))

    @classmethod
    def _nodal_fields(cls, u_flat, nodes, elements, dNdX, dV0, D):
        n_nodes = len(nodes)
        u_e = u_flat.reshape(-1, 2)[elements]
        F, detF, S = cls._kinematics(u_e, dNdX, D)
        detF = np.where(np.abs(detF) < 1e-12, 1e-12, detF)
        S_mat = np.empty(F.shape)
        S_mat[..., 0, 0] = S[..., 0]
        S_mat[..., 1, 1] = S[..., 1]
        S_mat[..., 0, 1] = S[..., 2]
        S_mat[..., 1, 0] = S[..., 2]
        FS = np.einsum('egij,egjk->egik', F, S_mat)
        sig = np.einsum('egij,egkj->egik', FS, F) / detF[..., None, None]
        sig_v = np.stack([sig[..., 0, 0], sig[..., 1, 1], sig[..., 0, 1]], axis=2)
        w = dV0 / 6.0
        e_sig = np.einsum('eg,egk->ek', w, sig_v)
        e_F = np.einsum('eg,egij->eij', w, F).reshape(len(elements), 4)
        e_w = w.sum(axis=1)
        flat_ids = elements.ravel()
        acc_w = np.bincount(flat_ids, weights=np.repeat(e_w, 6), minlength=n_nodes)
        acc_sig = np.column_stack([
            np.bincount(flat_ids, weights=np.repeat(e_sig[:, k], 6), minlength=n_nodes)
            for k in range(3)
        ])
        acc_F = np.column_stack([
            np.bincount(flat_ids, weights=np.repeat(e_F[:, k], 6), minlength=n_nodes)
            for k in range(4)
        ]).reshape(n_nodes, 2, 2)
        acc_w = np.where(acc_w < 1e-30, 1e-30, acc_w)
        sig_node = acc_sig / acc_w[:, None]
        F_node = acc_F / acc_w[:, None, None]
        sxx, syy, sxy = sig_node[:, 0], sig_node[:, 1], sig_node[:, 2]
        von_mises = np.sqrt(np.maximum(sxx ** 2 - sxx * syy + syy ** 2 + 3.0 * sxy ** 2, 0.0))
        rot_deg = np.degrees(np.arctan2(F_node[:, 1, 0] - F_node[:, 0, 1], F_node[:, 0, 0] + F_node[:, 1, 1]))
        return von_mises, sig_node, rot_deg

    @staticmethod
    def _evaluate_probes(probes_dict, u, von_mises, sig, rot_deg):
        out = {}
        u2 = u.reshape(-1, 2)
        for pid, info in (probes_dict or {}).items():
            nid = int(info.get("node_id", -1))
            if nid < 0 or nid >= len(u2):
                continue
            dx = float(u2[nid, 0])
            dy = float(u2[nid, 1])
            out[pid] = {
                "probe_id": pid,
                "layer": info.get("layer"),
                "node_id": nid,
                "node_xy": info.get("node_xy"),
                "center_xy": info.get("center_xy"),
                "snap_dist": info.get("snap_dist"),
                "dx": dx,
                "dy": dy,
                "dxy": math.hypot(dx, dy),
                "disp_theta": math.degrees(math.atan2(dy, dx)),
                "stress": float(von_mises[nid]) if nid < len(von_mises) else 0.0,
                "sxx": float(sig[nid, 0]) if nid < len(sig) else 0.0,
                "syy": float(sig[nid, 1]) if nid < len(sig) else 0.0,
                "txy": float(sig[nid, 2]) if nid < len(sig) else 0.0,
                "rot_theta": float(rot_deg[nid]) if nid < len(rot_deg) else 0.0,
            }
        return out

    @classmethod
    def _build_bc(cls, mesh, nodes, hp):
        """BC 一律 1:1 真實物理量：DISP 的 x/y 直接是 mm，FORCE 的 x/y 直接是 gf（轉 N）。"""
        n_nodes = len(nodes)
        n_dof = 2 * n_nodes
        constrained = np.zeros(n_dof, dtype=bool)
        u_target = np.zeros(n_dof)
        f_ext = np.zeros(n_dof)
        layer_groups = {}
        for lay, info in (mesh.get("bc_groups") or {}).items():
            ids = np.asarray(info.get("node_ids", []), dtype=int)
            if len(ids) == 0:
                continue
            parsed = cls._parse_layer(lay)
            btype = parsed["type"]
            layer_groups[str(lay)] = (ids, parsed)
            if btype == "FIXED":
                constrained[2 * ids] = True
                constrained[2 * ids + 1] = True
            elif btype == "DISP":
                constrained[2 * ids] = True
                constrained[2 * ids + 1] = True
                u_target[2 * ids] = parsed["x"]
                u_target[2 * ids + 1] = parsed["y"]
            elif btype == "FORCE":
                edges = np.asarray(info.get("edges_t6", []), dtype=int)
                if edges.size == 0:
                    continue
                n0 = edges[:, 0]
                n1 = edges[:, 1]
                m01 = edges[:, 2]
                L = np.linalg.norm(nodes[n1] - nodes[n0], axis=1)
                L_total = max(float(L.sum()), 1e-12)
                force_n = np.array([parsed["x"], parsed["y"]], dtype=float) * GF_TO_N
                trac = force_n / L_total
                for nd, wt in ((n0, 1.0 / 6.0), (n1, 1.0 / 6.0), (m01, 4.0 / 6.0)):
                    np.add.at(f_ext, 2 * nd, wt * L * trac[0])
                    np.add.at(f_ext, 2 * nd + 1, wt * L * trac[1])
        return n_dof, constrained, u_target, f_ext, layer_groups

    @classmethod
    def solve(cls, mesh: dict, hp: SolverHyperParams = None) -> dict:
        if hp is None:
            hp = SolverHyperParams()
        t0 = time.perf_counter()
        nodes = np.asarray(mesh["nodes"], dtype=float)
        elements = np.asarray(mesh["elements"], dtype=int)
        n_dof, constrained, u_target, f_ext, groups = cls._build_bc(mesh, nodes, hp)
        attached = np.zeros(len(nodes), dtype=bool)
        attached[elements.ravel()] = True
        orphan = np.where(~attached)[0]
        if len(orphan):
            constrained[2 * orphan] = True
            constrained[2 * orphan + 1] = True
        free = np.where(~constrained)[0]
        E = float(hp.E_mpa)
        nu = float(hp.nu)
        if not (-0.95 < nu < 0.4999):
            nu = 0.3
        D = cls._plane_stress_matrix(E, nu)
        dof_map = (elements[:, :, None] * 2 + np.arange(2)[None, None, :]).reshape(len(elements), 12)
        dNdX, dV0 = cls._precompute_reference(nodes, elements, hp.thickness_mm, hp.n_gauss)
        n_free = len(free)
        free_idx_map = np.full(n_dof, -1, dtype=np.int32)
        free_idx_map[free] = np.arange(n_free, dtype=np.int32)
        rows_full = np.repeat(dof_map, 12, axis=1).ravel()
        cols_full = np.tile(dof_map, (1, 12)).ravel()
        r_free_idx = free_idx_map[rows_full]
        c_free_idx = free_idx_map[cols_full]
        mask_ff = (r_free_idx >= 0) & (c_free_idx >= 0)
        ff_rows = r_free_idx[mask_ff]
        ff_cols = c_free_idx[mask_ff]

        if n_free > 0:
            keys_1d = ff_cols.astype(np.int64) * np.int64(n_free) + ff_rows.astype(np.int64)
            uniq_keys, coo_to_csc_idx = np.unique(keys_1d, return_inverse=True)
            nnz = len(uniq_keys)
            csc_cols = (uniq_keys // np.int64(n_free)).astype(np.int32)
            csc_indices = (uniq_keys % np.int64(n_free)).astype(np.int32)
            csc_indptr = np.zeros(n_free + 1, dtype=np.int32)
            csc_indptr[1:] = np.cumsum(np.bincount(csc_cols, minlength=n_free))
            K_ff = csc_matrix((np.zeros(nnz, dtype=float), csc_indices, csc_indptr), shape=(n_free, n_free))
        else:
            coo_to_csc_idx = np.empty(0, dtype=np.int32)
            nnz = 0
            K_ff = None

        def _factorize_free(K_e_l):
            K_ff.data[:] = np.bincount(coo_to_csc_idx, weights=K_e_l.ravel()[mask_ff], minlength=nnz)
            try:
                return splu(K_ff, permc_spec="MMD_AT_PLUS_A", diag_pivot_thresh=0.01)
            except RuntimeError:
                return splu(K_ff, permc_spec="COLAMD")

        u = np.zeros(n_dof)
        lam = 0.0
        d_lam = 1.0 / max(1, int(hp.n_steps)) if hp.large_disp else 1.0
        d_lam_prev = 1.0
        du_prev = np.zeros(n_dof)
        step_history = []
        warning = None
        n_iter_total = 0
        has_probes = bool(mesh.get("probes"))
        lu_cached = None
        if hp.large_disp and n_free > 0:
            u_pre = np.zeros(n_dof)
            u_pre[constrained] = u_target[constrained]
            _f0, _md0, F0, S0, B0 = cls._assemble_residual(
                np.zeros(n_dof), elements, dNdX, dV0, D, dof_map, n_dof
            )
            K_e0 = cls._assemble_tangent(F0, S0, B0, dNdX, dV0, D)
            f_lin = np.bincount(
                dof_map.ravel(),
                weights=np.einsum('eab,eb->ea', K_e0, u_pre[dof_map]).ravel(),
                minlength=n_dof,
            )
            lu_cached = _factorize_free(K_e0)
            du_lin = lu_cached.solve(-(f_lin - f_ext)[free])
            du_prev = np.zeros(n_dof)
            du_prev[free] = du_lin
            du_prev[constrained] = u_target[constrained]
            d_lam_prev = 1.0
        while lam < 1.0 - 1e-12:
            lam_try = min(1.0, lam + d_lam)
            step_dl = lam_try - lam
            if d_lam_prev > 1e-12:
                u_try = u + (step_dl / d_lam_prev) * du_prev
            else:
                u_try = u.copy()
            u_try[constrained] = lam_try * u_target[constrained]
            if hp.large_disp and cls._min_det_f(u_try, elements, dNdX) <= 0.05:
                d_lam *= 0.5
                if d_lam < 1e-4:
                    warning = f"已達機構物理大變形極限 (lambda={lam:.3f})"
                    break
                continue
            converged = False
            it = 0
            prev_res_norm = float("inf")
            for it in range(max(1, int(hp.max_nr_iter))):
                n_iter_total += 1
                f_int, min_det, F_cur, S_cur, B_cur = cls._assemble_residual(
                    u_try, elements, dNdX, dV0, D, dof_map, n_dof
                )
                if min_det <= hp.min_det_f and it > 0:
                    break
                resid = f_int - lam_try * f_ext
                ref_scale = max(
                    float(np.linalg.norm(f_int)),
                    float(np.linalg.norm(lam_try * f_ext)),
                    1.0,
                )
                res_norm = float(np.linalg.norm(resid[free])) / ref_scale
                if res_norm < hp.tol_rel or n_free == 0:
                    converged = True
                    break
                if lu_cached is None or it == 0 or res_norm >= 0.20 * prev_res_norm:
                    K_e = cls._assemble_tangent(F_cur, S_cur, B_cur, dNdX, dV0, D)
                    lu_cached = _factorize_free(K_e)
                prev_res_norm = res_norm
                du = lu_cached.solve(-resid[free])
                if float(np.linalg.norm(du)) <= 1e-12 * max(float(np.linalg.norm(u_try)), 1.0):
                    converged = True
                    break
                alpha = 1.0
                accepted = False
                while alpha >= 1.0 / 32.0:
                    u_cand = u_try.copy()
                    u_cand[free] += alpha * du
                    if cls._min_det_f(u_cand, elements, dNdX) > 0.02:
                        u_try = u_cand
                        accepted = True
                        break
                    alpha *= 0.5
                if not accepted:
                    break
            if converged:
                du_prev = u_try - u
                d_lam_prev = step_dl
                u = u_try
                lam = lam_try
                if has_probes:
                    von_mises, sig, rot_deg = cls._nodal_fields(
                        u, nodes, elements, dNdX, dV0, D
                    )
                    probe_snap = cls._evaluate_probes(mesh.get("probes") or {}, u, von_mises, sig, rot_deg)
                else:
                    probe_snap = {}
                step_history.append({
                    "lambda": lam,
                    "probes": probe_snap,
                })
                if hp.large_disp and it <= 3:
                    d_lam = min(d_lam * 1.4, 0.25)
            else:
                lu_cached = None
                d_lam *= 0.5
                if d_lam < 1e-4:
                    warning = f"已達機構物理大變形極限 (lambda={lam:.3f})"
                    break
        von_mises, sig, rot_deg = cls._nodal_fields(u, nodes, elements, dNdX, dV0, D)
        probes = cls._evaluate_probes(mesh.get("probes") or {}, u, von_mises, sig, rot_deg)
        f_int, _min_det, _, _, _ = cls._assemble_residual(u, elements, dNdX, dV0, D, dof_map, n_dof)
        reactions = {}
        balance_vec = np.array([float(np.sum(f_ext[0::2])), float(np.sum(f_ext[1::2]))])
        for lay, (ids_raw, parsed) in groups.items():
            if parsed.get("type") not in ("FIXED", "DISP"):
                continue
            ids = np.unique(np.asarray(ids_raw, dtype=int))
            rx = float(np.sum(f_int[2 * ids]) - np.sum(f_ext[2 * ids]))
            ry = float(np.sum(f_int[2 * ids + 1]) - np.sum(f_ext[2 * ids + 1]))
            balance_vec += np.array([rx, ry])
            reactions[str(lay)] = {
                "rx_n": rx,
                "ry_n": ry,
                "r_n": math.hypot(rx, ry),
                "rx_gf": rx / GF_TO_N,
                "ry_gf": ry / GF_TO_N,
                "r_gf": math.hypot(rx, ry) / GF_TO_N,
                "n_nodes": int(len(ids)),
            }
        balance = float(np.linalg.norm(balance_vec))
        u2 = u.reshape(-1, 2)
        depth = {}
        for pid, pinfo in probes.items():
            hist = [
                {
                    "lambda": rec["lambda"],
                    "dx": rec["probes"][pid]["dx"],
                    "dy": rec["probes"][pid]["dy"],
                    "dxy": rec["probes"][pid]["dxy"],
                    "stress": rec["probes"][pid]["stress"],
                    "disp_theta": rec["probes"][pid]["disp_theta"],
                    "rot_theta": rec["probes"][pid]["rot_theta"],
                }
                for rec in step_history
                if pid in rec["probes"]
            ]
            pinfo["history"] = hist
            depth[pid] = pinfo
        vm_max = float(np.max(von_mises)) if len(von_mises) else 0.0
        return {
            "u": u2,
            "u_x": u2[:, 0],
            "u_y": u2[:, 1],
            "u_mag": np.hypot(u2[:, 0], u2[:, 1]),
            "disp_theta_deg": np.degrees(np.arctan2(u2[:, 1], u2[:, 0])),
            "rot_theta_deg": rot_deg,
            "von_mises": von_mises,
            "stress_tensor": sig,
            "probes": depth,
            "reactions": reactions,
            "converged_lambda": float(lam),
            "max_von_mises": vm_max,
            "safety_factor": (float(hp.yield_mpa) / vm_max) if vm_max > 1e-12 else float("inf"),
            "equilibrium_residual_n": balance,
            "n_dof": n_dof,
            "n_free": int(len(free)),
            "n_iter_total": n_iter_total,
            "step_history": step_history,
            "warning": warning,
            "hp": hp,
            "elapsed_ms": (time.perf_counter() - t0) * 1000.0,
        }

FiniteEleSolverHelper = FeaSolver
